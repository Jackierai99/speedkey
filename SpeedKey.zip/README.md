# MakimaOS
Open in Android Studio, or push to GitHub: Actions -> Build APK -> download the MakimaOS-apk artifact.
Settings -> paste any API key (Gemini / Grok / DeepSeek / OpenAI / Groq). Provider and model are detected automatically.
Enable the Accessibility Service for phone control.
Optional: add bg_listen.png / bg_speak.png (same layout as bg_main.png) to app/src/main/res/drawable-nodpi for real pose animations.

## v2.0
- AI agent: Makima now operates the phone herself (open apps, YouTube search + auto-play, tap, type, scroll, read screen, calls, alarms, settings...). Needs the Accessibility service ON.
- Floating subtitles under the bubble (what you said + her reply) while another app is open.
- Keys: paste one or many keys; auto provider detect; keys rotate on rate limit; retries and non-stream fallback when the connection drops.
- Home screen artwork no longer moves.

## v2.1 - animated Makima
- Home screen now has a live layered character (cut from the character sheet), standing in the centre:
  - blinks, breathes, braid sways, head moves slightly
  - LISTENING: head tilts toward you, soft smile, sound waves at her ear
  - THINKING: head tilts the other way, three dots
  - SPEAKING: mouth changes shape with the loudness of her real voice (lip-sync); with the phone's own voice it follows a natural talking rhythm
  - tap her to hear "Main yahin hoon"
- Sprites live in res/drawable-nodpi/rig_*.png. Positions are the constants at the top of HomeScreen.kt (spHead, spMouth, spEyes, ...).
- Buttons (chat, mic, voice, nav bar) are now real Compose widgets instead of being baked into the picture.

## v2.2 - clip-based body
- The character is now 14 short transparent animated clips (res/raw/mk_*.webp): idle, blink, listen, talk1-3, think_finger, think_chin, walk_left, walk_right, angry, happy, tease, sad.
- Listening -> listen, thinking -> think/walk clips, speaking -> talk clips, idle -> idle/blink. The AI can add {{mood:angry|happy|tease|sad}} at the start of a reply to play that emotion first.
- Every clip starts and ends in the same standing pose, so switching is a short cross-fade with no jump. minSdk is now 28 (animated WebP).
- Lips are not word-exact: the talk clips are pre-rendered speech motion.

## v2.3 - faster voice + real feelings
Faster replies
- AI voice clips are trimmed (the 0.3-0.6 s of dead air Gemini adds at the start and end is cut).
- First sentence is spoken sooner: it may end at a short pause (comma) and tiny openers like "Hmm." are spoken at once.
- Connection to the AI server is warmed up the moment the mic opens (no TLS handshake delay on the first reply).
- Settings -> Voice -> Reply speed: Fast (phone voice answers at once if the AI voice takes more than 1.5 s), Best quality, Phone voice (instant).
- Mic stops waiting sooner after you finish (1.1 s), and the extra wait is shorter for longer sentences. Default extra wait is now 0.6 s.
- Phone voice now picks the best installed voice and changes pitch / speed with her mood.

Real human feelings (new Feelings.kt)
- She has moods: happy, hurt/angry, sad, bored. Sweet words warm her up, rude words hurt her, "sorry" calms her. Moods fade with time. A bond level grows slowly the more you talk.
- If you stay silent (hands-free on): 45 s she checks on you, 100 s bored, 200 s annoyed, 6 min angry, 10 min she sulks and goes quiet. Lines are written by the AI, with offline fallbacks. Not between 11 pm and 7 am.
- She greets you when you come back after hours or days, and remembers if she is still angry.
- Voice follows the feeling (Gemini / OpenAI voice gets an emotion instruction; phone voice changes pitch and speed). The body clip follows too.
- AI talks like a person: fillers, short sentences, reacts first and answers second, late-night caring mode.
- New silent tags: {{mood:angry|happy|tease|sad|bored}} and {{remember:fact}} (saved to Memory automatically).
- Settings -> Feelings: turn Human mode and "speak up when quiet" on or off.
