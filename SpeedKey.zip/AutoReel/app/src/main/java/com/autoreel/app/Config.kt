package com.autoreel.app

// Paste your Google OAuth "Desktop app" client here ONCE, then rebuild. Users of the app never see this.
object Config {
    const val CLIENT_ID = ""
    const val CLIENT_SECRET = ""
}
