package com.autoreel.app

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

object Share {
    fun intent(c: Context): Intent? {
        val p = c.p(); val f = File(p.getString("last_video", null) ?: return null)
        if (!f.exists()) return null
        val uri = FileProvider.getUriForFile(c, "com.autoreel.app.fp", f)
        return Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"; putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, p.getString("last_title", "")); putExtra(Intent.EXTRA_TITLE, p.getString("last_title", "")); putExtra(Intent.EXTRA_TEXT, p.getString("last_desc", ""))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    fun toYouTube(a: Activity) {
        val i = intent(a) ?: run { Toast.makeText(a, "Make a video first (RUN NOW)", Toast.LENGTH_SHORT).show(); return }
        val p = a.p()
        (a.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("yt", p.getString("last_title", "") + "\n\n" + p.getString("last_desc", "")))
        Toast.makeText(a, "Title + hashtags copied. Paste them in YouTube.", Toast.LENGTH_LONG).show()
        try { a.startActivity(Intent(i).setPackage("com.google.android.youtube")) }
        catch (e: Exception) { a.startActivity(Intent.createChooser(i, "Upload via")) }
    }

    fun notify(c: Context) {
        val i = intent(c)?.setPackage("com.google.android.youtube") ?: return
        val pi = PendingIntent.getActivity(c, 2, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ar_done", "AutoReel done", NotificationManager.IMPORTANCE_HIGH))
        nm.notify(2, Notification.Builder(c, "ar_done").setContentTitle("Video ready ✅").setContentText("Tap to upload on YouTube")
            .setSmallIcon(android.R.drawable.stat_sys_upload_done).setContentIntent(pi).setAutoCancel(true).build())
    }
}
