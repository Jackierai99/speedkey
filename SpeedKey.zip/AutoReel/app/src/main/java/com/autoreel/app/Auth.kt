package com.autoreel.app

import android.app.Activity
import android.content.Context
import android.net.Uri
import androidx.browser.customtabs.CustomTabsIntent
import org.json.JSONObject
import java.net.InetAddress
import java.net.ServerSocket
import java.net.URLDecoder
import java.net.URLEncoder

object Auth {
    private const val TOKEN = "https://oauth2.googleapis.com/token"
    private const val SCOPE = "https://www.googleapis.com/auth/youtube.upload https://www.googleapis.com/auth/youtube.readonly"
    private val H = mapOf("Content-Type" to "application/x-www-form-urlencoded")
    private fun form(vararg kv: Pair<String, String>) = kv.joinToString("&") { it.first + "=" + URLEncoder.encode(it.second, "UTF-8") }
    private const val PAGE = "<html><body style='background:#0B0614;color:#fff;font-family:sans-serif;text-align:center;padding:60px 20px'><h2>Login successful</h2><p>Go back to AutoReel</p><a href='autoreel://done' style='display:inline-block;background:#8B3DFF;color:#fff;padding:18px 36px;border-radius:14px;text-decoration:none;font-size:20px'>Open AutoReel</a><script>setTimeout(function(){location.href='autoreel://done'},500)</script></body></html>"

    fun login(a: Activity) {
        val p = a.p()
        val id = p.getString("yt_client_id", "")!!.trim(); val sec = p.getString("yt_client_secret", "")!!.trim()
        if (id.isEmpty() || sec.isEmpty()) { Pipeline.log(a, "Settings: add Google client ID + secret first (one time)"); return }
        Thread {
            try {
                val ss = ServerSocket(0, 1, InetAddress.getByName("127.0.0.1")); ss.soTimeout = 300000
                val redirect = "http://127.0.0.1:${ss.localPort}"
                val url = "https://accounts.google.com/o/oauth2/v2/auth?" + form("client_id" to id, "redirect_uri" to redirect,
                    "response_type" to "code", "scope" to SCOPE, "access_type" to "offline", "prompt" to "consent")
                a.runOnUiThread { CustomTabsIntent.Builder().build().launchUrl(a, Uri.parse(url)) }
                val s = ss.accept()
                val line = s.getInputStream().bufferedReader().readLine() ?: ""
                val q = line.split(" ").getOrElse(1) { "" }.substringAfter("?", "")
                val code = q.split("&").map { it.split("=") }.firstOrNull { it[0] == "code" }?.getOrNull(1)?.let { URLDecoder.decode(it, "UTF-8") }
                s.getOutputStream().write(("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nConnection: close\r\n\r\n" + PAGE).toByteArray())
                s.close(); ss.close()
                if (code == null) { Pipeline.log(a, "Login cancelled"); return@Thread }
                val t = JSONObject(Net.req(TOKEN, "POST", H, form("code" to code, "client_id" to id, "client_secret" to sec,
                    "redirect_uri" to redirect, "grant_type" to "authorization_code").toByteArray()).text())
                if (t.has("refresh_token")) { p.edit().putString("yt_refresh", t.getString("refresh_token")).apply(); Pipeline.log(a, "YouTube connected") }
                else Pipeline.log(a, "Login failed: " + t.toString().take(150))
            } catch (e: Exception) { Pipeline.log(a, "Login error: " + e.message) }
        }.start()
    }

    fun token(c: Context): String? {
        val p = c.p(); val r = p.getString("yt_refresh", "")!!
        if (r.isEmpty()) return null
        val t = JSONObject(Net.req(TOKEN, "POST", H, form("client_id" to p.getString("yt_client_id", "")!!.trim(),
            "client_secret" to p.getString("yt_client_secret", "")!!.trim(), "refresh_token" to r, "grant_type" to "refresh_token").toByteArray()).text())
        return t.optString("access_token").ifEmpty { null }
    }
}
