package com.autoreel.app

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import org.json.JSONObject
import java.net.URLEncoder

object Auth {
    private val H = mapOf("Content-Type" to "application/x-www-form-urlencoded")
    private fun form(vararg kv: Pair<String, String>) =
        kv.joinToString("&") { it.first + "=" + URLEncoder.encode(it.second, "UTF-8") }.toByteArray()

    fun login(a: Activity) {
        val p = a.p()
        val id = p.getString("yt_client_id", "")!!.trim()
        val sec = p.getString("yt_client_secret", "")!!.trim()
        if (id.isEmpty() || sec.isEmpty()) { Pipeline.log(a, "Enter YouTube client ID and secret first"); return }
        Thread {
            try {
                val d = JSONObject(Net.req("https://oauth2.googleapis.com/device/code", "POST", H,
                    form("client_id" to id, "scope" to "https://www.googleapis.com/auth/youtube.upload")).text())
                val code = d.getString("user_code")
                a.runOnUiThread {
                    (a.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("code", code))
                    a.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(d.getString("verification_url"))))
                }
                Pipeline.log(a, "Google login: enter code $code (already copied, just paste)")
                var wait = d.optInt("interval", 5)
                val end = System.currentTimeMillis() + d.optInt("expires_in", 1800) * 1000L
                while (System.currentTimeMillis() < end) {
                    Thread.sleep(wait * 1000L)
                    val t = JSONObject(Net.req("https://oauth2.googleapis.com/token", "POST", H,
                        form("client_id" to id, "client_secret" to sec, "device_code" to d.getString("device_code"),
                            "grant_type" to "urn:ietf:params:oauth:grant-type:device_code")).text())
                    if (t.has("refresh_token")) {
                        p.edit().putString("yt_refresh", t.getString("refresh_token")).apply()
                        Pipeline.log(a, "YouTube connected. Now turn on Auto-upload."); return@Thread
                    }
                    when (t.optString("error")) {
                        "authorization_pending" -> {}
                        "slow_down" -> wait += 5
                        else -> { Pipeline.log(a, "Login failed: " + t.toString().take(150)); return@Thread }
                    }
                }
                Pipeline.log(a, "Login timed out, press the button again")
            } catch (e: Exception) { Pipeline.log(a, "Login error: " + e.message) }
        }.start()
    }
}
