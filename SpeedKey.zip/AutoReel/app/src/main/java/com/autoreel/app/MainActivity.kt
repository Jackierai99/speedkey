package com.autoreel.app

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.work.*
import java.io.File
import java.util.concurrent.TimeUnit

fun Context.p() = getSharedPreferences("ar", 0)
fun Context.dp(i: Int) = (i * resources.displayMetrics.density).toInt()
val BG = Color.parseColor("#0B0614"); val CARD = Color.parseColor("#161028"); val EDGE = Color.parseColor("#668B3DFF")
val PINK = Color.parseColor("#E040FB"); val DIM = Color.parseColor("#A99BC8"); val GREEN = Color.parseColor("#4ADE80")
fun shape(c: Int, r: Int, stroke: Int = 0) = GradientDrawable().apply { setColor(c); cornerRadius = r.toFloat(); if (stroke != 0) setStroke(3, stroke) }
fun lp(w: Int, h: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, h, wt)

class F(val key: String, val label: String, val def: String, val kind: String = "t")
val SECTIONS = listOf(
    "Video" to listOf(F("niche", "Niche / topic (e.g. funny animals)", ""), F("language", "Language", "Hindi"), F("per_day", "Videos per day", "3"),
        F("aspect", "Aspect ratio (9:16 or 16:9)", "9:16"), F("seconds", "Seconds (4 / 6 / 8)", "8"), F("style", "Extra style notes", ""),
        F("best_veo", "Best-quality Veo (costs more)", "false", "b")),
    "YouTube" to listOf(F("privacy", "Privacy (public / private / unlisted)", "private"), F("upload", "Auto-upload to YouTube", "false", "b")),
    "Gemini" to listOf(F("gemini_key", "Gemini API key", "", "p")),
    "Advanced (only if not set in Config.kt)" to listOf(F("yt_client_id", "Google client ID (Desktop app type)", ""), F("yt_client_secret", "Google client secret", "", "p")),
)

class MainActivity : Activity() {
    private val views = HashMap<String, View>()
    private lateinit var studio: ScrollView; private lateinit var settings: ScrollView
    private lateinit var video: VideoView; private lateinit var hint: TextView; private lateinit var info: TextView
    private lateinit var logV: TextView; private lateinit var loginState: TextView
    private val steps = ArrayList<TextView>(); private var shown: String? = null
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable { override fun run() { refresh(); h.postDelayed(this, 1000) } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG; window.navigationBarColor = BG
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        studio = ScrollView(this).apply { addView(buildStudio()) }
        settings = ScrollView(this).apply { addView(buildSettings()); visibility = View.GONE }
        val frame = FrameLayout(this).apply { addView(studio); addView(settings) }
        val bar = LinearLayout(this).apply { setBackgroundColor(CARD); setPadding(0, dp(12), 0, dp(12)) }
        fun tab(t: String, s: Boolean) = TextView(this).apply {
            text = t; gravity = Gravity.CENTER; textSize = 15f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            setOnClickListener { save(); studio.visibility = if (s) View.VISIBLE else View.GONE; settings.visibility = if (s) View.GONE else View.VISIBLE }
        }
        bar.addView(tab("🎬  STUDIO", true), lp(0, -2, 1f)); bar.addView(tab("⚙️  SETTINGS", false), lp(0, -2, 1f))
        setContentView(LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG); addView(frame, lp(-1, 0, 1f)); addView(bar) })
    }

    private fun card() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)); background = shape(CARD, dp(18), EDGE) }
    private fun LinearLayout.add(v: View, w: Int = -1, hh: Int = -2, wt: Float = 0f) = addView(v, lp(w, hh, wt).apply { setMargins(dp(4), dp(6), dp(4), dp(6)) })
    private fun txt(t: String, sz: Float = 14f, c: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply { text = t; textSize = sz; setTextColor(c); if (bold) typeface = Typeface.DEFAULT_BOLD }
    private fun btn(t: String, c: Int, a: () -> Unit) = txt(t, 15f, Color.WHITE, true).apply {
        gravity = Gravity.CENTER; setPadding(0, dp(14), 0, dp(14)); background = shape(c, dp(14)); setOnClickListener { save(); a() }
    }

    private fun buildStudio(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(36), dp(12), dp(12)) }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(ImageView(this).apply { setImageResource(R.drawable.logo); scaleType = ImageView.ScaleType.CENTER_CROP; clipToOutline = true; outlineProvider = object : android.view.ViewOutlineProvider() { override fun getOutline(v: View, o: android.graphics.Outline) { o.setOval(0, 0, v.width, v.height) } } }, lp(dp(64), dp(64)))
        val tt = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        tt.addView(txt("AutoReel", 28f, Color.WHITE, true)); tt.addView(txt("Idea → Prompt → Video → Upload", 12f, DIM))
        head.addView(tt); col.addView(head)
        val row = LinearLayout(this)
        for (n in listOf("🔎 Research", "🧠 Idea", "🎬 Veo", "🚀 Upload")) { val s = txt(n, 11f, DIM, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(8)) }; steps.add(s); row.add(s, 0, -2, 1f) }
        col.add(row)
        val vc = card(); val fl = FrameLayout(this)
        video = VideoView(this); fl.addView(video, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        hint = txt("Your video appears here live", 14f, DIM).apply { gravity = Gravity.CENTER }; fl.addView(hint, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        vc.addView(fl, lp(-1, dp(430))); col.add(vc)
        info = txt("", 13f); val ic = card(); ic.addView(info); col.add(ic)
        val r2 = LinearLayout(this)
        r2.add(btn("▶ START AUTO", Color.parseColor("#8B3DFF")) { start() }, 0, -2, 1f)
        r2.add(btn("⚡ RUN NOW", Color.parseColor("#C026D3")) { WorkManager.getInstance(this).enqueue(OneTimeWorkRequestBuilder<RunWorker>().build()); Toast.makeText(this, "Started, watch the Studio", Toast.LENGTH_SHORT).show() }, 0, -2, 1f)
        col.add(r2)
        col.add(btn("■ STOP", Color.parseColor("#3B2A5C")) { WorkManager.getInstance(this).cancelUniqueWork("auto"); Toast.makeText(this, "Stopped", Toast.LENGTH_SHORT).show() })
        val yt = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(12)); background = shape(Color.WHITE, dp(14)); setOnClickListener { save(); Auth.login(this@MainActivity) } }
        yt.addView(ImageView(this).apply { setImageResource(R.drawable.ic_yt) }, lp(dp(40), dp(28)))
        yt.addView(txt("  Login with YouTube", 16f, Color.parseColor("#111111"), true))
        col.add(yt); loginState = txt("", 12f, DIM).apply { gravity = Gravity.CENTER }; col.add(loginState)
        col.add(btn("🔋 Allow background running", Color.parseColor("#2A1F44")) { startActivity(android.content.Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, android.net.Uri.parse("package:$packageName"))) })
        logV = txt("", 11f, DIM).apply { typeface = Typeface.MONOSPACE }; val lc = card(); lc.addView(logV); col.add(lc)
        return col
    }

    private fun buildSettings(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(36), dp(12), dp(12)) }
        col.addView(txt("Settings", 26f, Color.WHITE, true))
        for ((title, fields) in SECTIONS) {
            val c = card(); c.addView(txt(title.uppercase(), 12f, PINK, true))
            for (f in fields) {
                val saved = p().getString(f.key, f.def)!!
                if (f.kind == "b") c.add(CheckBox(this).apply { text = f.label; setTextColor(Color.WHITE); isChecked = saved == "true"; views[f.key] = this })
                else {
                    c.add(txt(f.label, 12f, DIM))
                    c.add(EditText(this).apply {
                        setText(saved); setSingleLine(); setTextColor(Color.WHITE); setPadding(dp(12), dp(10), dp(12), dp(10)); background = shape(BG, dp(10), EDGE)
                        if (f.kind == "p") inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                        views[f.key] = this
                    })
                }
            }
            if (title == "Gemini") c.add(btn("🔑 TEST KEY", Color.parseColor("#8B3DFF")) { testKey((views["gemini_key"] as EditText).text.toString().trim()) })
            col.add(c)
        }
        col.add(txt("Gemini and Veo models are picked automatically (latest best).", 12f, DIM))
        return col
    }

    private fun testKey(k: String) {
        if (k.isEmpty()) { Toast.makeText(this, "Paste your Gemini key first", Toast.LENGTH_SHORT).show(); return }
        Toast.makeText(this, "Testing key...", Toast.LENGTH_SHORT).show()
        Thread {
            val msg = try {
                val r = Net.req("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200", "GET", mapOf("x-goog-api-key" to k))
                if (r.code == 200) "✅ Key works\nGemini: ${Models.pick(k, false, true)}\nVeo: ${Models.pick(k, true, false)}\n(Making Veo videos needs billing on the API)"
                else "❌ Key rejected (${r.code})\n" + r.text().take(150)
            } catch (e: Exception) { "❌ No internet or error: " + e.message }
            runOnUiThread { android.app.AlertDialog.Builder(this).setMessage(msg).setPositiveButton("OK", null).show() }
        }.start()
    }

    private fun save() { val e = p().edit(); for ((k, v) in views) e.putString(k, if (v is CheckBox) v.isChecked.toString() else (v as EditText).text.toString().trim()); e.apply() }

    private fun start() {
        val n = (p().getString("per_day", "3")?.toIntOrNull() ?: 3).coerceIn(1, 24)
        val req = PeriodicWorkRequestBuilder<RunWorker>(maxOf(15L, 24 * 60L / n), TimeUnit.MINUTES).setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("auto", ExistingPeriodicWorkPolicy.UPDATE, req)
        Toast.makeText(this, "Running $n videos/day in background", Toast.LENGTH_SHORT).show()
    }

    private fun refresh() {
        for (i in steps.indices) { val on = Live.stage == i + 1; val done = Live.stage > i + 1
            steps[i].setTextColor(if (on) PINK else if (done) GREEN else DIM); steps[i].background = if (on) shape(CARD, dp(10), PINK) else null }
        if (Live.info.isNotEmpty()) info.text = Live.info else if (info.text.isEmpty()) info.text = "Press RUN NOW to see AutoReel work live."
        logV.text = p().getString("log", "")
        loginState.text = if (p().getString("yt_refresh", "")!!.isNotEmpty()) "✅ YouTube connected" else "Not connected"
        val v = Live.video ?: p().getString("last_video", null)
        if (v != null && v != shown && File(v).exists()) { shown = v; hint.visibility = View.GONE; video.setVideoPath(v); video.setOnPreparedListener { it.isLooping = true; video.start() } }
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick); save() }
}
