package com.autoreel.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.*
import androidx.work.*
import java.util.concurrent.TimeUnit

fun Context.p() = getSharedPreferences("ar", 0)

val FIELDS = listOf(
    Triple("gemini_key", "Gemini API key", ""),
    Triple("text_model", "Gemini text model", "gemini-2.5-flash"),
    Triple("veo_model", "Veo model", "veo-3.1-fast-generate-preview"),
    Triple("niche", "Niche / topic (e.g. funny animals, space facts)", ""),
    Triple("language", "Video language", "Hindi"),
    Triple("region", "Region code for viral research", "IN"),
    Triple("per_day", "Videos per day", "3"),
    Triple("aspect", "Aspect ratio (9:16 or 16:9)", "9:16"),
    Triple("seconds", "Video seconds (4 / 6 / 8)", "8"),
    Triple("style", "Extra style notes (optional)", ""),
    Triple("yt_key", "YouTube Data API key (viral research)", ""),
    Triple("yt_client_id", "YouTube OAuth client ID", ""),
    Triple("yt_client_secret", "YouTube OAuth client secret", ""),
    Triple("privacy", "YouTube privacy (public / private / unlisted)", "private"),
    Triple("upload", "Auto-upload to YouTube", "false"),
)

class MainActivity : Activity() {
    private val views = HashMap<String, View>()
    private lateinit var logView: TextView
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { logView.text = p().getString("log", "No activity yet"); h.postDelayed(this, 3000) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 32, 32, 32) }
        val logo = ImageView(this).apply { setImageResource(R.drawable.logo); layoutParams = LinearLayout.LayoutParams(400, 400).apply { gravity = android.view.Gravity.CENTER } }
        root.addView(logo)
        for ((k, label, def) in FIELDS) {
            root.addView(TextView(this).apply { text = label; setPadding(0, 24, 0, 0) })
            val saved = p().getString(k, def)!!
            if (def == "true" || def == "false") {
                root.addView(CheckBox(this).apply { isChecked = saved == "true"; views[k] = this })
            } else {
                root.addView(EditText(this).apply { setText(saved); setSingleLine(); views[k] = this })
            }
        }
        fun btn(t: String, a: () -> Unit) = Button(this).apply { text = t; setOnClickListener { save(); a() } }
        root.addView(btn("START (auto schedule)") { start() })
        root.addView(btn("LOGIN WITH GOOGLE (YouTube)") { Auth.login(this) })
        root.addView(btn("RUN ONE VIDEO NOW") {
            WorkManager.getInstance(this).enqueue(OneTimeWorkRequestBuilder<RunWorker>().build())
            toast("Started in background")
        })
        root.addView(btn("STOP") { WorkManager.getInstance(this).cancelUniqueWork("auto"); toast("Stopped") })
        root.addView(btn("Allow unrestricted background") {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        })
        logView = TextView(this).apply { setPadding(0, 32, 0, 0) }
        root.addView(logView)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun save() {
        val e = p().edit()
        for ((k, v) in views) e.putString(k, if (v is CheckBox) v.isChecked.toString() else (v as EditText).text.toString().trim())
        e.apply()
    }

    private fun start() {
        val n = (p().getString("per_day", "3")?.toIntOrNull() ?: 3).coerceIn(1, 24)
        val mins = maxOf(15L, 24 * 60L / n)
        val req = PeriodicWorkRequestBuilder<RunWorker>(mins, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("auto", ExistingPeriodicWorkPolicy.UPDATE, req)
        toast("Running $n videos/day in background")
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick); save() }
}
