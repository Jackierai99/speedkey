package com.autoreel.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class RunWorker(private val c: Context, wp: WorkerParameters) : CoroutineWorker(c, wp) {
    override suspend fun doWork(): Result {
        c.getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("ar", "AutoReel", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(c, "ar").setContentTitle("AutoReel is making a video").setSmallIcon(android.R.drawable.stat_sys_upload).build()
        try { setForeground(ForegroundInfo(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)) } catch (_: Exception) {}
        try { Pipeline.run(c) } catch (e: Exception) { Pipeline.log(c, "ERROR: " + e.message); Live.stage = 0 }
        return Result.success()
    }
}

class Resp(val code: Int, val body: ByteArray, val loc: String?) { fun text() = String(body) }

object Live { @Volatile var stage = 0; @Volatile var info = ""; @Volatile var video: String? = null; @Volatile var startedAt = 0L; @Volatile var newVideo = false }

object Net {
    fun req(url: String, method: String = "GET", headers: Map<String, String> = emptyMap(), body: ByteArray? = null): Resp {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method; c.connectTimeout = 30000; c.readTimeout = 600000
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        if (body != null) { c.doOutput = true; c.setFixedLengthStreamingMode(body.size); c.outputStream.use { it.write(body) } }
        val code = c.responseCode
        return Resp(code, (if (code < 400) c.inputStream else c.errorStream)?.readBytes() ?: ByteArray(0), c.getHeaderField("Location"))
    }
}

object Models {
    private const val GL = "https://generativelanguage.googleapis.com/v1beta"
    private val skip = listOf("tts", "image", "live", "embedding", "audio", "robotics", "computer", "vision", "lite", "exp")
    fun pick(key: String, veo: Boolean, best: Boolean): String? = try {
        val arr = JSONObject(Net.req("$GL/models?pageSize=200", "GET", mapOf("x-goog-api-key" to key)).text()).getJSONArray("models")
        var out: String? = null; var top = -1.0
        for (i in 0 until arr.length()) {
            val m = arr.getJSONObject(i); val n = m.getString("name").removePrefix("models/")
            val meth = m.optJSONArray("supportedGenerationMethods")?.toString() ?: ""
            if (veo) { if (!n.startsWith("veo") || !meth.contains("predictLongRunning")) continue }
            else { if (!n.startsWith("gemini-") || !meth.contains("generateContent") || skip.any { n.contains(it) }) continue }
            val v = Regex("\\d+(\\.\\d+)?").find(n)?.value?.toDouble() ?: 0.0
            val bonus = if (veo) (if (n.contains("fast") == !best) 1.0 else 0.0) else (if (n.contains("pro")) 1.0 else 0.0)
            if (v * 10 + bonus > top) { top = v * 10 + bonus; out = n }
        }
        out
    } catch (e: Exception) { null }
}

object Pipeline {
    private const val GL = "https://generativelanguage.googleapis.com/v1beta"
    fun log(c: Context, m: String) {
        val p = c.p(); val old = p.getString("log", "")!!.lines().takeLast(30)
        p.edit().putString("log", (old + m).joinToString("\n")).apply()
    }

    fun run(c: Context) {
        val p = c.p(); fun g(k: String) = p.getString(k, "")!!.trim()
        val gk = g("gemini_key")
        if (gk.isEmpty()) { log(c, "Add Gemini API key in Settings"); return }
        val hdr = mapOf("x-goog-api-key" to gk, "Content-Type" to "application/json")
        Live.startedAt = System.currentTimeMillis(); Live.stage = 1; Live.info = ""

        val niche = g("niche").ifEmpty { "any trending topic" }
        val tm = Models.pick(gk, false, true) ?: "gemini-2.5-flash"; log(c, "Gemini model: $tm")
        val prompt = """You are a viral short-video strategist. Language: ${g("language")}. Niche: $niche. Style notes: ${g("style")}.
Step 1: use Google Search to find videos going viral right now in this niche on YouTube.
Step 2: briefly analyze why they went viral (hook, emotion, pacing).
Step 3: invent ONE completely NEW original idea with the same viral principles. Never copy them.
Reply with ONLY a JSON object: {"analysis":"...","veo_prompt":"detailed cinematic ${g("seconds")} second prompt with camera, lighting, sound and one spoken line","title":"catchy, under 80 chars","description":"2-3 lines plus a call to action","hashtags":["#tag1","#tag2"]}"""
        fun ask(search: Boolean): Resp {
            val b = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            if (search) b.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
            else b.put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
            return Net.req("$GL/models/$tm:generateContent", "POST", hdr, b.toString().toByteArray())
        }
        Live.stage = 2
        var tr = ask(true)
        if (tr.code >= 400) tr = ask(false)
        if (tr.code >= 400) { log(c, "Gemini error ${tr.code}: " + tr.text().take(200)); Live.stage = 0; return }
        val raw = JSONObject(tr.text()).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        val idea = JSONObject(raw.substring(raw.indexOf('{'), raw.lastIndexOf('}') + 1))
        val tags = idea.getJSONArray("hashtags"); val tagLine = (0 until tags.length()).joinToString(" ") { tags.getString(it) }
        Live.info = "🎬 " + idea.getString("title") + "\n\n🧠 " + idea.getString("analysis") + "\n\n" + tagLine
        p.edit().putString("last_title", idea.getString("title") + if (g("aspect") == "9:16") " #Shorts" else "").putString("last_desc", idea.getString("description") + "\n\n" + tagLine).apply()
        log(c, "Idea: " + idea.getString("title"))

        Live.stage = 3
        val vm = Models.pick(gk, true, g("best_veo") == "true") ?: "veo-3.1-fast-generate-preview"; log(c, "Veo model: $vm (a few minutes)")
        val vb = JSONObject().put("instances", JSONArray().put(JSONObject().put("prompt", idea.getString("veo_prompt"))))
            .put("parameters", JSONObject().put("aspectRatio", g("aspect")).put("durationSeconds", g("seconds").toIntOrNull() ?: 8))
        val vr = Net.req("$GL/models/$vm:predictLongRunning", "POST", hdr, vb.toString().toByteArray())
        if (vr.code >= 400) { log(c, "Veo error ${vr.code}: " + vr.text().take(200) + " (Veo needs API billing)"); Live.stage = 0; return }
        val op = JSONObject(vr.text()).getString("name")
        var uri: String? = null
        repeat(120) {
            if (uri != null) return@repeat
            Thread.sleep(10000)
            val o = JSONObject(Net.req("$GL/$op", "GET", hdr).text())
            if (o.optBoolean("done")) {
                uri = o.optJSONObject("response")?.optJSONObject("generateVideoResponse")?.optJSONArray("generatedSamples")?.optJSONObject(0)?.optJSONObject("video")?.optString("uri")
                if (uri == null) { log(c, "Video blocked or failed: " + o.toString().take(200)); Live.stage = 0; return }
            }
        }
        val u = uri ?: run { log(c, "Veo timed out"); Live.stage = 0; return }
        val dl = Net.req(u, "GET", mapOf("x-goog-api-key" to gk))
        if (dl.code != 200 || dl.body.size < 20000) { log(c, "Download failed ${dl.code}: " + dl.text().take(150)); Live.stage = 0; return }
        val file = File(c.filesDir, "v_${System.currentTimeMillis()}.mp4"); file.writeBytes(dl.body)
        c.filesDir.listFiles { f -> f.name.startsWith("v_") }?.sortedBy { it.lastModified() }?.dropLast(3)?.forEach { it.delete() }
        p.edit().putString("last_video", file.absolutePath).apply(); Live.video = file.absolutePath
        log(c, "Video ready (${file.length() / 1024} KB). YouTube opens for upload.")
        Live.stage = 4; Live.newVideo = true; Share.notify(c)
    }
}
