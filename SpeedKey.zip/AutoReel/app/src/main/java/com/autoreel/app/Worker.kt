package com.autoreel.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import android.app.Notification
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class RunWorker(private val c: Context, wp: WorkerParameters) : CoroutineWorker(c, wp) {
    override suspend fun doWork(): Result {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ar", "AutoReel", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(c, "ar").setContentTitle("AutoReel is making a video").setSmallIcon(android.R.drawable.stat_sys_upload).build()
        try { setForeground(ForegroundInfo(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)) } catch (_: Exception) {}
        try { Pipeline.run(c) } catch (e: Exception) { Pipeline.log(c, "ERROR: " + e.message) }
        return Result.success()
    }
}

class Resp(val code: Int, val body: ByteArray, val loc: String?) { fun text() = String(body) }

object Net {
    fun req(url: String, method: String = "GET", headers: Map<String, String> = emptyMap(), body: ByteArray? = null): Resp {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method; c.connectTimeout = 30000; c.readTimeout = 600000
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        if (body != null) { c.doOutput = true; c.setFixedLengthStreamingMode(body.size); c.outputStream.use { it.write(body) } }
        val code = c.responseCode
        val s = if (code < 400) c.inputStream else c.errorStream
        return Resp(code, s?.readBytes() ?: ByteArray(0), c.getHeaderField("Location"))
    }
}

object Pipeline {
    private const val GL = "https://generativelanguage.googleapis.com/v1beta"
    fun log(c: Context, m: String) {
        val p = c.p()
        val old = p.getString("log", "")!!.lines().takeLast(40)
        p.edit().putString("log", (old + m).joinToString("\n")).apply()
    }

    fun run(c: Context) {
        val p = c.p()
        fun g(k: String) = p.getString(k, "")!!.trim()
        val gk = g("gemini_key")
        if (gk.isEmpty()) { log(c, "Add your Gemini API key first"); return }
        val hdr = mapOf("x-goog-api-key" to gk, "Content-Type" to "application/json")

        // 1) Research viral videos
        var research = "(no research data)"
        if (g("yt_key").isNotEmpty()) try {
            log(c, "Researching viral videos...")
            val after = URLEncoder.encode(java.time.Instant.now().minus(java.time.Duration.ofDays(14)).toString(), "UTF-8")
            val q = URLEncoder.encode(g("niche") + " shorts", "UTF-8")
            val r = Net.req("https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&order=viewCount&maxResults=8&q=$q&publishedAfter=$after&regionCode=${g("region")}&key=${g("yt_key")}")
            val items = JSONObject(r.text()).getJSONArray("items")
            research = (0 until items.length()).joinToString("\n") {
                val s = items.getJSONObject(it).getJSONObject("snippet")
                "- " + s.getString("title") + ": " + s.getString("description").take(150)
            }
        } catch (e: Exception) { log(c, "Research failed: " + e.message) }

        // 2) Gemini: analysis + new idea + Veo prompt + title + hashtags
        log(c, "Gemini is writing the idea...")
        val prompt = """You are a viral short-video strategist. Language: ${g("language")}. Niche: ${g("niche")}. Style notes: ${g("style")}.
Recent top videos in this niche:
$research
Briefly analyze why they went viral (hook, emotion, pacing). Then invent ONE completely NEW, original video idea using the same viral principles. Never copy them.
Return JSON only: {"analysis":"...","veo_prompt":"detailed cinematic ${g("seconds")} second prompt with camera, lighting, sound and one spoken line","title":"catchy, under 80 chars","description":"2-3 lines plus a call to action","hashtags":["#tag1","#tag2"]}"""
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        val tr = Net.req("$GL/models/${g("text_model")}:generateContent", "POST", hdr, body.toString().toByteArray())
        if (tr.code >= 400) { log(c, "Gemini text error ${tr.code}: " + tr.text().take(200)); return }
        val idea = JSONObject(JSONObject(tr.text()).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text"))
        log(c, "Idea: " + idea.getString("title"))

        // 3) Veo video generation
        log(c, "Veo is generating the video (a few minutes)...")
        val vb = JSONObject().put("instances", JSONArray().put(JSONObject().put("prompt", idea.getString("veo_prompt"))))
            .put("parameters", JSONObject().put("aspectRatio", g("aspect")).put("durationSeconds", g("seconds").toIntOrNull() ?: 8))
        val vr = Net.req("$GL/models/${g("veo_model")}:predictLongRunning", "POST", hdr, vb.toString().toByteArray())
        if (vr.code >= 400) { log(c, "Veo error ${vr.code}: " + vr.text().take(200) + " (Veo API needs billing enabled)"); return }
        val op = JSONObject(vr.text()).getString("name")
        var uri: String? = null
        repeat(120) {
            if (uri != null) return@repeat
            Thread.sleep(10000)
            val o = JSONObject(Net.req("$GL/$op", "GET", hdr).text())
            if (o.optBoolean("done")) {
                uri = o.optJSONObject("response")?.optJSONObject("generateVideoResponse")?.optJSONArray("generatedSamples")
                    ?.optJSONObject(0)?.optJSONObject("video")?.optString("uri")
                if (uri == null) { log(c, "Video blocked or failed: " + o.toString().take(200)); return }
            }
        }
        val u = uri ?: run { log(c, "Veo timed out"); return }
        val file = File(c.cacheDir, "v_${System.currentTimeMillis()}.mp4")
        file.writeBytes(Net.req(u, "GET", mapOf("x-goog-api-key" to gk)).body)
        log(c, "Video ready (${file.length() / 1024} KB)")

        // 4) YouTube upload
        if (g("upload") != "true") { log(c, "Auto-upload is off. Saved: " + file.absolutePath); return }
        try {
            val form = "client_id=${g("yt_client_id")}&client_secret=${g("yt_client_secret")}&refresh_token=${g("yt_refresh")}&grant_type=refresh_token"
            val tk = JSONObject(Net.req("https://oauth2.googleapis.com/token", "POST", mapOf("Content-Type" to "application/x-www-form-urlencoded"), form.toByteArray()).text()).getString("access_token")
            val tags = idea.getJSONArray("hashtags")
            val tagLine = (0 until tags.length()).joinToString(" ") { tags.getString(it) }
            var title = idea.getString("title")
            if (g("aspect") == "9:16" && !title.contains("#Shorts")) title += " #Shorts"
            val meta = JSONObject().put("snippet", JSONObject().put("title", title.take(100))
                .put("description", idea.getString("description") + "\n\n" + tagLine).put("categoryId", "22"))
                .put("status", JSONObject().put("privacyStatus", g("privacy").ifEmpty { "private" }).put("selfDeclaredMadeForKids", false).put("containsSyntheticMedia", true))
            val init = Net.req("https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status", "POST",
                mapOf("Authorization" to "Bearer $tk", "Content-Type" to "application/json; charset=UTF-8", "X-Upload-Content-Type" to "video/mp4"), meta.toString().toByteArray())
            val loc = init.loc ?: run { log(c, "YouTube init failed ${init.code}: " + init.text().take(200)); return }
            val up = Net.req(loc, "PUT", mapOf("Content-Type" to "video/mp4"), file.readBytes())
            log(c, if (up.code < 300) "Uploaded to YouTube: $title" else "YouTube upload failed ${up.code}: " + up.text().take(200))
            if (up.code < 300) file.delete()
        } catch (e: Exception) { log(c, "YouTube error: " + e.message) }
    }
}
