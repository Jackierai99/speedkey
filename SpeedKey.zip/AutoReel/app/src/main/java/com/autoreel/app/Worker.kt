package com.autoreel.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class RunWorker(private val c: Context, wp: WorkerParameters) : CoroutineWorker(c, wp) {
    override suspend fun doWork(): Result {
        c.getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("ar", "AutoReel", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(c, "ar").setContentTitle("AutoReel is making a video").setSmallIcon(android.R.drawable.stat_sys_upload).build()
        try { setForeground(ForegroundInfo(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)) } catch (_: Exception) {}
        try { Pipeline.run(c) } catch (e: Exception) { Pipeline.log(c, "ERROR: " + e.message) }
        Live.stage = 0
        return Result.success()
    }
}

class Resp(val code: Int, val body: ByteArray, val loc: String?) { fun text() = String(body) }

object Live { @Volatile var stage = 0; @Volatile var info = ""; @Volatile var video: String? = null }

object Net {
    fun req(url: String, method: String = "GET", headers: Map<String, String> = emptyMap(), body: ByteArray? = null): Resp {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method; c.connectTimeout = 30000; c.readTimeout = 600000
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        if (body != null) { c.doOutput = true; c.setFixedLengthStreamingMode(body.size); c.outputStream.use { it.write(body) } }
        val code = c.responseCode
        return Resp(code, (if (code < 400) c.inputStream else c.errorStream)?.readBytes() ?: ByteArray(0), c.getHeaderField("Location"))
    }
}

object Models {
    private const val GL = "https://generativelanguage.googleapis.com/v1beta"
    private val skip = listOf("tts", "image", "live", "embedding", "audio", "robotics", "computer", "vision", "lite", "exp")
    fun pick(key: String, veo: Boolean, best: Boolean): String? = try {
        val arr = JSONObject(Net.req("$GL/models?pageSize=200", "GET", mapOf("x-goog-api-key" to key)).text()).getJSONArray("models")
        var out: String? = null; var top = -1.0
        for (i in 0 until arr.length()) {
            val m = arr.getJSONObject(i); val n = m.getString("name").removePrefix("models/")
            val meth = m.optJSONArray("supportedGenerationMethods")?.toString() ?: ""
            if (veo) { if (!n.startsWith("veo") || !meth.contains("predictLongRunning")) continue }
            else { if (!n.startsWith("gemini-") || !meth.contains("generateContent") || skip.any { n.contains(it) }) continue }
            val v = Regex("\\d+(\\.\\d+)?").find(n)?.value?.toDouble() ?: 0.0
            val bonus = if (veo) (if (n.contains("fast") == !best) 1.0 else 0.0) else (if (n.contains("pro")) 1.0 else 0.0)
            if (v * 10 + bonus > top) { top = v * 10 + bonus; out = n }
        }
        out
    } catch (e: Exception) { null }
}

object Pipeline {
    private const val GL = "https://generativelanguage.googleapis.com/v1beta"
    fun log(c: Context, m: String) {
        val p = c.p(); val old = p.getString("log", "")!!.lines().takeLast(30)
        p.edit().putString("log", (old + m).joinToString("\n")).apply()
    }

    fun run(c: Context) {
        val p = c.p(); fun g(k: String) = p.getString(k, "")!!.trim()
        val gk = g("gemini_key")
        if (gk.isEmpty()) { log(c, "Add Gemini API key in Settings"); return }
        val hdr = mapOf("x-goog-api-key" to gk, "Content-Type" to "application/json")

        Live.stage = 1; Live.info = "Researching viral videos..."; log(c, "Researching viral videos...")
        var research = "(none)"
        val tk = try { Auth.token(c) } catch (e: Exception) { null }
        if (tk != null) try {
            val after = URLEncoder.encode(java.time.Instant.now().minus(java.time.Duration.ofDays(14)).toString(), "UTF-8")
            val q = URLEncoder.encode(g("niche") + " shorts", "UTF-8")
            val r = Net.req("https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&order=viewCount&maxResults=8&q=$q&publishedAfter=$after", "GET", mapOf("Authorization" to "Bearer $tk"))
            val items = JSONObject(r.text()).getJSONArray("items")
            research = (0 until items.length()).joinToString("\n") { val s = items.getJSONObject(it).getJSONObject("snippet"); "- " + s.getString("title") + ": " + s.getString("description").take(150) }
        } catch (e: Exception) { log(c, "Research skipped: " + e.message) }

        Live.stage = 2; Live.info = "Gemini is thinking of a new viral idea..."
        val tm = Models.pick(gk, false, true) ?: "gemini-2.5-flash"; log(c, "Gemini model: $tm")
        val prompt = """You are a viral short-video strategist. Language: ${g("language")}. Niche: ${g("niche")}. Style notes: ${g("style")}.
Recent top videos in this niche:
$research
Briefly analyze why they went viral (hook, emotion, pacing). Then invent ONE completely NEW, original idea using the same viral principles. Never copy them.
Return JSON only: {"analysis":"...","veo_prompt":"detailed cinematic ${g("seconds")} second prompt with camera, lighting, sound and one spoken line","title":"catchy, under 80 chars","description":"2-3 lines plus a call to action","hashtags":["#tag1","#tag2"]}"""
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        val tr = Net.req("$GL/models/$tm:generateContent", "POST", hdr, body.toString().toByteArray())
        if (tr.code >= 400) { log(c, "Gemini error ${tr.code}: " + tr.text().take(200)); return }
        val idea = JSONObject(JSONObject(tr.text()).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text"))
        val tags = idea.getJSONArray("hashtags"); val tagLine = (0 until tags.length()).joinToString(" ") { tags.getString(it) }
        Live.info = "🎬 " + idea.getString("title") + "\n\n🧠 " + idea.getString("analysis") + "\n\n" + tagLine
        log(c, "Idea: " + idea.getString("title"))

        Live.stage = 3
        val vm = Models.pick(gk, true, g("best_veo") == "true") ?: "veo-3.1-fast-generate-preview"; log(c, "Veo model: $vm (generating, a few minutes)")
        val vb = JSONObject().put("instances", JSONArray().put(JSONObject().put("prompt", idea.getString("veo_prompt"))))
            .put("parameters", JSONObject().put("aspectRatio", g("aspect")).put("durationSeconds", g("seconds").toIntOrNull() ?: 8))
        val vr = Net.req("$GL/models/$vm:predictLongRunning", "POST", hdr, vb.toString().toByteArray())
        if (vr.code >= 400) { log(c, "Veo error ${vr.code}: " + vr.text().take(200) + " (Veo needs API billing)"); return }
        val op = JSONObject(vr.text()).getString("name")
        var uri: String? = null
        repeat(120) {
            if (uri != null) return@repeat
            Thread.sleep(10000)
            val o = JSONObject(Net.req("$GL/$op", "GET", hdr).text())
            if (o.optBoolean("done")) {
                uri = o.optJSONObject("response")?.optJSONObject("generateVideoResponse")?.optJSONArray("generatedSamples")?.optJSONObject(0)?.optJSONObject("video")?.optString("uri")
                if (uri == null) { log(c, "Video blocked or failed: " + o.toString().take(200)); return }
            }
        }
        val u = uri ?: run { log(c, "Veo timed out"); return }
        val file = File(c.filesDir, "v_${System.currentTimeMillis()}.mp4")
        file.writeBytes(Net.req(u, "GET", mapOf("x-goog-api-key" to gk)).body)
        c.filesDir.listFiles { f -> f.name.startsWith("v_") }?.sortedBy { it.lastModified() }?.dropLast(3)?.forEach { it.delete() }
        p.edit().putString("last_video", file.absolutePath).apply(); Live.video = file.absolutePath
        log(c, "Video ready (${file.length() / 1024} KB)")

        if (g("upload") != "true") { Live.stage = 5; log(c, "Auto-upload is off"); return }
        Live.stage = 4
        val t = Auth.token(c) ?: run { log(c, "Login with YouTube first"); return }
        var title = idea.getString("title")
        if (g("aspect") == "9:16" && !title.contains("#Shorts")) title += " #Shorts"
        val meta = JSONObject().put("snippet", JSONObject().put("title", title.take(100)).put("description", idea.getString("description") + "\n\n" + tagLine).put("categoryId", "22"))
            .put("status", JSONObject().put("privacyStatus", g("privacy").ifEmpty { "private" }).put("selfDeclaredMadeForKids", false).put("containsSyntheticMedia", true))
        val init = Net.req("https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status", "POST",
            mapOf("Authorization" to "Bearer $t", "Content-Type" to "application/json; charset=UTF-8", "X-Upload-Content-Type" to "video/mp4"), meta.toString().toByteArray())
        val loc = init.loc ?: run { log(c, "YouTube init failed ${init.code}: " + init.text().take(200)); return }
        val up = Net.req(loc, "PUT", mapOf("Content-Type" to "video/mp4"), file.readBytes())
        log(c, if (up.code < 300) "Uploaded to YouTube: $title" else "YouTube upload failed ${up.code}: " + up.text().take(200))
        Live.stage = 5
    }
}
