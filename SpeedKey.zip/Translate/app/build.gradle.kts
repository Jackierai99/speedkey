plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.translate.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.translate.app"
        minSdk = 26
        // 28 जानबूझकर: इससे ऐप खुद WiFi/Bluetooth ON-OFF कर पाता है
        targetSdk = 28
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
