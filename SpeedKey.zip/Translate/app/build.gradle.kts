plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.translate.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.translate.app"
        minSdk = 26
        // 32 जानबूझकर: नए target पर Bluetooth/WiFi को कोड से ON/OFF करना सीमित हो जाता है
        targetSdk = 32
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
