package com.translate.app

import android.app.admin.DevicePolicyManager
import android.bluetooth.BluetoothManager
import android.content.ComponentName
import android.content.Context
import android.net.wifi.WifiManager
import android.os.UserManager

/**
 * नियम: WiFi/Bluetooth सिर्फ़ इस ऐप से ON हो सकते हैं।
 * बाहर (नोटिफिकेशन पैनल/सेटिंग्स) से ON करने की कोशिश तुरंत वापस OFF हो जाती है।
 * बाहर से OFF करना allowed है (और उसके बाद वो OFF ही रहता है जब तक ऐप से ON न करें)।
 */
object Guard {
    private const val NO_WIFI_STATE = "no_change_wifi_state" // Android 13+ पर सीधे toggle रोकता है

    fun dpm(c: Context) = c.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
    fun admin(c: Context) = ComponentName(c, AdminReceiver::class.java)
    fun isOwner(c: Context) = dpm(c).isDeviceOwnerApp(c.packageName)

    private fun sp(c: Context): android.content.SharedPreferences {
        // Device-protected storage: रीस्टार्ट के बाद फ़ोन अनलॉक करने से पहले भी सेटिंग मिलती है
        val ctx = if (android.os.Build.VERSION.SDK_INT >= 24) c.createDeviceProtectedStorageContext() else c
        return ctx.getSharedPreferences("guard", Context.MODE_PRIVATE)
    }
    fun wantWifi(c: Context) = sp(c).getBoolean("wifi", false)
    fun wantBt(c: Context) = sp(c).getBoolean("bt", false)
    fun setWant(c: Context, key: String, v: Boolean) = sp(c).edit().putBoolean(key, v).apply()

    private fun restrict(c: Context, key: String, on: Boolean) {
        try {
            if (on) dpm(c).addUserRestriction(admin(c), key) else dpm(c).clearUserRestriction(admin(c), key)
        } catch (_: Exception) {}
    }

    fun grant(c: Context) {
        if (!isOwner(c)) return
        for (p in listOf("android.permission.BLUETOOTH_CONNECT", "android.permission.POST_NOTIFICATIONS")) {
            try {
                dpm(c).setPermissionGrantState(admin(c), c.packageName, p, DevicePolicyManager.PERMISSION_GRANT_STATE_GRANTED)
            } catch (_: Exception) {}
        }
    }

    @Suppress("DEPRECATION")
    fun applyWifi(c: Context) {
        if (!isOwner(c)) return
        val wm = c.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val want = wantWifi(c)
        if (wm.isWifiEnabled != want) {
            restrict(c, NO_WIFI_STATE, false)
            wm.isWifiEnabled = want
        }
        restrict(c, NO_WIFI_STATE, true)
    }

    @Suppress("DEPRECATION")
    fun applyBt(c: Context) {
        if (!isOwner(c)) return
        val ad = (c.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter ?: return
        try {
            if (wantBt(c)) {
                restrict(c, UserManager.DISALLOW_BLUETOOTH, false)
                if (!ad.isEnabled) ad.enable()
            } else {
                restrict(c, UserManager.DISALLOW_BLUETOOTH, true) // इससे BT बंद भी होता है और चालू भी नहीं हो पाता
                if (ad.isEnabled) ad.disable()
            }
        } catch (_: SecurityException) {}
    }

    /** यूज़र ऐप को Force Stop / Clear data / बंद न कर सके */
    fun protect(c: Context) {
        if (!isOwner(c)) return
        try {
            if (android.os.Build.VERSION.SDK_INT >= 30)
                dpm(c).setUserControlDisabledPackages(admin(c), listOf(c.packageName))
        } catch (_: Exception) {}
    }

    fun enforce(c: Context) {
        try { protect(c) } catch (_: Throwable) {}
        try { applyWifi(c) } catch (_: Throwable) {}
        try { applyBt(c) } catch (_: Throwable) {}
    }

    /** सारी पाबंदियाँ हटाकर Device Owner भी हटा देता है (uninstall से पहले यही करें) */
    fun release(c: Context) {
        try {
            restrict(c, NO_WIFI_STATE, false)
            restrict(c, UserManager.DISALLOW_BLUETOOTH, false)
            if (android.os.Build.VERSION.SDK_INT >= 30)
                dpm(c).setUserControlDisabledPackages(admin(c), emptyList())
            c.stopService(android.content.Intent(c, GuardService::class.java))
            dpm(c).clearDeviceOwnerApp(c.packageName)
        } catch (_: Exception) {}
    }
}
