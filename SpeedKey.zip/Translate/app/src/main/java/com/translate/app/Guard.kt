package com.translate.app

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.net.wifi.WifiManager

/** नियम: ON सिर्फ़ ऐप से। बाहर से ON हुआ तो वापस OFF। बाहर से OFF मंज़ूर (फिर ऐप से ही ON होगा)। */
object Guard {
    private fun sp(c: Context): android.content.SharedPreferences {
        val ctx = if (android.os.Build.VERSION.SDK_INT >= 24) c.createDeviceProtectedStorageContext() else c
        return ctx.getSharedPreferences("guard", Context.MODE_PRIVATE)
    }
    fun wantWifi(c: Context) = sp(c).getBoolean("wifi", false)
    fun wantBt(c: Context) = sp(c).getBoolean("bt", false)
    fun setWant(c: Context, key: String, v: Boolean) = sp(c).edit().putBoolean(key, v).commit()

    private fun wm(c: Context) = c.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private fun bt(c: Context): BluetoothAdapter? =
        (c.applicationContext.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter

    fun wifiOn(c: Context): Boolean = try {
        val s = wm(c).wifiState; s == WifiManager.WIFI_STATE_ENABLED || s == WifiManager.WIFI_STATE_ENABLING
    } catch (_: Throwable) { false }

    fun btOn(c: Context): Boolean = try {
        val s = bt(c)?.state; s == BluetoothAdapter.STATE_ON || s == BluetoothAdapter.STATE_TURNING_ON
    } catch (_: Throwable) { false }

    @Suppress("DEPRECATION")
    fun applyWifi(c: Context, allowOn: Boolean = true) {
        try {
            val want = wantWifi(c)
            if (want && allowOn && !wifiOn(c)) wm(c).isWifiEnabled = true
            if (!want && wifiOn(c)) wm(c).isWifiEnabled = false
        } catch (_: Throwable) {}
    }

    @Suppress("DEPRECATION")
    fun applyBt(c: Context, allowOn: Boolean = true) {
        try {
            val a = bt(c) ?: return
            val want = wantBt(c)
            if (want && allowOn && !btOn(c)) a.enable()
            if (!want && btOn(c)) a.disable()
        } catch (_: Throwable) {}
    }

    fun enforce(c: Context, allowOn: Boolean = true) { applyWifi(c, allowOn); applyBt(c, allowOn) }
}
