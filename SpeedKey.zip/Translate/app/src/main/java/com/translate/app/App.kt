package com.translate.app

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { GuardService.scheduleRestart(this, 1500) } catch (_: Throwable) {}
            old?.uncaughtException(t, e)
        }
        try { if (Guard.isOwner(this)) { Guard.enforce(this); GuardService.start(this) } } catch (_: Throwable) {}
    }
}
