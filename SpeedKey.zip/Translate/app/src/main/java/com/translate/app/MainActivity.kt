package com.translate.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.accessibility.AccessibilityManager
import android.accessibilityservice.AccessibilityServiceInfo
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var swWifi: Switch
    private lateinit var swBt: Switch

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun a11yOn(): Boolean {
        val am = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        return am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.resolveInfo.serviceInfo.packageName == packageName }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(48), dp(24), dp(24))
            setBackgroundColor(Color.WHITE)
        }
        root.addView(ImageView(this).apply {
            setImageResource(R.drawable.logo)
            layoutParams = LinearLayout.LayoutParams(dp(120), dp(120))
        })
        root.addView(TextView(this).apply {
            text = "Translate"; textSize = 26f; setTextColor(Color.BLACK)
            gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(28))
        })
        swWifi = Switch(this).apply { text = "WiFi"; textSize = 20f }
        swBt = Switch(this).apply { text = "Bluetooth"; textSize = 20f }
        for (s in listOf(swWifi, swBt)) {
            s.setPadding(0, dp(14), 0, dp(14))
            root.addView(s, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        }
        status = TextView(this).apply { textSize = 14f; setPadding(0, dp(20), 0, dp(12)) }
        root.addView(status)
        root.addView(Button(this).apply {
            text = "Accessibility चालू करो"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "Battery restriction हटाओ"
            setOnClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                } catch (_: Exception) { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
            }
        })
        root.addView(Button(this).apply {
            text = "App info (Restricted setting हटाने के लिए)"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            }
        })
        setContentView(ScrollView(this).apply { addView(root) })

        swWifi.setOnCheckedChangeListener { v, on ->
            if (v.isPressed) { Guard.setWant(this, "wifi", on); Guard.applyWifi(this) }
        }
        swBt.setOnCheckedChangeListener { v, on ->
            if (v.isPressed) { Guard.setWant(this, "bt", on); Guard.applyBt(this) }
        }
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 1)
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        swWifi.isChecked = Guard.wantWifi(this)
        swBt.isChecked = Guard.wantBt(this)
        status.text = if (a11yOn()) "✅ लॉक चालू है। WiFi/Bluetooth सिर्फ़ यहीं से ON होंगे।"
        else "⚠️ लॉक बंद है। नीचे 'Accessibility चालू करो' दबाकर Translate को ON करें।\n" +
            "अगर ON नहीं हो रहा: 'App info' → ऊपर ⋮ → 'Allow restricted settings'।"
    }
}
