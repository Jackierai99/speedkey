package com.translate.app

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var swWifi: Switch
    private lateinit var swBt: Switch

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(48), dp(24), dp(24))
            setBackgroundColor(Color.WHITE)
        }
        root.addView(ImageView(this).apply {
            setImageResource(R.drawable.logo)
            layoutParams = LinearLayout.LayoutParams(dp(120), dp(120))
        })
        root.addView(TextView(this).apply {
            text = "Translate"; textSize = 26f; setTextColor(Color.BLACK)
            gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(32))
        })
        swWifi = Switch(this).apply { text = "WiFi"; textSize = 20f }
        swBt = Switch(this).apply { text = "Bluetooth"; textSize = 20f }
        for (s in listOf(swWifi, swBt)) {
            s.setPadding(0, dp(14), 0, dp(14))
            root.addView(s, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        }
        status = TextView(this).apply { textSize = 14f; setPadding(0, dp(24), 0, dp(16)); setTextIsSelectable(true) }
        root.addView(status)
        root.addView(Button(this).apply {
            text = "पाबंदी हटाओ (Unlock)"
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage("सारी पाबंदी हट जाएगी और ऐप Device Owner से हट जाएगा। ठीक है?")
                    .setPositiveButton("हाँ") { _, _ -> Guard.release(this@MainActivity); refresh() }
                    .setNegativeButton("नहीं", null).show()
            }
        })
        setContentView(ScrollView(this).apply { addView(root) })

        swWifi.setOnCheckedChangeListener { v, on ->
            if (v.isPressed) { Guard.setWant(this, "wifi", on); Guard.applyWifi(this) }
        }
        swBt.setOnCheckedChangeListener { v, on ->
            if (v.isPressed) { Guard.setWant(this, "bt", on); Guard.applyBt(this) }
        }
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        val owner = Guard.isOwner(this)
        swWifi.isEnabled = owner; swBt.isEnabled = owner
        swWifi.isChecked = Guard.wantWifi(this)
        swBt.isChecked = Guard.wantBt(this)
        if (owner) {
            Guard.grant(this); Guard.enforce(this); GuardService.start(this)
            status.text = "✅ लॉक चालू है। WiFi/Bluetooth सिर्फ़ यहीं से ON होंगे।"
        } else {
            status.text = "⚠️ अभी लॉक चालू नहीं है। कंप्यूटर से एक बार यह कमांड चलाएँ:\n\n" +
                "adb shell dpm set-device-owner com.translate.app/.AdminReceiver"
        }
    }
}
