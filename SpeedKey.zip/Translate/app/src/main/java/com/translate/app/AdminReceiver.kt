package com.translate.app

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

class AdminReceiver : DeviceAdminReceiver() {
    override fun onEnabled(context: Context, intent: Intent) {
        Guard.grant(context)
        Guard.enforce(context)
        GuardService.start(context)
    }
}
