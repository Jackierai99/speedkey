package com.translate.app

import android.accessibilityservice.AccessibilityService
import android.bluetooth.BluetoothAdapter
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.wifi.WifiManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class GuardAccessibility : AccessibilityService() {
    private val h = Handler(Looper.getMainLooper())
    private var lastClick = 0L
    private var lastQs = 0L
    private var fails = 0

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            try {
                when (i.action) {
                    WifiManager.WIFI_STATE_CHANGED_ACTION -> when (i.getIntExtra(WifiManager.EXTRA_WIFI_STATE, -1)) {
                        WifiManager.WIFI_STATE_DISABLED -> if (Guard.wantWifi(c)) Guard.setWant(c, "wifi", false)
                        WifiManager.WIFI_STATE_ENABLING, WifiManager.WIFI_STATE_ENABLED ->
                            if (!Guard.wantWifi(c)) Guard.applyWifi(c)
                    }
                    BluetoothAdapter.ACTION_STATE_CHANGED -> when (i.getIntExtra(BluetoothAdapter.EXTRA_STATE, -1)) {
                        BluetoothAdapter.STATE_OFF -> if (Guard.wantBt(c)) Guard.setWant(c, "bt", false)
                        BluetoothAdapter.STATE_TURNING_ON, BluetoothAdapter.STATE_ON ->
                            if (!Guard.wantBt(c)) Guard.applyBt(c)
                    }
                }
            } catch (_: Throwable) {}
        }
    }

    // हर 2 सेकंड में जाँच: कुछ ग़लत ON हो तो OFF; सीधे OFF न हो पाए तो Quick Settings से टाइल दबाकर OFF
    private val tick = object : Runnable {
        override fun run() {
            try {
                Guard.enforce(this@GuardAccessibility, allowOn = false)
                val stuck = (!Guard.wantWifi(this@GuardAccessibility) && Guard.wifiOn(this@GuardAccessibility)) ||
                        (!Guard.wantBt(this@GuardAccessibility) && Guard.btOn(this@GuardAccessibility))
                if (stuck) {
                    fails++
                    val now = SystemClock.elapsedRealtime()
                    if (fails >= 2 && now - lastQs > 15000) {
                        lastQs = now
                        performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
                        h.postDelayed({ performGlobalAction(GLOBAL_ACTION_BACK) }, 4000)
                    }
                } else fails = 0
            } catch (_: Throwable) {}
            h.postDelayed(this, 2000)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        try {
            val f = IntentFilter().apply {
                addAction(WifiManager.WIFI_STATE_CHANGED_ACTION)
                addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
            }
            registerReceiver(receiver, f)
            Guard.enforce(this)
        } catch (_: Throwable) {}
        h.removeCallbacks(tick); h.post(tick)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        try {
            val needWifi = !Guard.wantWifi(this) && Guard.wifiOn(this)
            val needBt = !Guard.wantBt(this) && Guard.btOn(this)
            if (!needWifi && !needBt) return
            val now = SystemClock.elapsedRealtime()
            if (now - lastClick < 1500) return
            val root = rootInActiveWindow ?: return
            if (clickOff(root, needWifi, needBt)) lastClick = now
        } catch (_: Throwable) {}
    }

    private fun clickOff(n: AccessibilityNodeInfo, w: Boolean, b: Boolean): Boolean {
        val label = ((n.text ?: "").toString() + " " + (n.contentDescription ?: "")).lowercase()
        val isWifi = label.contains("wi-fi") || label.contains("wifi") || label.contains("वाई")
        val isBt = label.contains("bluetooth") || label.contains("ब्लूटूथ")
        if (n.isCheckable && n.isChecked && ((w && isWifi) || (b && isBt))) return clickUp(n)
        for (i in 0 until n.childCount) {
            val ch = n.getChild(i) ?: continue
            if (clickOff(ch, w, b)) return true
        }
        return false
    }

    private fun clickUp(n: AccessibilityNodeInfo): Boolean {
        var x: AccessibilityNodeInfo? = n
        while (x != null) {
            if (x.isClickable) return x.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            x = x.parent
        }
        return false
    }

    override fun onInterrupt() {}
    override fun onDestroy() {
        h.removeCallbacks(tick)
        try { unregisterReceiver(receiver) } catch (_: Throwable) {}
        super.onDestroy()
    }
}
