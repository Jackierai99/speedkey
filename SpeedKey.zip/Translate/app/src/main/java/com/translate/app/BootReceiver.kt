package com.translate.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        try {
            if (Guard.isOwner(context)) {
                Guard.enforce(context)
                GuardService.start(context)
                GuardService.scheduleRestart(context)
            }
        } catch (_: Throwable) {}
    }
}
