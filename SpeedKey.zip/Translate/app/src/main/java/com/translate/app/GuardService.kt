package com.translate.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.bluetooth.BluetoothAdapter
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.wifi.WifiManager
import android.os.IBinder

class GuardService : Service() {

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (!Guard.isOwner(c)) return
            when (i.action) {
                WifiManager.WIFI_STATE_CHANGED_ACTION -> {
                    when (i.getIntExtra(WifiManager.EXTRA_WIFI_STATE, -1)) {
                        WifiManager.WIFI_STATE_DISABLED, WifiManager.WIFI_STATE_DISABLING ->
                            if (Guard.wantWifi(c)) Guard.setWant(c, "wifi", false) // बाहर से OFF = मंज़ूर
                        WifiManager.WIFI_STATE_ENABLED, WifiManager.WIFI_STATE_ENABLING ->
                            if (!Guard.wantWifi(c)) Guard.applyWifi(c) // बाहर से ON = वापस OFF
                    }
                }
                BluetoothAdapter.ACTION_STATE_CHANGED -> {
                    when (i.getIntExtra(BluetoothAdapter.EXTRA_STATE, -1)) {
                        BluetoothAdapter.STATE_OFF, BluetoothAdapter.STATE_TURNING_OFF -> {
                            if (Guard.wantBt(c)) { Guard.setWant(c, "bt", false); Guard.applyBt(c) }
                        }
                        BluetoothAdapter.STATE_ON, BluetoothAdapter.STATE_TURNING_ON ->
                            if (!Guard.wantBt(c)) Guard.applyBt(c)
                    }
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("guard", "Translate", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "guard")
            .setContentTitle("Translate")
            .setContentText("चालू है")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .build()
        startForeground(1, n)
        val f = IntentFilter().apply {
            addAction(WifiManager.WIFI_STATE_CHANGED_ACTION)
            addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
        }
        registerReceiver(receiver, f)
        Guard.enforce(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try { Guard.enforce(this); scheduleRestart(this) } catch (_: Throwable) {}
        return START_STICKY
    }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onTaskRemoved(rootIntent: Intent?) { scheduleRestart(this, 1000); super.onTaskRemoved(rootIntent) }
    override fun onDestroy() {
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        scheduleRestart(this, 1000)
        super.onDestroy()
    }

    companion object {
        /** AlarmManager से सर्विस को दोबारा जगाना (watchdog). delayMs डिफ़ॉल्ट = 15 मिनट */
        fun scheduleRestart(c: Context, delayMs: Long = 15 * 60 * 1000L) {
            try {
                val pi = android.app.PendingIntent.getForegroundService(
                    c, 7, Intent(c, GuardService::class.java),
                    android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE)
                val am = c.getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
                am.setAndAllowWhileIdle(android.app.AlarmManager.ELAPSED_REALTIME_WAKEUP,
                    android.os.SystemClock.elapsedRealtime() + delayMs, pi)
            } catch (_: Throwable) {}
        }

        fun start(c: Context) { try { c.startForegroundService(Intent(c, GuardService::class.java)) } catch (_: Exception) {} }
    }
}
