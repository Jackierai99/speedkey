package com.friday.app

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.*

class OrbView(c: Context) : View(c) {
    private val n = 650
    private val sx = FloatArray(n); private val sy = FloatArray(n); private val sz = FloatArray(n)
    private val pts = FloatArray(n * 2)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f; private var lv = 0f; private var spd = 0.01f
    private var cr = 255f; private var cg = 140f; private var cb = 30f
    private val oval = RectF()

    init {
        val ga = Math.PI * (3 - sqrt(5.0))
        for (i in 0 until n) {
            val y = 1 - 2f * i / (n - 1); val r = sqrt(1 - y * y)
            sx[i] = (cos(ga * i) * r).toFloat(); sy[i] = y; sz[i] = (sin(ga * i) * r).toFloat()
        }
    }

    private fun col(al: Int, dg: Int = 0) = Color.argb(al.coerceIn(0, 255), cr.toInt(), (cg + dg).toInt().coerceIn(0, 255), cb.toInt())

    override fun onDraw(cv: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val R = min(width, height) * 0.30f
        val st = Bus.state; val emo = Bus.emotion
        val tgt = when (emo) {
            "happy" -> floatArrayOf(255f, 200f, 40f); "caring" -> floatArrayOf(255f, 110f, 125f)
            "angry" -> floatArrayOf(255f, 35f, 30f); "sulking" -> floatArrayOf(120f, 135f, 210f)
            "thinking" -> floatArrayOf(255f, 215f, 130f); else -> floatArrayOf(255f, 140f, 30f)
        }
        cr += (tgt[0] - cr) * 0.06f; cg += (tgt[1] - cg) * 0.06f; cb += (tgt[2] - cb) * 0.06f
        lv += ((if (st == Bus.MUTED) 0f else Bus.level) - lv) * 0.25f
        val mult = when (emo) { "angry" -> 1.7f; "happy" -> 1.25f; "sulking" -> 0.5f; else -> 1f }
        val tgtSpd = mult * when (st) { Bus.THINK -> 0.05f; Bus.SPEAK -> 0.022f; Bus.LISTEN -> 0.016f; Bus.MUTED -> 0.004f; else -> 0.01f }
        spd += (tgtSpd - spd) * 0.05f; t += spd
        val dim = if (st == Bus.MUTED || emo == "sulking") (if (st == Bus.MUTED) 0.3f else 0.6f) else 1f
        val a = { v: Int -> (v * dim).toInt() }
        val breathe = 1f + 0.04f * sin(t * 3) + lv * 0.35f

        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND
        for (i in 0 until 26) {
            val ang = i * 2 * PI / 26 + sin(t * 0.7 + i) * 0.35
            val jit = if (emo == "angry") 1f + 0.25f * sin(t * 12 + i) else 1f
            val len = R * (0.7f + 0.8f * abs(sin(t * 1.3f + i * 1.7f))) * (1f + lv * 1.6f) * jit
            p.strokeWidth = 2f + (i % 3); p.color = col(a(150), (i % 4) * 15)
            cv.drawLine(cx, cy, cx + (cos(ang) * len).toFloat(), cy + (sin(ang) * len).toFloat(), p)
        }
        val ca = cos(t); val sa = sin(t); val cb2 = cos(t * 0.6f); val sb = sin(t * 0.6f)
        val spread = R * breathe
        for (back in 0..1) {
            var k = 0
            for (i in 0 until n) {
                val x1 = sx[i] * ca + sz[i] * sa; val z1 = -sx[i] * sa + sz[i] * ca
                val y2 = sy[i] * cb2 - z1 * sb; val z2 = sy[i] * sb + z1 * cb2
                if ((z2 < 0) != (back == 0)) continue
                val j = 1f + 0.06f * sin(t * 4 + i)
                pts[k++] = cx + x1 * spread * j * (1 + lv * 0.5f * ((i % 5) / 4f)); pts[k++] = cy + y2 * spread * j
            }
            p.strokeWidth = if (back == 0) 2.5f else 4.5f
            p.color = col(a(if (back == 0) 90 else 230), 10)
            cv.drawPoints(pts, 0, k, p)
        }
        p.strokeWidth = 4f
        for (i in 0 until 3) {
            cv.save(); cv.rotate((t * (30 + i * 20) * (if (i % 2 == 0) 1 else -1)) + i * 60, cx, cy)
            val rr = R * (1.15f + i * 0.14f) * (1 + lv * 0.4f); oval.set(cx - rr, cy - rr * 0.45f, cx + rr, cy + rr * 0.45f)
            p.color = col(a(200), i * 25)
            cv.drawArc(oval, 0f, 150f + lv * 150f, false, p); cv.restore()
        }
        p.style = Paint.Style.FILL
        val core = R * (0.38f + lv * 0.35f)
        p.shader = RadialGradient(cx, cy, core * 2.2f, intArrayOf(Color.argb(a(255), 255, 245, 200), col(a(210), 20), Color.TRANSPARENT), floatArrayOf(0f, 0.35f, 1f), Shader.TileMode.CLAMP)
        cv.drawCircle(cx, cy, core * 2.2f, p); p.shader = null
        postInvalidateOnAnimation()
    }
}
