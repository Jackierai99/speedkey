package com.friday.app

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.*

/** 3D particle orb: dense depth-shaded sphere, orbiting 3D rings, glowing rays, hot core. Reacts to voice level + emotion. */
class OrbView(c: Context) : View(c) {
    private val n = 2200
    private val bx = FloatArray(n); private val by = FloatArray(n); private val bz = FloatArray(n)
    private val ph = FloatArray(n)
    private val pts = Array(4) { FloatArray(n * 2) }
    private val cnt = IntArray(4)

    private val nr = 3; private val rn = 320
    private val ringTilt = floatArrayOf(0.5f, 1.2f, 2.1f)
    private val ringSpd = floatArrayOf(0.9f, -0.7f, 0.5f)
    private val ringRad = floatArrayOf(1.30f, 1.48f, 1.66f)
    private val rpts = Array(4) { FloatArray(nr * rn * 2) }
    private val rcnt = IntArray(4)

    private val ns = 64
    private val rdx = FloatArray(ns); private val rdy = FloatArray(ns); private val rdz = FloatArray(ns); private val rph = FloatArray(ns)

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val add = PorterDuffXfermode(PorterDuff.Mode.ADD)
    private val path = Path()
    private var t = 0f; private var lv = 0f; private var spd = 0.01f
    private var cr = 255f; private var cg = 140f; private var cb = 30f
    private val rnd = java.util.Random(7)

    init {
        for (i in 0 until n) {
            // random direction, radius biased to the shell so it reads as a hollow sphere with some inner haze
            var x: Float; var y: Float; var z: Float; var l: Float
            do { x = rnd.nextGaussian().toFloat(); y = rnd.nextGaussian().toFloat(); z = rnd.nextGaussian().toFloat(); l = sqrt(x * x + y * y + z * z) } while (l < 1e-3f)
            val r = if (rnd.nextFloat() < 0.78f) 0.92f + rnd.nextFloat() * 0.16f else 0.25f + rnd.nextFloat() * 0.65f
            bx[i] = x / l * r; by[i] = y / l * r; bz[i] = z / l * r; ph[i] = rnd.nextFloat() * 6.283f
        }
        for (i in 0 until ns) {
            var x: Float; var y: Float; var z: Float; var l: Float
            do { x = rnd.nextGaussian().toFloat(); y = rnd.nextGaussian().toFloat(); z = rnd.nextGaussian().toFloat(); l = sqrt(x * x + y * y + z * z) } while (l < 1e-3f)
            rdx[i] = x / l; rdy[i] = y / l; rdz[i] = z / l; rph[i] = rnd.nextFloat() * 6.283f
        }
    }

    private fun col(al: Int, dr: Int = 0, dg: Int = 0, db: Int = 0) =
        Color.argb(al.coerceIn(0, 255), (cr + dr).toInt().coerceIn(0, 255), (cg + dg).toInt().coerceIn(0, 255), (cb + db).toInt().coerceIn(0, 255))

    override fun onDraw(cv: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val R = min(width, height) * 0.27f
        val st = Bus.state; val emo = Bus.emotion
        val tgt = when (emo) {
            "happy" -> floatArrayOf(255f, 200f, 40f); "caring" -> floatArrayOf(255f, 110f, 125f)
            "angry" -> floatArrayOf(255f, 35f, 30f); "sulking" -> floatArrayOf(120f, 135f, 210f)
            "thinking" -> floatArrayOf(255f, 215f, 130f); else -> floatArrayOf(255f, 140f, 30f)
        }
        cr += (tgt[0] - cr) * 0.06f; cg += (tgt[1] - cg) * 0.06f; cb += (tgt[2] - cb) * 0.06f
        lv += ((if (st == Bus.MUTED) 0f else Bus.level) - lv) * 0.25f
        val mult = when (emo) { "angry" -> 1.7f; "happy" -> 1.25f; "sulking" -> 0.5f; else -> 1f }
        val tgtSpd = mult * when (st) { Bus.THINK -> 0.05f; Bus.SPEAK -> 0.024f; Bus.LISTEN -> 0.016f; Bus.MUTED -> 0.004f; else -> 0.01f }
        spd += (tgtSpd - spd) * 0.05f; t += spd
        val dim = if (st == Bus.MUTED) 0.3f else if (emo == "sulking") 0.6f else 1f
        val breathe = 1f + 0.04f * sin(t * 3) + lv * 0.30f

        p.xfermode = add
        p.strokeCap = Paint.Cap.ROUND

        // 1) big soft glow behind everything
        p.style = Paint.Style.FILL
        val gr = R * (2.1f + lv * 0.6f)
        p.shader = RadialGradient(cx, cy, gr, intArrayOf(col((70 * dim).toInt()), col((28 * dim).toInt()), Color.TRANSPARENT), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        cv.drawCircle(cx, cy, gr, p); p.shader = null

        // shared rotation (sphere)
        val ca = cos(t); val sa = sin(t); val cb2 = cos(t * 0.6f + 0.5f); val sb = sin(t * 0.6f + 0.5f)

        // 2) radial rays (3D, depth faded, glowing)
        p.style = Paint.Style.STROKE
        for (i in 0 until ns) {
            val x1 = rdx[i] * ca + rdz[i] * sa; val z1 = -rdx[i] * sa + rdz[i] * ca
            val y2 = rdy[i] * cb2 - z1 * sb; val z2 = rdy[i] * sb + z1 * cb2
            val jit = if (emo == "angry") 1f + 0.25f * sin(t * 12 + i) else 1f
            val pulse = 0.55f + 0.45f * abs(sin(t * 1.4f + rph[i] * 3f))
            val len = R * (0.9f + 1.35f * pulse * (if (i % 5 == 0) 1.25f else 1f)) * (1f + lv * 1.4f) * jit
            val persp = 1f / (1.6f - z2 * 0.5f)
            val ex = cx + x1 * len * persp * 1.35f; val ey = cy + y2 * len * persp * 1.35f
            val depthA = (0.45f + 0.55f * (z2 * 0.5f + 0.5f))
            val bright = if (i % 4 == 0) 1f else 0.6f
            p.strokeWidth = (if (i % 4 == 0) 3.2f else 1.6f) * (0.7f + persp * 0.5f)
            p.color = col((95 * depthA * bright * dim).toInt(), 0, (i % 4) * 14, 0)
            cv.drawLine(cx, cy, ex, ey, p)
            if (i % 4 == 0) { p.strokeWidth = 1.1f; p.color = col((200 * depthA * dim).toInt(), 0, 90, 90); cv.drawLine(cx, cy, ex, ey, p) }
        }

        // 3) particle sphere, bucketed by depth (far = small/dim, near = big/bright)
        java.util.Arrays.fill(cnt, 0)
        val spread = R * breathe
        for (i in 0 until n) {
            val x1 = bx[i] * ca + bz[i] * sa; val z1 = -bx[i] * sa + bz[i] * ca
            val y2 = by[i] * cb2 - z1 * sb; val z2 = by[i] * sb + z1 * cb2
            val j = 1f + 0.05f * sin(t * 4 + ph[i]) + lv * 0.5f * ((i % 5) / 4f)
            val persp = 1f / (1.5f - z2 * 0.45f)
            val b = ((z2 + 1f) * 1.5f).toInt().coerceIn(0, 3)
            val k = cnt[b]; val arr = pts[b]
            arr[k] = cx + x1 * spread * j * persp * 1.3f; arr[k + 1] = cy + y2 * spread * j * persp * 1.3f
            cnt[b] = k + 2
        }
        val bw = floatArrayOf(1.6f, 2.4f, 3.4f, 4.8f); val ba = intArrayOf(70, 120, 185, 255)
        for (b in 0..3) {
            p.strokeWidth = bw[b]; p.color = col((ba[b] * dim).toInt(), 0, b * 12, b * 8)
            cv.drawPoints(pts[b], 0, cnt[b], p)
        }

        // 4) orbiting 3D rings of particles with comet tails
        java.util.Arrays.fill(rcnt, 0)
        for (r in 0 until nr) {
            val a0 = t * ringSpd[r] * 1.6f; val tl = ringTilt[r] + 0.25f * sin(t * 0.5f + r)
            val ct = cos(tl); val stl = sin(tl); val cyz = cos(t * 0.4f + r); val syz = sin(t * 0.4f + r)
            val rr = R * ringRad[r] * (1f + lv * 0.35f)
            for (i in 0 until rn) {
                val tail = i / rn.toFloat()                       // 0 = head, 1 = end of tail
                val ang = a0 + tail * 4.4f * (if (ringSpd[r] > 0) -1 else 1)
                val x = cos(ang) * rr; val z0 = sin(ang) * rr
                val y = z0 * stl; val z = z0 * ct
                val x2 = x * cyz + z * syz; val z2 = -x * syz + z * cyz
                val nz = z2 / (R * 1.7f)
                val persp = 1f / (1.5f - nz * 0.45f)
                val b = (((1f - tail) * 2.2f) + (nz + 1f) * 0.4f).toInt().coerceIn(0, 3)
                val k = rcnt[b]; val arr = rpts[b]
                arr[k] = cx + x2 * persp * 1.3f; arr[k + 1] = cy + y * persp * 1.3f
                rcnt[b] = k + 2
            }
        }
        val rw = floatArrayOf(1.4f, 2.2f, 3.2f, 4.6f); val ra = intArrayOf(55, 110, 175, 245)
        for (b in 0..3) {
            p.strokeWidth = rw[b]; p.color = col((ra[b] * dim).toInt(), 0, 25 + b * 15, 20 + b * 12)
            cv.drawPoints(rpts[b], 0, rcnt[b], p)
        }

        // 5) bright elliptical arcs (like the big swooshes in the reference)
        for (i in 0 until 3) {
            cv.save(); cv.rotate(t * (28 + i * 18) * (if (i % 2 == 0) 1 else -1) * 3f + i * 60, cx, cy)
            val rr = R * (1.25f + i * 0.2f) * (1 + lv * 0.4f)
            path.reset(); path.addArc(RectF(cx - rr, cy - rr * 0.42f, cx + rr, cy + rr * 0.42f), 0f, 130f + lv * 160f)
            p.strokeWidth = 7f; p.color = col((38 * dim).toInt(), 0, 40, 20); cv.drawPath(path, p)
            p.strokeWidth = 2.4f; p.color = col((210 * dim).toInt(), 0, 50 + i * 20, 30); cv.drawPath(path, p)
            cv.restore()
        }

        // 6) hot core
        p.style = Paint.Style.FILL
        val core = R * (0.40f + lv * 0.4f)
        p.shader = RadialGradient(cx, cy, core * 2.6f,
            intArrayOf(Color.argb((255 * dim).toInt(), 255, 250, 225), col((230 * dim).toInt(), 0, 50, 40), col((70 * dim).toInt()), Color.TRANSPARENT),
            floatArrayOf(0f, 0.22f, 0.55f, 1f), Shader.TileMode.CLAMP)
        cv.drawCircle(cx, cy, core * 2.6f, p); p.shader = null
        p.xfermode = null
        postInvalidateOnAnimation()
    }
}
