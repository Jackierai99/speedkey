package com.friday.app

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.*

/**
 * 3D particle orb. Only dots + soft glow (no straight lines).
 * compact = true is used for the floating popup: everything stays inside a circle, so no square background.
 */
class OrbView(c: Context, private val compact: Boolean = false) : View(c) {
    private val n = if (compact) 1500 else 3600
    private val bx = FloatArray(n); private val by = FloatArray(n); private val bz = FloatArray(n); private val ph = FloatArray(n)
    private val pts = Array(4) { FloatArray(n * 2) }
    private val cnt = IntArray(4)

    private val nr = 5; private val rn = if (compact) 90 else 140
    private val ringTilt = floatArrayOf(0.5f, 1.25f, 2.1f, 0.85f, 1.7f)
    private val ringSpd = floatArrayOf(0.9f, -0.7f, 0.5f, -1.1f, 0.65f)
    private val ringRad = floatArrayOf(1.22f, 1.36f, 1.50f, 1.64f, 1.78f)
    private val rpts = Array(4) { FloatArray(nr * rn * 2) }
    private val rcnt = IntArray(4)

    // sparks flying outward (dots, fade with age)
    private val ns = 150
    private val sdx = FloatArray(ns); private val sdy = FloatArray(ns); private val sdz = FloatArray(ns)
    private val sage = FloatArray(ns); private val sv = FloatArray(ns)
    private val spts = Array(3) { FloatArray(ns * 2) }
    private val scnt = IntArray(3)

    // thin glowing rays (fade outward) like the reference video
    private val rayN = if (compact) 90 else 260
    private val rdx = FloatArray(rayN); private val rdy = FloatArray(rayN); private val rdz = FloatArray(rayN)
    private val rlen = FloatArray(rayN); private val rph = FloatArray(rayN)
    private val rl = Array(6) { FloatArray(rayN * 4) }
    private val rlc = IntArray(6)
    // tapered comet arcs
    private val am = 40
    private val arcX = FloatArray(am + 1); private val arcY = FloatArray(am + 1)
    private val ap = Path()
    // outer dust haze
    private val nd = if (compact) 450 else 1300
    private val ddx = FloatArray(nd); private val ddy = FloatArray(nd); private val ddz = FloatArray(nd)
    private val dpts = Array(2) { FloatArray(nd * 2) }; private val dcnt = IntArray(2)

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val add = PorterDuffXfermode(PorterDuff.Mode.ADD)
    private var t = 0f; private var lv = 0f; private var spd = 0.01f
    private var cr = 255f; private var cg = 140f; private var cb = 30f
    private val rnd = java.util.Random(7)

    private fun dir(out: FloatArray) {
        var x: Float; var y: Float; var z: Float; var l: Float
        do { x = rnd.nextGaussian().toFloat(); y = rnd.nextGaussian().toFloat(); z = rnd.nextGaussian().toFloat(); l = sqrt(x * x + y * y + z * z) } while (l < 1e-3f)
        out[0] = x / l; out[1] = y / l; out[2] = z / l
    }

    init {
        val d = FloatArray(3)
        for (i in 0 until n) {
            dir(d)
            val r = if (rnd.nextFloat() < 0.7f) 0.93f + rnd.nextFloat() * 0.14f else 0.25f + rnd.nextFloat() * 0.65f
            bx[i] = d[0] * r; by[i] = d[1] * r; bz[i] = d[2] * r; ph[i] = rnd.nextFloat() * 6.283f
        }
        for (i in 0 until nd) {
            dir(d); val u = rnd.nextFloat(); val r = 1.1f + u * u * (if (compact) 0.4f else 0.62f)
            ddx[i] = d[0] * r; ddy[i] = d[1] * r; ddz[i] = d[2] * r
        }
        for (i in 0 until rayN) {
            dir(d); rdx[i] = d[0]; rdy[i] = d[1]; rdz[i] = d[2]; rph[i] = rnd.nextFloat() * 6.283f
            val u = rnd.nextFloat(); rlen[i] = if (u > 0.9f) 2.3f + rnd.nextFloat() * 0.6f else 1.05f + u * 1.2f
        }
        for (i in 0 until ns) { dir(d); sdx[i] = d[0]; sdy[i] = d[1]; sdz[i] = d[2]; sage[i] = rnd.nextFloat(); sv[i] = 0.35f + rnd.nextFloat() * 0.65f }
    }

    private fun col(al: Int, dg: Int = 0, db: Int = 0) =
        Color.argb(al.coerceIn(0, 255), cr.toInt().coerceIn(0, 255), (cg + dg).toInt().coerceIn(0, 255), (cb + db).toInt().coerceIn(0, 255))

    override fun onDraw(cv: Canvas) {
        val half = min(width, height) / 2f
        val cx = width / 2f; val cy = height / 2f
        val R = min(width, height) * (if (compact) 0.165f else 0.2f)

        val st = Bus.state; val emo = Bus.emotion
        val tgt = when (emo) {
            "happy" -> floatArrayOf(255f, 200f, 40f); "caring" -> floatArrayOf(255f, 110f, 125f)
            "angry" -> floatArrayOf(255f, 35f, 30f); "sulking" -> floatArrayOf(120f, 135f, 210f)
            "thinking" -> floatArrayOf(255f, 215f, 130f); else -> floatArrayOf(255f, 140f, 30f)
        }
        cr += (tgt[0] - cr) * 0.06f; cg += (tgt[1] - cg) * 0.06f; cb += (tgt[2] - cb) * 0.06f
        lv += ((if (st == Bus.MUTED) 0f else Bus.level) - lv) * 0.25f
        val mult = when (emo) { "angry" -> 1.7f; "happy" -> 1.25f; "sulking" -> 0.5f; else -> 1f }
        val tgtSpd = mult * when (st) { Bus.THINK -> 0.05f; Bus.SPEAK -> 0.024f; Bus.LISTEN -> 0.016f; Bus.MUTED -> 0.004f; else -> 0.01f }
        spd += (tgtSpd - spd) * 0.05f; t += spd
        val dim = if (st == Bus.MUTED) 0.3f else if (emo == "sulking") 0.6f else 1f
        val breathe = 1f + 0.035f * sin(t * 3) + lv * 0.28f

        p.xfermode = add; p.strokeCap = Paint.Cap.ROUND
        val s = if (compact) 0.6f else 1f

        // soft glow (fades to fully transparent before the view edge)
        p.style = Paint.Style.FILL
        if (!compact) {
            val gr = half
            p.shader = RadialGradient(cx, cy, gr, intArrayOf(col((70 * dim).toInt()), col((28 * dim).toInt()), col((8 * dim).toInt()), Color.TRANSPARENT), floatArrayOf(0f, 0.45f, 0.75f, 1f), Shader.TileMode.CLAMP)
            cv.drawCircle(cx, cy, gr, p); p.shader = null
        }

        val ca = cos(t); val sa = sin(t); val cb2 = cos(t * 0.6f + 0.5f); val sb = sin(t * 0.6f + 0.5f)
        p.style = Paint.Style.STROKE

        // glowing rays: bright at the core, fading outward, 3D depth
        java.util.Arrays.fill(rlc, 0)
        for (i in 0 until rayN) {
            val x1 = rdx[i] * ca + rdz[i] * sa; val z1 = -rdx[i] * sa + rdz[i] * ca
            val y2 = rdy[i] * cb2 - z1 * sb; val z2 = rdy[i] * sb + z1 * cb2
            val pf = 1.3f / (1.5f - z2 * 0.45f)
            val pulse = 0.6f + 0.4f * sin(t * 1.7f + rph[i] * 2f)
            val jit = if (emo == "angry") 1f + 0.2f * sin(t * 14f + i) else 1f
            val r0 = R * 0.12f
            var r1 = R * rlen[i] * (if (compact) 0.72f else 1f) * pulse * (1f + lv * 1.1f) * jit
            r1 = min(r1, half * 0.93f / pf)
            val near = if (z2 > 0f) 1 else 0
            for (bd in 0..2) {
                val fa = bd * 0.34f; val fb = (bd + 1) * 0.34f
                val ra = r0 + (r1 - r0) * fa; val rb = r0 + (r1 - r0) * fb
                val g = near * 3 + bd; val k = rlc[g]; val arr = rl[g]
                arr[k] = cx + x1 * ra * pf; arr[k + 1] = cy + y2 * ra * pf; arr[k + 2] = cx + x1 * rb * pf; arr[k + 3] = cy + y2 * rb * pf
                rlc[g] = k + 4
            }
        }
        val rwid = floatArrayOf(1.5f, 1.1f, 0.8f); val ral = intArrayOf(210, 120, 50)
        for (g in 0..5) {
            val bd = g % 3; val near = g / 3
            p.strokeWidth = rwid[bd] * s * (if (near == 1) 1.25f else 0.8f)
            p.color = col(((ral[bd] * (if (near == 1) 1f else 0.6f)) * dim).toInt(), 70 - bd * 30, 50 - bd * 20)
            cv.drawLines(rl[g], 0, rlc[g], p)
        }

        // outer dust haze (slow drift)
        java.util.Arrays.fill(dcnt, 0)
        val ca2 = cos(t * 0.5f); val sa2 = sin(t * 0.5f)
        for (i in 0 until nd) {
            val x1 = ddx[i] * ca2 + ddz[i] * sa2; val z1 = -ddx[i] * sa2 + ddz[i] * ca2
            val y2 = ddy[i] * cb2 - z1 * sb; val z2 = ddy[i] * sb + z1 * cb2
            val pf = 1.3f / (1.5f - z2 * 0.45f) * R * (1f + lv * 0.15f)
            val b = if (z2 > 0f) 1 else 0; val k = dcnt[b]
            dpts[b][k] = cx + x1 * pf; dpts[b][k + 1] = cy + y2 * pf; dcnt[b] = k + 2
        }
        p.strokeWidth = 1.3f * s; p.color = col((45 * dim).toInt(), 40, 20); cv.drawPoints(dpts[0], 0, dcnt[0], p)
        p.strokeWidth = 1.8f * s; p.color = col((100 * dim).toInt(), 50, 30); cv.drawPoints(dpts[1], 0, dcnt[1], p)

        // particle sphere
        java.util.Arrays.fill(cnt, 0)
        val spread = R * breathe * 1.3f
        for (i in 0 until n) {
            val x1 = bx[i] * ca + bz[i] * sa; val z1 = -bx[i] * sa + bz[i] * ca
            val y2 = by[i] * cb2 - z1 * sb; val z2 = by[i] * sb + z1 * cb2
            val j = 1f + 0.05f * sin(t * 4 + ph[i]) + lv * 0.45f * ((i % 5) / 4f)
            val persp = 1f / (1.5f - z2 * 0.45f)
            val b = ((z2 + 1f) * 1.5f + 0.7f * sin(t * 6f + ph[i])).toInt().coerceIn(0, 3)
            val k = cnt[b]; val arr = pts[b]
            arr[k] = cx + x1 * spread * j * persp; arr[k + 1] = cy + y2 * spread * j * persp
            cnt[b] = k + 2
        }
        val bw = floatArrayOf(1.6f, 2.4f, 3.4f, 4.8f); val ba = intArrayOf(70, 120, 185, 255)
        for (b in 0..3) { p.strokeWidth = bw[b] * s; p.color = col((ba[b] * dim).toInt(), b * 12, b * 8); cv.drawPoints(pts[b], 0, cnt[b], p) }

        // orbiting 3D dotted rings with fading tails
        java.util.Arrays.fill(rcnt, 0)
        for (r in 0 until nr) {
            val a0 = t * ringSpd[r] * 1.6f; val tl = ringTilt[r] + 0.25f * sin(t * 0.5f + r)
            val ct = cos(tl); val stl = sin(tl); val cyz = cos(t * 0.4f + r); val syz = sin(t * 0.4f + r)
            val rr = R * ringRad[r] * (1f + lv * (if (compact) 0.15f else 0.3f))
            for (i in 0 until rn) {
                val tail = i / rn.toFloat()
                val ang = a0 + tail * 3.6f * (if (ringSpd[r] > 0) -1 else 1)
                val x = cos(ang) * rr; val z0 = sin(ang) * rr
                val y = z0 * stl; val z = z0 * ct
                val x2 = x * cyz + z * syz; val z2 = -x * syz + z * cyz
                val nz = z2 / (R * 1.7f)
                val persp = 1f / (1.5f - nz * 0.45f)
                val b = (((1f - tail) * 2.6f) + (nz + 1f) * 0.3f).toInt().coerceIn(0, 3)
                val k = rcnt[b]; val arr = rpts[b]
                arr[k] = cx + x2 * persp * 1.3f; arr[k + 1] = cy + y * persp * 1.3f
                rcnt[b] = k + 2
            }
        }
        val rw = floatArrayOf(1.4f, 2.2f, 3.2f, 4.6f); val ra = intArrayOf(60, 120, 190, 255)
        for (b in 0..3) { p.strokeWidth = rw[b] * s; p.color = col((ra[b] * dim).toInt(), 25 + b * 15, 20 + b * 12); cv.drawPoints(rpts[b], 0, rcnt[b], p) }

        // tapered comet arcs (thick bright head, thin fading tail)
        p.strokeJoin = Paint.Join.ROUND
        val na = if (compact) 3 else 5
        for (a in 0 until na) {
            val rr = R * (if (compact) 1.2f + a * 0.12f else 1.25f + a * 0.14f) * (1f + lv * 0.2f)
            val head = t * (2.2f + a * 0.9f) * (if (a % 2 == 0) 1 else -1) + a * 2.1f
            val sweep = 1.5f + a * 0.28f + lv * 1.5f
            val tl = 0.6f + a * 0.7f + 0.2f * sin(t * 0.6f + a)
            val ct = cos(tl); val stl = sin(tl); val cyz = cos(t * 0.5f + a); val syz = sin(t * 0.5f + a)
            for (k in 0..am) {
                val th = head - sweep * k / am
                val x = cos(th) * rr; val z0 = sin(th) * rr * 0.6f
                val y = z0 * stl; val z = z0 * ct
                val x2 = x * cyz + z * syz; val z2 = -x * syz + z * cyz
                val persp = 1f / (1.5f - (z2 / (R * 1.7f)) * 0.45f)
                arcX[k] = cx + x2 * persp * 1.3f; arcY[k] = cy + y * persp * 1.3f
            }
            val fr = floatArrayOf(1f, 0.65f, 0.35f, 0.15f); val wd = floatArrayOf(1.6f, 3.2f, 5.2f, 8f); val al = intArrayOf(110, 130, 140, 170)
            for (q in 0..3) {
                ap.reset(); ap.moveTo(arcX[0], arcY[0])
                val last = (fr[q] * am).toInt().coerceAtLeast(2)
                for (k in 1..last) ap.lineTo(arcX[k], arcY[k])
                p.strokeWidth = wd[q] * s * (0.8f + 0.25f * (a % 3)); p.color = col((al[q] * dim).toInt(), 40 + q * 22, 25 + q * 20)
                cv.drawPath(ap, p)
            }
        }

        // sparks: dots drifting outward and fading
        java.util.Arrays.fill(scnt, 0)
        for (i in 0 until ns) {
            sage[i] += 0.006f * sv[i] * (1f + lv * 3f) * (1f + spd * 20f)
            if (sage[i] >= 1f) { sage[i] = 0f }
            val a = sage[i]
            val x1 = sdx[i] * ca + sdz[i] * sa; val z1 = -sdx[i] * sa + sdz[i] * ca
            val y2 = sdy[i] * cb2 - z1 * sb
            val dist = R * (1.0f + a * (0.55f + lv * 0.9f)) * 1.3f
            val b = if (a < 0.4f) 2 else if (a < 0.75f) 1 else 0
            val k = scnt[b]; val arr = spts[b]
            arr[k] = cx + x1 * dist; arr[k + 1] = cy + y2 * dist; scnt[b] = k + 2
        }
        val sw = floatArrayOf(2.2f, 3.2f, 4.2f); val sal = intArrayOf(70, 150, 235)
        for (b in 0..2) { p.strokeWidth = sw[b] * s; p.color = col((sal[b] * dim).toInt(), 70, 50); cv.drawPoints(spts[b], 0, scnt[b], p) }

        // hot core
        p.style = Paint.Style.FILL
        val core = R * (0.38f + lv * 0.4f)
        val cr2 = min(core * (if (compact) 2.2f else 2.6f), half * 0.9f)
        p.shader = RadialGradient(cx, cy, cr2,
            intArrayOf(Color.argb((255 * dim).toInt(), 255, 250, 225), col((225 * dim).toInt(), 50, 40), col((65 * dim).toInt()), Color.TRANSPARENT),
            floatArrayOf(0f, 0.22f, 0.55f, 1f), Shader.TileMode.CLAMP)
        cv.drawCircle(cx, cy, cr2, p); p.shader = null
        p.xfermode = null
        postInvalidateOnAnimation()
    }
}
