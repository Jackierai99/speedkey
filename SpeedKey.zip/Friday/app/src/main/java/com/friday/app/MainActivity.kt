package com.friday.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {
    private val OR = Color.parseColor("#FF8A1F")
    private val h = Handler(Looper.getMainLooper())
    private lateinit var pages: List<View>
    private lateinit var tabs: List<TextView>
    private lateinit var emoLbl: TextView
    private lateinit var status: TextView
    private lateinit var keyBox: EditText
    private lateinit var testRes: TextView
    private lateinit var startBtn: Button
    private lateinit var chatBox: LinearLayout
    private lateinit var chatScroll: ScrollView
    private lateinit var dashBox: LinearLayout
    private var tab = 0

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun glass(r: Int = 16, stroke: Boolean = true) = GradientDrawable().apply {
        cornerRadius = dp(r).toFloat(); setColor(Color.parseColor("#16FFFFFF"))
        if (stroke) setStroke(dp(1), Color.parseColor("#44FF8A1F"))
    }
    private fun solid(c: Int, r: Int = 16) = GradientDrawable().apply { cornerRadius = dp(r).toFloat(); setColor(c) }
    private fun tv(t: String, sz: Float = 14f, c: Int = Color.WHITE) = TextView(this).apply { text = t; textSize = sz; setTextColor(c) }
    private fun btn(t: String, bg: Int = OR) = Button(this).apply { text = t; setTextColor(Color.BLACK); isAllCaps = false; textSize = 15f; background = solid(bg) }
    private fun lbl(t: String) = tv(t, 12f, OR).apply { setPadding(0, dp(18), 0, dp(6)) }
    private fun card(title: String, body: String, ok: Boolean? = null) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = glass(); setPadding(dp(16), dp(12), dp(16), dp(12))
        addView(tv(title, 12f, OR)); addView(tv(body, 15f, when (ok) { true -> Color.parseColor("#4CD964"); false -> Color.parseColor("#FF5252"); else -> Color.WHITE }))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
    }
    private fun sw(label: String, on: Boolean, f: (Boolean) -> Unit) = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL; background = glass(); setPadding(dp(16), dp(10), dp(16), dp(10))
        addView(tv(label, 14f), LinearLayout.LayoutParams(0, -2, 1f))
        addView(Switch(this@MainActivity).apply {
            isChecked = on; setOnCheckedChangeListener { _, c -> f(c) }
            val cs = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(OR, Color.GRAY))
            thumbTintList = cs; trackTintList = cs
        })
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
    }
    private fun scroll(inner: LinearLayout) = ScrollView(this).apply { addView(inner) }
    private fun col() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(18)) }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.statusBarColor = Color.BLACK; window.navigationBarColor = Color.BLACK
        Bus.muted = Prefs.muted(this); Bus.screenLive = Prefs.screen(this)

        // ---------- HOME
        val home = col().apply { gravity = Gravity.CENTER_HORIZONTAL }
        home.addView(tv("F R I D A Y", 22f, OR).apply { gravity = Gravity.CENTER })
        home.addView(OrbView(this), LinearLayout.LayoutParams(-1, 0, 1f))
        emoLbl = tv("", 18f).apply { gravity = Gravity.CENTER }; home.addView(emoLbl)
        status = tv(Bus.status, 13f, Color.LTGRAY).apply { gravity = Gravity.CENTER; setPadding(0, dp(4), 0, dp(10)) }; home.addView(status)
        Bus.onStatus = { runOnUiThread { status.text = Bus.status } }
        home.addView(sw("📺  Screen Live (Private Mode: OFF karo)", Bus.screenLive) { Bus.screenLive = it; Prefs.save(this, sc = it) })
        home.addView(sw("🔇  Friday ki Awaaz Mute (jawab chalta rahega)", Bus.muted) { Bus.muted = it; Prefs.save(this, mu = it) })
        startBtn = btn("")
        home.addView(startBtn, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(14) })
        startBtn.setOnClickListener { if (Bus.running) { stopService(Intent(this, FridayService::class.java)); refresh() } else start() }

        // ---------- CHAT
        val chat = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(10)) }
        chat.addView(tv("💬  Chat", 20f, OR))
        chatBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(10), 0, dp(10)) }
        chatScroll = scroll(chatBox); chat.addView(chatScroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val input = EditText(this).apply { hint = "Friday ko likho..."; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); background = glass(24); setPadding(dp(16), dp(10), dp(16), dp(10)); maxLines = 3 }
        val send = btn("➤").apply { setOnClickListener {
            val t = input.text.toString().trim()
            if (t.isNotEmpty()) { Bus.say(true, t); FridayService.inst?.client?.sendText(t); input.setText("") } } }
        chat.addView(LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL
            addView(input, LinearLayout.LayoutParams(0, -2, 1f)); addView(send, LinearLayout.LayoutParams(dp(56), dp(48)).apply { leftMargin = dp(8) }) })
        Bus.onChat = { runOnUiThread { renderChat() } }

        // ---------- DASHBOARD
        dashBox = col(); val dash = scroll(dashBox)

        // ---------- SETTINGS
        val st = col()
        st.addView(tv("⚙️  Settings", 20f, OR))
        st.addView(lbl("GEMINI API KEY"))
        keyBox = EditText(this).apply {
            setText(Prefs.key(this@MainActivity)); setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); hint = "AIza..."
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD; background = glass(); setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        st.addView(keyBox)
        st.addView(btn("🔑  Key Test Karo", Color.WHITE).apply { setOnClickListener { testKey() } }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10) })
        testRes = tv("", 14f, Color.LTGRAY).apply { setPadding(0, dp(8), 0, 0) }; st.addView(testRes)
        st.addView(lbl("VOICE (5 options)"))
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, Prefs.VOICES)
        sp.setSelection(Prefs.VOICES.indexOf(Prefs.voice(this)).coerceAtLeast(0))
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, i: Int, id: Long) { Prefs.save(this@MainActivity, v = Prefs.VOICES[i]) }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        sp.background = glass(); st.addView(sp, LinearLayout.LayoutParams(-1, dp(48)))
        st.addView(tv("Voice badalne ke baad Friday ko Band → Shuru karo.", 12f, Color.GRAY).apply { setPadding(0, dp(6), 0, 0) })
        st.addView(lbl("LIVE MODEL (fast/natural)"))
        val ml = (Prefs.models(this) + Prefs.model(this)).filter { it.isNotBlank() }.distinct()
        if (ml.isEmpty()) st.addView(tv("Pehle 'Key Test Karo' dabao, phir yahan models dikhenge. Agar jawab slow lage to yahan se 'live' wala (native-audio nahi) model chuno, wo aksar tez hota hai.", 12f, Color.GRAY))
        else {
            val msp = Spinner(this); msp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, ml)
            msp.setSelection(ml.indexOf(Prefs.model(this)).coerceAtLeast(0))
            msp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, i: Int, id: Long) { Prefs.save(this@MainActivity, m = ml[i]) }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
            msp.background = glass(); st.addView(msp, LinearLayout.LayoutParams(-1, dp(48)))
            st.addView(tv("Model badalne ke baad Friday ko Band → Shuru karo.", 12f, Color.GRAY).apply { setPadding(0, dp(6), 0, 0) })
        }
        st.addView(lbl("PHONE CONTROL"))
        st.addView(btn("♿  Accessibility Enable Karo").apply { setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } }, LinearLayout.LayoutParams(-1, dp(48)))
        st.addView(tv("Agar enable na ho paaye: Phone Settings → Apps → Friday → ⋮ → 'Allow restricted settings', phir dobara try karo.", 12f, Color.GRAY).apply { setPadding(0, dp(6), 0, 0) })
        st.addView(lbl("BINA ACCESSIBILITY SETTING WALE PHONE"))
        st.addView(btn("⚡  Auto-Enable Accessibility", Color.WHITE).apply { setOnClickListener {
            val ok = AccessHelper.tryEnable(this@MainActivity)
            Toast.makeText(this@MainActivity, if (ok) "Enable kar diya ✅ (2-3 sec mein Dashboard dekho)" else "Pehle neeche wali ADB permission ek baar do", Toast.LENGTH_LONG).show()
        } }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) })
        st.addView(btn("📱  App Info (Restricted Settings)", Color.WHITE).apply { setOnClickListener {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        } }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) })
        st.addView(btn("📖  Ek-baar ADB Guide (sirf apne phone se)", Color.WHITE).apply { setOnClickListener { showAdbGuide() } }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) })
        st.addView(tv("Accessibility ke bina bhi chalte hain: app kholna, link/Google search, call dialer, music next/play, torch, volume. Tap/scroll/type ke liye accessibility chahiye; agar Settings mein option hi nahi dikhta to ADB guide se ek baar permission do, phir 'Auto-Enable' khud chalu kar dega.", 12f, Color.GRAY).apply { setPadding(0, dp(6), 0, 0) })
        st.addView(lbl("FRIDAY KI YAADDASHT"))
        st.addView(btn("🧹  Yaaddasht Saaf Karo", Color.parseColor("#FF5252")).apply { setOnClickListener { Prefs.clearNotes(this@MainActivity); Toast.makeText(this@MainActivity, "Saaf ho gayi", Toast.LENGTH_SHORT).show() } }, LinearLayout.LayoutParams(-1, dp(48)))

        pages = listOf(home, chat, dash, scroll(st))
        val frame = FrameLayout(this); pages.forEach { frame.addView(it, FrameLayout.LayoutParams(-1, -1)) }
        val names = listOf("🏠\nHome", "💬\nChat", "📊\nDashboard", "⚙️\nSettings")
        tabs = names.mapIndexed { i, n -> tv(n, 12f, Color.GRAY).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(8)); setOnClickListener { showTab(i) } } }
        val nav = LinearLayout(this).apply { background = solid(Color.parseColor("#101010"), 0); tabs.forEach { addView(it, LinearLayout.LayoutParams(0, -2, 1f)) } }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.BLACK, Color.parseColor("#1A0A00")))
            addView(frame, LinearLayout.LayoutParams(-1, 0, 1f)); addView(nav, LinearLayout.LayoutParams(-1, -2))
        }
        setContentView(root)
        showTab(0); refresh(); renderChat()
        tick()
        if (Prefs.key(this).isNotBlank() && !Bus.running) start()   // open hote hi Live connect
    }


    private fun showAdbGuide() {
        val cmd = "adb shell pm grant $packageName android.permission.WRITE_SECURE_SETTINGS"
        val msg = "Ye ek baar karna hai (Android 11+, PC nahi chahiye):\n\n" +
            "1) Settings → About phone → Build number 7 baar dabao (Developer options on)\n" +
            "2) Developer options → 'Wireless debugging' ON karo → 'Pair device with pairing code' dabao (code + IP:port dikhega)\n" +
            "3) Termux install karo (F-Droid se) aur ye chalao:\n   pkg install android-tools\n   adb pair IP:PAIRPORT   (code daalo)\n   adb connect IP:PORT\n   $cmd\n" +
            "4) Wapas yahan aao → 'Auto-Enable Accessibility' dabao.\n\nPhone restart ke baad bhi permission bani rehti hai. Command copy karne ke liye neeche button dabao."
        android.app.AlertDialog.Builder(this).setTitle("Bina Accessibility Settings ke").setMessage(msg)
            .setPositiveButton("Command Copy") { _, _ ->
                (getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("adb", cmd))
                Toast.makeText(this, "Copy ho gaya", Toast.LENGTH_SHORT).show() }
            .setNegativeButton("Band", null).show()
    }

    private fun showTab(i: Int) {
        tab = i
        pages.forEachIndexed { k, v -> v.visibility = if (k == i) View.VISIBLE else View.GONE; if (k == i) { v.alpha = 0f; v.animate().alpha(1f).setDuration(220).start() } }
        tabs.forEachIndexed { k, t -> t.setTextColor(if (k == i) OR else Color.GRAY) }
        if (i == 2) renderDash()
    }

    private fun tick() {
        emoLbl.text = when (Bus.emotion) { "happy" -> "😄 Khush"; "caring" -> "🥰 Care"; "angry" -> "😡 Gussa"; "sulking" -> "😒 Ruthi hui"; "thinking" -> "🤔 Soch rahi hai"; else -> "😌 Shaant" }
        refresh(); if (tab == 2) renderDash()
        h.postDelayed({ tick() }, 1000)
    }

    private fun refresh() { startBtn.text = if (Bus.running) "⏹  Friday Band Karo" else "▶  Friday Shuru Karo" }

    private fun renderChat() {
        chatBox.removeAllViews()
        if (Bus.chat.isEmpty()) chatBox.addView(tv("Abhi koi baat nahi hui. Bolo ya likho 🙂", 14f, Color.GRAY))
        Bus.chat.forEach { (u, t) ->
            chatBox.addView(TextView(this).apply {
                text = t; textSize = 15f; maxWidth = dp(280); setPadding(dp(14), dp(10), dp(14), dp(10))
                setTextColor(if (u) Color.BLACK else Color.WHITE); background = if (u) solid(OR, 18) else glass(18)
                layoutParams = LinearLayout.LayoutParams(-2, -2).apply { gravity = if (u) Gravity.END else Gravity.START; bottomMargin = dp(8) }
            })
        }
        chatScroll.post { chatScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun renderDash() {
        dashBox.removeAllViews()
        dashBox.addView(tv("📊  Dashboard", 20f, OR).apply { setPadding(0, 0, 0, dp(12)) })
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val bat = (getSystemService(BATTERY_SERVICE) as BatteryManager).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        dashBox.addView(card("🔗 CONNECTION", Bus.status, Bus.status.contains("✅")))
        dashBox.addView(card("♿ ACCESSIBILITY (tap/scroll/screen)", if (FridayAccess.inst != null) "ON ✅" else "OFF ❌ — Settings tab se enable karo", FridayAccess.inst != null))
        dashBox.addView(card("⚡ AUTO-ENABLE PERMISSION", if (AccessHelper.canWrite(this)) "Mili hui hai ✅" else "Nahi (Settings → ADB guide)", AccessHelper.canWrite(this)))
        dashBox.addView(card("🪟 DISPLAY OVER APPS", if (Settings.canDrawOverlays(this)) "Allowed ✅" else "Not allowed ❌", Settings.canDrawOverlays(this)))
        dashBox.addView(card("🎙 MIC PERMISSION", if (mic) "Allowed ✅" else "Not allowed ❌", mic))
        dashBox.addView(card("📺 SCREEN LIVE", if (Bus.screenLive) "ON (Friday screen dekh rahi hai)" else "OFF (Private Mode)", Bus.screenLive))
        dashBox.addView(card("🧠 MODEL / VOICE", "${Prefs.model(this)}  •  ${Prefs.voice(this)}"))
        dashBox.addView(card("⚡ COMMANDS CHALE", "${Bus.cmdCount}"))
        dashBox.addView(card("🔋 BATTERY", "$bat%"))
        dashBox.addView(card("🕘 RECENT COMMANDS", if (Bus.cmds.isEmpty()) "Abhi koi nahi" else Bus.cmds.joinToString("\n")))
    }

    private fun start() {
        Prefs.save(this, k = keyBox.text.toString().trim())
        if (Prefs.key(this).isBlank()) { showTab(3); testRes.text = "Pehle API key daalo"; return }
        val need = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isNotEmpty()) { requestPermissions(need.toTypedArray(), 1); return }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Friday ko 'Display over other apps' permission do", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); return
        }
        startForegroundService(Intent(this, FridayService::class.java)); refresh()
    }

    override fun onRequestPermissionsResult(r: Int, p: Array<out String>, g: IntArray) { start() }
    override fun onResume() {
        super.onResume(); refresh()
        if (Prefs.key(this).isNotBlank() && !Bus.running && Settings.canDrawOverlays(this) &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) start()
    }
    override fun onDestroy() { h.removeCallbacksAndMessages(null); Bus.onStatus = null; Bus.onChat = null; super.onDestroy() }

    private fun testKey() {
        val k = keyBox.text.toString().trim(); Prefs.save(this, k = k)
        testRes.setTextColor(Color.LTGRAY); testRes.text = "Test ho raha hai..."
        Thread {
            var ok = false; var msg: String
            try {
                val c = URL("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200&key=$k").openConnection() as HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 8000
                if (c.responseCode == 200) {
                    val arr = JSONObject(c.inputStream.bufferedReader().readText()).getJSONArray("models")
                    val live = (0 until arr.length()).map { arr.getJSONObject(it) }
                        .filter { (it.optJSONArray("supportedGenerationMethods")?.toString() ?: "").contains("bidiGenerateContent") }
                        .map { it.getString("name").removePrefix("models/") }
                    val best = live.filter { it.contains("native-audio") }.sortedDescending().firstOrNull() ?: live.firstOrNull()
                    if (best != null && Prefs.model(this).isBlank()) Prefs.save(this, m = best)
                    Prefs.saveModels(this, live.sortedByDescending { it.contains("native-audio") })
                    ok = true; msg = "✅ Key lag gayi! Live model: ${best ?: "nahi mila"}"
                } else msg = if (c.responseCode == 400 || c.responseCode == 403) "❌ Key galat hai ya allowed nahi (${c.responseCode})" else "❌ Error ${c.responseCode}"
            } catch (e: Exception) { msg = "❌ Internet/Network problem: ${e.message}" }
            runOnUiThread { testRes.text = msg; testRes.setTextColor(if (ok) Color.parseColor("#4CD964") else Color.parseColor("#FF5252")) }
        }.start()
    }
}
