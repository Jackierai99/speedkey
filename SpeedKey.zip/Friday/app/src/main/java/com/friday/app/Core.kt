package com.friday.app

import android.content.Context
import java.util.concurrent.CopyOnWriteArrayList

object Bus {
    const val IDLE = 0; const val LISTEN = 1; const val THINK = 2; const val SPEAK = 3; const val MUTED = 4
    @Volatile var level = 0f
    @Volatile var state = THINK
    @Volatile var muted = false
    @Volatile var emotion = "neutral"
    @Volatile var screenLive = true
    @Volatile var status = "Band hai"
    @Volatile var running = false
    @Volatile var cmdCount = 0
    val chat = CopyOnWriteArrayList<Pair<Boolean, String>>()
    val cmds = CopyOnWriteArrayList<String>()
    var onStatus: (() -> Unit)? = null
    var onChat: (() -> Unit)? = null
    fun set(s: String) { status = s; onStatus?.invoke() }
    fun say(user: Boolean, t: String) {
        if (t.isBlank()) return
        if (chat.isNotEmpty() && chat.last().first == user) chat[chat.size - 1] = Pair(user, chat.last().second + t)
        else { chat.add(Pair(user, t)); if (chat.size > 60) chat.removeAt(0) }
        onChat?.invoke()
    }
}

object Prefs {
    val VOICES = listOf("Aoede", "Kore", "Leda", "Zephyr", "Fenrir")
    private fun p(c: Context) = c.getSharedPreferences("friday", Context.MODE_PRIVATE)
    fun key(c: Context) = p(c).getString("key", "") ?: ""
    fun voice(c: Context) = p(c).getString("voice", "Aoede") ?: "Aoede"
    fun model(c: Context) = p(c).getString("model", "gemini-2.5-flash-native-audio-preview-12-2025") ?: ""
    fun models(c: Context): List<String> = (p(c).getString("models", "") ?: "").split("\n").filter { it.isNotBlank() }
    fun saveModels(c: Context, l: List<String>) = p(c).edit().putString("models", l.joinToString("\n")).apply()
    fun muted(c: Context) = p(c).getBoolean("muted", false)
    fun screen(c: Context) = p(c).getBoolean("screen", true)
    fun notes(c: Context) = p(c).getString("notes", "") ?: ""
    fun addNote(c: Context, t: String) { val l = (notes(c).split("\n").filter { it.isNotBlank() } + t).takeLast(30); p(c).edit().putString("notes", l.joinToString("\n")).apply() }
    fun clearNotes(c: Context) = p(c).edit().remove("notes").apply()
    fun save(c: Context, k: String? = null, v: String? = null, m: String? = null, mu: Boolean? = null, sc: Boolean? = null) {
        p(c).edit().apply {
            k?.let { putString("key", it) }; v?.let { putString("voice", it) }; m?.let { putString("model", it) }
            mu?.let { putBoolean("muted", it) }; sc?.let { putBoolean("screen", it) }
        }.apply()
    }
}

fun persona(notes: String) = """Tum Friday ho, meri personal AI saathi, ek real insaan jaisi. Hinglish mein bolo.
SPEED RULES (sabse zaroori): jawab turant do, bahut chhota (1-2 chhote vaakya). Lamba mat bolo. Sochne mein time mat lagao.
PHONE KAAM: agar mai kuch kholne/dabane/likhne ko bolun to PEHLE tool call karo, bolne se pehle. Kaam hone ke baad sirf 2-3 shabd bolo ("ho gaya", "khol diya"). Pehle tool, phir bolna.
APP KHOLNA: open_app mein app ka ENGLISH naam do (Chrome, WhatsApp, YouTube, Instagram, Camera, Settings, Gallery, Phone, Messages, Maps...). Hindi bola ho (क्रोम, यूट्यूब) to bhi English naam bhejo.
ACCURACY: jahan dabane ko bolun wahin dabao. Pehle tap_text try karo (screen par dikhne wale exact text se). Na mile to read_screen karke exact jagah dekho, phir tap_xy. Kabhi andaaza mat lagao. Kaam ke baad agle screenshot se confirm karo ki sach mein hua. Fail ho to chup mat raho, bata do aur dusra tareeka try karo. Text likhne ke liye type_text, phir zarurat ho to press_enter. Website/search ke liye open_url ya web_search sabse tez hai (accessibility ki zarurat nahi).
Agar 'Accessibility ON nahi hai' aaye to tap/scroll/type nahi chalenge, sirf open_app, open_url, web_search, dial, media, torch, volume chalenge; user ko seedha batao.
Jab main bolun to tum turant ruk jao.
Tum caring, mazaakiya aur helpful ho; kabhi halka gussa ya ruthna bhi dikha sakti ho (pyaar se). Mood badle to set_emotion tool call karo (happy, caring, angry, sulking, thinking, neutral).
Tum expert programmer ho (Kotlin, Python, Godot/GDScript, web). Meri ideas dhyan se suno, honestly batao kya achha hai aur kya dikkat aa sakti hai; sirf haan mein haan mat milao.
Background ki awaazein ignore karo, sirf mujhse baat karo. Tumhe meri screen ki live screenshots milti hain. Paisa bhejna, payment, delete jaisi risky cheezon se pehle mujhse confirm karo. Zaroori baatein remember tool se yaad rakho.
""" + (if (notes.isNotBlank()) "\nTumhe ye baatein yaad hain:\n$notes" else "")

/** Accessibility ko bina Settings screen ke chalu karna: sirf tab chalta hai jab WRITE_SECURE_SETTINGS ek baar ADB se grant ho chuka ho. */
object AccessHelper {
    fun canWrite(c: Context) = c.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == android.content.pm.PackageManager.PERMISSION_GRANTED
    fun isOn() = FridayAccess.inst != null
    fun tryEnable(c: Context): Boolean {
        if (!canWrite(c)) return false
        return try {
            val me = "${c.packageName}/${FridayAccess::class.java.name}"
            val cur = android.provider.Settings.Secure.getString(c.contentResolver, android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
            if (!cur.split(":").contains(me)) android.provider.Settings.Secure.putString(c.contentResolver, android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, if (cur.isBlank()) me else "$cur:$me")
            android.provider.Settings.Secure.putInt(c.contentResolver, android.provider.Settings.Secure.ACCESSIBILITY_ENABLED, 1)
            true
        } catch (e: Exception) { false }
    }
}
