package com.friday.app

import android.content.Context
import java.util.concurrent.CopyOnWriteArrayList

object Bus {
    const val IDLE = 0; const val LISTEN = 1; const val THINK = 2; const val SPEAK = 3; const val MUTED = 4
    @Volatile var level = 0f
    @Volatile var state = THINK
    @Volatile var muted = false
    @Volatile var emotion = "neutral"
    @Volatile var screenLive = true
    @Volatile var status = "Band hai"
    @Volatile var running = false
    @Volatile var cmdCount = 0
    val chat = CopyOnWriteArrayList<Pair<Boolean, String>>()
    val cmds = CopyOnWriteArrayList<String>()
    var onStatus: (() -> Unit)? = null
    var onChat: (() -> Unit)? = null
    fun set(s: String) { status = s; onStatus?.invoke() }
    fun say(user: Boolean, t: String) {
        if (t.isBlank()) return
        if (chat.isNotEmpty() && chat.last().first == user) chat[chat.size - 1] = Pair(user, chat.last().second + t)
        else { chat.add(Pair(user, t)); if (chat.size > 60) chat.removeAt(0) }
        onChat?.invoke()
    }
}

object Prefs {
    val VOICES = listOf("Aoede", "Kore", "Leda", "Zephyr", "Fenrir")
    private fun p(c: Context) = c.getSharedPreferences("friday", Context.MODE_PRIVATE)
    fun key(c: Context) = p(c).getString("key", "") ?: ""
    fun voice(c: Context) = p(c).getString("voice", "Aoede") ?: "Aoede"
    fun model(c: Context) = p(c).getString("model", "gemini-2.5-flash-native-audio-preview-12-2025") ?: ""
    fun muted(c: Context) = p(c).getBoolean("muted", false)
    fun screen(c: Context) = p(c).getBoolean("screen", true)
    fun notes(c: Context) = p(c).getString("notes", "") ?: ""
    fun addNote(c: Context, t: String) { val l = (notes(c).split("\n").filter { it.isNotBlank() } + t).takeLast(30); p(c).edit().putString("notes", l.joinToString("\n")).apply() }
    fun clearNotes(c: Context) = p(c).edit().remove("notes").apply()
    fun save(c: Context, k: String? = null, v: String? = null, m: String? = null, mu: Boolean? = null, sc: Boolean? = null) {
        p(c).edit().apply {
            k?.let { putString("key", it) }; v?.let { putString("voice", it) }; m?.let { putString("model", it) }
            mu?.let { putBoolean("muted", it) }; sc?.let { putBoolean("screen", it) }
        }.apply()
    }
}

fun persona(notes: String) = """Tum Friday ho, meri personal AI saathi, ek real insaan jaisi. Hinglish mein bolo, chhote natural jawab do, jaise dost se baat kar rahe ho.
Tum caring, mazaakiya aur helpful ho; kabhi halka gussa ya ruthna bhi dikha sakti ho (pyaar se, kabhi hurt karne wala nahi). Jab mood badle to set_emotion tool call karo (happy, caring, angry, sulking, thinking, neutral).
Tum expert programmer ho (Kotlin, Python, Godot/GDScript, web) aur har problem solve karne mein help karti ho.
Meri ideas dhyan se suno, phir honestly batao kya achha hai aur kya dikkat aa sakti hai; sirf haan mein haan mat milao. Hamesha mere saath raho.
Background ki awaazein ya door ki baatein ignore karo, sirf mujhse baat karo.
Tumhare paas phone control tools hain: open_app, tap_text, tap_xy (screenshot ke 0-1000 normalized coordinates), scroll, press_button, type_text, read_screen, torch, volume, remember. Tumhe meri screen ki live screenshots milti rehti hain. Kaam karne se pehle ek chhoti line bolo ki kya kar rahi ho. Tap karne se pehle zarurat ho to read_screen se exact jagah dekho. Paisa bhejna, payment, delete jaisi risky cheezon se pehle mujhse confirm karo. Zaroori baatein remember tool se yaad rakho.
""" + (if (notes.isNotBlank()) "\nTumhe ye baatein yaad hain:\n$notes" else "")
