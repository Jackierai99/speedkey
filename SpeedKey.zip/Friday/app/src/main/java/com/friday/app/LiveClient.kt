package com.friday.app

import android.util.Base64
import okhttp3.*
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class LiveClient(private val key: String, private val model: String, private val voice: String, private val persona: String, private val thinkOff: Boolean, private val cb: Cb) {
    interface Cb {
        fun ready(); fun audio(pcm: ByteArray); fun interrupted(); fun turnDone(); fun closed(err: String?)
        fun tool(id: String, name: String, args: JSONObject); fun chat(user: Boolean, text: String)
    }

    private val http = OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).readTimeout(0, TimeUnit.SECONDS).build()
    @Volatile private var ws: WebSocket? = null
    @Volatile var open = false

    fun connect() {
        val url = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=$key"
        ws = http.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
            override fun onOpen(w: WebSocket, r: Response) { w.send(setup().toString()) }
            override fun onMessage(w: WebSocket, text: String) = parse(text)
            override fun onMessage(w: WebSocket, bytes: ByteString) = parse(bytes.utf8())
            override fun onClosed(w: WebSocket, code: Int, reason: String) { open = false; cb.closed("$code $reason") }
            override fun onFailure(w: WebSocket, t: Throwable, r: Response?) { open = false; cb.closed(t.message ?: "fail") }
        })
    }

    private fun fn(n: String, d: String, vararg p: Pair<String, String>): JSONObject {
        val o = JSONObject().put("name", n).put("description", d)
        if (p.isNotEmpty()) {
            val pr = JSONObject(); p.forEach { pr.put(it.first, JSONObject().put("type", it.second)) }
            o.put("parameters", JSONObject().put("type", "OBJECT").put("properties", pr).put("required", JSONArray(p.map { it.first })))
        }
        return o
    }

    private fun tools() = JSONArray().put(JSONObject().put("functionDeclarations", JSONArray(listOf(
        fn("open_app", "Phone mein app kholo naam se", "name" to "STRING"),
        fn("tap_text", "Screen par dikhe text/button par tap karo", "text" to "STRING"),
        fn("tap_xy", "Screenshot ke normalized coordinates (0-1000) par tap karo", "x" to "NUMBER", "y" to "NUMBER"),
        fn("scroll", "Scroll/swipe karo. direction: up, down, left, right (down = neeche ka content dikhao)", "direction" to "STRING"),
        fn("press_button", "back, home, recents ya notifications dabao", "button" to "STRING"),
        fn("type_text", "Focused text box mein text likho", "text" to "STRING"),
        fn("read_screen", "Screen ka text aur unki jagah padho"),
        fn("set_emotion", "Apna mood set karo: happy, caring, angry, sulking, thinking, neutral", "emotion" to "STRING"),
        fn("remember", "Koi zaroori baat hamesha ke liye yaad rakho", "note" to "STRING"),
        fn("torch", "Flashlight on/off. on = true ya false", "on" to "STRING"),
        fn("volume", "Volume up ya down", "direction" to "STRING"),
        fn("press_enter", "Keyboard ka Enter/Search/Go dabao (text likhne ke baad)"),
        fn("open_url", "Browser mein link ya website kholo (bina accessibility ke bhi chalta hai)", "url" to "STRING"),
        fn("web_search", "Google par kuch search karo (bina accessibility ke bhi chalta hai)", "query" to "STRING"),
        fn("dial", "Phone dialer mein number kholo (bina accessibility ke)", "number" to "STRING"),
        fn("media", "Music/video control: play_pause, next, previous (bina accessibility ke)", "action" to "STRING")
    ))))

    private fun setup() = JSONObject().put("setup", JSONObject()
        .put("model", "models/$model")
        .put("generationConfig", JSONObject()
            .put("responseModalities", JSONArray().put("AUDIO"))
            .also { if (thinkOff) it.put("thinkingConfig", JSONObject().put("thinkingBudget", 0)) }
            .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice)))))
        .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", persona))))
        .put("tools", tools())
        .put("inputAudioTranscription", JSONObject()).put("outputAudioTranscription", JSONObject())
        .put("realtimeInputConfig", JSONObject().put("automaticActivityDetection", JSONObject()
            .put("startOfSpeechSensitivity", "START_SENSITIVITY_HIGH")
            .put("endOfSpeechSensitivity", "END_SENSITIVITY_HIGH")
            .put("prefixPaddingMs", 120).put("silenceDurationMs", 350))))

    private fun parse(s: String) {
        try {
            val j = JSONObject(s)
            if (j.has("setupComplete")) { open = true; cb.ready() }
            j.optJSONObject("toolCall")?.optJSONArray("functionCalls")?.let { fc ->
                for (i in 0 until fc.length()) { val f = fc.getJSONObject(i); cb.tool(f.optString("id"), f.optString("name"), f.optJSONObject("args") ?: JSONObject()) }
            }
            val sc = j.optJSONObject("serverContent") ?: return
            if (sc.optBoolean("interrupted")) cb.interrupted()
            sc.optJSONObject("inputTranscription")?.optString("text")?.let { cb.chat(true, it) }
            sc.optJSONObject("outputTranscription")?.optString("text")?.let { cb.chat(false, it) }
            sc.optJSONObject("modelTurn")?.optJSONArray("parts")?.let { ps ->
                for (i in 0 until ps.length()) ps.getJSONObject(i).optJSONObject("inlineData")?.optString("data")?.let { cb.audio(Base64.decode(it, Base64.DEFAULT)) }
            }
            if (sc.optBoolean("turnComplete")) cb.turnDone()
        } catch (_: Exception) {}
    }

    private fun rt(k: String, o: JSONObject) { if (open) ws?.send(JSONObject().put("realtimeInput", JSONObject().put(k, o)).toString()) }
    fun sendAudio(buf: ByteArray, len: Int) = rt("audio", JSONObject().put("data", Base64.encodeToString(buf, 0, len, Base64.NO_WRAP)).put("mimeType", "audio/pcm;rate=16000"))
    fun sendVideo(jpg: ByteArray) = rt("video", JSONObject().put("data", Base64.encodeToString(jpg, Base64.NO_WRAP)).put("mimeType", "image/jpeg"))
    fun sendText(t: String) { if (open) ws?.send(JSONObject().put("realtimeInput", JSONObject().put("text", t)).toString()) }
    fun toolResponse(id: String, name: String, res: String) {
        if (!open) return
        ws?.send(JSONObject().put("toolResponse", JSONObject().put("functionResponses", JSONArray().put(
            JSONObject().put("id", id).put("name", name).put("response", JSONObject().put("result", res))))).toString())
    }
    fun close() { open = false; ws?.close(1000, null); ws = null }
}
