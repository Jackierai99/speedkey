package com.friday.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.io.ByteArrayOutputStream
import kotlin.math.max

class FridayAccess : AccessibilityService() {
    companion object { @Volatile var inst: FridayAccess? = null; @Volatile var dirty = true }

    override fun onServiceConnected() { inst = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) { dirty = true }
    override fun onInterrupt() {}
    override fun onUnbind(i: Intent?): Boolean { inst = null; return super.onUnbind(i) }

    private fun gesture(path: Path, dur: Long): Boolean =
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, dur)).build(), null, null)

    fun tapPx(x: Float, y: Float) = gesture(Path().apply { moveTo(x, y) }, 60)
    fun tapNorm(x: Float, y: Float): Boolean { val d = resources.displayMetrics; return tapPx(x / 1000f * d.widthPixels, y / 1000f * d.heightPixels) }

    fun scroll(dir: String): Boolean {
        val d = resources.displayMetrics; val w = d.widthPixels.toFloat(); val h = d.heightPixels.toFloat()
        val p = Path()
        when (dir.lowercase()) {
            "down" -> { p.moveTo(w / 2, h * 0.72f); p.lineTo(w / 2, h * 0.28f) }
            "up" -> { p.moveTo(w / 2, h * 0.28f); p.lineTo(w / 2, h * 0.72f) }
            "right" -> { p.moveTo(w * 0.8f, h / 2); p.lineTo(w * 0.2f, h / 2) }
            "left" -> { p.moveTo(w * 0.2f, h / 2); p.lineTo(w * 0.8f, h / 2) }
            else -> return false
        }
        return gesture(p, 320)
    }

    fun press(b: String): Boolean = when (b.lowercase()) {
        "back" -> performGlobalAction(GLOBAL_ACTION_BACK); "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
        "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS); "notifications" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
        else -> false
    }

    private fun allNodes(root: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?, d: Int) {
            if (n == null || out.size > 600 || d > 40) return
            out.add(n); for (i in 0 until n.childCount) walk(n.getChild(i), d + 1)
        }
        walk(root, 0); return out
    }
    private fun label(n: AccessibilityNodeInfo) = (n.text?.toString() ?: "") + "|" + (n.contentDescription?.toString() ?: "") + "|" + (n.hintText?.toString() ?: "")
    private fun norm(x: String) = x.lowercase().filter { it.isLetterOrDigit() }

    /** Best match: exact > starts-with > contains; visible + clickable preferred. */
    fun tapText(t: String): Boolean {
        val q = norm(t); if (q.isEmpty()) return false
        val roots = windows?.mapNotNull { it.root }?.ifEmpty { null } ?: listOfNotNull(rootInActiveWindow)
        var best: AccessibilityNodeInfo? = null; var bestScore = 0
        for (root in roots) for (n in allNodes(root)) {
            if (!n.isVisibleToUser) continue
            var sc = 0
            for (part in label(n).split("|")) {
                val p = norm(part); if (p.isEmpty()) continue
                sc = max(sc, when { p == q -> 100; p.startsWith(q) -> 70; q.length >= 3 && p.contains(q) -> 50; p.length >= 3 && q.contains(p) -> 25; else -> 0 })
            }
            if (sc == 0) continue
            var c: AccessibilityNodeInfo? = n; var clickable = false
            while (c != null) { if (c.isClickable) { clickable = true; break }; c = c.parent }
            if (clickable) sc += 10
            if (sc > bestScore) { bestScore = sc; best = n }
        }
        val n = best ?: return false
        var c: AccessibilityNodeInfo? = n
        while (c != null && !c.isClickable) c = c.parent
        if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        val r = Rect(); n.getBoundsInScreen(r)
        return if (!r.isEmpty) tapPx(r.exactCenterX(), r.exactCenterY()) else false
    }

    fun typeText(t: String): Boolean {
        val root = rootInActiveWindow ?: return false
        var n = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (n == null) {
            n = allNodes(root).firstOrNull { it.isEditable && it.isVisibleToUser }
            n?.performAction(AccessibilityNodeInfo.ACTION_CLICK); n?.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        }
        if (n == null) return false
        val b = Bundle(); b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t)
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    fun pressEnter(): Boolean {
        val root = rootInActiveWindow ?: return false
        val n = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: allNodes(root).firstOrNull { it.isEditable && it.isVisibleToUser } ?: return false
        return if (Build.VERSION.SDK_INT >= 30) n.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id) else false
    }

    fun readScreen(): String {
        val roots = windows?.mapNotNull { it.root }?.ifEmpty { null } ?: listOfNotNull(rootInActiveWindow)
        if (roots.isEmpty()) return "screen read nahi ho paayi"
        val d = resources.displayMetrics; val sb = StringBuilder(); var cnt = 0
        for (root in roots) for (n in allNodes(root)) {
            if (cnt > 150) break
            if (!n.isVisibleToUser) continue
            val t = (n.text ?: n.contentDescription ?: n.hintText)?.toString()
            if (t.isNullOrBlank() && !n.isEditable) continue
            val r = Rect(); n.getBoundsInScreen(r)
            val tag = (if (n.isClickable) " [tap]" else "") + (if (n.isEditable) " [input]" else "")
            sb.append("${(t ?: "").take(60)} @(${r.centerX() * 1000 / d.widthPixels},${r.centerY() * 1000 / d.heightPixels})$tag\n"); cnt++
        }
        return sb.toString().ifBlank { "koi text nahi mila" }
    }

    fun shot(cb: (ByteArray?) -> Unit) {
        if (Build.VERSION.SDK_INT < 30) { cb(null); return }
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                try {
                    val hb = r.hardwareBuffer
                    val bmp = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)!!.copy(Bitmap.Config.ARGB_8888, false); hb.close()
                    val w = 480; val s = Bitmap.createScaledBitmap(bmp, w, bmp.height * w / bmp.width, true)
                    val o = ByteArrayOutputStream(); s.compress(Bitmap.CompressFormat.JPEG, 55, o); cb(o.toByteArray())
                } catch (e: Exception) { cb(null) }
            }
            override fun onFailure(code: Int) { cb(null) }
        })
    }
}
