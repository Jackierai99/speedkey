package com.friday.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.io.ByteArrayOutputStream

class FridayAccess : AccessibilityService() {
    companion object { @Volatile var inst: FridayAccess? = null; @Volatile var dirty = true }

    override fun onServiceConnected() { inst = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) { dirty = true }
    override fun onInterrupt() {}
    override fun onUnbind(i: Intent?): Boolean { inst = null; return super.onUnbind(i) }

    private fun gesture(path: Path, dur: Long): Boolean =
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, dur)).build(), null, null)

    fun tapPx(x: Float, y: Float) = gesture(Path().apply { moveTo(x, y) }, 60)
    fun tapNorm(x: Float, y: Float): Boolean { val d = resources.displayMetrics; return tapPx(x / 1000f * d.widthPixels, y / 1000f * d.heightPixels) }

    fun scroll(dir: String): Boolean {
        val d = resources.displayMetrics; val w = d.widthPixels.toFloat(); val h = d.heightPixels.toFloat()
        val p = Path()
        when (dir.lowercase()) {
            "down" -> { p.moveTo(w / 2, h * 0.72f); p.lineTo(w / 2, h * 0.28f) }
            "up" -> { p.moveTo(w / 2, h * 0.28f); p.lineTo(w / 2, h * 0.72f) }
            "right" -> { p.moveTo(w * 0.8f, h / 2); p.lineTo(w * 0.2f, h / 2) }
            "left" -> { p.moveTo(w * 0.2f, h / 2); p.lineTo(w * 0.8f, h / 2) }
            else -> return false
        }
        return gesture(p, 320)
    }

    fun press(b: String): Boolean = when (b.lowercase()) {
        "back" -> performGlobalAction(GLOBAL_ACTION_BACK); "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
        "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS); "notifications" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
        else -> false
    }

    fun tapText(t: String): Boolean {
        val root = rootInActiveWindow ?: return false
        for (n in root.findAccessibilityNodeInfosByText(t)) {
            var c: AccessibilityNodeInfo? = n
            while (c != null && !c.isClickable) c = c.parent
            if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            val r = Rect(); n.getBoundsInScreen(r)
            if (!r.isEmpty) return tapPx(r.exactCenterX(), r.exactCenterY())
        }
        return false
    }

    fun typeText(t: String): Boolean {
        val n = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val b = Bundle(); b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t)
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    fun readScreen(): String {
        val root = rootInActiveWindow ?: return "screen read nahi ho paayi"
        val d = resources.displayMetrics; val sb = StringBuilder(); var cnt = 0
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || cnt > 120) return
            val t = (n.text ?: n.contentDescription)?.toString()
            if (!t.isNullOrBlank()) {
                val r = Rect(); n.getBoundsInScreen(r)
                sb.append("${t.take(60)} @(${r.centerX() * 1000 / d.widthPixels},${r.centerY() * 1000 / d.heightPixels})${if (n.isClickable) " [tap]" else ""}\n"); cnt++
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return sb.toString().ifBlank { "koi text nahi mila" }
    }

    fun shot(cb: (ByteArray?) -> Unit) {
        if (Build.VERSION.SDK_INT < 30) { cb(null); return }
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                try {
                    val hb = r.hardwareBuffer
                    val bmp = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)!!.copy(Bitmap.Config.ARGB_8888, false); hb.close()
                    val w = 480; val s = Bitmap.createScaledBitmap(bmp, w, bmp.height * w / bmp.width, true)
                    val o = ByteArrayOutputStream(); s.compress(Bitmap.CompressFormat.JPEG, 55, o); cb(o.toByteArray())
                } catch (e: Exception) { cb(null) }
            }
            override fun onFailure(code: Int) { cb(null) }
        })
    }
}
