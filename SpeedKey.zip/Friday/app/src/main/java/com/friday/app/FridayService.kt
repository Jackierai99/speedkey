package com.friday.app

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.Context
import android.graphics.Color
import android.hardware.camera2.CameraManager
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.*
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.*
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject
import java.util.concurrent.LinkedBlockingQueue
import kotlin.math.max
import kotlin.math.sqrt

class FridayService : Service(), LiveClient.Cb {
    private val ui = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var overlay: View? = null
    companion object { @Volatile var inst: FridayService? = null }
    var client: LiveClient? = null
    private var rec: AudioRecord? = null
    private var track: AudioTrack? = null
    @Volatile private var alive = false
    private val q = LinkedBlockingQueue<ByteArray>()
    private val END = ByteArray(0)

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (alive) return START_STICKY
        val ch = "friday"
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(ch, "Friday", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch).setContentTitle("Friday sun rahi hai").setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(1, n)
        alive = true; inst = this; Bus.running = true; Bus.muted = Prefs.muted(this); Bus.screenLive = Prefs.screen(this)
        showOverlay(); startAudio(); connect(); startFrames()
        return START_STICKY
    }

    private fun connect() {
        if (!alive) return
        Bus.state = Bus.THINK; Bus.set("Connect ho raha hai...")
        client?.close()
        client = LiveClient(Prefs.key(this), Prefs.model(this), Prefs.voice(this), persona(Prefs.notes(this)), this).also { it.connect() }
    }

    // ---- LiveClient callbacks
    override fun ready() { Bus.state = if (Bus.muted) Bus.MUTED else Bus.LISTEN; Bus.set("Live connected ✅") }
    override fun audio(pcm: ByteArray) { Bus.state = Bus.SPEAK; q.offer(pcm) }
    override fun interrupted() { q.clear(); track?.pause(); track?.flush(); track?.play(); Bus.level = 0f }
    override fun turnDone() { q.offer(END) }
    override fun closed(err: String?) {
        if (!alive) return
        Bus.set("Dobara connect... ($err)"); Bus.state = Bus.THINK
        ui.postDelayed({ connect() }, 1500)
    }

    override fun chat(user: Boolean, text: String) { Bus.say(user, text) }

    override fun tool(id: String, name: String, a: JSONObject) {
        ui.post {
            Bus.state = Bus.THINK; Bus.cmdCount++
            Bus.cmds.add(0, "$name ${a.toString().take(50)}"); if (Bus.cmds.size > 15) Bus.cmds.removeAt(Bus.cmds.size - 1)
            val acc = FridayAccess.inst
            val noAcc = "Accessibility ON nahi hai, user ko Settings mein Friday enable karne bolo"
            val res = try {
                when (name) {
                    "open_app" -> openApp(a.optString("name"))
                    "tap_text" -> if (acc == null) noAcc else if (acc.tapText(a.optString("text"))) "tap ho gaya" else "text nahi mila"
                    "tap_xy" -> if (acc == null) noAcc else if (acc.tapNorm(a.optDouble("x").toFloat(), a.optDouble("y").toFloat())) "tap ho gaya" else "tap fail"
                    "scroll" -> if (acc == null) noAcc else if (acc.scroll(a.optString("direction"))) "scroll ho gaya" else "scroll fail"
                    "press_button" -> if (acc == null) noAcc else if (acc.press(a.optString("button"))) "ho gaya" else "fail"
                    "type_text" -> if (acc == null) noAcc else if (acc.typeText(a.optString("text"))) "likh diya" else "koi text box focused nahi hai"
                    "read_screen" -> if (acc == null) noAcc else acc.readScreen()
                    "set_emotion" -> { Bus.emotion = a.optString("emotion", "neutral"); "ok" }
                    "remember" -> { Prefs.addNote(this, a.optString("note")); "yaad kar liya" }
                    "torch" -> { val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager; cm.setTorchMode(cm.cameraIdList[0], a.optString("on") == "true"); "ok" }
                    "volume" -> { (getSystemService(Context.AUDIO_SERVICE) as AudioManager).adjustStreamVolume(AudioManager.STREAM_MUSIC,
                        if (a.optString("direction") == "up") AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); "ok" }
                    else -> "unknown tool"
                }
            } catch (e: Exception) { "error: ${e.message}" }
            ui.postDelayed({ client?.toolResponse(id, name, res); if (Bus.state == Bus.THINK) Bus.state = if (Bus.muted) Bus.MUTED else Bus.LISTEN }, 500)
        }
    }

    private fun openApp(n: String): String {
        val pm = packageManager
        val l = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val q = n.lowercase().trim()
        val m = l.firstOrNull { it.loadLabel(pm).toString().lowercase() == q } ?: l.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) } ?: return "app nahi mila: $n"
        val i = pm.getLaunchIntentForPackage(m.activityInfo.packageName) ?: return "app khul nahi sakta"
        startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return "${m.loadLabel(pm)} khul gaya"
    }

    // live screen frames (Private Mode = Bus.screenLive off)
    private fun startFrames() {
        Thread {
            var last = 0L
            while (alive) {
                try { Thread.sleep(1200) } catch (_: Exception) {}
                val acc = FridayAccess.inst; val c = client
                if (!Bus.screenLive || acc == null || c == null || !c.open) continue
                if (!FridayAccess.dirty && System.currentTimeMillis() - last < 10000) continue
                FridayAccess.dirty = false; last = System.currentTimeMillis()
                ui.post { acc.shot { b -> if (b != null) client?.sendVideo(b) } }
            }
        }.start()
    }

    // ---- audio
    private fun startAudio() {
        val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val r = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, 16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(min, 6400))
        if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(r.audioSessionId)
        if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(r.audioSessionId)
        if (AutomaticGainControl.isAvailable()) AutomaticGainControl.create(r.audioSessionId)
        rec = r; r.startRecording()
        val tmin = AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
            .setBufferSizeInBytes(max(tmin, 9600)).setTransferMode(AudioTrack.MODE_STREAM).build().also { it.play() }

        Thread {   // mic -> gemini, with adaptive noise gate
            val buf = ByteArray(1600); var floor = 300f
            while (alive) {
                val n = r.read(buf, 0, buf.size); if (n <= 0) continue
                val rms = rms(buf, n)
                if (Bus.muted) { if (Bus.state != Bus.SPEAK) Bus.level = 0f; continue }
                if (rms < floor) floor = rms.coerceAtLeast(80f) else floor += (rms - floor) * 0.003f
                val gate = max(floor * 2.2f, 450f)
                if (Bus.state != Bus.SPEAK) Bus.level = if (rms > gate) (rms / 6000f).coerceAtMost(1f) else 0f
                if (rms < gate) java.util.Arrays.fill(buf, 0, n, 0)
                client?.sendAudio(buf, n)
            }
        }.start()

        Thread {   // gemini -> speaker
            while (alive) {
                val c = q.take()
                if (c === END || c.isEmpty()) { Bus.level = 0f; if (!Bus.muted) Bus.state = Bus.LISTEN else Bus.state = Bus.MUTED; continue }
                Bus.level = (rms(c, c.size) / 5000f).coerceAtMost(1f)
                track?.write(c, 0, c.size)
            }
        }.start()
    }

    private fun rms(b: ByteArray, n: Int): Float {
        var s = 0.0; var i = 0
        while (i + 1 < n) { val v = (b[i].toInt() and 0xff) or (b[i + 1].toInt() shl 8); val x = v.toShort().toInt(); s += x.toDouble() * x; i += 2 }
        return sqrt(s / max(1, n / 2)).toFloat()
    }

    // ---- overlay: small orb + mic button under it
    private fun showOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val d = resources.displayMetrics.density
        val orb = OrbView(this)
        val mic = TextView(this).apply {
            gravity = Gravity.CENTER; textSize = 18f; setTextColor(Color.WHITE)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#CC1A1A1A")); setStroke((2 * d).toInt(), Color.parseColor("#FF8A1F")) }
        }
        fun paintMic() { mic.text = if (Bus.muted) "🔇" else "🎤"; if (Bus.muted) Bus.state = Bus.MUTED else if (Bus.state == Bus.MUTED) Bus.state = Bus.LISTEN }
        paintMic()
        mic.setOnClickListener { Bus.muted = !Bus.muted; Prefs.save(this, mu = Bus.muted); paintMic() }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            addView(orb, LinearLayout.LayoutParams((110 * d).toInt(), (110 * d).toInt()))
            addView(mic, LinearLayout.LayoutParams((38 * d).toInt(), (38 * d).toInt()))
        }
        val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START; lp.x = (20 * d).toInt(); lp.y = (200 * d).toInt()
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
        orb.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> { if (Math.abs(e.rawX - dx) > 10 || Math.abs(e.rawY - dy) > 10) moved = true
                    lp.x = sx + (e.rawX - dx).toInt(); lp.y = sy + (e.rawY - dy).toInt(); wm?.updateViewLayout(box, lp) }
                MotionEvent.ACTION_UP -> if (!moved) startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }; true
        }
        overlay = box; wm?.addView(box, lp)
    }

    override fun onDestroy() {
        alive = false; inst = null; Bus.running = false; Bus.set("Band hai")
        client?.close(); rec?.stop(); rec?.release(); track?.release()
        overlay?.let { wm?.removeView(it) }; q.offer(END)
        super.onDestroy()
    }
}
