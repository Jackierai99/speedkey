package com.friday.app

import android.app.*
import android.content.Intent
import android.content.pm.ResolveInfo
import android.content.pm.ServiceInfo
import android.content.Context
import android.graphics.Color
import android.hardware.camera2.CameraManager
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.*
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.*
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject
import java.util.concurrent.LinkedBlockingQueue
import kotlin.math.max
import kotlin.math.sqrt

class FridayService : Service(), LiveClient.Cb {
    private val ui = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var overlay: View? = null
    companion object { @Volatile var inst: FridayService? = null }
    var client: LiveClient? = null
    private var rec: AudioRecord? = null
    private var track: AudioTrack? = null
    @Volatile private var alive = false
    @Volatile private var thinkOff = true
    @Volatile private var readySeen = false
    @Volatile private var barge = 0
    private val q = LinkedBlockingQueue<ByteArray>()
    private val END = ByteArray(0)

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (alive) return START_STICKY
        val ch = "friday"
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(ch, "Friday", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch).setContentTitle("Friday sun rahi hai").setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(1, n)
        alive = true; inst = this; Bus.running = true; Bus.muted = Prefs.muted(this); Bus.screenLive = Prefs.screen(this)
        AccessHelper.tryEnable(this); showOverlay(); startAudio(); connect(); startFrames()
        return START_STICKY
    }

    private fun connect() {
        if (!alive) return
        Bus.state = Bus.THINK; Bus.set("Connect ho raha hai..."); readySeen = false
        client?.close()
        client = LiveClient(Prefs.key(this), Prefs.model(this), Prefs.voice(this), persona(Prefs.notes(this)), thinkOff, this).also { it.connect() }
    }

    // ---- LiveClient callbacks
    override fun ready() { readySeen = true; try { routeToSpeaker() } catch (_: Exception) {}; Bus.state = Bus.LISTEN; Bus.set("Live connected ✅") }
    override fun audio(pcm: ByteArray) { Bus.state = Bus.SPEAK; barge = 0; q.offer(pcm) }
    override fun interrupted() { q.clear(); track?.pause(); track?.flush(); track?.play(); Bus.level = 0f }
    override fun turnDone() { q.offer(END) }
    override fun closed(err: String?) {
        if (!alive) return
        if (!readySeen && thinkOff) thinkOff = false   // is model ko thinking-off pasand nahi, bina uske connect karo
        Bus.set("Dobara connect... ($err)"); Bus.state = Bus.THINK
        ui.postDelayed({ connect() }, if (readySeen) 600 else 1200)
    }

    override fun chat(user: Boolean, text: String) { Bus.say(user, text) }

    override fun tool(id: String, name: String, a: JSONObject) {
        ui.post {
            Bus.state = Bus.THINK; Bus.cmdCount++
            Bus.cmds.add(0, "$name ${a.toString().take(50)}"); if (Bus.cmds.size > 15) Bus.cmds.removeAt(Bus.cmds.size - 1)
            val acc = FridayAccess.inst
            val noAcc = "Accessibility ON nahi hai. Tap/scroll/type nahi ho sakte. Chal sakte hain: open_app, open_url, web_search, dial, media, torch, volume. User ko Settings tab mein 'Bina Accessibility' guide dekhne bolo."
            val res = try {
                when (name) {
                    "open_app" -> openApp(a.optString("name"))
                    "tap_text" -> if (acc == null) noAcc else if (acc.tapText(a.optString("text"))) "tap ho gaya" else "text nahi mila"
                    "tap_xy" -> if (acc == null) noAcc else if (acc.tapNorm(a.optDouble("x").toFloat(), a.optDouble("y").toFloat())) "tap ho gaya" else "tap fail"
                    "scroll" -> if (acc == null) noAcc else if (acc.scroll(a.optString("direction"))) "scroll ho gaya" else "scroll fail"
                    "press_button" -> if (acc == null) noAcc else if (acc.press(a.optString("button"))) "ho gaya" else "fail"
                    "type_text" -> if (acc == null) noAcc else if (acc.typeText(a.optString("text"))) "likh diya" else "koi text box focused nahi hai"
                    "read_screen" -> if (acc == null) noAcc else acc.readScreen()
                    "press_enter" -> if (acc == null) noAcc else if (acc.pressEnter()) "enter ho gaya" else "enter nahi hua"
                    "open_url" -> { var u = a.optString("url").trim(); if (!u.contains("://")) u = "https://$u"; startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "khul gaya" }
                    "web_search" -> { startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com/search?q=" + android.net.Uri.encode(a.optString("query")))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "search khul gaya" }
                    "dial" -> { startActivity(Intent(Intent.ACTION_DIAL, android.net.Uri.parse("tel:" + android.net.Uri.encode(a.optString("number")))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "dialer khul gaya" }
                    "media" -> { val k = when (a.optString("action")) { "next" -> KeyEvent.KEYCODE_MEDIA_NEXT; "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS; else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE }
                        val am2 = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                        am2.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, k)); am2.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, k)); "ho gaya" }
                    "set_emotion" -> { Bus.emotion = a.optString("emotion", "neutral"); "ok" }
                    "remember" -> { Prefs.addNote(this, a.optString("note")); "yaad kar liya" }
                    "torch" -> { val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager; cm.setTorchMode(cm.cameraIdList[0], a.optString("on") == "true"); "ok" }
                    "volume" -> { (getSystemService(Context.AUDIO_SERVICE) as AudioManager).adjustStreamVolume(AudioManager.STREAM_MUSIC,
                        if (a.optString("direction") == "up") AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); "ok" }
                    else -> "unknown tool"
                }
            } catch (e: Exception) { "error: ${e.message}" }
            ui.postDelayed({ client?.toolResponse(id, name, res); if (Bus.state == Bus.THINK) Bus.state = Bus.LISTEN }, if (name == "open_app" || name == "open_url" || name == "web_search") 350 else 120)
        }
    }

    private fun lev(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) { var p = d[0]; d[0] = i
            for (j in 1..b.length) { val t = d[j]; d[j] = minOf(d[j] + 1, d[j - 1] + 1, p + if (a[i - 1] == b[j - 1]) 0 else 1); p = t } }
        return d[b.length]
    }
    private fun openApp(n: String): String {
        val pm = packageManager
        val l = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val alias = mapOf("क्रोम" to "chrome", "यूट्यूब" to "youtube", "व्हाट्सऐप" to "whatsapp", "वॉट्सऐप" to "whatsapp", "इंस्टाग्राम" to "instagram",
            "कैमरा" to "camera", "सेटिंग" to "settings", "गैलरी" to "gallery", "प्ले स्टोर" to "play store", "मैप" to "maps")
        val q = (alias.entries.firstOrNull { n.contains(it.key) }?.value ?: n).lowercase().filter { it.isLetterOrDigit() }
        fun nm(r: ResolveInfo) = r.loadLabel(pm).toString().lowercase().filter { it.isLetterOrDigit() }
        val m = l.firstOrNull { nm(it) == q } ?: l.firstOrNull { nm(it).startsWith(q) } ?: l.firstOrNull { q.length >= 3 && nm(it).contains(q) }
            ?: l.firstOrNull { q.length >= 3 && it.activityInfo.packageName.lowercase().contains(q) }
            ?: l.minByOrNull { lev(nm(it), q) }?.takeIf { lev(nm(it), q) <= 2 } ?: return "app nahi mila: $n"
        val i = pm.getLaunchIntentForPackage(m.activityInfo.packageName) ?: return "app khul nahi sakta"
        startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return "${m.loadLabel(pm)} khul gaya"
    }

    // live screen frames (Private Mode = Bus.screenLive off)
    private fun startFrames() {
        Thread {
            var last = 0L
            while (alive) {
                try { Thread.sleep(700) } catch (_: Exception) {}
                val acc = FridayAccess.inst; val c = client
                if (!Bus.screenLive || acc == null || c == null || !c.open) continue
                val now = System.currentTimeMillis(); if (now - last < 2000 || (!FridayAccess.dirty && now - last < 8000) || Bus.state == Bus.SPEAK) continue
                FridayAccess.dirty = false; last = System.currentTimeMillis()
                ui.post { acc.shot { b -> if (b != null) client?.sendVideo(b) } }
            }
        }.start()
    }

    // ---- audio
    private var am: AudioManager? = null
    private var oldMode = AudioManager.MODE_NORMAL

    // Voice-communication audio goes to the tiny earpiece by default -> force loudspeaker + good volume
    @Suppress("DEPRECATION")
    private fun routeToSpeaker() {
        val a = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (am == null) oldMode = a.mode
        am = a
        a.mode = AudioManager.MODE_IN_COMMUNICATION
        if (Build.VERSION.SDK_INT >= 31) {
            a.availableCommunicationDevices.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }?.let { a.setCommunicationDevice(it) }
        } else {
            a.isSpeakerphoneOn = true
        }
        val mx = a.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL)
        try { a.setStreamVolume(AudioManager.STREAM_VOICE_CALL, mx, 0) } catch (_: Exception) {}
        try { a.setStreamVolume(AudioManager.STREAM_MUSIC, a.getStreamMaxVolume(AudioManager.STREAM_MUSIC), 0) } catch (_: Exception) {}
    }

    private fun startAudio() {
        routeToSpeaker()
        val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val r = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, 16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(min, 3200))
        if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(r.audioSessionId)
        if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(r.audioSessionId)
        if (AutomaticGainControl.isAvailable()) AutomaticGainControl.create(r.audioSessionId)
        rec = r; r.startRecording()
        val tmin = AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
            .setBufferSizeInBytes(max(tmin, 4800)).setTransferMode(AudioTrack.MODE_STREAM).setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY).build().also { it.setVolume(AudioTrack.getMaxVolume()); it.play()
                try { android.media.audiofx.LoudnessEnhancer(it.audioSessionId).apply { setTargetGain(900); enabled = true } } catch (_: Exception) {} }

        Thread {   // mic -> gemini: noise ignore (gate + pre-roll + hangover), instant barge-in
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO)
            val CH = 640   // 20 ms
            val buf = ByteArray(CH); val zero = ByteArray(CH)
            val pre = Array(10) { ByteArray(CH) }; var pi = 0; var pc = 0
            var floor = 250f; var hang = 0
            while (alive) {
                val n = r.read(buf, 0, CH); if (n <= 0) continue
                val rms = rms(buf, n)
                val speaking = Bus.state == Bus.SPEAK && !Bus.muted
                val gate = max(floor * 3f, 380f)
                if (speaking) {
                    // Friday bol rahi hai: sirf zor ki awaaz (barge-in) bhejo, baaki chup (echo se bachne ke liye)
                    if (rms > 2200f) barge++ else barge = 0
                    if (barge >= 3) {
                        q.clear(); track?.pause(); track?.flush(); track?.play(); Bus.level = 0f
                        Bus.state = Bus.LISTEN; barge = 0; hang = 25
                        client?.sendAudio(buf, n)
                    } else client?.sendAudio(zero, n)
                    continue
                }
                if (rms > gate) {
                    if (hang == 0) { // speech abhi shuru hua: pichla 200ms bhi bhejo taaki shabd na kate
                        for (k in 0 until pc) client?.sendAudio(pre[(pi - pc + k + 10 * 2) % 10], CH)
                    }
                    hang = 20; pc = 0
                } else if (hang == 0) floor += (rms - floor) * 0.02f
                if (hang > 0) { hang--; client?.sendAudio(buf, n); Bus.level = if (rms > gate) (rms / 6000f).coerceAtMost(1f) else Bus.level * 0.8f }
                else { System.arraycopy(buf, 0, pre[pi], 0, n); pi = (pi + 1) % 10; if (pc < 10) pc++; client?.sendAudio(zero, n); Bus.level = 0f }
            }
        }.start()

        Thread {   // gemini -> speaker (mute = sirf awaaz band, jawab chalta rahe)
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO)
            while (alive) {
                val c = q.take()
                if (c === END || c.isEmpty()) { Bus.level = 0f; Bus.state = Bus.LISTEN; continue }
                Bus.level = (rms(c, c.size) / 5000f).coerceAtMost(1f)
                if (!Bus.muted) track?.write(c, 0, c.size) else try { Thread.sleep((c.size / 48).toLong().coerceAtMost(200)) } catch (_: Exception) {}
            }
        }.start()
    }

    private fun rms(b: ByteArray, n: Int): Float {
        var s = 0.0; var i = 0
        while (i + 1 < n) { val v = (b[i].toInt() and 0xff) or (b[i + 1].toInt() shl 8); val x = v.toShort().toInt(); s += x.toDouble() * x; i += 2 }
        return sqrt(s / max(1, n / 2)).toFloat()
    }

    // ---- overlay: small orb + mic button under it
    private fun showOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val d = resources.displayMetrics.density
        val orb = OrbView(this, true)
        val mic = TextView(this).apply {
            gravity = Gravity.CENTER; textSize = 18f; setTextColor(Color.WHITE)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#CC1A1A1A")); setStroke((2 * d).toInt(), Color.parseColor("#FF8A1F")) }
        }
        fun paintMic() { mic.text = if (Bus.muted) "🔇" else "🔊" }
        paintMic()
        mic.setOnClickListener { Bus.muted = !Bus.muted; Prefs.save(this, mu = Bus.muted); paintMic() }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            addView(orb, LinearLayout.LayoutParams((120 * d).toInt(), (120 * d).toInt()))
            addView(mic, LinearLayout.LayoutParams((38 * d).toInt(), (38 * d).toInt()))
        }
        val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START; lp.x = (20 * d).toInt(); lp.y = (200 * d).toInt()
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
        orb.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> { if (Math.abs(e.rawX - dx) > 10 || Math.abs(e.rawY - dy) > 10) moved = true
                    lp.x = sx + (e.rawX - dx).toInt(); lp.y = sy + (e.rawY - dy).toInt(); wm?.updateViewLayout(box, lp) }
                MotionEvent.ACTION_UP -> if (!moved) startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }; true
        }
        overlay = box; wm?.addView(box, lp)
    }

    @Suppress("DEPRECATION")
    override fun onDestroy() {
        alive = false; inst = null; Bus.running = false; Bus.set("Band hai")
        am?.let { a ->
            if (Build.VERSION.SDK_INT >= 31) a.clearCommunicationDevice() else a.isSpeakerphoneOn = false
            a.mode = oldMode
        }
        client?.close(); rec?.stop(); rec?.release(); track?.release()
        overlay?.let { wm?.removeView(it) }; q.offer(END)
        super.onDestroy()
    }
}
