# Instant notification (FCM push) setup — ek baar

1. Firebase console > Project settings > Service accounts > "Generate new private key" -> ek .json file download hogi. Use text mein kholo, poora copy karo.
2. Supabase dashboard > Edge Functions > "Deploy a new function" (editor) > naam: push > push.ts ka poora code paste karo > Deploy.
3. Us function ki settings mein "Verify JWT" OFF karo.
4. Supabase > Edge Functions > Secrets mein 2 secret banao:
   - FCM_SERVICE_ACCOUNT = step 1 ka poora JSON text
   - PUSH_SECRET = 748d8fe95d7ad90143e48d0478a02af6
5. Dono phones par naya APK install karo, ek baar app kholkar chat tak jao (token save hota hai).
