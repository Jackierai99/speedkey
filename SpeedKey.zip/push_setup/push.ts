// Supabase Edge Function: naam "push"  (Verify JWT = OFF)
const SECRET = Deno.env.get("PUSH_SECRET")!;
const SA = JSON.parse(Deno.env.get("FCM_SERVICE_ACCOUNT")!);

function b64url(d: ArrayBuffer | Uint8Array) {
  const u = d instanceof Uint8Array ? d : new Uint8Array(d);
  let s = ""; u.forEach((c) => (s += String.fromCharCode(c)));
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

async function accessToken() {
  const enc = (o: unknown) => b64url(new TextEncoder().encode(JSON.stringify(o)));
  const now = Math.floor(Date.now() / 1000);
  const unsigned = enc({ alg: "RS256", typ: "JWT" }) + "." + enc({
    iss: SA.client_email, scope: "https://www.googleapis.com/auth/firebase.messaging",
    aud: "https://oauth2.googleapis.com/token", iat: now, exp: now + 3600,
  });
  const pem = SA.private_key.replace(/-----[^-]+-----/g, "").replace(/\s/g, "");
  const der = Uint8Array.from(atob(pem), (c) => c.charCodeAt(0));
  const key = await crypto.subtle.importKey("pkcs8", der, { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, new TextEncoder().encode(unsigned));
  const r = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: "grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=" + unsigned + "." + b64url(sig),
  });
  return (await r.json()).access_token;
}

Deno.serve(async (req) => {
  try {
    const { token, id, secret } = await req.json();
    if (secret !== SECRET || !token) return new Response("no", { status: 401 });
    const at = await accessToken();
    const r = await fetch(`https://fcm.googleapis.com/v1/projects/${SA.project_id}/messages:send`, {
      method: "POST",
      headers: { Authorization: "Bearer " + at, "Content-Type": "application/json" },
      body: JSON.stringify({ message: { token, data: { id: String(id) }, android: { priority: "HIGH" } } }),
    });
    return new Response(await r.text(), { status: r.status });
  } catch (e) { return new Response(String(e), { status: 500 }); }
});
