plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.beep.board"
    compileSdk = 34
    defaultConfig { applicationId = "com.beep.board"; minSdk = 23; targetSdk = 33; versionCode = 1; versionName = "1.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
