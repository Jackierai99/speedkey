package com.beep.board

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.IBinder
import android.text.TextUtils
import android.view.*
import android.widget.*

class FloatingService : Service() {
    private class S(val id: Int, val key: String, val label: String, val cat: String)
    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var panel: LinearLayout
    private lateinit var grid: GridLayout
    private lateinit var bubble: TextView
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var all: List<S>
    private val players = mutableListOf<MediaPlayer>()
    private val chips = mutableMapOf<String, TextView>()
    private val tabs = listOf("⭐ FAV", "ALL", "CID", "ANIME", "GIRL", "DESI", "MEME")
    private val tc = mapOf("⭐ FAV" to "#FBC02D", "ALL" to "#00ACC1", "CID" to "#1E88E5", "ANIME" to "#AB47BC",
        "GIRL" to "#EC407A", "DESI" to "#FB8C00", "MEME" to "#43A047")
    private var cur = "ALL"
    private var vol = 1f
    private val prefs by lazy { getSharedPreferences("beep", 0) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun g(c1: String, c2: String = c1, r: Int = 12) = GradientDrawable(GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.parseColor(c1), Color.parseColor(c2))).apply { cornerRadius = dp(r).toFloat() }
    private fun tv(t: String, sz: Float = 13f) = TextView(this).apply {
        text = t; textSize = sz; setTextColor(Color.WHITE); gravity = Gravity.CENTER }

    private fun catOf(k: String): String {
        val w = k.split('_')
        return when {
            "cid" in w -> "CID"
            listOf("anime", "kira", "sukuna", "gojo", "solo", "death").any { it in w } -> "ANIME"
            "girl" in w -> "GIRL"
            listOf("akshay", "shah", "modi", "samjha", "sajjan", "gand", "nahi").any { it in w } -> "DESI"
            else -> "MEME"
        }
    }
    private fun labelOf(k: String): String {
        val t = k.split('_').filter { it != "cid" && it.isNotEmpty() }
            .joinToString(" ") { it.replaceFirstChar { c -> c.uppercase() } }
        return if ("laugh" in k) "$t 😂" else t
    }
    private fun favs(): MutableSet<String> = prefs.getStringSet("fav", emptySet())!!.toMutableSet()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(
            NotificationChannel("beep", "Voice Mod", NotificationManager.IMPORTANCE_LOW))
        val nb = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "beep") else Notification.Builder(this)
        startForeground(1, nb.setContentTitle("Voice Mod chal raha hai")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build())

        all = R.raw::class.java.fields.map { it.name to it.getInt(null) }.sortedBy { it.first }
            .map { (n, id) -> S(id, n, labelOf(n), catOf(n)) }

        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        lp = WindowManager.LayoutParams(-2, -2, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(60) }

        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        bubble = tv("🔊", 24f).apply { background = g("#00E5FF", "#7C4DFF", 30)
            layoutParams = LinearLayout.LayoutParams(dp(54), dp(54)) }
        root.addView(bubble)

        val row = LinearLayout(this)
        tabs.forEach { t ->
            val c = tv(t, 12f).apply { setPadding(dp(10), dp(6), dp(10), dp(6))
                layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }
                setOnClickListener { cur = t; refresh() } }
            chips[t] = c; row.addView(c)
        }
        val tabScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) }

        grid = GridLayout(this).apply { columnCount = 3 }
        val h = minOf(dp(190), (resources.displayMetrics.heightPixels * 0.45).toInt())
        val sv = ScrollView(this).apply { layoutParams = LinearLayout.LayoutParams(-1, h); addView(grid) }

        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(4), dp(4), dp(4)) }
        bar.addView(tv("🔉", 14f))
        bar.addView(SeekBar(this).apply { max = 100; progress = 100
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    vol = p / 100f; players.forEach { try { it.setVolume(vol, vol) } catch (_: Exception) {} } }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            }) })
        fun ib(t: String, c: String, a: () -> Unit) = tv(t, 15f).apply { background = g(c, c, 10)
            setPadding(dp(10), dp(6), dp(10), dp(6))
            layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(3), 0, dp(3), 0) }
            setOnClickListener { a() } }
        bar.addView(ib("🎲", "#6A1B9A") { if (all.isNotEmpty()) play(all.random().id) })
        bar.addView(ib("⏹", "#C62828") { stopAll() })
        bar.addView(ib("✕", "#455A64") { stopSelf() })

        panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE
            background = g("#F2101020", "#F21A1030", 16); setPadding(dp(4), dp(4), dp(4), dp(4))
            layoutParams = LinearLayout.LayoutParams(dp(318), -2)
            addView(tabScroll); addView(sv); addView(bar) }
        root.addView(panel)
        refresh()

        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        bubble.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true
                    if (moved) { lp.x = sx + dx; lp.y = sy + dy; wm.updateViewLayout(root, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) {
                    if (panel.visibility == View.VISIBLE) panel.visibility = View.GONE
                    else { refresh(); panel.visibility = View.VISIBLE } }
            }
            true
        }
        wm.addView(root, lp)
    }

    private fun refresh() {
        chips.forEach { (t, c) -> c.background = if (t == cur) g(tc[t]!!, tc[t]!!, 20) else g("#2A2A3C", "#2A2A3C", 20) }
        grid.removeAllViews()
        val f = favs(); val cols = prefs.getInt("cols", 3); grid.columnCount = cols
        val w = dp(306) / cols - dp(4)
        val list = when (cur) { "ALL" -> all; "⭐ FAV" -> all.filter { it.key in f }; else -> all.filter { it.cat == cur } }
        if (list.isEmpty()) grid.addView(tv("Koi sound nahi.\nLong-press se ⭐ jodo", 12f).apply { setPadding(dp(20), dp(30), dp(20), dp(30)) })
        list.forEach { s ->
            val col = tc[s.cat] ?: "#00ACC1"
            val name = (if (s.key in f) "⭐ " else "") + prefs.getString("n_" + s.key, s.label)
            val pf = java.io.File(filesDir, "p_" + s.key + ".jpg")
            val has = pf.exists()
            grid.addView(FrameLayout(this).apply {
                background = g(col, "#1C1C2B", 12)
                layoutParams = GridLayout.LayoutParams().apply { width = w; height = if (cols == 1) dp(46) else dp(58); setMargins(dp(2), dp(2), dp(2), dp(2)) }
                if (has) addView(ImageView(this@FloatingService).apply { scaleType = ImageView.ScaleType.CENTER_CROP
                    setImageBitmap(android.graphics.BitmapFactory.decodeFile(pf.path)) })
                addView(tv(name, 11f).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END; setPadding(dp(3), dp(3), dp(3), dp(3))
                    if (has) { setBackgroundColor(Color.parseColor("#99000000")); layoutParams = FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM) }
                    else layoutParams = FrameLayout.LayoutParams(-1, -1) })
                setOnClickListener { play(s.id) }
                setOnLongClickListener { val n = favs(); if (!n.add(s.key)) n.remove(s.key)
                    prefs.edit().putStringSet("fav", n).apply(); refresh(); true }
            })
        }
    }

    private fun play(id: Int) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.setStreamVolume(AudioManager.STREAM_MUSIC, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC), 0)
        val mp = MediaPlayer.create(this, id) ?: return
        mp.setVolume(vol, vol); players.add(mp); bubble.text = "🎵"
        mp.setOnCompletionListener { it.release(); players.remove(it); if (players.isEmpty()) bubble.text = "🔊" }
        mp.start()
    }

    private fun stopAll() {
        players.toList().forEach { try { it.release() } catch (_: Exception) {} }
        players.clear(); bubble.text = "🔊"
    }

    override fun onDestroy() {
        stopAll(); try { wm.removeView(root) } catch (_: Exception) {}
        super.onDestroy()
    }
}
