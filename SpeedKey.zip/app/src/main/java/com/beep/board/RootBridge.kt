package com.beep.board

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.os.Environment
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

// Sound ko PCM me decode karke /sdcard/VoiceMod/cur.pcm me likhta hai. Root module isse game ke mic me daalta hai.
object RootBridge {
    fun send(c: Context, id: Int) {
        Thread {
            try {
                val afd = c.resources.openRawResourceFd(id)
                val ex = MediaExtractor(); ex.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length); afd.close()
                ex.selectTrack(0)
                val fmt = ex.getTrackFormat(0)
                val codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
                codec.configure(fmt, null, null, 0); codec.start()
                var rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE); var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                val out = ByteArrayOutputStream(); val info = MediaCodec.BufferInfo(); var eos = false
                while (true) {
                    if (!eos) {
                        val i = codec.dequeueInputBuffer(10000)
                        if (i >= 0) {
                            val n = ex.readSampleData(codec.getInputBuffer(i)!!, 0)
                            if (n < 0) { codec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); eos = true }
                            else { codec.queueInputBuffer(i, 0, n, ex.sampleTime, 0); ex.advance() }
                        }
                    }
                    val o = codec.dequeueOutputBuffer(info, 10000)
                    if (o >= 0) {
                        val a = ByteArray(info.size); codec.getOutputBuffer(o)!!.get(a); out.write(a)
                        codec.releaseOutputBuffer(o, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) break
                    } else if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        val f = codec.outputFormat
                        rate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE); ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    }
                }
                codec.stop(); codec.release(); ex.release()
                val pcm = out.toByteArray()
                val bb = ByteBuffer.allocate(8 + pcm.size).order(ByteOrder.LITTLE_ENDIAN)
                bb.putInt(rate); bb.putInt(ch); bb.put(pcm)
                val dir = File(Environment.getExternalStorageDirectory(), "VoiceMod"); dir.mkdirs()
                val tmp = File(dir, "cur.tmp"); tmp.writeBytes(bb.array()); tmp.renameTo(File(dir, "cur.pcm"))
            } catch (_: Exception) {}
        }.start()
    }
}
