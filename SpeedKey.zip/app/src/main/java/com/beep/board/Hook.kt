package com.beep.board

import android.media.AudioRecord
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.callbacks.XC_LoadPackage
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

class Hook : IXposedHookLoadPackage {
    private var pcm: ShortArray? = null
    private var srcRate = 44100; private var srcCh = 1
    private var pos = 0.0; private var stamp = 0L
    private val f = File("/sdcard/VoiceMod/cur.pcm")

    private fun active(): Boolean {
        val m = f.lastModified()
        if (m != stamp && m > 0) try {
            val b = ByteBuffer.wrap(f.readBytes()).order(ByteOrder.LITTLE_ENDIAN)
            srcRate = b.int; srcCh = b.int
            val s = ShortArray(b.remaining() / 2); b.asShortBuffer().get(s)
            pcm = s; pos = 0.0; stamp = m
        } catch (_: Exception) {}
        return pcm != null
    }

    private fun fill(d: ShortArray, rate: Int, ch: Int) {
        val s = pcm ?: return
        val step = srcRate.toDouble() / rate
        var i = 0
        while (i + ch <= d.size) {
            val idx = pos.toInt() * srcCh
            if (idx + srcCh > s.size) { pcm = null; return }
            var v = 0; for (c in 0 until srcCh) v += s[idx + c]
            v /= srcCh
            for (c in 0 until ch) d[i + c] = v.toShort()
            pos += step; i += ch
        }
    }

    override fun handleLoadPackage(p: XC_LoadPackage.LoadPackageParam) {
        if (!p.packageName.startsWith("com.dts.freefire")) return
        XposedBridge.hookAllMethods(AudioRecord::class.java, "read", object : XC_MethodHook() {
            override fun afterHookedMethod(a: MethodHookParam) {
                try {
                    val n = a.result as? Int ?: return
                    if (n <= 0 || !active()) return
                    val ar = a.thisObject as AudioRecord
                    when (val b = a.args[0]) {
                        is ShortArray -> {
                            val off = a.args[1] as Int
                            val t = b.copyOfRange(off, off + n); fill(t, ar.sampleRate, ar.channelCount)
                            System.arraycopy(t, 0, b, off, n)
                        }
                        is ByteArray -> {
                            val off = a.args[1] as Int; val t = ShortArray(n / 2)
                            ByteBuffer.wrap(b, off, n).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(t)
                            fill(t, ar.sampleRate, ar.channelCount)
                            ByteBuffer.wrap(b, off, n).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().put(t)
                        }
                        is ByteBuffer -> {
                            val t = ShortArray(n / 2)
                            b.duplicate().order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(t)
                            fill(t, ar.sampleRate, ar.channelCount)
                            b.duplicate().order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().put(t)
                        }
                    }
                } catch (_: Throwable) {}
            }
        })
    }
}
