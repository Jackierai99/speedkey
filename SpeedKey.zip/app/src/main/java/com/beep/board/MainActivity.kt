package com.beep.board

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import java.io.File

class MainActivity : Activity() {
    private lateinit var col: LinearLayout
    private var pending: String? = null
    private val prefs by lazy { getSharedPreferences("beep", 0) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun g(c: String, r: Int = 12) = GradientDrawable().apply { setColor(Color.parseColor(c)); cornerRadius = dp(r).toFloat() }
    private fun tv(t: String, sz: Float = 14f, c: Int = Color.WHITE) = TextView(this).apply {
        text = t; textSize = sz; setTextColor(c); gravity = Gravity.CENTER }
    private fun defLabel(k: String): String {
        val t = k.split('_').filter { it != "cid" && it.isNotEmpty() }.joinToString(" ") { it.replaceFirstChar { c -> c.uppercase() } }
        return if ("laugh" in k) "$t 😂" else t
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(28), dp(16), dp(28)) }
        setContentView(ScrollView(this).apply { setBackgroundColor(Color.parseColor("#0B0B12")); addView(col) })
        render()
    }

    private fun render() {
        col.removeAllViews()
        col.addView(ImageView(this).apply { setImageResource(R.mipmap.ic_launcher)
            layoutParams = LinearLayout.LayoutParams(dp(130), dp(130)).apply { gravity = Gravity.CENTER_HORIZONTAL } })
        col.addView(tv("VOICE MOD", 26f, Color.parseColor("#C77DFF")))
        col.addView(tv("Game me mic ON rakho aur phone ka speaker use karo (earphone nahi).", 12f, Color.LTGRAY).apply { setPadding(0, dp(6), 0, dp(12)) })
        col.addView(tv("▶  START FLOATING BAR", 16f).apply { background = g("#7C4DFF", 24); setPadding(dp(16), dp(14), dp(16), dp(14))
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else {
                    val i = Intent(this@MainActivity, FloatingService::class.java)
                    if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                    moveTaskToBack(true)
                }
            } })
        col.addView(tv("\nLAYOUT (kitne button ek line me)", 13f, Color.LTGRAY))
        val cur = prefs.getInt("cols", 3)
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
        listOf(2 to "2", 3 to "3", 4 to "4", 1 to "LIST").forEach { (n, l) ->
            row.addView(tv(l, 14f).apply { setPadding(dp(18), dp(8), dp(18), dp(8))
                background = g(if (n == cur) "#00ACC1" else "#2A2A3C", 18)
                layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(4), dp(6), dp(4), dp(6)) }
                setOnClickListener { prefs.edit().putInt("cols", n).apply(); render() } })
        }
        col.addView(row)
        col.addView(tv("\nAWAAZ MODE (game me test karo)", 13f, Color.LTGRAY))
        val mr = LinearLayout(this).apply { gravity = Gravity.CENTER }
        fun chip(l: String, on: Boolean, a: () -> Unit) = tv(l, 13f).apply { setPadding(dp(14), dp(8), dp(14), dp(8))
            background = g(if (on) "#00ACC1" else "#2A2A3C", 18)
            layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(4), dp(6), dp(4), dp(6)) }
            setOnClickListener { a(); render() } }
        val md = prefs.getInt("mode", 0); val bo = prefs.getBoolean("boost", false)
        mr.addView(chip("MEDIA", md == 0) { prefs.edit().putInt("mode", 0).apply() })
        mr.addView(chip("CALL", md == 1) { prefs.edit().putInt("mode", 1).apply() })
        mr.addView(chip(if (bo) "BOOST ON" else "BOOST OFF", bo) { prefs.edit().putBoolean("boost", !bo).apply() })
        val rt = prefs.getBoolean("root", false)
        mr.addView(chip(if (rt) "ROOT ON" else "ROOT OFF", rt) { prefs.edit().putBoolean("root", !rt).apply()
            if (!rt && Build.VERSION.SDK_INT >= 23) requestPermissions(arrayOf("android.permission.WRITE_EXTERNAL_STORAGE"), 2) })
        col.addView(mr)
        col.addView(tv("\nSOUNDS: ✏️ naam badlo  🖼 photo lagao  ↩ reset", 13f, Color.LTGRAY))

        R.raw::class.java.fields.map { it.name }.sorted().forEach { k ->
            val pf = File(filesDir, "p_$k.jpg")
            val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; background = g("#1A1A2A")
                setPadding(dp(8), dp(8), dp(8), dp(8))
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(4), 0, dp(4)) } }
            r.addView(ImageView(this).apply { layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
                scaleType = ImageView.ScaleType.CENTER_CROP
                if (pf.exists()) setImageBitmap(BitmapFactory.decodeFile(pf.path)) else { setImageResource(R.mipmap.ic_launcher); alpha = 0.35f } })
            r.addView(tv(prefs.getString("n_$k", defLabel(k))!!, 13f).apply { gravity = Gravity.START
                setPadding(dp(10), 0, dp(6), 0); layoutParams = LinearLayout.LayoutParams(0, -2, 1f) })
            fun bt(t: String, a: () -> Unit) = tv(t, 18f).apply { setPadding(dp(10), dp(6), dp(10), dp(6)); setOnClickListener { a() } }
            r.addView(bt("✏️") { rename(k) })
            r.addView(bt("🖼") { pending = k; startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 1) })
            r.addView(bt("↩") { prefs.edit().remove("n_$k").apply(); pf.delete(); render() })
            col.addView(r)
        }
    }

    private fun rename(k: String) {
        val e = EditText(this).apply { setText(prefs.getString("n_$k", defLabel(k))) }
        AlertDialog.Builder(this).setTitle("Naam badlo").setView(e)
            .setPositiveButton("OK") { _, _ ->
                prefs.edit().putString("n_$k", e.text.toString().trim().ifEmpty { defLabel(k) }).apply(); render() }
            .setNegativeButton("Cancel", null).show()
    }

    override fun onActivityResult(rq: Int, rs: Int, d: Intent?) {
        super.onActivityResult(rq, rs, d)
        val u = d?.data; val k = pending
        if (rq == 1 && rs == RESULT_OK && u != null && k != null) try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
            o.inSampleSize = maxOf(1, minOf(o.outWidth, o.outHeight) / 200); o.inJustDecodeBounds = false
            val bm = contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) } ?: throw Exception()
            File(filesDir, "p_$k.jpg").outputStream().use { bm.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            render()
        } catch (_: Exception) { Toast.makeText(this, "Photo load nahi hui", Toast.LENGTH_SHORT).show() }
    }
}
