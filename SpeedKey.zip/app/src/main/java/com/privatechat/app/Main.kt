package com.privatechat.app

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.pm.ServiceInfo
import com.google.firebase.firestore.ListenerRegistration
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Paint
import android.graphics.Typeface
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Base64
import android.view.WindowManager
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import com.google.firebase.firestore.SetOptions
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import android.content.BroadcastReceiver
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.ui.res.painterResource
import android.os.PowerManager
import android.app.AlarmManager
import android.os.SystemClock
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

const val SB = "https://obohjkshxneagjsxnqdh.supabase.co"
const val PUSH_SECRET = "748d8fe95d7ad90143e48d0478a02af6"
const val KEY = "sb_publishable_4TPiN_BzNsnEa84qIfZ8DQ_u6FohR3U"
val ACC = Brush.horizontalGradient(listOf(Color(0xFF2979FF), Color(0xFF8E4DFF)))
val CACHE = HashMap<String, Bitmap>()

fun cc(h: Int): Int = (0xFF shl 24) or h
fun onCol(c: Int): Color = if (Color(c).luminance() > 0.55f) Color(0xFF111111) else Color.White

// ---------- FONTS (system fonts, koi internet nahi chahiye) ----------
fun tf(name: String, style: Int = Typeface.NORMAL): FontFamily = FontFamily(Typeface.create(name, style))
val FONTS: List<Pair<String, FontFamily>> = listOf(
    "Default" to FontFamily.Default, "Serif" to FontFamily.Serif, "Mono" to FontFamily.Monospace, "Cursive" to FontFamily.Cursive,
    "Sans" to FontFamily.SansSerif, "Casual" to tf("casual"), "Casual Bold" to tf("casual", Typeface.BOLD),
    "Light" to tf("sans-serif-light"), "Light Italic" to tf("sans-serif-light", Typeface.ITALIC), "Thin" to tf("sans-serif-thin"),
    "Medium" to tf("sans-serif-medium"), "Medium Italic" to tf("sans-serif-medium", Typeface.ITALIC),
    "Black" to tf("sans-serif-black"), "Black Italic" to tf("sans-serif-black", Typeface.ITALIC),
    "Bold" to tf("sans-serif", Typeface.BOLD), "Italic" to tf("sans-serif", Typeface.ITALIC), "Bold Italic" to tf("sans-serif", Typeface.BOLD_ITALIC),
    "Condensed" to tf("sans-serif-condensed"), "Cond Bold" to tf("sans-serif-condensed", Typeface.BOLD), "Cond Italic" to tf("sans-serif-condensed", Typeface.ITALIC),
    "Cond Light" to tf("sans-serif-condensed-light"), "Small Caps" to tf("sans-serif-smallcaps"),
    "Serif Bold" to tf("serif", Typeface.BOLD), "Serif Italic" to tf("serif", Typeface.ITALIC), "Serif BoldIt" to tf("serif", Typeface.BOLD_ITALIC),
    "Serif Mono" to tf("serif-monospace"), "Mono Bold" to tf("monospace", Typeface.BOLD), "Mono Italic" to tf("monospace", Typeface.ITALIC),
    "Cursive Bold" to tf("cursive", Typeface.BOLD), "Cursive Italic" to tf("cursive", Typeface.ITALIC)
)

// ---------- COLORS ----------
val SOLID_HEX = listOf(
    0x0B0B14, 0x000000, 0x0D1B2A, 0x1A0F24, 0x0E1F17, 0x121212, 0x1B1B1B, 0x1F1F2E, 0x14213D, 0x2B2D42, 0x22223A, 0x111827, 0x0F172A, 0x2D1B3D,
    0x2979FF, 0x1565C0, 0x0D47A1, 0x00B0FF, 0x40C4FF, 0x00BCD4, 0x0097A7,
    0x00C853, 0x2E7D32, 0x1B5E20, 0x76FF03, 0x009688, 0x004D40,
    0xE53935, 0xB71C1C, 0xFF1744, 0xD81B60, 0xF06292, 0xFF4081, 0xAD1457,
    0x8E4DFF, 0x6A1B9A, 0x4A148C, 0x7C4DFF, 0xAA00FF, 0xE040FB,
    0xFF6D00, 0xFF9800, 0xFFC107, 0xFFEB3B, 0xFFD600, 0xFF7043,
    0xFFFFFF, 0xECEFF1, 0xB0BEC5, 0x78909C, 0x455A64, 0x8D6E63, 0x5D4037, 0x795548,
    0xFFF3E0, 0xE8F5E9, 0xE3F2FD, 0xFCE4EC, 0xF3E5F5
)
val SOLIDS: List<Pair<Int, Int>> = SOLID_HEX.map { h -> cc(h) to cc(h) }
val GRADS: List<Pair<Int, Int>> = listOf(
    0x2979FF to 0x8E4DFF, 0xFF512F to 0xDD2476, 0x11998E to 0x38EF7D, 0xFC466B to 0x3F5EFB, 0xF7971E to 0xFFD200, 0x00C6FF to 0x0072FF,
    0x8E2DE2 to 0x4A00E0, 0xFF5F6D to 0xFFC371, 0x43E97B to 0x38F9D7, 0x667EEA to 0x764BA2, 0xF953C6 to 0xB91D73, 0x0F2027 to 0x2C5364,
    0x141E30 to 0x243B55, 0x232526 to 0x414345, 0x200122 to 0x6F0000, 0x3A1C71 to 0xD76D77, 0x1D976C to 0x93F9B9, 0xED213A to 0x93291E,
    0x02AAB0 to 0x00CDAC, 0xDA22FF to 0x9733EE, 0x000000 to 0x434343, 0x606C88 to 0x3F4C6B, 0xFDC830 to 0xF37335, 0x4568DC to 0xB06AB3
).map { cc(it.first) to cc(it.second) }
val ALLC: List<Pair<Int, Int>> = GRADS + SOLIDS

class Pack(val n: String, val bg1: Int, val bg2: Int, val bar: Int, val my1: Int, val my2: Int, val t1: Int, val t2: Int, val myT: Int, val thT: Int)
val PACKS = listOf(
    Pack("Midnight", cc(0x0B0B14), cc(0x0B0B14), cc(0x14142A), cc(0x2979FF), cc(0x8E4DFF), cc(0x22223A), cc(0x22223A), cc(0xFFFFFF), cc(0xFFFFFF)),
    Pack("Ocean", cc(0x0D1B2A), cc(0x1B3B5A), cc(0x0A1420), cc(0x00B0FF), cc(0x0072FF), cc(0x1B3A57), cc(0x1B3A57), cc(0xFFFFFF), cc(0xFFFFFF)),
    Pack("Sunset", cc(0x2B1020), cc(0x4A1A2C), cc(0x2A0F1E), cc(0xFF512F), cc(0xDD2476), cc(0x4A2236), cc(0x4A2236), cc(0xFFFFFF), cc(0xFFFFFF)),
    Pack("Forest", cc(0x0E1F17), cc(0x143D2B), cc(0x0A1812), cc(0x11998E), cc(0x38EF7D), cc(0x1F3A2D), cc(0x1F3A2D), cc(0xFFFFFF), cc(0xFFFFFF)),
    Pack("Neon", cc(0x000000), cc(0x000000), cc(0x0A0A0A), cc(0xFF00E5), cc(0x7C4DFF), cc(0x111111), cc(0x111111), cc(0xFFFFFF), cc(0x39FF14)),
    Pack("WA Dark", cc(0x0B141A), cc(0x0B141A), cc(0x1F2C34), cc(0x005C4B), cc(0x005C4B), cc(0x1F2C34), cc(0x1F2C34), cc(0xFFFFFF), cc(0xFFFFFF)),
    Pack("Insta", cc(0x000000), cc(0x000000), cc(0x000000), cc(0x833AB4), cc(0xFD1D1D), cc(0x262626), cc(0x262626), cc(0xFFFFFF), cc(0xFFFFFF)),
    Pack("Light", cc(0xF2F2F7), cc(0xF2F2F7), cc(0xFFFFFF), cc(0x2979FF), cc(0x2979FF), cc(0xFFFFFF), cc(0xFFFFFF), cc(0xFFFFFF), cc(0x111111)),
    Pack("Rose", cc(0x2D0A1B), cc(0x4A1030), cc(0x3A0D24), cc(0xF953C6), cc(0xB91D73), cc(0x4A1A36), cc(0x4A1A36), cc(0xFFFFFF), cc(0xFFFFFF)),
    Pack("Gold", cc(0x1A1405), cc(0x2B220A), cc(0x241C08), cc(0xFDC830), cc(0xF37335), cc(0x332B12), cc(0x332B12), cc(0x1A1A1A), cc(0xFFE9A8)),
    Pack("Royal", cc(0x1A0B2E), cc(0x2E1065), cc(0x160A28), cc(0x8E2DE2), cc(0x4A00E0), cc(0x2E1F4D), cc(0x2E1F4D), cc(0xFFFFFF), cc(0xFFFFFF)),
    Pack("Ice", cc(0xE3F2FD), cc(0xBBDEFB), cc(0x90CAF9), cc(0x1565C0), cc(0x1565C0), cc(0xFFFFFF), cc(0xFFFFFF), cc(0xFFFFFF), cc(0x0D1B2A)),
    Pack("Carbon", cc(0x121212), cc(0x121212), cc(0x1E1E1E), cc(0x424242), cc(0x616161), cc(0x2A2A2A), cc(0x2A2A2A), cc(0xFFFFFF), cc(0xFFFFFF))
)

val DEF: Map<String, Int> = mapOf(
    "bg1" to cc(0x0B0B14), "bg2" to cc(0x0B0B14), "bar" to cc(0x14142A), "my1" to cc(0x2979FF), "my2" to cc(0x8E4DFF),
    "th1" to cc(0x22223A), "th2" to cc(0x22223A), "myT" to cc(0xFFFFFF), "thT" to cc(0xFFFFFF),
    "rad" to 18, "ff" to 0, "fsz" to 16, "bold" to 0, "wdim" to 35,
    "notif" to 1, "prev" to 0, "snd" to 1, "secure" to 1, "auto" to 1, "lockd" to 0, "blk" to 1, "rcpt" to 1
)
val APPEARANCE = listOf("bg1", "bg2", "bar", "my1", "my2", "th1", "th2", "myT", "thT", "rad", "ff", "fsz", "bold", "wdim")

class Th(private val p: SharedPreferences) {
    private val m = mutableStateMapOf<String, Int>().also { mm ->
        DEF.forEach { (k, d) -> mm[k] = try { p.getInt(k, d) } catch (e: Exception) { d } }
    }
    operator fun get(k: String): Int = m[k] ?: DEF[k] ?: 0
    operator fun set(k: String, v: Int) { m[k] = v; p.edit().putInt(k, v).apply() }
    fun col(k: String): Color = Color(this[k])
    fun on(k: String): Boolean = this[k] != 0
    fun setPack(t: Pack) {
        this["bg1"] = t.bg1; this["bg2"] = t.bg2; this["bar"] = t.bar; this["my1"] = t.my1; this["my2"] = t.my2
        this["th1"] = t.t1; this["th2"] = t.t2; this["myT"] = t.myT; this["thT"] = t.thT
    }
    fun resetLook() { APPEARANCE.forEach { k -> this[k] = DEF[k] ?: 0 } }
}

object St {
    var locked by mutableStateOf(true)
    var skip = false
    var viewing = false
    var screen by mutableIntStateOf(0)
    var ret by mutableIntStateOf(0)
}
data class Msg(val id: String, val mine: Boolean, val type: String, val body: String, val ts: Long, val read: Boolean, val pending: Boolean, val rx: Map<String, String> = emptyMap(), val reply: String = "", val edited: Boolean = false, val pin: Boolean = false, val delivered: Boolean = false)

object Cx {
    lateinit var key: SecretKeySpec
    fun set(s: String) {
        val f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        key = SecretKeySpec(f.generateSecret(PBEKeySpec(s.toCharArray(), "clock-v1".toByteArray(), 100000, 256)).encoded, "AES")
    }
    fun enc(b: ByteArray): ByteArray {
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
        return iv + c.doFinal(b)
    }
    fun dec(b: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, b, 0, 12))
        return c.doFinal(b, 12, b.size - 12)
    }
    fun encS(s: String) = Base64.encodeToString(enc(s.toByteArray()), Base64.NO_WRAP)
    fun decS(s: String) = try { String(dec(Base64.decode(s, Base64.NO_WRAP))) } catch (e: Exception) { "🔒 Secret key match nahi (Settings > Secret key badlo)" }
}

object Sb {
    private fun conn(path: String, post: Boolean): HttpURLConnection {
        val c = URL("$SB/storage/v1/object/$path").openConnection() as HttpURLConnection
        c.setRequestProperty("apikey", KEY); c.connectTimeout = 20000; c.readTimeout = 120000
        if (post) { c.requestMethod = "POST"; c.doOutput = true; c.setRequestProperty("Content-Type", "application/octet-stream") }
        return c
    }
    fun up(name: String, d: ByteArray): Boolean {
        val c = conn("media/$name", true); c.setFixedLengthStreamingMode(d.size)
        c.outputStream.use { it.write(d) }
        return c.responseCode in 200..299
    }
    fun down(name: String): ByteArray? {
        val c = conn("authenticated/media/$name", false)
        return if (c.responseCode == 200) c.inputStream.use { it.readBytes() } else null
    }
}


fun shrink(c: Context, u: Uri): ByteArray {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    c.contentResolver.openInputStream(u)!!.use { BitmapFactory.decodeStream(it, null, o) }
    var s = 1; while (o.outWidth / s > 1600) s *= 2
    val b = c.contentResolver.openInputStream(u)!!.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s }) }!!
    return ByteArrayOutputStream().also { b.compress(Bitmap.CompressFormat.JPEG, 82, it) }.toByteArray()
}


fun saveMedia(c: Context, d: ByteArray, video: Boolean): Boolean {
    return try {
        val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val name = if (video) "Snake_$ts.mp4" else "Snake_$ts.jpg"
        val mime = if (video) "video/mp4" else "image/jpeg"
        if (Build.VERSION.SDK_INT >= 29) {
            val v = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, if (video) "Movies/Snake" else "Pictures/Snake")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val col = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            val u = c.contentResolver.insert(col, v)!!
            c.contentResolver.openOutputStream(u)!!.use { it.write(d) }
            val v2 = ContentValues(); v2.put(MediaStore.MediaColumns.IS_PENDING, 0)
            c.contentResolver.update(u, v2, null, null)
            true
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(if (video) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_PICTURES), "Snake")
            dir.mkdirs()
            val f = File(dir, name); f.writeBytes(d)
            MediaScannerConnection.scanFile(c, arrayOf(f.path), arrayOf(mime), null)
            true
        }
    } catch (e: Exception) { false }
}

class MainActivity : ComponentActivity() {
    var fg = false
    var stopT = 0L
    var stopSkip = false
    val prefs: SharedPreferences by lazy {
        EncryptedSharedPreferences.create(this, "p", MasterKey.Builder(this).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV, EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    }
    lateinit var th: Th

    fun startSvc() {
        if (FirebaseAuth.getInstance().currentUser == null) return
        try { startForegroundService(Intent(this, ListenService::class.java)) } catch (e: Exception) { }
    }
    fun pres(on: Boolean) {
        val u = FirebaseAuth.getInstance().currentUser ?: return
        FirebaseFirestore.getInstance().collection("users").document(u.uid)
            .set(hashMapOf<String, Any>("online" to on, "lastSeen" to FieldValue.serverTimestamp()), SetOptions.merge())
    }
    fun stopSvc() { stopService(Intent(this, ListenService::class.java)) }

    fun secure() {
        if (th.on("secure")) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        th = Th(prefs)
        secure()
        val nm = getSystemService(NotificationManager::class.java)
        ensureChannels(this)
        val need = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 33) {
            need.add(Manifest.permission.POST_NOTIFICATIONS)
            need.add(Manifest.permission.READ_MEDIA_IMAGES)
            need.add(Manifest.permission.READ_MEDIA_VIDEO)
        } else {
            need.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            if (Build.VERSION.SDK_INT <= 28) need.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        val miss = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (miss.isNotEmpty()) { St.skip = true; requestPermissions(miss.toTypedArray(), 1) }
        startSvc()
        setContent { App(this) }
    }

    override fun onStart() {
        super.onStart(); fg = true; St.viewing = true; startSvc(); scheduleGame(this)
        val d = th["lockd"]
        if (!stopSkip && th.on("auto") && d > 0 && stopT > 0 && System.currentTimeMillis() - stopT >= d * 1000L) St.locked = true
        St.skip = false
        if (!St.locked) pres(true)
    }
    override fun onResume() { super.onResume(); St.skip = false }
    override fun onStop() {
        super.onStop(); fg = false; St.viewing = false; pres(false)
        stopSkip = St.skip; stopT = System.currentTimeMillis()
        if (!St.skip && th.on("auto") && th["lockd"] == 0) St.locked = true
    }

    fun ping(body: String?) {
        if (!th.on("notif")) return
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(this, if (th.on("snd")) "mh" else "mq").setSmallIcon(android.R.drawable.ic_dialog_email)
            .setContentTitle("Snake").setContentText(body ?: "Naya message").setContentIntent(pi).setAutoCancel(true)
            .setVisibility(Notification.VISIBILITY_SECRET).build()
        getSystemService(NotificationManager::class.java).notify(1, n)
    }
}

@Composable fun App(a: MainActivity) {
    val p = a.prefs
    var user by remember { mutableStateOf(FirebaseAuth.getInstance().currentUser) }
    var sec by remember { mutableStateOf(p.getString("sec", null)?.also { Cx.set(it) }) }
    MaterialTheme(colorScheme = darkColorScheme()) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFF0B0B14)) {
            when {
                St.locked -> SnakeLock()
                user == null -> Login { user = it; a.startSvc() }
                sec == null -> Secret { p.edit().putString("sec", it).apply(); Cx.set(it); sec = it }
                else -> Chat(a, p, { p.edit().remove("sec").apply(); sec = null }) { St.screen = 0; St.ret = 0; a.stopSvc(); FirebaseAuth.getInstance().signOut(); user = null }
            }
        }
    }
}

// ---------- SNAKE LOCK SCREEN (ye hi ab "lock" hai) ----------
private const val COLS = 16
private const val ROWS = 22
private val LV_NAMES = listOf("Open Field", "Barrier", "Twin Walls", "Cross", "Corners", "Zigzag", "Box", "Pillars")
private val LV_TARGET = intArrayOf(8, 10, 12, 14, 16, 18, 20, 0) // itne point par agla level khulta hai

private fun lvWalls(l: Int): Set<Pair<Int, Int>> {
    val w = HashSet<Pair<Int, Int>>()
    when (l) {
        1 -> for (x in 4..11) w.add(Pair(x, 11))
        2 -> for (y in 8..14) { w.add(Pair(4, y)); w.add(Pair(11, y)) }
        3 -> { for (x in 5..10) w.add(Pair(x, 11)); for (y in 8..14) w.add(Pair(8, y)) }
        4 -> for (cx in listOf(3, 11)) for (cy in listOf(8, 14)) for (dx in 0..1) for (dy in 0..1) w.add(Pair(cx + dx, cy + dy))
        5 -> { for (x in 0..9) w.add(Pair(x, 8)); for (x in 6..15) w.add(Pair(x, 15)) }
        6 -> {
            for (x in 4..11) { w.add(Pair(x, 8)); w.add(Pair(x, 15)) }
            for (y in 8..15) { w.add(Pair(4, y)); w.add(Pair(11, y)) }
            for (g in listOf(Pair(7, 8), Pair(8, 8), Pair(7, 15), Pair(8, 15), Pair(4, 11), Pair(4, 12), Pair(11, 11), Pair(11, 12))) w.remove(g)
        }
        7 -> for (x in listOf(3, 6, 9, 12)) for (y in listOf(8, 11, 14, 17)) w.add(Pair(x, y))
    }
    return w
}

@Composable fun SnakeLock() {
    val ctx = LocalContext.current
    val gp = remember { ctx.getSharedPreferences("snake", Context.MODE_PRIVATE) }
    var lvl by remember { mutableIntStateOf(0) }
    var unl by remember { mutableIntStateOf(gp.getInt("unl", 0).coerceIn(0, 7)) }
    var walls by remember { mutableStateOf(lvWalls(0)) }
    var snake by remember { mutableStateOf(listOf(Pair(4, 2), Pair(3, 2), Pair(2, 2))) }
    var dir by remember { mutableStateOf(Pair(1, 0)) }
    var nextDir by remember { mutableStateOf(Pair(1, 0)) }
    var food by remember { mutableStateOf(Pair(12, 4)) }
    var score by remember { mutableIntStateOf(0) }
    var best by remember { mutableIntStateOf(gp.getInt("best0", 0)) }
    var state by remember { mutableIntStateOf(0) } // 0 ready, 1 playing, 2 game over
    var newBest by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf("") }

    fun spawn(s: List<Pair<Int, Int>>, w: Set<Pair<Int, Int>>): Pair<Int, Int> {
        var f: Pair<Int, Int>
        do { f = Pair((0 until COLS).random(), (0 until ROWS).random()) } while (f in s || f in w)
        return f
    }
    fun prep(l: Int) {
        lvl = l; walls = lvWalls(l); best = gp.getInt("best$l", 0)
        snake = listOf(Pair(4, 2), Pair(3, 2), Pair(2, 2)); dir = Pair(1, 0); nextDir = Pair(1, 0)
        score = 0; newBest = false; food = spawn(snake, walls)
    }
    LaunchedEffect(Unit) { prep(0) }
    LaunchedEffect(state) {
        while (state == 1) {
            delay(maxOf(60L, 150L - lvl * 7L - score * 2L))
            if (state != 1) break
            if (!St.viewing) { state = 0; break }
            dir = nextDir
            val h = snake.first()
            val nh = Pair((h.first + dir.first + COLS) % COLS, (h.second + dir.second + ROWS) % ROWS) // border cross karke dusri taraf
            val eat = nh == food
            val body = if (eat) snake else snake.dropLast(1)
            if (nh in body || nh in walls) {
                if (score > best) { best = score; newBest = true; gp.edit().putInt("best$lvl", best).apply() }
                if (score > gp.getInt("best", 0)) gp.edit().putInt("best", score).apply()
                state = 2; break
            }
            snake = listOf(nh) + body
            if (eat) {
                score++; food = spawn(snake, walls)
                if (lvl == unl && lvl < 7 && score >= LV_TARGET[lvl]) { unl = lvl + 1; gp.edit().putInt("unl", unl).apply(); note = "🔓 Level ${unl + 1} unlock ho gaya!" }
            }
        }
    }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0B1A12), Color(0xFF07110B))))) {
        Column(Modifier.fillMaxSize().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(R.drawable.snake_logo), null, Modifier.size(42.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("SNAKE · Level ${lvl + 1}", color = Color(0xFF7CFC00), fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text("Score $score   ·   Best $best", color = Color.White.copy(alpha = 0.75f), fontSize = 13.sp)
                }
                // chhota "lives" jaisa dikhne wala heart: tap/short-press par kuch nahi, 3 sec dabaye rakho to chat khulti hai
                Row(Modifier.pointerInput(Unit) {
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false)
                        val r = withTimeoutOrNull(3000L) { waitForUpOrCancellation(); true }
                        if (r == null) St.locked = false
                    }
                }.padding(horizontal = 12.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Favorite, null, tint = Color(0xFFE53935).copy(alpha = 0.55f), modifier = Modifier.size(16.dp))
                    Text(" x1", color = Color.White.copy(alpha = 0.4f), fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(8.dp))
            Box(Modifier.fillMaxWidth().aspectRatio(COLS.toFloat() / ROWS).clip(RoundedCornerShape(14.dp)).background(Color(0xFF12281B))
                .pointerInput(Unit) { detectTapGestures { if (state != 1) { prep(lvl); note = ""; state = 1 } } }
                .pointerInput(Unit) {
                    var ax = 0f; var ay = 0f
                    detectDragGestures(onDragStart = { ax = 0f; ay = 0f }) { change, d ->
                        change.consume(); ax += d.x; ay += d.y
                        if (maxOf(abs(ax), abs(ay)) > 36f) {
                            val nd = if (abs(ax) > abs(ay)) Pair(if (ax > 0) 1 else -1, 0) else Pair(0, if (ay > 0) 1 else -1)
                            if (state == 1 && (nd.first != -dir.first || nd.second != -dir.second)) nextDir = nd
                            ax = 0f; ay = 0f
                        }
                    }
                }) {
                Canvas(Modifier.fillMaxSize()) {
                    val cs = size.width / COLS
                    for (x in 0 until COLS) for (y in 0 until ROWS) if ((x + y) % 2 == 0) drawRect(Color(0x0FFFFFFF), Offset(x * cs, y * cs), Size(cs, cs))
                    for (w in walls) {
                        drawRoundRect(Color(0xFF546E7A), Offset(w.first * cs + cs * 0.04f, w.second * cs + cs * 0.04f), Size(cs * 0.92f, cs * 0.92f), CornerRadius(cs * 0.18f))
                        drawRoundRect(Color(0x33FFFFFF), Offset(w.first * cs + cs * 0.12f, w.second * cs + cs * 0.12f), Size(cs * 0.76f, cs * 0.3f), CornerRadius(cs * 0.12f))
                    }
                    val fc = Offset(food.first * cs + cs / 2f, food.second * cs + cs / 2f)
                    drawCircle(Color(0xFFE53935), cs * 0.38f, fc + Offset(0f, cs * 0.05f))
                    drawCircle(Color(0x66FFFFFF), cs * 0.09f, fc + Offset(-cs * 0.13f, -cs * 0.06f))
                    drawLine(Color(0xFF5D4037), Offset(fc.x, fc.y - cs * 0.28f), Offset(fc.x + cs * 0.04f, fc.y - cs * 0.45f), cs * 0.07f, StrokeCap.Round)
                    drawOval(Color(0xFF66BB6A), Offset(fc.x + cs * 0.03f, fc.y - cs * 0.5f), Size(cs * 0.28f, cs * 0.15f))
                    snake.forEachIndexed { i, p ->
                        val col = if (i == 0) Color(0xFF9BEA4A) else if (i % 2 == 0) Color(0xFF2FD24A) else Color(0xFF27B83F)
                        val inset = if (i == 0) cs * 0.02f else cs * 0.07f
                        drawRoundRect(col, Offset(p.first * cs + inset, p.second * cs + inset), Size(cs - inset * 2, cs - inset * 2), CornerRadius(cs * 0.32f))
                    }
                    val hd = snake.first(); val hc2 = Offset(hd.first * cs + cs / 2f, hd.second * cs + cs / 2f)
                    val fx = dir.first.toFloat(); val fy = dir.second.toFloat()
                    for (sd in listOf(-1f, 1f)) {
                        val e = hc2 + Offset(fx * cs * 0.16f - fy * sd * cs * 0.17f, fy * cs * 0.16f + fx * sd * cs * 0.17f)
                        drawCircle(Color.White, cs * 0.12f, e)
                        drawCircle(Color.Black, cs * 0.06f, e + Offset(fx * cs * 0.03f, fy * cs * 0.03f))
                    }
                }
                if (state != 1) Box(Modifier.fillMaxSize().background(Color(0x99000000)), Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        if (state == 2) {
                            Text("Game Over", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                            Text("Score: $score", color = Color(0xFF7CFC00), fontSize = 20.sp, modifier = Modifier.padding(top = 6.dp))
                            if (newBest) Text("🏆 New Best!", color = Color(0xFFFFD600), fontSize = 18.sp, modifier = Modifier.padding(top = 4.dp))
                            Text("Dobara khelne ke liye tap karo", color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp, modifier = Modifier.padding(top = 14.dp))
                        } else {
                            Text("🐍 Tap to play", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                            Text("Level ${lvl + 1}: ${LV_NAMES[lvl]}", color = Color(0xFF7CFC00), fontSize = 16.sp, modifier = Modifier.padding(top = 8.dp))
                            Text("Swipe karke snake ghumao", color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp))
                        }
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Column(Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState())) {
                Text("LEVELS", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                (0 until 8).chunked(4).forEach { row ->
                    Row(Modifier.fillMaxWidth().padding(bottom = 6.dp)) {
                        row.forEach { i ->
                            val open = i <= unl; val sel = i == lvl
                            Box(Modifier.weight(1f).padding(horizontal = 3.dp).height(46.dp).clip(RoundedCornerShape(12.dp))
                                .background(if (sel) Color(0xFF1F6B34) else if (open) Color(0xFF16301F) else Color(0xFF111A14))
                                .border(if (sel) 2.dp else 1.dp, if (sel) Color(0xFF7CFC00) else Color(0x33FFFFFF), RoundedCornerShape(12.dp))
                                .clickable {
                                    if (state == 1) return@clickable
                                    if (open) { prep(i); note = ""; state = 0 }
                                    else note = "🔒 Pehle Level $i mein ${LV_TARGET[i - 1]} point banao"
                                }, Alignment.Center) {
                                Text(if (open) "${i + 1}" else "🔒", color = if (open) Color.White else Color.White.copy(alpha = 0.5f), fontSize = 17.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                Text(if (lvl < 7) "Level ${lvl + 1} mein ${LV_TARGET[lvl]} point banao → Level ${lvl + 2} khulega" else "Last level! Ab bas high score banao 🏆",
                    color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp)
                if (note.isNotEmpty()) Text(note, color = Color(0xFFFFD600), fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
            }
        }
    }
}

@Composable fun Login(done: (FirebaseUser) -> Unit) {
    var e by remember { mutableStateOf("") }; var pw by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }; var busy by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF16213E), Color(0xFF0B0B14)))).padding(28.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Text("🕒", fontSize = 64.sp)
        Text("Snake", fontSize = 34.sp, color = Color.White, fontWeight = FontWeight.Bold)
        Text("Sirf hum dono ke liye", color = Color.Gray)
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(e, { e = it }, label = { Text("Email") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(pw, { pw = it }, label = { Text("Password") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(16.dp))
        Button({
            busy = true; msg = ""
            FirebaseAuth.getInstance().signInWithEmailAndPassword(e.trim(), pw).addOnCompleteListener {
                busy = false
                if (it.isSuccessful) done(it.result.user!!) else msg = it.exception?.message ?: "Login fail"
            }
        }, Modifier.fillMaxWidth().height(52.dp), enabled = !busy && e.isNotBlank() && pw.isNotBlank()) { Text(if (busy) "..." else "Login", fontSize = 18.sp) }
        Text(msg, color = Color(0xFFFF6B6B), modifier = Modifier.padding(top = 10.dp), textAlign = TextAlign.Center)
    }
}

@Composable fun Secret(ok: (String) -> Unit) {
    var s by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(28.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Text("🔐", fontSize = 56.sp)
        Text("Secret key", fontSize = 26.sp, color = Color.White, fontWeight = FontWeight.Bold)
        Text("Dono phone mein bilkul same daalna. Isse chat encrypt hoti hai.", color = Color.Gray, textAlign = TextAlign.Center)
        Spacer(Modifier.height(16.dp))
        Text("Spelling dono mein bilkul same (capital/small farak nahi padta)", color = Color.Gray, fontSize = 12.sp)
        OutlinedTextField(s, { s = it }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        Button({ if (s.trim().length >= 6) ok(s.trim().lowercase()) }, Modifier.fillMaxWidth()) { Text(if (s.length >= 6) "Save" else "Kam se kam 6 character") }
    }
}

const val U1 = "DJ9MrRvM3HTLjUgMhlNFnZcXMjB3"
const val U2 = "X7xUw4dVCQeYVy1jGmzN8Fz1TzV2"

@Composable fun Avatar(photo: String?, s: Dp, label: String, mod: Modifier = Modifier) {
    var b by remember(photo) { mutableStateOf(photo?.let { CACHE[it] }) }
    LaunchedEffect(photo) {
        if (photo != null && b == null) b = withContext(Dispatchers.IO) {
            runCatching { Sb.down(photo)?.let { val d = Cx.dec(it); BitmapFactory.decodeByteArray(d, 0, d.size) } }.getOrNull()?.also { CACHE[photo] = it }
        }
    }
    Box(mod.size(s).clip(CircleShape).background(ACC), Alignment.Center) {
        val x = b
        if (x != null) Image(x.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Text(label.take(1).uppercase(), color = Color.White, fontSize = (s.value / 2.2f).sp, fontWeight = FontWeight.Bold)
    }
}


@OptIn(ExperimentalFoundationApi::class)
@Composable fun Voice(n: String, tc: Color, onLong: () -> Unit) {
    val ctx = LocalContext.current; val sc = rememberCoroutineScope()
    var st by remember { mutableIntStateOf(0) }
    var mp by remember { mutableStateOf<MediaPlayer?>(null) }
    DisposableEffect(Unit) { onDispose { runCatching { mp?.release() } } }
    Row(Modifier.combinedClickable(onLongClick = onLong) {
        if (st == 2) { runCatching { mp?.release() }; mp = null; st = 0 }
        else if (st == 0) {
            st = 1
            sc.launch(Dispatchers.IO) {
                val path = runCatching { Sb.down(n)?.let { val f = File(ctx.cacheDir, "$n.m4a"); f.writeBytes(Cx.dec(it)); f.path } }.getOrNull()
                withContext(Dispatchers.Main) {
                    if (path == null) st = 0 else try {
                        val m = MediaPlayer(); m.setDataSource(path); m.prepare()
                        m.setOnCompletionListener { it.release(); mp = null; st = 0; File(path).delete() }
                        m.start(); mp = m; st = 2
                    } catch (e: Exception) { st = 0 }
                }
            }
        }
    }, verticalAlignment = Alignment.CenterVertically) {
        Text(when (st) { 1 -> "⏳"; 2 -> "⏸"; else -> "▶" }, fontSize = 26.sp, color = tc)
        Spacer(Modifier.width(8.dp))
        Box(Modifier.width(110.dp).height(4.dp).clip(RoundedCornerShape(2.dp)).background(tc.copy(alpha = 0.4f)))
        Spacer(Modifier.width(8.dp))
        Text("🎤", fontSize = 16.sp)
    }
}

fun bubbleShape(th: Th, mine: Boolean): Shape {
    val r = th["rad"].dp
    return RoundedCornerShape(r, r, if (mine) 4.dp else r, if (mine) r else 4.dp)
}
fun bubbleBrush(th: Th, mine: Boolean): Brush =
    if (mine) Brush.horizontalGradient(listOf(th.col("my1"), th.col("my2"))) else Brush.horizontalGradient(listOf(th.col("th1"), th.col("th2")))

@Composable fun Bubble(m: Msg, th: Th, ff: FontFamily, onMenu: (Msg) -> Unit, onOpen: (Msg) -> Unit, onReact: (Msg, String) -> Unit) {
    val fmt = remember { SimpleDateFormat("h:mm a", Locale.getDefault()) }
    val body = remember(m.body) { Cx.decS(m.body) }
    val tcol = th.col(if (m.mine) "myT" else "thT")
    Column(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalAlignment = if (m.mine) Alignment.End else Alignment.Start) {
        Column(Modifier.widthIn(max = 280.dp).clip(bubbleShape(th, m.mine)).background(bubbleBrush(th, m.mine))
            .pointerInput(m.id) {
                detectTapGestures(onDoubleTap = { if (m.type != "deleted") onReact(m, "❤️") }, onLongPress = { onMenu(m) }, onTap = { if (m.type == "image" || m.type == "video") onOpen(m) })
            }.padding(10.dp)) {
            if (m.reply.isNotEmpty() && m.type != "deleted") Box(Modifier.padding(bottom = 6.dp).clip(RoundedCornerShape(8.dp)).background(tcol.copy(alpha = 0.14f)).padding(horizontal = 8.dp, vertical = 5.dp)) {
                Text(Cx.decS(m.reply), color = tcol.copy(alpha = 0.8f), fontSize = 12.sp, maxLines = 2)
            }
            when (m.type) {
                "text" -> Text(body, color = tcol, fontFamily = ff, fontSize = th["fsz"].sp, fontWeight = if (th.on("bold")) FontWeight.Bold else FontWeight.Normal)
                "voice" -> Voice(body, tcol) { onMenu(m) }
                "deleted" -> Text("🚫 Ye message unsend ho gaya", color = tcol.copy(alpha = 0.6f), fontSize = 14.sp)
                else -> Media(body, m.type == "video")
            }
            Row(Modifier.align(Alignment.End), verticalAlignment = Alignment.CenterVertically) {
                Text((if (m.pin) "📌 " else "") + (if (m.edited && m.type == "text") "edited · " else "") + fmt.format(Date(m.ts)), color = tcol.copy(alpha = 0.7f), fontSize = 10.sp)
                if (m.mine) {
                    val seen = m.read
                    val tk = if (m.pending) "🕓" else if (m.delivered || m.read) "✓✓" else "✓"
                    val tkc = if (seen) (if (Color(th[if (m.mine) "my1" else "th1"]).luminance() > 0.5f) Color(0xFF0277BD) else Color(0xFF4FC3F7)) else tcol.copy(alpha = 0.65f)
                    Text("  " + tk, color = tkc, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        if (m.rx.isNotEmpty() && m.type != "deleted") Box(Modifier.offset(y = (-6).dp).padding(horizontal = 8.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF2B2B3F)).padding(horizontal = 7.dp, vertical = 2.dp)) {
            Text(m.rx.values.joinToString(" "), fontSize = 14.sp)
        }
    }
}

@Composable fun Media(n: String, v: Boolean) {
    var bmp by remember { mutableStateOf(CACHE[n]) }
    LaunchedEffect(n) {
        if (!v && bmp == null) bmp = withContext(Dispatchers.IO) {
            runCatching { Sb.down(n)?.let { val d = Cx.dec(it); BitmapFactory.decodeByteArray(d, 0, d.size) } }.getOrNull()?.also { CACHE[n] = it }
        }
    }
    Box(Modifier.size(220.dp).clip(RoundedCornerShape(12.dp)).background(if (v) Color(0xFF1C1C28) else Color(0x33000000)), Alignment.Center) {
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Text(if (v) "▶  Video" else "⏳", color = Color.White, fontSize = if (v) 18.sp else 28.sp)
    }
}

@Composable fun Viewer(n: String, video: Boolean, close: () -> Unit) {
    val ctx = LocalContext.current; val sc = rememberCoroutineScope()
    var bmp by remember { mutableStateOf<Bitmap?>(null) }
    var path by remember { mutableStateOf<String?>(null) }
    var fail by remember { mutableStateOf(false) }
    var scale by remember { mutableFloatStateOf(1f) }
    var off by remember { mutableStateOf(Offset.Zero) }
    fun toast(s: String) { Handler(Looper.getMainLooper()).post { Toast.makeText(ctx, s, Toast.LENGTH_LONG).show() } }
    LaunchedEffect(n) {
        val r = withContext(Dispatchers.IO) {
            runCatching {
                val d = Cx.dec(Sb.down(n)!!)
                if (video) { val f = File(ctx.cacheDir, "$n.mp4"); f.writeBytes(d); Pair<String?, Bitmap?>(f.path, null) }
                else Pair<String?, Bitmap?>(null, BitmapFactory.decodeByteArray(d, 0, d.size))
            }.getOrNull()
        }
        if (r == null) fail = true else { path = r.first; bmp = r.second }
    }
    DisposableEffect(Unit) { onDispose { path?.let { File(it).delete() } } }
    fun download() {
        sc.launch(Dispatchers.IO) {
            val ok = runCatching {
                val d = if (video) File(path!!).readBytes() else Cx.dec(Sb.down(n)!!)
                saveMedia(ctx, d, video)
            }.getOrDefault(false)
            toast(if (ok) "✅ Save ho gaya (Gallery > Snake)" else "Save fail — storage permission check karo")
        }
    }
    Dialog(close, DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            val b = bmp; val pth = path
            if (b != null) {
                Image(b.asImageBitmap(), null,
                    Modifier.fillMaxSize()
                        .pointerInput(Unit) {
                            detectTransformGestures { _, pan, zoom, _ ->
                                scale = (scale * zoom).coerceIn(1f, 6f)
                                off = if (scale <= 1f) Offset.Zero else off + pan
                            }
                        }
                        .pointerInput(Unit) {
                            detectTapGestures(onDoubleTap = { if (scale > 1f) { scale = 1f; off = Offset.Zero } else scale = 2.5f })
                        }
                        .graphicsLayer(scaleX = scale, scaleY = scale, translationX = off.x, translationY = off.y),
                    contentScale = ContentScale.Fit)
            } else if (pth != null) {
                AndroidView({ c -> VideoView(c).apply { setVideoPath(pth); setMediaController(MediaController(c).also { it.setAnchorView(this) }); setOnPreparedListener { start() } } }, Modifier.fillMaxSize())
            } else {
                Text(if (fail) "Load nahi hua" else "⏳ Load ho raha hai...", color = Color.White, fontSize = 18.sp, modifier = Modifier.align(Alignment.Center))
            }
            Row(Modifier.fillMaxWidth().align(Alignment.TopCenter).background(Color(0x66000000)).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(close) { Text("✕", color = Color.White, fontSize = 22.sp) }
                Spacer(Modifier.weight(1f))
                TextButton({ download() }, enabled = b != null || pth != null) { Text("⬇ Download", color = Color.White, fontSize = 16.sp) }
            }
        }
    }
}

// ---------- settings helpers ----------
@Composable fun Sec(tc: Color, title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp).clip(RoundedCornerShape(16.dp)).background(tc.copy(alpha = 0.07f)).padding(14.dp)) {
        Text(title, color = tc, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Spacer(Modifier.height(8.dp))
        content()
    }
}
@Composable fun Lbl(tc: Color, t: String) { Text(t, color = tc.copy(alpha = 0.65f), fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp, bottom = 4.dp)) }
@Composable fun Sw(tc: Color, title: String, sub: String, on: Boolean, change: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = tc, fontSize = 15.sp)
            if (sub.isNotEmpty()) Text(sub, color = tc.copy(alpha = 0.6f), fontSize = 12.sp)
        }
        Switch(on, change)
    }
}
@Composable fun Pill(t: String, sel: Boolean, tc: Color, mod: Modifier = Modifier, f: FontFamily = FontFamily.Default, onClick: () -> Unit) {
    Box(mod.padding(3.dp).clip(RoundedCornerShape(20.dp)).background(if (sel) Color(0xFF2979FF) else tc.copy(alpha = 0.12f)).clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 8.dp), Alignment.Center) {
        Text(t, color = if (sel) Color.White else tc, fontFamily = f, fontSize = 14.sp, maxLines = 1)
    }
}

@Composable fun ColorDialog(init: Int, ok: (Int) -> Unit, close: () -> Unit) {
    var r by remember { mutableFloatStateOf(((init shr 16) and 255).toFloat()) }
    var g by remember { mutableFloatStateOf(((init shr 8) and 255).toFloat()) }
    var b by remember { mutableFloatStateOf((init and 255).toFloat()) }
    AlertDialog(onDismissRequest = close,
        confirmButton = { TextButton({ ok(cc((r.toInt() shl 16) or (g.toInt() shl 8) or b.toInt())); close() }) { Text("OK") } },
        dismissButton = { TextButton(close) { Text("Cancel") } },
        title = { Text("🎨 Apna color") },
        text = {
            Column {
                Box(Modifier.fillMaxWidth().height(54.dp).clip(RoundedCornerShape(12.dp)).background(Color(r.toInt(), g.toInt(), b.toInt())))
                Text("Red"); Slider(r, { r = it }, valueRange = 0f..255f)
                Text("Green"); Slider(g, { g = it }, valueRange = 0f..255f)
                Text("Blue"); Slider(b, { b = it }, valueRange = 0f..255f)
            }
        })
}

@Composable fun Swatches(list: List<Pair<Int, Int>>, a: Int, b: Int, onPick: (Int, Int) -> Unit) {
    var custom by remember { mutableStateOf(false) }
    val items: List<Pair<Int, Int>?> = list + listOf(null)
    Column {
        items.chunked(8).forEach { row ->
            Row {
                row.forEach { pr ->
                    if (pr == null) {
                        Box(Modifier.padding(3.dp).size(34.dp).clip(CircleShape).background(Brush.sweepGradient(listOf(Color.Red, Color.Yellow, Color.Green, Color.Cyan, Color.Blue, Color.Magenta, Color.Red)))
                            .clickable { custom = true }, Alignment.Center) { Text("+", color = Color.White, fontWeight = FontWeight.Bold) }
                    } else {
                        val s = pr.first == a && pr.second == b
                        Box(Modifier.padding(3.dp).size(34.dp).clip(CircleShape).background(Brush.verticalGradient(listOf(Color(pr.first), Color(pr.second))))
                            .border(if (s) 3.dp else 1.dp, if (s) Color(0xFF2979FF) else Color(0x55888888), CircleShape).clickable { onPick(pr.first, pr.second) })
                    }
                }
            }
        }
    }
    if (custom) ColorDialog(a, { onPick(it, it) }, { custom = false })
}

@Composable fun Sample(th: Th, mine: Boolean, t: String, ff: FontFamily) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Box(Modifier.padding(vertical = 3.dp).clip(bubbleShape(th, mine)).background(bubbleBrush(th, mine)).padding(10.dp)) {
            Text(t, color = th.col(if (mine) "myT" else "thT"), fontFamily = ff, fontSize = th["fsz"].sp, fontWeight = if (th.on("bold")) FontWeight.Bold else FontWeight.Normal)
        }
    }
}

@Composable fun SettingsScreen(a: MainActivity, th: Th, name: String, photo: String?, wall: Bitmap?, onWall: () -> Unit, rmWall: () -> Unit,
                               onProfile: () -> Unit, onBack: () -> Unit, reKey: () -> Unit, out: () -> Unit, clear: () -> Unit, unhide: () -> Unit, clearAll: () -> Unit) {
    val tc = onCol(th["bg1"]); val hc = onCol(th["bar"])
    val ff = FONTS[th["ff"].coerceIn(0, FONTS.lastIndex)].second
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().background(th.col("bar")).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onBack) { Text("←", color = hc, fontSize = 24.sp) }
            Text("Settings", color = hc, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(14.dp)) {
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(tc.copy(alpha = 0.07f)).clickable { onProfile() }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Avatar(photo, 60.dp, name)
                Spacer(Modifier.width(14.dp))
                Column {
                    Text(name, color = tc, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("Profile edit karne ke liye tap karo", color = tc.copy(alpha = 0.6f), fontSize = 12.sp)
                }
            }
            Sec(tc, "👀 Live preview") {
                Sample(th, false, "Hello! Kaise ho? 😊", ff)
                Sample(th, true, "Mast hoon, tum batao 😎", ff)
            }
            Sec(tc, "🎨 Ready themes (ek tap mein)") {
                Row(Modifier.horizontalScroll(rememberScrollState())) {
                    PACKS.forEach { pk ->
                        Column(Modifier.padding(4.dp).width(96.dp).clip(RoundedCornerShape(14.dp)).background(Brush.verticalGradient(listOf(Color(pk.bg1), Color(pk.bg2))))
                            .border(1.dp, tc.copy(alpha = 0.25f), RoundedCornerShape(14.dp)).clickable { th.setPack(pk) }.padding(8.dp)) {
                            Box(Modifier.clip(RoundedCornerShape(8.dp)).background(Brush.horizontalGradient(listOf(Color(pk.t1), Color(pk.t2)))).padding(horizontal = 8.dp, vertical = 3.dp)) { Text("Hi", color = Color(pk.thT), fontSize = 12.sp) }
                            Spacer(Modifier.height(4.dp))
                            Box(Modifier.align(Alignment.End).clip(RoundedCornerShape(8.dp)).background(Brush.horizontalGradient(listOf(Color(pk.my1), Color(pk.my2)))).padding(horizontal = 8.dp, vertical = 3.dp)) { Text("Hey", color = Color(pk.myT), fontSize = 12.sp) }
                            Spacer(Modifier.height(4.dp))
                            Text(pk.n, color = onCol(pk.bg1), fontSize = 11.sp)
                        }
                    }
                }
            }
            Sec(tc, "🌄 Background") {
                Row(Modifier.padding(top = 8.dp)) {
                    Pill("🖼 Wallpaper chuno", false, tc) { onWall() }
                    if (wall != null) Pill("❌ Wallpaper hatao", false, tc) { rmWall() }
                }
                if (wall != null) {
                    Lbl(tc, "Wallpaper dim (${th["wdim"]}%)")
                    Slider(th["wdim"].toFloat(), { th["wdim"] = it.toInt() }, valueRange = 0f..85f)
                }
            }
            Sec(tc, "🔔 Notifications") {
                Sw(tc, "Message notification", "Naya message aane par notification", th.on("notif")) { th["notif"] = if (it) 1 else 0 }
                Sw(tc, "Notification mein message dikhao", "Lock screen par hamesha chhupa rehta hai", th.on("prev")) { th["prev"] = if (it) 1 else 0 }
                Sw(tc, "Sound", "Band karne par silent notification", th.on("snd")) { th["snd"] = if (it) 1 else 0 }
                Pill("🔋 Battery restriction hatao (notification ke liye)", false, tc) {
                    St.skip = true
                    a.startActivity(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                }
                Pill("⚙ Android notification settings", false, tc) {
                    St.skip = true
                    a.startActivity(Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, a.packageName))
                }
            }
            Sec(tc, "🔒 Privacy & Security") {
                Sw(tc, "Recents / screenshot mein chat chhupao", "Recent apps mein blank dikhega (screenshot bhi band)", th.on("secure")) { th["secure"] = if (it) 1 else 0; a.secure() }
                Sw(tc, "App chhodte hi game lock", "Home / recents par jaate hi lock", th.on("auto")) { th["auto"] = if (it) 1 else 0 }
                if (th.on("auto")) {
                    Lbl(tc, "Lock kitni der baad")
                    Row(Modifier.horizontalScroll(rememberScrollState())) {
                        listOf(0 to "Turant", 15 to "15 sec", 30 to "30 sec", 60 to "1 min", 300 to "5 min").forEach { (s, l) -> Pill(l, th["lockd"] == s, tc) { th["lockd"] = s } }
                    }
                }
                Sw(tc, "Back dabate hi game lock", "Unlock karte hi wahi screen khulegi jo chal rahi thi", th.on("blk")) { th["blk"] = if (it) 1 else 0 }
                Sw(tc, "Read receipts (✓✓)", "Band karne par samne wale ko 'seen' nahi dikhega", th.on("rcpt")) { th["rcpt"] = if (it) 1 else 0 }
                Pill("🔐 Secret key badlo", false, tc) { reKey() }
            }
            Sec(tc, "💾 Storage & chat") {
                Text("Photo/video kholkar ⬇ Download dabao — Gallery > Snake mein save hoga. Message par long-press karke copy / delete bhi kar sakte ho.", color = tc.copy(alpha = 0.7f), fontSize = 13.sp)
                Row(Modifier.padding(top = 8.dp).horizontalScroll(rememberScrollState())) {
                    Pill("🧹 Cache saaf karo", false, tc) { CACHE.clear(); a.cacheDir.listFiles()?.forEach { it.delete() }; Toast.makeText(a, "Cache saaf", Toast.LENGTH_SHORT).show() }
                    Pill("🗑 Chat clear (sirf mere phone se)", false, tc) { clear() }
                    Pill("↩ Cleared messages wapas", false, tc) { unhide() }
                    Pill("🔥 Poori chat sabke liye delete", false, Color(0xFFFF6B6B)) { clearAll() }
                }
            }
            Sec(tc, "ℹ️ About") {
                Text("Snake 2.0 · Sirf hum dono ke liye", color = tc.copy(alpha = 0.7f), fontSize = 13.sp)
                Row(Modifier.padding(top = 8.dp)) {
                    Pill("♻ Look reset", false, tc) { th.resetLook(); rmWall() }
                    Pill("Logout", false, Color(0xFFFF6B6B)) { out() }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}


@Composable fun Chat(a: MainActivity, p: SharedPreferences, reKey: () -> Unit, out: () -> Unit) {
    val th = a.th
    val db = remember { FirebaseFirestore.getInstance() }
    val me = remember { FirebaseAuth.getInstance().currentUser!!.uid }
    val partner = if (me == U1) U2 else U1
    val msgs = remember { mutableStateListOf<Msg>() }
    val prof = remember { mutableStateMapOf<String, Pair<String, String?>>() }
    val pres = remember { mutableStateMapOf<String, Pair<Boolean, Long>>() }
    val tok = remember { mutableStateMapOf<String, String>() }
    var nowT by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val sc = rememberCoroutineScope(); val ls = rememberLazyListState()
    var text by remember { mutableStateOf("") }
    var eName by remember { mutableStateOf("") }; var ePhoto by remember { mutableStateOf<String?>(null) }
    var rec by remember { mutableStateOf<MediaRecorder?>(null) }; var recFile by remember { mutableStateOf<File?>(null) }
    var recT by remember { mutableLongStateOf(0L) }; var recording by remember { mutableStateOf(false) }
    var searching by remember { mutableStateOf(false) }; var q by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf<Msg?>(null) }
    var replyTo by remember { mutableStateOf<Msg?>(null) }
    var editing by remember { mutableStateOf<Msg?>(null) }
    var batAsk by remember { mutableStateOf(false) }
    var view by remember { mutableStateOf<Msg?>(null) }
    var confirmClear by remember { mutableStateOf(false) }
    var confirmAll by remember { mutableStateOf(false) }
    var clr by remember { mutableLongStateOf(p.getLong("clr", 0L)) }
    var seenT by remember { mutableLongStateOf(p.getLong("seen", 0L)) }
    val hid = remember { mutableStateListOf<String>().also { l -> l.addAll(p.getStringSet("hid", emptySet()) ?: emptySet()) } }
    var wall by remember { mutableStateOf<Bitmap?>(File(a.filesDir, "wall.jpg").takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path) }) }
    val first = remember { booleanArrayOf(true) }
    val screen = St.screen
    val pName = prof[partner]?.first?.takeIf { it.isNotBlank() } ?: "Partner"
    val pPhoto = prof[partner]?.second
    fun toast(s: String) { Handler(Looper.getMainLooper()).post { Toast.makeText(a, s, Toast.LENGTH_LONG).show() } }
    fun snip(m: Msg): String = when (m.type) { "text" -> Cx.decS(m.body).take(80); "image" -> "📷 Photo"; "video" -> "🎥 Video"; "deleted" -> "🚫 Unsend"; else -> "🎤 Voice" }
    fun send(t: String, b: String) {
        val doc = hashMapOf<String, Any>("senderId" to me, "type" to t, "body" to b, "ts" to FieldValue.serverTimestamp(), "read" to false)
        replyTo?.let { doc["reply"] = Cx.encS(snip(it)); doc["replyId"] = it.id }
        replyTo = null
        db.collection("messages").add(doc).addOnSuccessListener { r ->
            tok[partner]?.takeIf { it.isNotEmpty() }?.let { pushTo(it, r.id) }
        }.addOnFailureListener { toast("Send fail: ${it.message}") }
    }
    fun react(m: Msg, e: String) {
        db.collection("messages").document(m.id).update("r_$me", if (m.rx[me] == e) "" else e).addOnFailureListener { toast("React fail: ${it.message}") }
    }
    fun go(x: Int) { St.ret = St.screen; St.screen = x }
    BackHandler(true) {
        when {
            searching -> { searching = false; q = "" }
            replyTo != null || editing != null -> { if (editing != null) text = ""; replyTo = null; editing = null }
            St.screen == 0 || St.screen == 1 -> {
                if (th.on("blk")) St.locked = true
                else if (St.screen == 1) St.screen = 0
                else a.finish()
            }
            else -> St.screen = if (St.ret == St.screen) 0 else St.ret
        }
    }
    DisposableEffect(Unit) {
        val r = db.collection("messages").orderBy("ts").addSnapshotListener { s, e ->
            if (e != null) toast("Sync error: ${e.message}")
            if (s == null) return@addSnapshotListener
            first[0] = false
            val l = s.documents.map { d ->
                val rx = (d.data ?: emptyMap<String, Any>()).filterKeys { it.startsWith("r_") }
                    .mapNotNull { (k, v) -> (v as? String)?.takeIf { it.isNotEmpty() }?.let { k.substring(2) to it } }.toMap()
                Msg(d.id, d.getString("senderId") == me, if (d.getBoolean("del") == true) "deleted" else (d.getString("type") ?: "text"), d.getString("body") ?: "",
                    d.getTimestamp("ts", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)?.toDate()?.time ?: 0L,
                    d.getBoolean("read") == true, d.metadata.hasPendingWrites(), rx, d.getString("reply") ?: "", d.getBoolean("edited") == true, d.getBoolean("pin") == true, d.getBoolean("delivered") == true)
            }
            msgs.clear(); msgs.addAll(l)
        }
        val r2 = db.collection("users").addSnapshotListener { s, _ ->
            s?.documents?.forEach { d ->
                pres[d.id] = Pair(d.getBoolean("online") == true, d.getTimestamp("lastSeen", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)?.toDate()?.time ?: 0L)
                tok[d.id] = d.getString("fcm") ?: ""
                prof[d.id] = Pair(d.getString("name")?.takeIf { it.isNotEmpty() }?.let { Cx.decS(it) } ?: "", d.getString("photo")?.takeIf { it.isNotEmpty() }?.let { Cx.decS(it) })
            }
        }
        onDispose { r.remove(); r2.remove() }
    }
    val vis = msgs.filter { (it.ts == 0L || it.ts > clr) && it.id !in hid }
    val shown = if (q.isBlank()) vis else vis.filter { it.type == "text" && Cx.decS(it.body).contains(q.trim(), true) }
    LaunchedEffect(shown.size, screen) { if (screen == 1 && shown.isNotEmpty()) ls.scrollToItem(shown.lastIndex) }
    LaunchedEffect(screen, msgs.size, th["rcpt"]) {
        if (screen == 1 && msgs.isNotEmpty()) {
            val mx = msgs.maxOf { it.ts }
            if (mx > seenT) { seenT = mx; p.edit().putLong("seen", mx).apply() }
            if (th.on("rcpt") && a.fg) msgs.filter { !it.mine && !it.read && !it.pending }.forEach { db.collection("messages").document(it.id).update("read", true) }
        }
    }
    LaunchedEffect(Unit) { while (true) { if (a.fg) a.pres(true); nowT = System.currentTimeMillis(); delay(30000) } }
    LaunchedEffect(Unit) { while (true) { delay(15000); nowT = System.currentTimeMillis() } }
    DisposableEffect(Unit) { onDispose { a.pres(false) } }
    LaunchedEffect(Unit) {
        FirebaseMessaging.getInstance().token.addOnSuccessListener { t -> db.collection("users").document(me).set(hashMapOf("fcm" to t), SetOptions.merge()) }
    }
    LaunchedEffect(msgs.size) {
        msgs.filter { !it.mine && !it.delivered && !it.pending }.forEach { db.collection("messages").document(it.id).update("delivered", true) }
    }
    LaunchedEffect(Unit) {
        val pm = a.getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(a.packageName) && p.getInt("batno", 0) < 3) { p.edit().putInt("batno", p.getInt("batno", 0) + 1).apply(); batAsk = true }
    }
    LaunchedEffect(screen) { if (screen == 3) { eName = prof[me]?.first ?: ""; ePhoto = prof[me]?.second } }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u: Uri? ->
        if (u != null) sc.launch(Dispatchers.IO) {
            try {
                val v = a.contentResolver.getType(u)?.startsWith("video") == true
                val raw = if (v) a.contentResolver.openInputStream(u)!!.use { it.readBytes() } else shrink(a, u)
                if (raw.size > 45_000_000) { toast("Video bada hai (max 45MB)"); return@launch }
                val n = UUID.randomUUID().toString()
                if (Sb.up(n, Cx.enc(raw))) send(if (v) "video" else "image", Cx.encS(n)) else toast("Upload fail")
            } catch (e: Exception) { toast("Error: ${e.message}") }
        }
    }
    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u: Uri? ->
        if (u != null) sc.launch(Dispatchers.IO) {
            try {
                val n = UUID.randomUUID().toString()
                if (Sb.up(n, Cx.enc(shrink(a, u)))) ePhoto = n else toast("Photo upload fail")
            } catch (e: Exception) { toast("Error: ${e.message}") }
        }
    }
    val pickWall = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u: Uri? ->
        if (u != null) sc.launch(Dispatchers.IO) {
            try {
                val d = shrink(a, u)
                File(a.filesDir, "wall.jpg").writeBytes(d)
                val b = BitmapFactory.decodeByteArray(d, 0, d.size)
                withContext(Dispatchers.Main) { wall = b }
            } catch (e: Exception) { toast("Error: ${e.message}") }
        }
    }
    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    fun startRec() {
        try {
            val f = File(a.cacheDir, "v${System.currentTimeMillis()}.m4a")
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(a) else MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC); r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC); r.setAudioEncodingBitRate(64000); r.setAudioSamplingRate(44100)
            r.setOutputFile(f.path); r.prepare(); r.start()
            rec = r; recFile = f; recT = System.currentTimeMillis(); recording = true
        } catch (e: Exception) { toast("Mic error: ${e.message}") }
    }
    fun stopRec() {
        val r = rec ?: return; rec = null; recording = false
        val ok = runCatching { r.stop() }.isSuccess; runCatching { r.release() }
        val f = recFile ?: return
        if (!ok || System.currentTimeMillis() - recT < 700) { f.delete(); return }
        sc.launch(Dispatchers.IO) {
            try {
                val n = UUID.randomUUID().toString()
                if (Sb.up(n, Cx.enc(f.readBytes()))) send("voice", Cx.encS(n)) else toast("Voice upload fail")
            } catch (e: Exception) { toast("Error: ${e.message}") }
            f.delete()
        }
    }
    val bar = th.col("bar"); val hc = onCol(th["bar"]); val bgc = onCol(th["bg1"])
    val ff = FONTS[th["ff"].coerceIn(0, FONTS.lastIndex)].second
    val fmt = remember { SimpleDateFormat("h:mm a", Locale.getDefault()) }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(th.col("bg1"), th.col("bg2"))))) {
        val w = wall
        if (w != null && screen in 0..1) {
            Image(w.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = th["wdim"] / 100f)))
        }
        when (screen) {
            0 -> Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().background(bar).padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Snake", Modifier.weight(1f), color = hc, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    IconButton({ go(4) }) { Icon(Icons.Default.Settings, null, tint = hc) }
                }
                val last = vis.lastOrNull()
                val lastTxt = last?.let {
                    (if (it.mine) "You: " else "") + when (it.type) { "text" -> Cx.decS(it.body); "image" -> "📷 Photo"; "video" -> "🎥 Video"; "deleted" -> "🚫 Message unsend hua"; else -> "🎤 Voice" }
                } ?: "Chat shuru karo"
                val unread = vis.count { !it.mine && it.ts > seenT }
                Row(Modifier.fillMaxWidth().clickable { go(1) }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(pPhoto, 56.dp, pName, Modifier.clickable { go(2) })
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(pName, color = bgc, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text(lastTxt, color = bgc.copy(alpha = 0.6f), maxLines = 1)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        if (last != null && last.ts > 0) Text(fmt.format(Date(last.ts)), color = bgc.copy(alpha = 0.6f), fontSize = 12.sp)
                        if (unread > 0) Box(Modifier.padding(top = 4.dp).clip(CircleShape).background(Color(0xFF2979FF)).padding(horizontal = 8.dp, vertical = 2.dp)) {
                            Text("$unread", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            1 -> Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().background(bar).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextButton({ if (searching) { searching = false; q = "" } else St.screen = 0 }) { Text("←", color = hc, fontSize = 24.sp) }
                    if (searching) {
                        TextField(q, { q = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text("Chat mein dhundo...") },
                            colors = TextFieldDefaults.colors(focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                                focusedContainerColor = hc.copy(alpha = 0.12f), unfocusedContainerColor = hc.copy(alpha = 0.12f),
                                focusedTextColor = hc, unfocusedTextColor = hc, cursorColor = hc))
                    } else {
                        Row(Modifier.weight(1f).clickable { go(2) }, verticalAlignment = Alignment.CenterVertically) {
                            Avatar(pPhoto, 40.dp, pName); Spacer(Modifier.width(10.dp))
                            Column {
                                Text(pName, color = hc, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                val pr = pres[partner]
                                val st = if (pr == null) "" else statusText(pr.first, pr.second, nowT)
                                if (st.isNotEmpty()) Text(st, color = hc.copy(alpha = 0.75f), fontSize = 12.sp)
                            }
                        }
                        IconButton({ searching = true }) { Icon(Icons.Default.Search, null, tint = hc) }
                        IconButton({ go(4) }) { Icon(Icons.Default.Settings, null, tint = hc) }
                    }
                }
                val pinned = vis.lastOrNull { it.pin && it.type != "deleted" }
                if (pinned != null && !searching) Row(Modifier.fillMaxWidth().background(bar.copy(alpha = 0.92f)).clickable {
                    sc.launch { val i = shown.indexOfFirst { it.id == pinned.id }; if (i >= 0) ls.animateScrollToItem(i) }
                }.padding(horizontal = 14.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("📌", fontSize = 14.sp); Spacer(Modifier.width(8.dp))
                    Text(snip(pinned), color = hc, fontSize = 13.sp, maxLines = 1)
                }
                LazyColumn(Modifier.weight(1f).padding(horizontal = 10.dp), state = ls) {
                    items(shown, key = { it.id }) { m -> Bubble(m, th, ff, { menu = it }, { view = it }, { mm, e -> react(mm, e) }) }
                }
                val rbar = editing ?: replyTo
                if (rbar != null) Row(Modifier.fillMaxWidth().background(bar).padding(start = 14.dp, end = 4.dp, top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(if (editing != null) "✏️ Message edit ho raha hai" else "↩️ Reply: " + (if (rbar.mine) "Aap" else pName), color = hc, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text(snip(rbar), color = hc.copy(alpha = 0.7f), fontSize = 13.sp, maxLines = 1)
                    }
                    TextButton({ if (editing != null) text = ""; replyTo = null; editing = null }) { Text("✕", color = hc, fontSize = 18.sp) }
                }
                Row(Modifier.fillMaxWidth().background(bar).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton({ St.skip = true; pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)) }) { Icon(Icons.Default.Add, null, tint = hc) }
                    TextField(text, { text = it }, Modifier.weight(1f), placeholder = { Text(if (recording) "🔴 Recording... chhodo to send" else "Message") }, shape = RoundedCornerShape(24.dp),
                        colors = TextFieldDefaults.colors(focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                            focusedContainerColor = hc.copy(alpha = 0.12f), unfocusedContainerColor = hc.copy(alpha = 0.12f),
                            focusedTextColor = hc, unfocusedTextColor = hc, cursorColor = hc,
                            focusedPlaceholderColor = hc.copy(alpha = 0.6f), unfocusedPlaceholderColor = hc.copy(alpha = 0.6f)))
                    Spacer(Modifier.width(6.dp))
                    Box(Modifier.size(46.dp).clip(CircleShape).background(if (recording) Color.Red else Color(0xFF2979FF)).pointerInput(Unit) {
                        detectTapGestures(onPress = {
                            if (text.isNotBlank()) {
                                val ed = editing
                                if (ed != null) {
                                    db.collection("messages").document(ed.id).update("body", Cx.encS(text.trim()), "edited", true).addOnFailureListener { toast("Edit fail: ${it.message}") }
                                    editing = null
                                } else send("text", Cx.encS(text.trim()))
                                text = ""
                            }
                            else if (a.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) { startRec(); tryAwaitRelease(); stopRec() }
                            else { St.skip = true; micPerm.launch(Manifest.permission.RECORD_AUDIO) }
                        })
                    }, Alignment.Center) {
                        if (text.isBlank()) Text("🎤", fontSize = 20.sp) else Icon(Icons.Default.Send, null, tint = Color.White)
                    }
                }
            }
            2 -> Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
                Avatar(pPhoto, 170.dp, pName)
                Text(pName, color = bgc, fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp))
                Button({ St.screen = 1 }) { Text("Message") }
                TextButton({ St.screen = if (St.ret == 2) 0 else St.ret }) { Text("← Wapas") }
            }
            3 -> Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
                Avatar(ePhoto, 150.dp, eName.ifBlank { "Me" }, Modifier.clickable { St.skip = true; pickPhoto.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) })
                Text("Photo badalne ke liye tap karo", color = bgc.copy(alpha = 0.6f), modifier = Modifier.padding(8.dp))
                OutlinedTextField(eName, { eName = it }, label = { Text("Naam") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = bgc, unfocusedTextColor = bgc))
                Spacer(Modifier.height(16.dp))
                Button({
                    db.collection("users").document(me).set(hashMapOf("name" to Cx.encS(eName.trim()), "photo" to (ePhoto?.let { Cx.encS(it) } ?: "")), SetOptions.merge())
                        .addOnSuccessListener { toast("Profile save ho gayi") }.addOnFailureListener { toast("Save fail: ${it.message}") }
                    St.screen = if (St.ret == 3) 0 else St.ret
                }, Modifier.fillMaxWidth().height(50.dp)) { Text("Save") }
                TextButton({ St.screen = if (St.ret == 3) 0 else St.ret }) { Text("Cancel") }
            }
            else -> SettingsScreen(a, th, prof[me]?.first?.takeIf { it.isNotBlank() } ?: "Me", prof[me]?.second, wall,
                { St.skip = true; pickWall.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                { File(a.filesDir, "wall.jpg").delete(); wall = null },
                { go(3) }, { St.screen = if (St.ret == 4) 0 else St.ret }, reKey, out,
                { confirmClear = true },
                { clr = 0L; p.edit().putLong("clr", 0L).putStringSet("hid", emptySet()).apply(); hid.clear(); toast("Messages wapas aa gaye") }, { confirmAll = true })
        }
    }
    if (confirmClear) AlertDialog(onDismissRequest = { confirmClear = false },
        title = { Text("Chat clear karein?") }, text = { Text("Sirf is phone se purane messages chhup jayenge. Samne wale ke paas rahenge.") },
        confirmButton = { TextButton({
            val t = (msgs.maxOfOrNull { it.ts } ?: System.currentTimeMillis()); clr = t; p.edit().putLong("clr", t).apply(); confirmClear = false
        }) { Text("Clear", color = Color(0xFFFF6B6B)) } },
        dismissButton = { TextButton({ confirmClear = false }) { Text("Cancel") } })
    if (confirmAll) AlertDialog(onDismissRequest = { confirmAll = false },
        title = { Text("Poori chat delete?") }, text = { Text("Saare messages dono phone se delete ho jayenge.") },
        confirmButton = { TextButton({
            msgs.filter { it.type != "deleted" && !it.pending }.forEach { db.collection("messages").document(it.id).update("del", true) }
            confirmAll = false
        }) { Text("Delete", color = Color(0xFFFF6B6B)) } },
        dismissButton = { TextButton({ confirmAll = false }) { Text("Cancel") } })
    menu?.let { m ->
        Dialog(onDismissRequest = { menu = null }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Box(Modifier.fillMaxSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { menu = null }.padding(24.dp), Alignment.Center) {
                Column(Modifier.width(290.dp), horizontalAlignment = if (m.mine) Alignment.End else Alignment.Start) {
                    if (m.type != "deleted") Row(Modifier.clip(RoundedCornerShape(32.dp)).background(Color(0xFFF7F7FA)).padding(horizontal = 10.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        listOf("❤️", "😂", "😮", "😢", "😡", "👍").forEach { e ->
                            Text(e, fontSize = 26.sp, modifier = Modifier.clip(CircleShape).background(if (m.rx[me] == e) Color(0x332979FF) else Color.Transparent)
                                .clickable { react(m, e); menu = null }.padding(6.dp))
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Color(0xFFF7F7FA)).pointerInput(Unit) { detectTapGestures { } }.padding(vertical = 6.dp)) {
                        if (m.type != "deleted") MenuRow("↩️", "Reply") { replyTo = m; editing = null; menu = null }
                        if (m.mine && m.type == "text") MenuRow("✏️", "Edit") { editing = m; replyTo = null; text = Cx.decS(m.body); menu = null }
                        if (m.type != "deleted") MenuRow("📌", if (m.pin) "Unpin" else "Pin") {
                            db.collection("messages").document(m.id).update("pin", !m.pin).addOnFailureListener { toast("Pin fail: ${it.message}") }; menu = null
                        }
                        if (m.type == "text") MenuRow("📋", "Copy") {
                            val cm = a.getSystemService(ClipboardManager::class.java)
                            cm.setPrimaryClip(ClipData.newPlainText("m", Cx.decS(m.body))); toast("Copy ho gaya"); menu = null
                        }
                        if (m.type == "image" || m.type == "video") MenuRow("⬇️", "Kholo / Download") { menu = null; view = m }
                        MenuRow("🗑️", "Delete for me", true) { hid.add(m.id); p.edit().putStringSet("hid", hid.toSet()).apply(); menu = null }
                        if (m.mine && m.type != "deleted") MenuRow("↩", "Unsend", true) {
                            db.collection("messages").document(m.id).update("del", true).addOnFailureListener { toast("Unsend fail: ${it.message}") }; menu = null
                        }
                    }
                }
            }
        }
    }
    if (batAsk) AlertDialog(onDismissRequest = { batAsk = false },
        title = { Text("Notification hamesha aane ke liye") }, text = { Text("Agle screen par 'Allow' dabao, taaki phone app ko band na kare aur message turant aaye.") },
        confirmButton = { TextButton({
            batAsk = false; St.skip = true
            try { a.startActivity(Intent("android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS", Uri.parse("package:" + a.packageName))) } catch (e: Exception) { }
        }) { Text("Allow") } },
        dismissButton = { TextButton({ batAsk = false }) { Text("Baad mein") } })
    view?.let { m -> Viewer(Cx.decS(m.body), m.type == "video") { view = null } }
}


class ListenService : Service() {
    private var reg: ListenerRegistration? = null
    override fun onBind(i: Intent?): android.os.IBinder? = null
    override fun onTaskRemoved(rootIntent: Intent?) {
        try {
            val pi = PendingIntent.getForegroundService(this, 7, Intent(this, ListenService::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_ONE_SHOT)
            getSystemService(AlarmManager::class.java).setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + 1500L, pi)
        } catch (e: Exception) { }
        super.onTaskRemoved(rootIntent)
    }
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("svc", "Snake background", NotificationManager.IMPORTANCE_MIN))
        ensureChannels(this)
        val n = Notification.Builder(this, "svc").setSmallIcon(android.R.drawable.ic_dialog_email)
            .setContentTitle("Snake").setContentText("Running").build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC) else startForeground(2, n)
        listen()
        return START_STICKY
    }
    private fun listen() {
        if (reg != null) return
        val me = FirebaseAuth.getInstance().currentUser?.uid ?: run { stopSelf(); return }
        val p = EncryptedSharedPreferences.create(this, "p", MasterKey.Builder(this).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV, EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
        p.getString("sec", null)?.let { Cx.set(it) }
        val partner = if (me == U1) U2 else U1
        val seenR = HashMap<String, String>()
        reg = FirebaseFirestore.getInstance().collection("messages").orderBy("ts").addSnapshotListener { s, _ ->
            if (s == null) return@addSnapshotListener
            for (c in s.documentChanges) {
                val d = c.document
                if (d.metadata.hasPendingWrites()) continue
                val ts = d.getTimestamp("ts", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)?.toDate()?.time ?: 0L
                if (c.type == DocumentChange.Type.ADDED) {
                    seenR[d.id] = d.getString("r_$partner") ?: ""
                    if (d.getString("senderId") != me && d.getBoolean("delivered") != true) d.reference.update("delivered", true)
                    val last = maxOf(p.getLong("nt", 0L), p.getLong("seen", 0L))
                    if (d.getString("senderId") != me && d.getBoolean("del") != true && ts > last) {
                        p.edit().putLong("nt", ts).apply()
                        var pv: String? = null
                        if (p.getInt("prev", 0) != 0 && d.getString("type") == "text") pv = runCatching { Cx.decS(d.getString("body") ?: "") }.getOrNull()
                        show(d.id, pv ?: "Naya message", p)
                    }
                } else if (c.type == DocumentChange.Type.MODIFIED) {
                    val r = d.getString("r_$partner") ?: ""
                    if (r.isNotEmpty() && r != seenR[d.id] && d.getString("senderId") == me) show(d.id + "r", "$r  react kiya", p)
                    seenR[d.id] = r
                }
            }
        }
    }
    private fun show(key: String, body: String, p: SharedPreferences) = showNote(this, key, body, p)
    override fun onDestroy() { reg?.remove(); reg = null; super.onDestroy() }
}


@Composable fun MenuRow(ic: String, label: String, red: Boolean = false, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 20.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(ic, fontSize = 20.sp, modifier = Modifier.width(36.dp))
        Text(label, fontSize = 17.sp, color = if (red) Color(0xFFE53935) else Color(0xFF111111))
    }
}

class BootReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent?) {
        scheduleGame(c)
        if (FirebaseAuth.getInstance().currentUser == null) return
        try { c.startForegroundService(Intent(c, ListenService::class.java)) } catch (e: Exception) { }
    }
}


fun ensureChannels(c: Context) {
    val nm = c.getSystemService(NotificationManager::class.java)
    nm.createNotificationChannel(NotificationChannel("mh", "Messages", NotificationManager.IMPORTANCE_HIGH))
    nm.createNotificationChannel(NotificationChannel("mq", "Messages (silent)", NotificationManager.IMPORTANCE_LOW))
    nm.createNotificationChannel(NotificationChannel("gm", "Game", NotificationManager.IMPORTANCE_DEFAULT))
}

fun showNote(c: Context, key: String, body: String, p: SharedPreferences) {
    if (p.getInt("notif", 1) == 0) return
    if (St.viewing && !St.locked && St.screen == 1) return
    ensureChannels(c)
    val pi = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    val pub = Notification.Builder(c, "mh").setSmallIcon(android.R.drawable.ic_dialog_email).setContentTitle("Snake").setContentText("Naya message").build()
    val n = Notification.Builder(c, if (p.getInt("snd", 1) != 0) "mh" else "mq").setSmallIcon(android.R.drawable.ic_dialog_email)
        .setContentTitle("Snake").setContentText(body).setContentIntent(pi).setAutoCancel(true).setOnlyAlertOnce(true)
        .setVisibility(Notification.VISIBILITY_PRIVATE).setPublicVersion(pub).build()
    c.getSystemService(NotificationManager::class.java).notify(key.hashCode(), n)
}

fun statusText(on: Boolean, ls: Long, now: Long): String {
    if (on && (ls == 0L || now - ls < 80_000L)) return "online"
    if (ls == 0L) return ""
    val t = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(ls))
    val a = Calendar.getInstance().apply { timeInMillis = ls }; val b = Calendar.getInstance().apply { timeInMillis = now }
    val days = (b.get(Calendar.YEAR) * 366 + b.get(Calendar.DAY_OF_YEAR)) - (a.get(Calendar.YEAR) * 366 + a.get(Calendar.DAY_OF_YEAR))
    return when {
        days == 0 -> "last seen today at $t"
        days == 1 -> "last seen yesterday at $t"
        else -> "last seen " + SimpleDateFormat("d MMM", Locale.getDefault()).format(Date(ls)) + " at $t"
    }
}

fun pushTo(token: String, id: String) {
    Thread {
        try {
            val c = URL("$SB/functions/v1/Push").openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 15000
            c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("apikey", KEY)
            c.outputStream.use { it.write("""{"token":"$token","id":"$id","secret":"$PUSH_SECRET"}""".toByteArray()) }
            c.responseCode; c.disconnect()
        } catch (e: Exception) { }
    }.start()
}

class PushService : FirebaseMessagingService() {
    override fun onNewToken(token: String) {
        val u = FirebaseAuth.getInstance().currentUser ?: return
        FirebaseFirestore.getInstance().collection("users").document(u.uid).set(hashMapOf("fcm" to token), SetOptions.merge())
    }
    override fun onMessageReceived(m: RemoteMessage) {
        val p = EncryptedSharedPreferences.create(this, "p", MasterKey.Builder(this).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV, EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
        val id = m.data["id"] ?: return
        showNote(this, id, "Naya message", p)
        try { FirebaseFirestore.getInstance().collection("messages").document(id).update("delivered", true) } catch (e: Exception) { }
    }
}

fun scheduleGame(c: Context) {
    try {
        val pi = PendingIntent.getBroadcast(c, 91, Intent(c, GameReminder::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        c.getSystemService(AlarmManager::class.java).setInexactRepeating(AlarmManager.ELAPSED_REALTIME, SystemClock.elapsedRealtime() + AlarmManager.INTERVAL_HOUR * 3,
            AlarmManager.INTERVAL_HOUR * 5, pi)
    } catch (e: Exception) { }
}

class GameReminder : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent?) {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        if (h < 9 || h >= 22) return
        val best = c.getSharedPreferences("snake", Context.MODE_PRIVATE).getInt("best", 0)
        val msgs = if (best > 0) listOf("🐍 Aaja, naya high score banate hain! Abhi best: $best", "🏆 Tera high score $best hai — kya isse tod sakta hai?", "🍎 Snake tera intezaar kar raha hai. Naya high score banao!")
                   else listOf("🐍 Aaja, ek game khelte hain! Pehla high score banao", "🍎 Snake tera intezaar kar raha hai!")
        ensureChannels(c)
        val pi = PendingIntent.getActivity(c, 1, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(c, "gm").setSmallIcon(android.R.drawable.ic_media_play).setContentTitle("Snake").setContentText(msgs.random()).setContentIntent(pi).setAutoCancel(true).build()
        c.getSystemService(NotificationManager::class.java).notify(9001, n)
    }
}
