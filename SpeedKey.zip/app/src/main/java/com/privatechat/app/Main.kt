package com.privatechat.app

import android.Manifest
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import java.util.Calendar
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.view.WindowManager
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.SecureFlagPolicy
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

const val SB = "https://obohjkshxneagjsxnqdh.supabase.co"
const val KEY = "sb_publishable_4TPiN_BzNsnEa84qIfZ8DQ_u6FohR3U"
val ACC = Brush.horizontalGradient(listOf(Color(0xFF2979FF), Color(0xFF8E4DFF)))
val BGS = listOf(0xFF0B0B14, 0xFF0D1B2A, 0xFF1A0F24, 0xFF0E1F17, 0xFF000000)
val FONTS = listOf("Default" to FontFamily.Default, "Serif" to FontFamily.Serif, "Mono" to FontFamily.Monospace, "Cursive" to FontFamily.Cursive)
val CACHE = HashMap<String, Bitmap>()

object St { var locked by mutableStateOf(true); var skip = false }
data class Msg(val id: String, val mine: Boolean, val type: String, val body: String, val ts: Long, val read: Boolean, val pending: Boolean)

object Cx {
    lateinit var key: SecretKeySpec
    fun set(s: String) {
        val f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        key = SecretKeySpec(f.generateSecret(PBEKeySpec(s.toCharArray(), "clock-v1".toByteArray(), 100000, 256)).encoded, "AES")
    }
    fun enc(b: ByteArray): ByteArray {
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
        return iv + c.doFinal(b)
    }
    fun dec(b: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, b, 0, 12))
        return c.doFinal(b, 12, b.size - 12)
    }
    fun encS(s: String) = Base64.encodeToString(enc(s.toByteArray()), Base64.NO_WRAP)
    fun decS(s: String) = try { String(dec(Base64.decode(s, Base64.NO_WRAP))) } catch (e: Exception) { "🔒 decrypt nahi hua" }
}

object Sb {
    private fun conn(path: String, post: Boolean): HttpURLConnection {
        val c = URL("$SB/storage/v1/object/$path").openConnection() as HttpURLConnection
        c.setRequestProperty("apikey", KEY); c.connectTimeout = 20000; c.readTimeout = 120000
        if (post) { c.requestMethod = "POST"; c.doOutput = true; c.setRequestProperty("Content-Type", "application/octet-stream") }
        return c
    }
    fun up(name: String, d: ByteArray): Boolean {
        val c = conn("media/$name", true); c.setFixedLengthStreamingMode(d.size)
        c.outputStream.use { it.write(d) }
        return c.responseCode in 200..299
    }
    fun down(name: String): ByteArray? {
        val c = conn("authenticated/media/$name", false)
        return if (c.responseCode == 200) c.inputStream.use { it.readBytes() } else null
    }
}


fun shrink(c: Context, u: Uri): ByteArray {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    c.contentResolver.openInputStream(u)!!.use { BitmapFactory.decodeStream(it, null, o) }
    var s = 1; while (o.outWidth / s > 1600) s *= 2
    val b = c.contentResolver.openInputStream(u)!!.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s }) }!!
    return ByteArrayOutputStream().also { b.compress(Bitmap.CompressFormat.JPEG, 82, it) }.toByteArray()
}

class MainActivity : ComponentActivity() {
    var fg = false
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("m", "Messages", NotificationManager.IMPORTANCE_DEFAULT))
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        setContent { App(this) }
    }
    override fun onStart() { super.onStart(); fg = true; St.skip = false }
    override fun onStop() { super.onStop(); fg = false; if (!St.skip) St.locked = true }
    fun ping() {
        val n = Notification.Builder(this, "m").setSmallIcon(android.R.drawable.ic_dialog_email)
            .setContentTitle("CLOCK").setContentText("Naya message").setVisibility(Notification.VISIBILITY_SECRET).build()
        getSystemService(NotificationManager::class.java).notify(1, n)
    }
}

@Composable fun App(a: MainActivity) {
    val p = remember { EncryptedSharedPreferences.create(a, "p", MasterKey.Builder(a).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV, EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM) }
    var user by remember { mutableStateOf(FirebaseAuth.getInstance().currentUser) }
    var sec by remember { mutableStateOf(p.getString("sec", null)?.also { Cx.set(it) }) }
    MaterialTheme(colorScheme = darkColorScheme()) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFF0B0B14)) {
            when {
                St.locked -> ClockLock()
                user == null -> Login { user = it }
                sec == null -> Secret { p.edit().putString("sec", it).apply(); Cx.set(it); sec = it }
                else -> Chat(a, p) { FirebaseAuth.getInstance().signOut(); user = null }
            }
        }
    }
}

@Composable fun ClockLock() {
    val sc = rememberCoroutineScope()
    var mode by remember { mutableIntStateOf(0) }
    var frame by remember { mutableLongStateOf(0L) }
    var hA by remember { mutableFloatStateOf(0f) }
    var mA by remember { mutableFloatStateOf(0f) }
    var bad by remember { mutableStateOf(false) }
    var sz by remember { mutableStateOf(IntSize.Zero) }
    var sel by remember { mutableIntStateOf(1) }
    LaunchedEffect(mode) { while (mode == 0) { withFrameMillis { frame = it } } }
    val f = frame
    val cal = Calendar.getInstance()
    val sec = cal.get(Calendar.SECOND) + cal.get(Calendar.MILLISECOND) / 1000f
    val min = cal.get(Calendar.MINUTE) + sec / 60f
    val hr = cal.get(Calendar.HOUR) + min / 60f
    val shownH = if (mode == 0) hr * 30f else hA
    val shownM = if (mode == 0) min * 6f else mA
    fun tip(a: Float, len: Float): Offset {
        val r = Math.toRadians(a.toDouble())
        return Offset(sz.width / 2f + len * sin(r).toFloat(), sz.height / 2f - len * cos(r).toFloat())
    }
    fun centerTap() {
        if (mode == 0) {
            val h0 = hr * 30f; val m0 = min * 6f; hA = h0; mA = m0; mode = 2
            sc.launch {
                val ht = if (h0 > 180f) 360f else 0f; val mt = if (m0 > 180f) 360f else 0f
                animate(0f, 1f, animationSpec = tween(900)) { t, _ -> hA = h0 + (ht - h0) * t; mA = m0 + (mt - m0) * t }
                hA = 0f; mA = 0f; mode = 1
            }
        } else if (mode == 1) {
            if (abs(mA - 180f) <= 12f && hA in 0f..30f) St.locked = false
            else sc.launch { bad = true; delay(450); bad = false; hA = 0f; mA = 0f }
        }
    }
    val onTap = rememberUpdatedState { centerTap() }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF16213E), Color(0xFF0B0B14)))), Alignment.Center) {
        Canvas(Modifier.fillMaxWidth().padding(16.dp).aspectRatio(1f).onSizeChanged { sz = it }
            .pointerInput(Unit) {
                detectTapGestures { o -> if ((o - Offset(sz.width / 2f, sz.height / 2f)).getDistance() < sz.width * 0.12f) onTap.value() }
            }
            .pointerInput(Unit) {
                detectDragGestures(onDragStart = { o ->
                    if (mode == 1) {
                        val dm = (o - tip(mA, sz.width / 2f * 0.7f)).getDistance()
                        val dh = (o - tip(hA, sz.width / 2f * 0.45f)).getDistance()
                        sel = if (dh < dm) 0 else 1
                    }
                }) { change, _ ->
                    if (mode == 1) {
                        val d = change.position - Offset(sz.width / 2f, sz.height / 2f)
                        var ang = Math.toDegrees(atan2(d.x.toDouble(), -d.y.toDouble())).toFloat()
                        if (ang < 0) ang += 360f
                        if (sel == 0) hA = ang else mA = ang
                    }
                }
            }) {
            val c = center; val R = size.width / 2f
            drawCircle(Brush.radialGradient(listOf(Color(0xFF1E2A4A), Color(0xFF0F1426))), R * 0.95f)
            drawCircle(if (bad) Color.Red else Color(0xFF2979FF), R * 0.95f, style = Stroke(8f))
            for (i in 0 until 60) {
                val big = i % 5 == 0; val r = Math.toRadians(i * 6.0)
                val sn = sin(r).toFloat(); val cs = cos(r).toFloat()
                val r1 = R * 0.88f; val r2 = if (big) R * 0.78f else R * 0.84f
                drawLine(Color.White.copy(alpha = if (big) 1f else 0.4f), Offset(c.x + r1 * sn, c.y - r1 * cs), Offset(c.x + r2 * sn, c.y - r2 * cs), if (big) 6f else 2f, StrokeCap.Round)
            }
            fun hand(a: Float, len: Float, col: Color, w: Float) {
                val r = Math.toRadians(a.toDouble())
                drawLine(col, c, Offset(c.x + len * sin(r).toFloat(), c.y - len * cos(r).toFloat()), w, StrokeCap.Round)
            }
            hand(shownH, R * 0.45f, Color.White, 16f)
            hand(shownM, R * 0.7f, Color(0xFF8E9BFF), 11f)
            if (mode == 0) hand(sec * 6f, R * 0.8f, Color(0xFFFF5252), 4f)
            drawCircle(Color(0xFF2979FF), R * 0.06f, c)
        }
    }
}

@Composable fun Login(done: (FirebaseUser) -> Unit) {
    var e by remember { mutableStateOf("") }; var pw by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }; var busy by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF16213E), Color(0xFF0B0B14)))).padding(28.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Text("🕒", fontSize = 64.sp)
        Text("CLOCK", fontSize = 34.sp, color = Color.White, fontWeight = FontWeight.Bold)
        Text("Sirf hum dono ke liye", color = Color.Gray)
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(e, { e = it }, label = { Text("Email") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(pw, { pw = it }, label = { Text("Password") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(16.dp))
        Button({
            busy = true; msg = ""
            FirebaseAuth.getInstance().signInWithEmailAndPassword(e.trim(), pw).addOnCompleteListener {
                busy = false
                if (it.isSuccessful) done(it.result.user!!) else msg = it.exception?.message ?: "Login fail"
            }
        }, Modifier.fillMaxWidth().height(52.dp), enabled = !busy && e.isNotBlank() && pw.isNotBlank()) { Text(if (busy) "..." else "Login", fontSize = 18.sp) }
        Text(msg, color = Color(0xFFFF6B6B), modifier = Modifier.padding(top = 10.dp), textAlign = TextAlign.Center)
    }
}

@Composable fun Secret(ok: (String) -> Unit) {
    var s by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(28.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Text("🔐", fontSize = 56.sp)
        Text("Secret key", fontSize = 26.sp, color = Color.White, fontWeight = FontWeight.Bold)
        Text("Dono phone mein bilkul same daalna. Isse chat encrypt hoti hai.", color = Color.Gray, textAlign = TextAlign.Center)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(s, { s = it }, singleLine = true, modifier = Modifier.fillMaxWidth(), visualTransformation = PasswordVisualTransformation())
        Spacer(Modifier.height(12.dp))
        Button({ if (s.length >= 6) ok(s) }, Modifier.fillMaxWidth()) { Text(if (s.length >= 6) "Save" else "Kam se kam 6 character") }
    }
}

@Composable fun Chat(a: MainActivity, p: SharedPreferences, out: () -> Unit) {
    val db = remember { FirebaseFirestore.getInstance() }
    val me = remember { FirebaseAuth.getInstance().currentUser!!.uid }
    val msgs = remember { mutableStateListOf<Msg>() }
    val sc = rememberCoroutineScope(); val ls = rememberLazyListState()
    var text by remember { mutableStateOf("") }
    var bg by remember { mutableIntStateOf(p.getInt("bg", 0)) }
    var ff by remember { mutableIntStateOf(p.getInt("ff", 0)) }
    var fs by remember { mutableFloatStateOf(p.getFloat("fs", 16f)) }
    var set by remember { mutableStateOf(false) }
    val first = remember { booleanArrayOf(true) }
    fun toast(s: String) { Handler(Looper.getMainLooper()).post { Toast.makeText(a, s, Toast.LENGTH_SHORT).show() } }
    fun send(t: String, b: String) {
        db.collection("messages").add(hashMapOf("senderId" to me, "type" to t, "body" to b, "ts" to FieldValue.serverTimestamp(), "read" to false))
    }
    DisposableEffect(Unit) {
        val r = db.collection("messages").orderBy("ts").addSnapshotListener { s, _ ->
            if (s == null) return@addSnapshotListener
            if (!first[0] && !a.fg && s.documentChanges.any { it.type == DocumentChange.Type.ADDED && it.document.getString("senderId") != me }) a.ping()
            first[0] = false
            val l = s.documents.map { d ->
                Msg(d.id, d.getString("senderId") == me, d.getString("type") ?: "text", d.getString("body") ?: "",
                    d.getTimestamp("ts", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)?.toDate()?.time ?: 0L,
                    d.getBoolean("read") == true, d.metadata.hasPendingWrites())
            }
            msgs.clear(); msgs.addAll(l)
            s.documents.filter { it.getString("senderId") != me && it.getBoolean("read") != true && !it.metadata.hasPendingWrites() }.forEach { it.reference.update("read", true) }
        }
        onDispose { r.remove() }
    }
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) ls.animateScrollToItem(msgs.lastIndex) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u: Uri? ->
        if (u != null) sc.launch(Dispatchers.IO) {
            try {
                val v = a.contentResolver.getType(u)?.startsWith("video") == true
                val raw = if (v) a.contentResolver.openInputStream(u)!!.use { it.readBytes() } else shrink(a, u)
                if (raw.size > 45_000_000) { toast("Video bada hai (max 45MB)"); return@launch }
                val n = UUID.randomUUID().toString()
                if (Sb.up(n, Cx.enc(raw))) send(if (v) "video" else "image", Cx.encS(n)) else toast("Upload fail")
            } catch (e: Exception) { toast("Error: ${e.message}") }
        }
    }
    Column(Modifier.fillMaxSize().background(Color(BGS[bg]))) {
        Row(Modifier.fillMaxWidth().background(Color(0xFF14142A)).padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("🕒 Chat", Modifier.weight(1f), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            IconButton({ set = true }) { Icon(Icons.Default.Settings, null, tint = Color.White) }
        }
        LazyColumn(Modifier.weight(1f).padding(horizontal = 10.dp), state = ls) { items(msgs, key = { it.id }) { Bubble(it, FONTS[ff].second, fs) } }
        Row(Modifier.fillMaxWidth().background(Color(0xFF14142A)).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ St.skip = true; pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)) }) { Icon(Icons.Default.Add, null, tint = Color.White) }
            TextField(text, { text = it }, Modifier.weight(1f), placeholder = { Text("Message") }, shape = RoundedCornerShape(24.dp),
                colors = TextFieldDefaults.colors(focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent))
            Spacer(Modifier.width(6.dp))
            Box(Modifier.size(46.dp).clip(CircleShape).background(ACC).clickable { if (text.isNotBlank()) { send("text", Cx.encS(text.trim())); text = "" } }, Alignment.Center) {
                Icon(Icons.Default.Send, null, tint = Color.White)
            }
        }
    }
    if (set) AlertDialog(onDismissRequest = { set = false }, confirmButton = { TextButton({ set = false }) { Text("Done") } },
        title = { Text("Theme") }, text = {
            Column {
                Text("Background", color = Color.Gray)
                Row { BGS.forEachIndexed { i, c ->
                    Box(Modifier.padding(4.dp).size(38.dp).clip(CircleShape).background(Color(c)).border(2.dp, if (i == bg) Color.White else Color.Gray, CircleShape)
                        .clickable { bg = i; p.edit().putInt("bg", i).apply() })
                } }
                Text("Font", color = Color.Gray, modifier = Modifier.padding(top = 8.dp))
                Row { FONTS.forEachIndexed { i, f ->
                    TextButton({ ff = i; p.edit().putInt("ff", i).apply() }, contentPadding = PaddingValues(6.dp)) {
                        Text(f.first, fontFamily = f.second, fontSize = 13.sp, color = if (i == ff) Color(0xFF2979FF) else Color.Gray)
                    }
                } }
                Text("Text size", color = Color.Gray)
                Slider(fs, { fs = it; p.edit().putFloat("fs", it).apply() }, valueRange = 12f..24f)
                TextButton(out) { Text("Logout", color = Color(0xFFFF6B6B)) }
            }
        })
}

@Composable fun Bubble(m: Msg, ff: FontFamily, fs: Float) {
    val fmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    val body = remember(m.body) { Cx.decS(m.body) }
    Column(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalAlignment = if (m.mine) Alignment.End else Alignment.Start) {
        Column(Modifier.widthIn(max = 280.dp)
            .clip(RoundedCornerShape(18.dp, 18.dp, if (m.mine) 4.dp else 18.dp, if (m.mine) 18.dp else 4.dp))
            .then(if (m.mine) Modifier.background(ACC) else Modifier.background(Color(0xFF22223A))).padding(10.dp)) {
            if (m.type == "text") Text(body, color = Color.White, fontFamily = ff, fontSize = fs.sp) else Media(body, m.type == "video")
            Text(fmt.format(Date(m.ts)) + if (m.mine) (if (m.pending) "  🕓" else if (m.read) "  ✓✓" else "  ✓") else "",
                Modifier.align(Alignment.End), color = Color(0xB3FFFFFF), fontSize = 10.sp)
        }
    }
}

@Composable fun Media(n: String, v: Boolean) {
    val ctx = LocalContext.current; val sc = rememberCoroutineScope()
    var bmp by remember { mutableStateOf(CACHE[n]) }; var vp by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(n) {
        if (!v && bmp == null) bmp = withContext(Dispatchers.IO) {
            runCatching { Sb.down(n)?.let { val d = Cx.dec(it); BitmapFactory.decodeByteArray(d, 0, d.size) } }.getOrNull()?.also { CACHE[n] = it }
        }
    }
    Box(Modifier.size(220.dp).clip(RoundedCornerShape(12.dp)).background(Color(0x33000000)).clickable(enabled = v) {
        sc.launch(Dispatchers.IO) {
            runCatching { Sb.down(n)?.let { val f = File(ctx.cacheDir, "$n.mp4"); f.writeBytes(Cx.dec(it)); f.path } }.getOrNull()?.let { path -> withContext(Dispatchers.Main) { vp = path } }
        }
    }, Alignment.Center) {
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Text(if (v) "▶  Video" else "⏳", color = Color.White, fontSize = if (v) 18.sp else 28.sp)
    }
    vp?.let { path ->
        Dialog({ File(path).delete(); vp = null }, DialogProperties(usePlatformDefaultWidth = false, securePolicy = SecureFlagPolicy.SecureOn)) {
            AndroidView({ c -> VideoView(c).apply { setVideoPath(path); setMediaController(MediaController(c).also { it.setAnchorView(this) }); setOnPreparedListener { start() } } }, Modifier.fillMaxSize())
        }
    }
}
