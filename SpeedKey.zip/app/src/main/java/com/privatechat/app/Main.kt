package com.privatechat.app

import android.Manifest
import android.graphics.Paint
import android.graphics.Typeface
import android.media.MediaPlayer
import android.media.MediaRecorder
import androidx.activity.compose.BackHandler
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import java.util.Calendar
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.view.WindowManager
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.SecureFlagPolicy
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

const val SB = "https://obohjkshxneagjsxnqdh.supabase.co"
const val KEY = "sb_publishable_4TPiN_BzNsnEa84qIfZ8DQ_u6FohR3U"
val ACC = Brush.horizontalGradient(listOf(Color(0xFF2979FF), Color(0xFF8E4DFF)))
val BGS = listOf(0xFF0B0B14, 0xFF0D1B2A, 0xFF1A0F24, 0xFF0E1F17, 0xFF000000)
val FONTS = listOf("Default" to FontFamily.Default, "Serif" to FontFamily.Serif, "Mono" to FontFamily.Monospace, "Cursive" to FontFamily.Cursive)
val CACHE = HashMap<String, Bitmap>()

object St { var locked by mutableStateOf(true); var skip = false }
data class Msg(val id: String, val mine: Boolean, val type: String, val body: String, val ts: Long, val read: Boolean, val pending: Boolean)

object Cx {
    lateinit var key: SecretKeySpec
    fun set(s: String) {
        val f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        key = SecretKeySpec(f.generateSecret(PBEKeySpec(s.toCharArray(), "clock-v1".toByteArray(), 100000, 256)).encoded, "AES")
    }
    fun enc(b: ByteArray): ByteArray {
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
        return iv + c.doFinal(b)
    }
    fun dec(b: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, b, 0, 12))
        return c.doFinal(b, 12, b.size - 12)
    }
    fun encS(s: String) = Base64.encodeToString(enc(s.toByteArray()), Base64.NO_WRAP)
    fun decS(s: String) = try { String(dec(Base64.decode(s, Base64.NO_WRAP))) } catch (e: Exception) { "🔒 Secret key match nahi (Settings > Secret key badlo)" }
}

object Sb {
    private fun conn(path: String, post: Boolean): HttpURLConnection {
        val c = URL("$SB/storage/v1/object/$path").openConnection() as HttpURLConnection
        c.setRequestProperty("apikey", KEY); c.connectTimeout = 20000; c.readTimeout = 120000
        if (post) { c.requestMethod = "POST"; c.doOutput = true; c.setRequestProperty("Content-Type", "application/octet-stream") }
        return c
    }
    fun up(name: String, d: ByteArray): Boolean {
        val c = conn("media/$name", true); c.setFixedLengthStreamingMode(d.size)
        c.outputStream.use { it.write(d) }
        return c.responseCode in 200..299
    }
    fun down(name: String): ByteArray? {
        val c = conn("authenticated/media/$name", false)
        return if (c.responseCode == 200) c.inputStream.use { it.readBytes() } else null
    }
}


fun shrink(c: Context, u: Uri): ByteArray {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    c.contentResolver.openInputStream(u)!!.use { BitmapFactory.decodeStream(it, null, o) }
    var s = 1; while (o.outWidth / s > 1600) s *= 2
    val b = c.contentResolver.openInputStream(u)!!.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s }) }!!
    return ByteArrayOutputStream().also { b.compress(Bitmap.CompressFormat.JPEG, 82, it) }.toByteArray()
}

class MainActivity : ComponentActivity() {
    var fg = false
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("m", "Messages", NotificationManager.IMPORTANCE_DEFAULT))
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        setContent { App(this) }
    }
    override fun onStart() { super.onStart(); fg = true; St.skip = false }
    override fun onStop() { super.onStop(); fg = false; if (!St.skip) St.locked = true }
    fun ping() {
        val n = Notification.Builder(this, "m").setSmallIcon(android.R.drawable.ic_dialog_email)
            .setContentTitle("CLOCK").setContentText("Naya message").setVisibility(Notification.VISIBILITY_SECRET).build()
        getSystemService(NotificationManager::class.java).notify(1, n)
    }
}

@Composable fun App(a: MainActivity) {
    val p = remember { EncryptedSharedPreferences.create(a, "p", MasterKey.Builder(a).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV, EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM) }
    var user by remember { mutableStateOf(FirebaseAuth.getInstance().currentUser) }
    var sec by remember { mutableStateOf(p.getString("sec", null)?.also { Cx.set(it) }) }
    MaterialTheme(colorScheme = darkColorScheme()) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFF0B0B14)) {
            when {
                St.locked -> ClockLock()
                user == null -> Login { user = it }
                sec == null -> Secret { p.edit().putString("sec", it).apply(); Cx.set(it); sec = it }
                else -> Chat(a, p, { p.edit().remove("sec").apply(); sec = null }) { FirebaseAuth.getInstance().signOut(); user = null }
            }
        }
    }
}

@Composable fun Perf() {
    Canvas(Modifier.fillMaxSize()) {
        drawRect(Color(0xFF101213))
        val st = 15.dp.toPx(); var y = 0f; var row = 0
        while (y < size.height) {
            var x = if (row % 2 == 0) 0f else st / 2
            while (x < size.width) { drawCircle(Color(0xFF2A2D2F), st * 0.24f, Offset(x, y)); x += st }
            y += st * 0.87f; row++
        }
    }
}

@Composable fun ClockLock() {
    val sc = rememberCoroutineScope(); val dens = LocalDensity.current
    var mode by remember { mutableIntStateOf(0) }
    var frame by remember { mutableLongStateOf(0L) }
    var hA by remember { mutableFloatStateOf(0f) }
    var mA by remember { mutableFloatStateOf(0f) }
    var bad by remember { mutableStateOf(false) }
    var sz by remember { mutableStateOf(IntSize.Zero) }
    var sel by remember { mutableIntStateOf(1) }
    var lcd by remember { mutableStateOf("00:00") }
    val fmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    val day = remember { SimpleDateFormat("EEEE", Locale.getDefault()).format(Date()) }
    val date = remember { SimpleDateFormat("MMM d", Locale.getDefault()).format(Date()) }
    val paint = remember { Paint().apply { isAntiAlias = true; textAlign = Paint.Align.CENTER; color = 0xFF1A1A1A.toInt(); typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL) } }
    LaunchedEffect(mode) { while (mode == 0) { withFrameMillis { frame = it }; lcd = fmt.format(Date()) } }
    fun now(): FloatArray {
        val c = Calendar.getInstance()
        val sc2 = c.get(Calendar.SECOND) + c.get(Calendar.MILLISECOND) / 1000f
        val m = c.get(Calendar.MINUTE) + sc2 / 60f
        val h = c.get(Calendar.HOUR) + m / 60f
        return floatArrayOf(h * 30f, m * 6f, sc2 * 6f)
    }
    fun tip(a: Float, len: Float): Offset {
        val r = Math.toRadians(a.toDouble())
        return Offset(sz.width / 2f + len * sin(r).toFloat(), sz.height / 2f - len * cos(r).toFloat())
    }
    fun centerTap() {
        if (mode == 0) {
            val n = now(); val h0 = n[0]; val m0 = n[1]; hA = h0; mA = m0; mode = 2
            sc.launch {
                val ht = if (h0 > 180f) 360f else 0f; val mt = if (m0 > 180f) 360f else 0f
                animate(0f, 1f, animationSpec = tween(900)) { t, _ -> hA = h0 + (ht - h0) * t; mA = m0 + (mt - m0) * t }
                hA = 0f; mA = 0f; mode = 1
            }
        } else if (mode == 1) {
            if (abs(mA - 180f) <= 12f && hA in 0f..30f) St.locked = false
            else sc.launch { bad = true; delay(450); bad = false; hA = 0f; mA = 0f }
        }
    }
    val onTap = rememberUpdatedState { centerTap() }
    Box(Modifier.fillMaxSize()) {
        Perf()
        Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
            Box(Modifier.fillMaxWidth(0.94f).aspectRatio(1f).onSizeChanged { sz = it }, Alignment.Center) {
                Canvas(Modifier.fillMaxSize()
                    .pointerInput(Unit) {
                        detectTapGestures { o -> if ((o - Offset(sz.width / 2f, sz.height / 2f)).getDistance() < sz.width * 0.1f) onTap.value() }
                    }
                    .pointerInput(Unit) {
                        detectDragGestures(onDragStart = { o ->
                            if (mode == 1) {
                                val dm = (o - tip(mA, sz.width / 2f * 0.62f)).getDistance()
                                val dh = (o - tip(hA, sz.width / 2f * 0.42f)).getDistance()
                                sel = if (dh < dm) 0 else 1
                            }
                        }) { change, _ ->
                            if (mode == 1) {
                                val d = change.position - Offset(sz.width / 2f, sz.height / 2f)
                                var ang = Math.toDegrees(atan2(d.x.toDouble(), -d.y.toDouble())).toFloat()
                                if (ang < 0) ang += 360f
                                if (sel == 0) hA = ang else mA = ang
                            }
                        }
                    }) {
                    val tt = frame
                    val c = center; val R = size.width / 2f
                    val n = now()
                    val hAng = if (mode == 0) n[0] else hA
                    val mAng = if (mode == 0) n[1] else mA
                    drawCircle(Brush.sweepGradient(listOf(Color(0xFFEDEDED), Color(0xFF9A9A9A), Color(0xFFF8F8F8), Color(0xFF8C8C8C), Color(0xFFEDEDED)), c), R * 0.99f)
                    drawCircle(Color(0xFF3A3A3A), R * 0.915f)
                    drawCircle(Brush.radialGradient(listOf(Color.White, Color(0xFFE6E6E6)), c, R * 0.9f), R * 0.9f)
                    if (bad) drawCircle(Color.Red, R * 0.95f, style = Stroke(10f))
                    for (i in 0 until 60) {
                        val big = i % 5 == 0; val a = Math.toRadians(i * 6.0)
                        val sn = sin(a).toFloat(); val cs = cos(a).toFloat()
                        val r1 = R * 0.66f; val r2 = if (big) R * 0.58f else R * 0.62f
                        drawLine(Color(0xFF222222), Offset(c.x + r1 * sn, c.y - r1 * cs), Offset(c.x + r2 * sn, c.y - r2 * cs), if (big) 5f else 2f)
                    }
                    paint.textSize = R * 0.2f
                    for (i in 1..12) {
                        val a = Math.toRadians(i * 30.0)
                        drawContext.canvas.nativeCanvas.drawText("$i", c.x + R * 0.78f * sin(a).toFloat(), c.y - R * 0.78f * cos(a).toFloat() + paint.textSize * 0.35f, paint)
                    }
                    fun hand(ang: Float, len: Float, w: Float) {
                        val r = Math.toRadians(ang.toDouble()); val sn = sin(r).toFloat(); val cs = cos(r).toFloat()
                        drawLine(Color(0xFF111111), Offset(c.x - len * 0.18f * sn, c.y + len * 0.18f * cs), Offset(c.x + len * sn, c.y - len * cs), w, StrokeCap.Round)
                        drawLine(Color.White, Offset(c.x + len * 0.35f * sn, c.y - len * 0.35f * cs), Offset(c.x + len * 0.93f * sn, c.y - len * 0.93f * cs), w * 0.4f, StrokeCap.Round)
                    }
                    hand(hAng, R * 0.42f, R * 0.085f)
                    hand(mAng, R * 0.62f, R * 0.065f)
                    if (mode == 0) {
                        val r = Math.toRadians(n[2].toDouble()); val sn = sin(r).toFloat(); val cs = cos(r).toFloat()
                        drawLine(Color(0xFFE53935), Offset(c.x - R * 0.2f * sn, c.y + R * 0.2f * cs), Offset(c.x + R * 0.8f * sn, c.y - R * 0.8f * cs), 3f)
                        drawLine(Color(0xFFE53935), Offset(c.x - R * 0.2f * sn, c.y + R * 0.2f * cs), Offset(c.x - R * 0.04f * sn, c.y + R * 0.04f * cs), 10f)
                    }
                    drawCircle(Brush.radialGradient(listOf(Color.White, Color(0xFF8E8E8E)), c, R * 0.08f), R * 0.08f, c)
                    drawCircle(Color(0xFFBBBBBB), R * 0.08f, c, style = Stroke(3f))
                }
                Box(Modifier.offset(y = with(dens) { (sz.height * 0.2f).toDp() }).clip(RoundedCornerShape(4.dp)).background(Color(0xFFF2F2F2))
                    .border(1.dp, Color.DarkGray, RoundedCornerShape(4.dp)).padding(horizontal = 10.dp, vertical = 2.dp)) {
                    Text(if (mode == 0) lcd else "--:--", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 22.sp, color = Color.Black)
                }
            }
            Spacer(Modifier.height(48.dp))
            Text(day, fontSize = 40.sp, color = Color(0xFFD0CCD8))
            Text(date, fontSize = 22.sp, color = Color(0xFFD0CCD8))
        }
    }
}

@Composable fun Login(done: (FirebaseUser) -> Unit) {
    var e by remember { mutableStateOf("") }; var pw by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }; var busy by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF16213E), Color(0xFF0B0B14)))).padding(28.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Text("🕒", fontSize = 64.sp)
        Text("CLOCK", fontSize = 34.sp, color = Color.White, fontWeight = FontWeight.Bold)
        Text("Sirf hum dono ke liye", color = Color.Gray)
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(e, { e = it }, label = { Text("Email") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(pw, { pw = it }, label = { Text("Password") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(16.dp))
        Button({
            busy = true; msg = ""
            FirebaseAuth.getInstance().signInWithEmailAndPassword(e.trim(), pw).addOnCompleteListener {
                busy = false
                if (it.isSuccessful) done(it.result.user!!) else msg = it.exception?.message ?: "Login fail"
            }
        }, Modifier.fillMaxWidth().height(52.dp), enabled = !busy && e.isNotBlank() && pw.isNotBlank()) { Text(if (busy) "..." else "Login", fontSize = 18.sp) }
        Text(msg, color = Color(0xFFFF6B6B), modifier = Modifier.padding(top = 10.dp), textAlign = TextAlign.Center)
    }
}

@Composable fun Secret(ok: (String) -> Unit) {
    var s by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(28.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Text("🔐", fontSize = 56.sp)
        Text("Secret key", fontSize = 26.sp, color = Color.White, fontWeight = FontWeight.Bold)
        Text("Dono phone mein bilkul same daalna. Isse chat encrypt hoti hai.", color = Color.Gray, textAlign = TextAlign.Center)
        Spacer(Modifier.height(16.dp))
        Text("Spelling dono mein bilkul same (capital/small farak nahi padta)", color = Color.Gray, fontSize = 12.sp)
        OutlinedTextField(s, { s = it }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        Button({ if (s.trim().length >= 6) ok(s.trim().lowercase()) }, Modifier.fillMaxWidth()) { Text(if (s.length >= 6) "Save" else "Kam se kam 6 character") }
    }
}

const val U1 = "DJ9MrRvM3HTLjUgMhlNFnZcXMjB3"
const val U2 = "X7xUw4dVCQeYVy1jGmzN8Fz1TzV2"

@Composable fun Avatar(photo: String?, s: Dp, label: String, mod: Modifier = Modifier) {
    var b by remember(photo) { mutableStateOf(photo?.let { CACHE[it] }) }
    LaunchedEffect(photo) {
        if (photo != null && b == null) b = withContext(Dispatchers.IO) {
            runCatching { Sb.down(photo)?.let { val d = Cx.dec(it); BitmapFactory.decodeByteArray(d, 0, d.size) } }.getOrNull()?.also { CACHE[photo] = it }
        }
    }
    Box(mod.size(s).clip(CircleShape).background(ACC), Alignment.Center) {
        val x = b
        if (x != null) Image(x.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Text(label.take(1).uppercase(), color = Color.White, fontSize = (s.value / 2.2f).sp, fontWeight = FontWeight.Bold)
    }
}

@Composable fun Voice(n: String) {
    val ctx = LocalContext.current; val sc = rememberCoroutineScope()
    var st by remember { mutableIntStateOf(0) }
    var mp by remember { mutableStateOf<MediaPlayer?>(null) }
    DisposableEffect(Unit) { onDispose { runCatching { mp?.release() } } }
    Row(Modifier.clickable {
        if (st == 2) { runCatching { mp?.release() }; mp = null; st = 0 }
        else if (st == 0) {
            st = 1
            sc.launch(Dispatchers.IO) {
                val path = runCatching { Sb.down(n)?.let { val f = File(ctx.cacheDir, "$n.m4a"); f.writeBytes(Cx.dec(it)); f.path } }.getOrNull()
                withContext(Dispatchers.Main) {
                    if (path == null) st = 0 else try {
                        val m = MediaPlayer(); m.setDataSource(path); m.prepare()
                        m.setOnCompletionListener { it.release(); mp = null; st = 0; File(path).delete() }
                        m.start(); mp = m; st = 2
                    } catch (e: Exception) { st = 0 }
                }
            }
        }
    }, verticalAlignment = Alignment.CenterVertically) {
        Text(when (st) { 1 -> "⏳"; 2 -> "⏸"; else -> "▶" }, fontSize = 26.sp, color = Color.White)
        Spacer(Modifier.width(8.dp))
        Box(Modifier.width(110.dp).height(4.dp).clip(RoundedCornerShape(2.dp)).background(Color(0x66FFFFFF)))
        Spacer(Modifier.width(8.dp))
        Text("🎤", fontSize = 16.sp)
    }
}

@Composable fun Chat(a: MainActivity, p: SharedPreferences, reKey: () -> Unit, out: () -> Unit) {
    val db = remember { FirebaseFirestore.getInstance() }
    val me = remember { FirebaseAuth.getInstance().currentUser!!.uid }
    val partner = if (me == U1) U2 else U1
    val msgs = remember { mutableStateListOf<Msg>() }
    val prof = remember { mutableStateMapOf<String, Pair<String, String?>>() }
    val sc = rememberCoroutineScope(); val ls = rememberLazyListState()
    var text by remember { mutableStateOf("") }
    var bg by remember { mutableIntStateOf(p.getInt("bg", 0)) }
    var ff by remember { mutableIntStateOf(p.getInt("ff", 0)) }
    var fs by remember { mutableFloatStateOf(p.getFloat("fs", 16f)) }
    var set by remember { mutableStateOf(false) }
    var screen by remember { mutableIntStateOf(0) }; var ret by remember { mutableIntStateOf(0) }
    var eName by remember { mutableStateOf("") }; var ePhoto by remember { mutableStateOf<String?>(null) }
    var rec by remember { mutableStateOf<MediaRecorder?>(null) }; var recFile by remember { mutableStateOf<File?>(null) }
    var recT by remember { mutableLongStateOf(0L) }; var recording by remember { mutableStateOf(false) }
    val first = remember { booleanArrayOf(true) }
    val pName = prof[partner]?.first?.takeIf { it.isNotBlank() } ?: "Partner"
    val pPhoto = prof[partner]?.second
    fun toast(s: String) { Handler(Looper.getMainLooper()).post { Toast.makeText(a, s, Toast.LENGTH_LONG).show() } }
    fun send(t: String, b: String) {
        db.collection("messages").add(hashMapOf("senderId" to me, "type" to t, "body" to b, "ts" to FieldValue.serverTimestamp(), "read" to false))
            .addOnFailureListener { toast("Send fail: ${it.message}") }
    }
    fun go(x: Int) { ret = screen; screen = x }
    BackHandler(screen != 0) { screen = if (screen == 2) ret else 0 }
    DisposableEffect(Unit) {
        val r = db.collection("messages").orderBy("ts").addSnapshotListener { s, e ->
            if (e != null) toast("Sync error: ${e.message}")
            if (s == null) return@addSnapshotListener
            if (!first[0] && !a.fg && s.documentChanges.any { it.type == DocumentChange.Type.ADDED && it.document.getString("senderId") != me }) a.ping()
            first[0] = false
            val l = s.documents.map { d ->
                Msg(d.id, d.getString("senderId") == me, d.getString("type") ?: "text", d.getString("body") ?: "",
                    d.getTimestamp("ts", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)?.toDate()?.time ?: 0L,
                    d.getBoolean("read") == true, d.metadata.hasPendingWrites())
            }
            msgs.clear(); msgs.addAll(l)
            s.documents.filter { it.getString("senderId") != me && it.getBoolean("read") != true && !it.metadata.hasPendingWrites() }.forEach { it.reference.update("read", true) }
        }
        val r2 = db.collection("users").addSnapshotListener { s, _ ->
            s?.documents?.forEach { d ->
                prof[d.id] = Pair(d.getString("name")?.takeIf { it.isNotEmpty() }?.let { Cx.decS(it) } ?: "", d.getString("photo")?.takeIf { it.isNotEmpty() }?.let { Cx.decS(it) })
            }
        }
        onDispose { r.remove(); r2.remove() }
    }
    LaunchedEffect(msgs.size, screen) { if (screen == 1 && msgs.isNotEmpty()) ls.scrollToItem(msgs.lastIndex) }
    LaunchedEffect(screen) { if (screen == 3) { eName = prof[me]?.first ?: ""; ePhoto = prof[me]?.second } }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u: Uri? ->
        if (u != null) sc.launch(Dispatchers.IO) {
            try {
                val v = a.contentResolver.getType(u)?.startsWith("video") == true
                val raw = if (v) a.contentResolver.openInputStream(u)!!.use { it.readBytes() } else shrink(a, u)
                if (raw.size > 45_000_000) { toast("Video bada hai (max 45MB)"); return@launch }
                val n = UUID.randomUUID().toString()
                if (Sb.up(n, Cx.enc(raw))) send(if (v) "video" else "image", Cx.encS(n)) else toast("Upload fail")
            } catch (e: Exception) { toast("Error: ${e.message}") }
        }
    }
    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u: Uri? ->
        if (u != null) sc.launch(Dispatchers.IO) {
            try {
                val n = UUID.randomUUID().toString()
                if (Sb.up(n, Cx.enc(shrink(a, u)))) ePhoto = n else toast("Photo upload fail")
            } catch (e: Exception) { toast("Error: ${e.message}") }
        }
    }
    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    fun startRec() {
        try {
            val f = File(a.cacheDir, "v${System.currentTimeMillis()}.m4a")
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(a) else MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC); r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC); r.setAudioEncodingBitRate(64000); r.setAudioSamplingRate(44100)
            r.setOutputFile(f.path); r.prepare(); r.start()
            rec = r; recFile = f; recT = System.currentTimeMillis(); recording = true
        } catch (e: Exception) { toast("Mic error: ${e.message}") }
    }
    fun stopRec() {
        val r = rec ?: return; rec = null; recording = false
        val ok = runCatching { r.stop() }.isSuccess; runCatching { r.release() }
        val f = recFile ?: return
        if (!ok || System.currentTimeMillis() - recT < 700) { f.delete(); return }
        sc.launch(Dispatchers.IO) {
            try {
                val n = UUID.randomUUID().toString()
                if (Sb.up(n, Cx.enc(f.readBytes()))) send("voice", Cx.encS(n)) else toast("Voice upload fail")
            } catch (e: Exception) { toast("Error: ${e.message}") }
            f.delete()
        }
    }
    val bar = Color(0xFF14142A)
    Box(Modifier.fillMaxSize().background(Color(BGS[bg]))) {
        when (screen) {
            0 -> Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().background(bar).padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("CLOCK", Modifier.weight(1f), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    IconButton({ set = true }) { Icon(Icons.Default.Settings, null, tint = Color.White) }
                }
                val last = msgs.lastOrNull()?.let {
                    (if (it.mine) "You: " else "") + when (it.type) { "text" -> Cx.decS(it.body); "image" -> "📷 Photo"; "video" -> "🎥 Video"; else -> "🎤 Voice" }
                } ?: "Chat shuru karo"
                Row(Modifier.fillMaxWidth().clickable { go(1) }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(pPhoto, 56.dp, pName, Modifier.clickable { go(2) })
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text(pName, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text(last, color = Color.Gray, maxLines = 1)
                    }
                }
            }
            1 -> Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().background(bar).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextButton({ screen = 0 }) { Text("←", color = Color.White, fontSize = 24.sp) }
                    Row(Modifier.weight(1f).clickable { go(2) }, verticalAlignment = Alignment.CenterVertically) {
                        Avatar(pPhoto, 40.dp, pName); Spacer(Modifier.width(10.dp))
                        Text(pName, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                    IconButton({ set = true }) { Icon(Icons.Default.Settings, null, tint = Color.White) }
                }
                LazyColumn(Modifier.weight(1f).padding(horizontal = 10.dp), state = ls) { items(msgs, key = { it.id }) { Bubble(it, FONTS[ff].second, fs) } }
                Row(Modifier.fillMaxWidth().background(bar).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton({ St.skip = true; pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)) }) { Icon(Icons.Default.Add, null, tint = Color.White) }
                    TextField(text, { text = it }, Modifier.weight(1f), placeholder = { Text(if (recording) "🔴 Recording... chhodo to send" else "Message") }, shape = RoundedCornerShape(24.dp),
                        colors = TextFieldDefaults.colors(focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent))
                    Spacer(Modifier.width(6.dp))
                    Box(Modifier.size(46.dp).clip(CircleShape).background(if (recording) Color.Red else Color(0xFF2979FF)).pointerInput(Unit) {
                        detectTapGestures(onPress = {
                            if (text.isNotBlank()) { send("text", Cx.encS(text.trim())); text = "" }
                            else if (a.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) { startRec(); tryAwaitRelease(); stopRec() }
                            else { St.skip = true; micPerm.launch(Manifest.permission.RECORD_AUDIO) }
                        })
                    }, Alignment.Center) {
                        if (text.isBlank()) Text("🎤", fontSize = 20.sp) else Icon(Icons.Default.Send, null, tint = Color.White)
                    }
                }
            }
            2 -> Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
                Avatar(pPhoto, 170.dp, pName)
                Text(pName, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp))
                Button({ screen = 1 }) { Text("Message") }
                TextButton({ screen = ret }) { Text("← Wapas") }
            }
            else -> Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
                Avatar(ePhoto, 150.dp, eName.ifBlank { "Me" }, Modifier.clickable { St.skip = true; pickPhoto.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) })
                Text("Photo badalne ke liye tap karo", color = Color.Gray, modifier = Modifier.padding(8.dp))
                OutlinedTextField(eName, { eName = it }, label = { Text("Naam") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(16.dp))
                Button({
                    db.collection("users").document(me).set(hashMapOf("name" to Cx.encS(eName.trim()), "photo" to (ePhoto?.let { Cx.encS(it) } ?: "")))
                        .addOnSuccessListener { toast("Profile save ho gayi") }.addOnFailureListener { toast("Save fail: ${it.message}") }
                    screen = 0
                }, Modifier.fillMaxWidth().height(50.dp)) { Text("Save") }
                TextButton({ screen = 0 }) { Text("Cancel") }
            }
        }
    }
    if (set) AlertDialog(onDismissRequest = { set = false }, confirmButton = { TextButton({ set = false }) { Text("Done") } },
        title = { Text("Settings") }, text = {
            Column {
                TextButton({ set = false; go(3) }) { Text("👤 Meri profile edit karo") }
                Text("Background", color = Color.Gray)
                Row { BGS.forEachIndexed { i, c ->
                    Box(Modifier.padding(4.dp).size(38.dp).clip(CircleShape).background(Color(c)).border(2.dp, if (i == bg) Color.White else Color.Gray, CircleShape)
                        .clickable { bg = i; p.edit().putInt("bg", i).apply() })
                } }
                Text("Font", color = Color.Gray, modifier = Modifier.padding(top = 8.dp))
                Row { FONTS.forEachIndexed { i, f ->
                    TextButton({ ff = i; p.edit().putInt("ff", i).apply() }, contentPadding = PaddingValues(6.dp)) {
                        Text(f.first, fontFamily = f.second, fontSize = 13.sp, color = if (i == ff) Color(0xFF2979FF) else Color.Gray)
                    }
                } }
                Text("Text size", color = Color.Gray)
                Slider(fs, { fs = it; p.edit().putFloat("fs", it).apply() }, valueRange = 12f..24f)
                TextButton({ set = false; reKey() }) { Text("🔐 Secret key badlo") }
                TextButton(out) { Text("Logout", color = Color(0xFFFF6B6B)) }
            }
        })
}

@Composable fun Bubble(m: Msg, ff: FontFamily, fs: Float) {
    val fmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    val body = remember(m.body) { Cx.decS(m.body) }
    Column(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalAlignment = if (m.mine) Alignment.End else Alignment.Start) {
        Column(Modifier.widthIn(max = 280.dp)
            .clip(RoundedCornerShape(18.dp, 18.dp, if (m.mine) 4.dp else 18.dp, if (m.mine) 18.dp else 4.dp))
            .then(if (m.mine) Modifier.background(ACC) else Modifier.background(Color(0xFF22223A))).padding(10.dp)) {
            when (m.type) {
                "text" -> Text(body, color = Color.White, fontFamily = ff, fontSize = fs.sp)
                "voice" -> Voice(body)
                else -> Media(body, m.type == "video")
            }
            Text(fmt.format(Date(m.ts)) + if (m.mine) (if (m.pending) "  🕓" else if (m.read) "  ✓✓" else "  ✓") else "",
                Modifier.align(Alignment.End), color = Color(0xB3FFFFFF), fontSize = 10.sp)
        }
    }
}

@Composable fun Media(n: String, v: Boolean) {
    val ctx = LocalContext.current; val sc = rememberCoroutineScope()
    var bmp by remember { mutableStateOf(CACHE[n]) }; var vp by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(n) {
        if (!v && bmp == null) bmp = withContext(Dispatchers.IO) {
            runCatching { Sb.down(n)?.let { val d = Cx.dec(it); BitmapFactory.decodeByteArray(d, 0, d.size) } }.getOrNull()?.also { CACHE[n] = it }
        }
    }
    Box(Modifier.size(220.dp).clip(RoundedCornerShape(12.dp)).background(Color(0x33000000)).clickable(enabled = v) {
        sc.launch(Dispatchers.IO) {
            runCatching { Sb.down(n)?.let { val f = File(ctx.cacheDir, "$n.mp4"); f.writeBytes(Cx.dec(it)); f.path } }.getOrNull()?.let { path -> withContext(Dispatchers.Main) { vp = path } }
        }
    }, Alignment.Center) {
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Text(if (v) "▶  Video" else "⏳", color = Color.White, fontSize = if (v) 18.sp else 28.sp)
    }
    vp?.let { path ->
        Dialog({ File(path).delete(); vp = null }, DialogProperties(usePlatformDefaultWidth = false)) {
            AndroidView({ c -> VideoView(c).apply { setVideoPath(path); setMediaController(MediaController(c).also { it.setAnchorView(this) }); setOnPreparedListener { start() } } }, Modifier.fillMaxSize())
        }
    }
}
