package com.makimaos.app
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val ACC: Color get() = MakimaTheme.accent

@Composable
fun Page(app: AppState, title: String, content: @Composable ColumnScope.() -> Unit) {
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(MakimaTheme.bg1, MakimaTheme.bg0, Color.Black)))) {
        Column(Modifier.fillMaxSize().systemBarsPadding().imePadding().padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { app.screen = Screen.HOME }) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
                Image(painterResource(R.drawable.logo), null, Modifier.size(40.dp).clip(CircleShape))
                Spacer(Modifier.width(10.dp))
                Text(title, color = ACC, fontSize = 22.sp)
            }
            Spacer(Modifier.height(8.dp))
            content()
        }
    }
}

@Composable
fun Chip(text: String, selected: Boolean, accent: Color, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(Modifier.clip(shape).background(if (selected) accent.copy(alpha = 0.35f) else Color(0x33FFFFFF))
        .border(1.dp, if (selected) accent else Color(0x44FFFFFF), shape).clickable { onClick() }.padding(horizontal = 14.dp, vertical = 8.dp)) {
        Text(text, color = Color.White, fontSize = 13.sp)
    }
}

@Composable
fun Field(value: String, onChange: (String) -> Unit, label: String, accent: Color, secret: Boolean = false,
          modifier: Modifier = Modifier, single: Boolean = true) {
    OutlinedTextField(value, onChange, modifier = modifier, label = { Text(label) }, singleLine = single,
        visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White,
            focusedBorderColor = accent, unfocusedBorderColor = Color(0x66FFFFFF), focusedLabelColor = accent,
            unfocusedLabelColor = Color(0xAAFFFFFF), cursorColor = accent))
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 7.dp).clip(RoundedCornerShape(16.dp))
        .background(Color(0x26FFFFFF)).border(1.dp, ACC.copy(alpha = 0.14f), RoundedCornerShape(16.dp)).padding(14.dp)) {
        Text(title, color = ACC, fontSize = 17.sp)
        Spacer(Modifier.height(6.dp))
        content()
    }
}

@Composable
private fun Hint(t: String) = Text(t, color = Color(0x99FFFFFF), fontSize = 12.sp, modifier = Modifier.padding(vertical = 3.dp))

@Composable
private fun Label(t: String) = Text(t, color = Color.White, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp, bottom = 4.dp))

@Composable
private fun ChipRow(options: List<String>, selected: Int, onPick: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEachIndexed { i, n -> Chip(n, selected == i, ACC) { onPick(i) } }
    }
}

@Composable
private fun PrefSwitch(title: String, sub: String, init: Boolean, onSet: (Boolean) -> Unit) {
    var v by remember { mutableStateOf(init) }
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 14.sp)
            if (sub.isNotEmpty()) Text(sub, color = Color(0x99FFFFFF), fontSize = 12.sp)
        }
        Switch(v, { v = it; onSet(it) }, colors = SwitchDefaults.colors(checkedTrackColor = ACC, checkedThumbColor = Color.White))
    }
}

@Composable
private fun PrefSlider(title: String, init: Float, range: ClosedFloatingPointRange<Float>, fmt: (Float) -> String, onSet: (Float) -> Unit) {
    var v by remember { mutableStateOf(init) }
    Label("$title: ${fmt(v)}")
    Slider(v, { v = it }, onValueChangeFinished = { onSet(v) }, valueRange = range,
        colors = SliderDefaults.colors(thumbColor = ACC, activeTrackColor = ACC))
}

private fun fmtTime(ts: Long) = SimpleDateFormat("d MMM, HH:mm", Locale.getDefault()).format(Date(ts))

// ------------------------------------------------------------------- CHAT
@Composable
fun ChatScreen(app: AppState) {
    var input by remember { mutableStateOf("") }
    val ls = rememberLazyListState()
    LaunchedEffect(app.messages.size) { if (app.messages.isNotEmpty()) ls.animateScrollToItem(app.messages.size - 1) }
    Page(app, "MAKIMA OS") {
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = ls, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(app.messages) { m ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.user) Arrangement.End else Arrangement.Start,
                    verticalAlignment = Alignment.Bottom) {
                    Box(Modifier.widthIn(max = 290.dp).clip(RoundedCornerShape(16.dp))
                        .background(if (m.user) ACC.copy(alpha = 0.4f) else Color(0x26FFFFFF)).padding(12.dp)) {
                        Text(m.text, color = Color.White, fontSize = 15.sp)
                    }
                    if (!m.user) IconButton(onClick = { app.toggleFav(m) }, modifier = Modifier.size(34.dp)) {
                        Icon(if (m.fav) Icons.Default.Star else Icons.Default.StarBorder, null, tint = if (m.fav) ACC else Color(0x99FFFFFF))
                    }
                }
            }
            if (app.thinking) item { Text("Makima is thinking...", color = Color(0xAAFFFFFF), fontSize = 13.sp) }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Field(input, { input = it }, "Type to Makima", ACC, modifier = Modifier.weight(1f))
            IconButton(onClick = { app.toggleListen() }) { Icon(Icons.Default.Mic, null, tint = if (app.listening) ACC else Color.White) }
            IconButton(onClick = { app.send(input); input = "" }) { Icon(Icons.Default.Send, null, tint = ACC) }
        }
    }
}

// --------------------------------------------------------------- FAVORITES
@Composable
fun FavoritesScreen(app: AppState) {
    val favs = app.messages.filter { it.fav }.reversed()
    Page(app, "Favorites") {
        if (favs.isEmpty()) Hint("Abhi koi favorite nahi. Chat me Makima ke jawab ke saamne star dabao.")
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(favs) { m ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0x26FFFFFF)).padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(m.text, color = Color.White, fontSize = 15.sp)
                        Text(fmtTime(m.ts), color = Color(0x88FFFFFF), fontSize = 11.sp)
                    }
                    IconButton(onClick = { app.toggleFav(m) }) { Icon(Icons.Default.Star, null, tint = ACC) }
                }
            }
        }
    }
}

// ----------------------------------------------------------------- HISTORY
@Composable
fun HistoryScreen(app: AppState) {
    val asked = app.messages.filter { it.user }.reversed()
    var confirm by remember { mutableStateOf(false) }
    Page(app, "History") {
        if (asked.isEmpty()) Hint("Abhi tak koi baat nahi hui.")
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(asked) { m ->
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0x26FFFFFF))
                    .clickable { app.screen = Screen.CHAT; app.send(m.text) }.padding(12.dp)) {
                    Text(m.text, color = Color.White, fontSize = 15.sp)
                    Text(fmtTime(m.ts) + "  -  tap to ask again", color = Color(0x88FFFFFF), fontSize = 11.sp)
                }
            }
        }
        if (asked.isNotEmpty()) Button(onClick = { if (confirm) { app.clearHistory(); confirm = false } else confirm = true },
            colors = ButtonDefaults.buttonColors(containerColor = ACC), modifier = Modifier.fillMaxWidth()) {
            Text(if (confirm) "Pakka? Dobara tap karo" else "Clear history")
        }
    }
}

// ---------------------------------------------------------------- SETTINGS
@Composable
private fun KeysSection(app: AppState) {
    val scope = rememberCoroutineScope()
    var keys by remember { mutableStateOf(Prefs.active()) }
    var primary by remember { mutableStateOf(Prefs.primaryName()) }
    var input by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val results = remember { mutableStateMapOf<String, String>() }

    Section("AI Brain - bas key paste karo") {
        Hint("Gemini, Grok, DeepSeek, OpenAI, Groq, OpenRouter ya Mistral ki koi bhi key. Ek ya kai keys ek saath paste kar sakte ho; provider aur model apne aap detect hote hain. Ek key ki limit khatam ho to dusri khud lag jaati hai.")
        Field(input, { input = it }, "Paste API key", ACC, secret = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        Button(enabled = !busy && input.isNotBlank(), colors = ButtonDefaults.buttonColors(containerColor = ACC), onClick = {
            scope.launch {
                busy = true; status = "Key check ho rahi hai..."
                val (ok, msg) = withContext(Dispatchers.IO) { Brain.addKey(input) }
                status = msg
                if (ok) { input = ""; keys = Prefs.active(); primary = Prefs.primaryName() }
                busy = false
            }
        }) { Text(if (busy) "Wait..." else "Activate") }
        if (status.isNotEmpty()) Text(status, fontSize = 13.sp, color = if (status.contains("activate ho gayi")) Color(0xFF7CFFA0) else Color(0xFFFF8A8A))

        keys.forEach { p ->
            val k = Prefs.key(p)
            Column(Modifier.fillMaxWidth().padding(top = 10.dp).clip(RoundedCornerShape(12.dp)).background(Color(0x22FFFFFF)).padding(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(p, color = Color.White, fontSize = 15.sp)
                        Text("${k.take(4)}...${k.takeLast(4)}  |  ${Prefs.model(p).ifBlank { "auto" }}  |  ${Prefs.keyCount(p)} key", color = Color(0x99FFFFFF), fontSize = 12.sp)
                    }
                    IconButton(onClick = { scope.launch { results[p] = "Testing..."; results[p] = withContext(Dispatchers.IO) { Brain.test(p) } } }) {
                        Icon(Icons.Default.PlayArrow, null, tint = ACC)
                    }
                    IconButton(onClick = { scope.launch { results[p] = "Model dhoondh rahi hoon..."; results[p] = withContext(Dispatchers.IO) { Brain.redetect(p) } } }) {
                        Icon(Icons.Default.Refresh, null, tint = Color.White)
                    }
                    IconButton(onClick = { Prefs.removeKey(p); keys = Prefs.active(); primary = Prefs.primaryName(); results.remove(p) }) {
                        Icon(Icons.Default.Delete, null, tint = Color(0xFFFF8A8A))
                    }
                }
                results[p]?.let { Text(it, fontSize = 12.sp, color = if (it.startsWith("Working") || it.startsWith("Model:")) Color(0xFF7CFFA0) else Color(0xFFFF8A8A)) }
            }
        }
        if (keys.size > 1) {
            Label("Primary brain")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                keys.forEach { p -> Chip(p, primary == p, ACC) { primary = p; Prefs.primary = p } }
            }
        }
        PrefSwitch("Auto-failover", "Primary fail ho to dusri key try karo", Prefs.failover) { Prefs.failover = it }
    }
}

@Composable
fun SettingsScreen(app: AppState) {
    val ctx = app.ctx
    var persona by remember { mutableStateOf(Prefs.persona) }
    var lang by remember { mutableStateOf(Prefs.lang) }
    var len by remember { mutableStateOf(Prefs.len) }
    var gv by remember { mutableStateOf(Prefs.geminiVoice) }
    var dv by remember { mutableStateOf(Prefs.voice) }
    var ml by remember { mutableStateOf(Prefs.micLang) }
    var custom by remember { mutableStateOf(Prefs.custom) }
    var hf by remember { mutableStateOf(app.handsFree) }
    var confirmMem by remember { mutableStateOf(false) }

    Page(app, "Settings") {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            KeysSection(app)

            Section("App Themes") {
                var th by remember { mutableStateOf(MakimaTheme.index) }
                Hint("Sirf rang badalte hain - icons, layout aur animation wahi rehte hain.")
                Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    MakimaTheme.themes.forEachIndexed { i, d ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { th = i; MakimaTheme.index = i }) {
                            Box(Modifier.size(52.dp).clip(CircleShape)
                                .background(Brush.linearGradient(listOf(d.accent, d.bg1)))
                                .border(if (th == i) 3.dp else 1.dp, if (th == i) Color.White else Color(0x55FFFFFF), CircleShape),
                                contentAlignment = Alignment.Center) {
                                if (th == i) Icon(Icons.Default.Check, null, tint = Color.White)
                            }
                            Text(d.name, color = Color.White, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                }
            }

            Section("Personality") {
                Label("Makima kaise baat kare")
                ChipRow(Prefs.personas, persona) { persona = it; Prefs.persona = it }
                Label("Language")
                ChipRow(Prefs.langs, lang) { lang = it; Prefs.lang = it }
                Label("Reply length")
                ChipRow(Prefs.lengths, len) { len = it; Prefs.len = it }
                Field(custom, { custom = it; Prefs.custom = it }, "Custom instructions (optional)", ACC,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp), single = false)
                Spacer(Modifier.height(6.dp))
                Button(onClick = { app.screen = Screen.MEMORY }, colors = ButtonDefaults.buttonColors(containerColor = ACC)) { Text("Manage Memory") }
            }

            Section("Autopilot - tumhare bina bhi kaam") {
                var names by remember { mutableStateOf(Prefs.autoNames) }
                var orders by remember { mutableStateOf(Prefs.autoOrders) }
                var job by remember { mutableStateOf("") }
                var mode by remember { mutableStateOf(Prefs.autoMode) }
                var tick by remember { mutableStateOf(0) }
                var msg by remember { mutableStateOf("") }
                val listenerOn = androidx.core.app.NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
                PrefSwitch("Autopilot ON", "WhatsApp / Instagram / SMS jaise messages ka Makima khud jawab dega (notification se, screen band ho tab bhi) aur diya hua kaam bina ruke poora karegi", Prefs.autoOn) { Prefs.autoOn = it }
                Hint(if (listenerOn) "Notification access: ON" else "Notification access OFF - neeche button se MakimaOS ko allow karo, warna kuch nahi hoga.")
                Button(onClick = { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) },
                    colors = ButtonDefaults.buttonColors(containerColor = ACC)) { Text("Notification access do") }
                Label("Kis ko jawab dena hai")
                ChipRow(listOf("Sabko", "Sirf chune hue"), mode) { mode = it; Prefs.autoMode = it }
                if (mode == 1) {
                    Field(names, { names = it; Prefs.autoNames = it }, "Naam (comma se alag): Papa, Mummy, Rahul", ACC, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
                }
                Field(orders, { orders = it; Prefs.autoOrders = it }, "Standing orders: kya bolna hai (jaise: Papa khana poochhe to bolo haan kha liya)", ACC,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp), single = false)
                PrefSwitch("Group chats me bhi", "Default band: groups me bina bulaye jawab dena theek nahi", Prefs.autoGroups) { Prefs.autoGroups = it }
                PrefSwitch("Jawab se pehle poori chat padho", "Phone unlock ho to Makima chat kholkar upar scroll karke purane messages padhti hai, phir jawab deti hai", Prefs.autoDeepRead) { Prefs.autoDeepRead = it }
                PrefSwitch("Sirf jab screen band ho", "Tum phone chala rahe ho to Makima beech me nahi aayegi", Prefs.autoOnlyAway) { Prefs.autoOnlyAway = it }
                PrefSwitch("Reply na ho paye to screen se bheje", "Jin apps ki notification me reply box nahi hota (phone unlock chahiye)", Prefs.autoUi) { Prefs.autoUi = it }
                PrefSwitch("Dusri notifications par bhi kaam", "Standing orders ke hisaab se Makima khud decide karegi ki kuch karna hai ya nahi", Prefs.autoOther) { Prefs.autoOther = it }
                Hint("Safety: OTP/password wale, paise maangne wale ya shak wale messages par Makima jawab nahi deti (SKIP). Ek insaan ko ghante me max 6 jawab.")
                Label("Abhi koi kaam do (tum chale jao, wo karti rahegi)")
                Field(job, { job = it }, "Jaise: WhatsApp par Rahul ko bolo 8 baje milte hain", ACC, modifier = Modifier.fillMaxWidth(), single = false)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
                    Button(onClick = { msg = AutoPilot.runTask(ctx, job).removePrefix("OK: "); tick++ }, colors = ButtonDefaults.buttonColors(containerColor = ACC)) { Text("Kaam shuru") }
                    OutlinedButton(onClick = { AutoPilot.stopAll(); msg = "Sab kaam roke" }) { Text("Roko", color = Color.White) }
                }
                if (msg.isNotBlank()) Hint(msg)
                Hint("Screen se kaam ke liye phone unlock aur Accessibility ON chahiye. Battery saver band rakho taaki Android app ko na maare.")
                Label("Autopilot log")
                val lines = remember(tick) { AutoPilot.logLines(12) }
                if (lines.isEmpty()) Hint("Abhi kuch nahi hua.")
                lines.forEach { Text(it, color = Color(0xCCFFFFFF), fontSize = 11.sp, modifier = Modifier.padding(vertical = 3.dp)) }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { tick++ }) { Text("Refresh", color = Color.White) }
                    OutlinedButton(onClick = { AutoPilot.clearLog(); tick++ }) { Text("Log saaf", color = Color.White) }
                }
            }

            Section("Voice") {
                PrefSwitch("Live mode", "Asli live baat-cheet (Gemini Live): awaaz seedhi jaati aur aati hai, beech me tok sakte ho, phone control bhi saath chalta hai. Gemini key chahiye. Limit khatam ho to normal mode apne aap chalu ho jata hai", Prefs.liveMode) { Prefs.liveMode = it }
                Hint("Live mode me phone ka speaker aur mic saath chalte hain; echo ho to earphone laga lo.")
                PrefSwitch("Auto-speak replies", "Jawab khud bolegi", Prefs.autoSpeak) { Prefs.autoSpeak = it }
                Label("Live voice (${Prefs.geminiVoices.size} Gemini voices) - chunte hi Live apne aap nayi awaaz se reconnect hota hai")
                ChipRow(Prefs.geminiVoiceInfo.map { it.first + " - " + it.second }, Prefs.geminiVoices.indexOf(gv).coerceAtLeast(0)) {
                    gv = Prefs.geminiVoices[it]; Prefs.geminiVoice = gv; app.applyLiveVoice()
                }
                Hint("Selected: $gv")
                Label("Phone voice (fallback)")
                ChipRow(listOf("Voice 1 Calm", "Voice 2 Soft", "Voice 3 Cold"), dv) { dv = it; Prefs.voice = it; app.sampleVoice() }
                PrefSlider("Speed", Prefs.speed, 0.6f..1.4f, { "%.2fx".format(it) }) { Prefs.speed = it }
                PrefSlider("Pitch", Prefs.pitch, 0.7f..1.3f, { "%.2fx".format(it) }) { Prefs.pitch = it }
                Text("Speed aur pitch phone-voice par lagte hain.", color = Color(0x88FFFFFF), fontSize = 11.sp)
                Spacer(Modifier.height(6.dp))
                Button(onClick = { app.sampleVoice() }, colors = ButtonDefaults.buttonColors(containerColor = ACC)) { Text("Test voice") }
                Label("Mic language")
                ChipRow(Prefs.micLangs, ml) { ml = it; Prefs.micLang = it }
            }

            Section("Feelings") {
                PrefSwitch("Human mode", "Mood badalta rehta hai: pyaar se baat karo to khush, bad-tameezi karo to naraz. Awaaz bhi mood ke hisaab se badalti hai", Prefs.humanMode) { Prefs.humanMode = it }
                PrefSwitch("Speak up when I am quiet", "Tum chup raho to pehle poochhegi, phir bore, phir naraz, aakhir me ruth jayegi (hands-free chalu ho tab, raat 11 se subah 7 tak nahi)", Prefs.proactive) { Prefs.proactive = it }
                Hint("Wo tumhari zaroori baatein khud yaad bhi rakhti hai (Manage Memory me dikhengi).")
            }

            Section("Conversation") {
                PrefSwitch("Hands-free mode", "Jawab ke baad khud sunna shuru karti hai (Home ka Voice button bhi yahi hai)", hf) {
                    hf = it; if (it != app.handsFree) app.toggleHandsFree()
                }
                PrefSwitch("Always listening", "App khulte hi hands-free chalu ho jaye", Prefs.autoHands) { Prefs.autoHands = it }
                PrefSlider("Extra wait after I stop", Prefs.waitSec, 0.5f..3f, { "%.1f s".format(it) }) { Prefs.waitSec = it }
                Hint("Beech me ruk kar bolo to bhi poori baat sunkar hi jawab degi.")
                PermRow("Floating bubble", "Doosri apps ke upar bubble dikhane ki permission", PermState.overlay(ctx)) {
                    ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
                PrefSlider("Context memory", Prefs.ctxTurns.toFloat(), 4f..30f, { "${it.toInt()} messages" }) { Prefs.ctxTurns = it.toInt() }
                PrefSwitch("Save chat history", "Band karo to history save nahi hogi", Prefs.saveHistory) { Prefs.saveHistory = it; app.save() }
            }

            Section("Phone Control") {
                PrefSwitch("Voice phone commands", "AI khud app kholti, tap, scroll, type, search, call, alarm sab karti hai", Prefs.phoneControl) { Prefs.phoneControl = it }
                PrefSwitch("Floating subtitles", "Doosri app me bubble ke neeche tumhari baat aur Makima ka jawab likha aata hai", Prefs.captions) { Prefs.captions = it }
                PermRow("Accessibility", "MakimaOS Control: tap, scroll, type jaise kaam ke liye", PermState.accessibility(ctx)) {
                    ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
                PermRow("Battery: don't kill Makima", "Android ko background me Makima band karne se roko", PermState.battery(ctx)) {
                    ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
                PermRow("Permissions", "Mic, call aur notifications", PermState.basic(ctx)) { app.askPerms() }
                PermRow("File manager (All files)", "Files padhne, badalne aur banane ki permission", PermState.files(ctx)) { PermState.openFiles(ctx) }
                Hint("Try: YouTube pe gana lagao brain, WhatsApp kholo, is par click karo, neeche scroll karo, screen pe kya hai, 7 baje ka alarm lagao, torch on, volume up, remember my birthday is 5 May. Rukne ke liye bolo: stop.")
            }

            Section("Data") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { app.clearHistory() }, colors = ButtonDefaults.buttonColors(containerColor = Color(0x44FFFFFF))) { Text("Clear history") }
                    Button(onClick = { if (confirmMem) { Prefs.memory = ""; confirmMem = false } else confirmMem = true },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0x44FFFFFF))) { Text(if (confirmMem) "Pakka? tap" else "Clear memory") }
                }
            }
            Spacer(Modifier.height(40.dp))
        }
    }
}

// ------------------------------------------------------------------ MEMORY
@Composable
fun MemoryScreen(app: AppState) {
    var lines by remember { mutableStateOf(Prefs.memory.lines().filter { it.isNotBlank() }) }
    var input by remember { mutableStateOf("") }
    fun save(l: List<String>) { lines = l; Prefs.memory = l.joinToString("\n") }
    Page(app, "Memory") {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Field(input, { input = it }, "Tell Makima to remember", ACC, modifier = Modifier.weight(1f))
            IconButton(onClick = { if (input.isNotBlank()) { save(lines + input.trim()); input = "" } }) { Icon(Icons.Default.Add, null, tint = ACC) }
        }
        LazyColumn(Modifier.weight(1f)) {
            items(lines) { l ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(12.dp)).background(Color(0x33FFFFFF)).padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Text(l, color = Color.White, modifier = Modifier.weight(1f))
                    IconButton(onClick = { save(lines - l) }) { Icon(Icons.Default.Delete, null, tint = Color(0xFFFF8A8A)) }
                }
            }
        }
    }
}

// ----------------------------------------------------------------- PROFILE
@Composable
fun ProfileScreen(app: AppState) {
    var name by remember { mutableStateOf(Prefs.userName) }
    Page(app, "Profile") {
        Field(name, { name = it; Prefs.userName = it }, "What should Makima call you?", ACC, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        Image(painterResource(R.drawable.logo), null, Modifier.size(160.dp).clip(CircleShape).align(Alignment.CenterHorizontally))
        Text("MakimaOS v2.4", color = Color(0xAAFFFFFF))
        Text("License: ${License.label()}", color = Color(0xFF7CFFA0))
        Text("Brain used last: ${Brain.lastUsed.ifEmpty { "none yet" }}", color = Color(0xAAFFFFFF))
        Text("Messages saved: ${app.messages.size}", color = Color(0xAAFFFFFF))
    }
}


// ------------------------------------------------------- permission toggles
object PermState {
    fun overlay(c: android.content.Context) = Settings.canDrawOverlays(c)
    fun accessibility(c: android.content.Context): Boolean {
        if (MakimaAccessibilityService.instance != null) return true
        val v = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return v.contains(c.packageName)
    }
    fun battery(c: android.content.Context) =
        (c.getSystemService(android.content.Context.POWER_SERVICE) as android.os.PowerManager).isIgnoringBatteryOptimizations(c.packageName)
    private fun has(c: android.content.Context, p: String) =
        androidx.core.content.ContextCompat.checkSelfPermission(c, p) == android.content.pm.PackageManager.PERMISSION_GRANTED
    fun basic(c: android.content.Context): Boolean {
        var ok = has(c, android.Manifest.permission.RECORD_AUDIO) && has(c, android.Manifest.permission.CALL_PHONE)
        if (android.os.Build.VERSION.SDK_INT >= 33) ok = ok && has(c, android.Manifest.permission.POST_NOTIFICATIONS)
        return ok
    }
    fun files(c: android.content.Context): Boolean =
        if (android.os.Build.VERSION.SDK_INT >= 30) android.os.Environment.isExternalStorageManager()
        else has(c, android.Manifest.permission.READ_EXTERNAL_STORAGE) && has(c, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
    fun openFiles(c: android.content.Context) {
        val i = if (android.os.Build.VERSION.SDK_INT >= 30)
            Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + c.packageName))
        else Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + c.packageName))
        try { c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (_: Exception) { c.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }
}

/** Setting row with an ON/OFF switch that shows the real state; tapping it opens the matching system screen. The state refreshes by itself when you come back. */
@Composable
private fun PermRow(title: String, sub: String, initial: Boolean, onOpen: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var on by remember { mutableStateOf(initial) }
    // re-check every second so the switch follows the real permission state after returning from system settings
    LaunchedEffect(title) {
        while (true) {
            kotlinx.coroutines.delay(1000)
            on = when {
                title.startsWith("Floating") -> PermState.overlay(ctx)
                title.startsWith("Accessibility") -> PermState.accessibility(ctx)
                title.startsWith("Battery") -> PermState.battery(ctx)
                title.startsWith("Permissions") -> PermState.basic(ctx)
                else -> PermState.files(ctx)
            }
        }
    }
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 14.sp)
            Text((if (on) "ON - " else "OFF - ") + sub, color = if (on) Color(0xFF7CFFA0) else Color(0x99FFFFFF), fontSize = 12.sp)
        }
        Switch(on, { onOpen() }, colors = SwitchDefaults.colors(checkedTrackColor = ACC, checkedThumbColor = Color.White))
    }
}
