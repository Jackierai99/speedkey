package com.makimaos.app
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Gives Autopilot the notifications (WhatsApp, Instagram, SMS ...). Needs "Notification access" in Android settings. */
class NotifListener : NotificationListenerService() {
    override fun onCreate() {
        super.onCreate()
        AppHolder.get(applicationContext)      // Prefs + app state must exist even when the app screen is closed
    }
    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        try { requestRebind(android.content.ComponentName(this, NotifListener::class.java)) } catch (_: Exception) {}   // Android killed us: reconnect
    }
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn != null) AutoPilot.onNotification(applicationContext, sbn)
    }
    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        if (sbn != null) AutoPilot.onRemoved(sbn)
    }
}
