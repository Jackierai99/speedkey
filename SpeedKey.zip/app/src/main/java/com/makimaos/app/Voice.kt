package com.makimaos.app
import kotlin.math.sqrt
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import java.util.Locale

/**
 * Makima's voice. Sentences arrive while the AI is still writing; each one is turned into speech
 * (AI voice via the same key, phone voice as automatic fallback) and played back-to-back.
 *
 * v2.3 speed work: silence at the start/end of every AI clip is trimmed, the connection is kept warm,
 * and in "Fast" mode the phone voice covers the first sentence when the AI voice is slower than ~1.5 s.
 * Phone voice now follows the mood (angry = sharper and faster, sad = slower and lower ...).
 */
class Mouth(ctx: Context, private val scope: CoroutineScope) {
    private class Item(val text: String, val mood: String?, val pcm: Deferred<ByteArray?>)

    var speaking by mutableStateOf(false)
    var onDone: (() -> Unit)? = null
    private var ready = false
    @Volatile private var gen = 0
    private var sj: Job? = null
    private var streamScope: CoroutineScope? = null
    private var q: Channel<Item>? = null
    @Volatile private var curTrack: AudioTrack? = null
    private val tts: TextToSpeech = TextToSpeech(ctx) { ready = it == TextToSpeech.SUCCESS }

    private fun finish(g: Int) { if (g == gen) { speaking = false; onDone?.invoke() } }
    private fun clean(t: String) = t.replace(Regex("[*_#`~>]"), " ").replace(Regex("[\\p{So}\\p{Cs}]"), "").trim()

    fun speak(text: String, mood: String? = null) { startStream(); feed(text, mood); endStream() }

    fun startStream() {
        stop()
        val g = gen
        speaking = true
        val job = SupervisorJob(scope.coroutineContext[Job])
        sj = job
        val sc = CoroutineScope(scope.coroutineContext + job)
        streamScope = sc
        val ch = Channel<Item>(Channel.UNLIMITED)
        q = ch
        sc.launch(Dispatchers.IO) { player(ch, g) }
    }

    fun feed(s: String, mood: String? = null) {
        val t = clean(s); if (t.isEmpty()) return
        val ch = q ?: return
        val sc = streamScope ?: return
        val d = sc.async(Dispatchers.IO) { null as ByteArray? }
        ch.trySend(Item(t, mood, d))
    }

    fun endStream() { q?.close() }

    // ---- live voice level (drives lip-sync): RMS of the PCM chunks, read at the current playback position
    private val lvQ = java.util.ArrayDeque<Pair<Long, Float>>()
    @Volatile private var wroteFrames = 0L
    private fun resetLevels() { synchronized(lvQ) { lvQ.clear() }; wroteFrames = 0L }
    private fun recordLevel(buf: ByteArray, off: Int, n: Int) {
        var sum = 0.0; var cnt = 0; var i = off
        while (i + 1 < off + n) {
            val v = (buf[i].toInt() and 0xFF) or (buf[i + 1].toInt() shl 8)
            sum += v.toDouble() * v; cnt++; i += 2
        }
        val rms = if (cnt > 0) sqrt(sum / cnt) / 32768.0 else 0.0
        wroteFrames += n / 2
        synchronized(lvQ) { lvQ.addLast(wroteFrames to rms.toFloat()) }
    }
    /** 0..1 loudness of what is being heard right now, or -1 when the system voice is used (no PCM available). */
    fun level(): Float {
        val t = curTrack ?: return -1f
        val head = try { t.playbackHeadPosition.toLong() } catch (_: Exception) { return -1f }
        synchronized(lvQ) {
            while (lvQ.size > 1 && lvQ.peekFirst()!!.first < head) lvQ.removeFirst()
            val e = lvQ.peekFirst() ?: return -1f
            if (e.first < head - 2400) return -1f
            return e.second
        }
    }

    private fun newTrack(): AudioTrack {
        val sr = 24000
        val minBuf = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        return AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(minBuf, 16384)).setTransferMode(AudioTrack.MODE_STREAM).build()
    }

    private fun drain(t: AudioTrack, frames: Long, g: Int) {
        var waited = 0
        while (g == gen && t.playbackHeadPosition.toLong() < frames && waited < 6000) { Thread.sleep(40); waited += 40 }
    }

    /** Cuts the dead air Gemini puts before and after each clip (usually 300-600 ms): replies start sooner and flow like speech. */
    private fun trim(pcm: ByteArray): ByteArray {
        val n = pcm.size / 2
        if (n < 4800) return pcm
        fun amp(i: Int): Int { val v = (pcm[2 * i].toInt() and 0xFF) or (pcm[2 * i + 1].toInt() shl 8); return if (v < 0) -v else v }
        val th = 700
        var a = 0
        while (a < n && amp(a) < th) a++
        var b = n - 1
        while (b > a && amp(b) < th) b--
        val from = maxOf(0, a - 960)             // keep 40 ms of breath before the first sound
        val to = minOf(n, b + 2880)              // and 120 ms after the last one
        if (to - from < 2400) return pcm
        return pcm.copyOfRange(from * 2, to * 2)
    }

    private suspend fun player(ch: Channel<Item>, g: Int) {
        var track: AudioTrack? = null
        var frames = 0L
        var first = true
        var phoneOnly = true
        try {
            for (item in ch) {
                if (g != gen) return
                var pcm: ByteArray? = null
                if (!phoneOnly) {
                    pcm = if (first && Prefs.voiceMode == 0) {
                        // fast mode: if the AI voice is slow for the first sentence, the phone voice answers at once
                        // and keeps the whole reply, so one reply never switches voices halfway
                        val r = withTimeoutOrNull(1500L) { item.pcm.await() }
                        if (r == null) { phoneOnly = true; null } else r
                    } else item.pcm.await()
                }
                first = false
                if (g != gen) return
                if (pcm != null && pcm.size > 1) {
                    val p = trim(pcm)
                    if (track == null) { track = newTrack(); curTrack = track; resetLevels(); track.play() }
                    var off = 0
                    while (off < p.size && g == gen) {
                        val n = track.write(p, off, minOf(4096, p.size - off))
                        if (n <= 0) break
                        recordLevel(p, off, n)
                        off += n
                    }
                    frames += p.size / 2
                } else {
                    if (phoneOnly) item.pcm.cancel()
                    track?.let { drain(it, frames, g) }
                    if (g != gen) return
                    systemSpeak(item.text, item.mood, g)
                }
            }
            track?.let { drain(it, frames, g) }
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
        } finally {
            try { track?.stop() } catch (_: Exception) {}
            try { track?.release() } catch (_: Exception) {}
            if (curTrack === track) curTrack = null
        }
        withContext(Dispatchers.Main) { finish(g) }
    }

    private fun pickVoice(loc: Locale): android.speech.tts.Voice? {
        val cand = (tts.voices ?: emptySet()).filter { it.locale.language == loc.language && it.features?.contains("notInstalled") != true }
        if (cand.isEmpty()) return null
        val fem = cand.filter { it.name.contains("female", true) || it.name.contains("-hif", true) || it.name.contains("-enf", true) }.ifEmpty { cand }
        // best quality first, so the phone voice sounds as natural as the phone can make it
        val best = fem.sortedWith(compareByDescending<android.speech.tts.Voice> { it.quality }.thenBy { it.isNetworkConnectionRequired })
        return best[Prefs.voice.coerceAtLeast(0) % minOf(best.size, 3)]
    }

    private suspend fun systemSpeak(text: String, mood: String?, g: Int) {
        if (!ready) return
        val done = CompletableDeferred<Unit>()
        val deva = text.any { it in '\u0900'..'\u097F' }
        val loc = if (deva) Locale("hi", "IN") else Locale("en", "IN")
        tts.language = loc
        pickVoice(loc)?.let { tts.voice = it }
        val (p0, r0) = when (Prefs.voice) { 0 -> 1.12f to 0.98f; 1 -> 1.3f to 1.05f; else -> 1.0f to 0.94f }
        // feelings change how the phone voice sounds
        val (pm, rm) = when (mood) {
            "angry", "annoyed" -> 0.93f to 1.1f
            "sad" -> 0.9f to 0.82f
            "bored", "sleepy" -> 0.92f to 0.85f
            "happy" -> 1.08f to 1.08f
            "tease" -> 1.03f to 0.93f
            else -> 1f to 1f
        }
        tts.setPitch((p0 * pm * Prefs.pitch).coerceIn(0.5f, 2f)); tts.setSpeechRate((r0 * rm * Prefs.speed).coerceIn(0.4f, 2.5f))
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { done.complete(Unit) }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { done.complete(Unit) }
        })
        tts.speak(text.take(3500), TextToSpeech.QUEUE_FLUSH, null, "mk")
        withTimeoutOrNull(60000) { done.await() }
    }

    fun stop() {
        gen++
        sj?.cancel(); sj = null; streamScope = null
        q?.close(); q = null
        try { curTrack?.pause(); curTrack?.flush() } catch (_: Exception) {}
        tts.stop(); speaking = false
    }
    fun release() { stop(); tts.shutdown() }
}

class Ears(private val ctx: Context, private val onPartial: (String) -> Unit, private val onFinal: (String) -> Unit,
           private val onEnd: (Int) -> Unit, private val onLevel: (Float) -> Unit) {
    private var sr: SpeechRecognizer? = null
    fun start() {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) { onEnd(-1); return }
        stop()
        sr = SpeechRecognizer.createSpeechRecognizer(ctx).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rms: Float) { onLevel(((rms + 2f) / 12f).coerceIn(0f, 1f)) }
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(e: Int) { onEnd(e) }
                override fun onResults(r: Bundle?) {
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                    if (t.isBlank()) onEnd(7) else onFinal(t)
                }
                override fun onPartialResults(r: Bundle?) {
                    r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { onPartial(it) }
                }
                override fun onEvent(t: Int, b: Bundle?) {}
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Prefs.micTags[Prefs.micLang.coerceIn(0, 2)])
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1100L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 900L)
        }
        sr?.startListening(i)
    }
    fun stop() { sr?.cancel(); sr?.destroy(); sr = null }
}
