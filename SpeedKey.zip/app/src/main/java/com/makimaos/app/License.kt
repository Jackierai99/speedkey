package com.makimaos.app
import android.annotation.SuppressLint
import android.content.Context
import android.provider.Settings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.security.SecureRandom
import java.util.concurrent.TimeUnit

class Res(val ok: Boolean, val msg: String)
class KeyRow(val code: String, val days: Int, val used: Boolean, val expiresAt: Long)

/** Firebase (Firestore + Auth) license system, talking to Firebase over plain REST - no google-services.json needed. */
object License {
    private const val API_KEY = "AIzaSyC4bbURHLbaz3-lN3Qhs7IN34JdcQmcQOU"
    private const val PROJECT = "makimaos"
    const val ADMIN_EMAIL = "raivip104@gmail.com"
    const val TRIAL_MS = 10L * 60 * 1000
    private const val DAY = 24L * 60 * 60 * 1000
    private const val BASE = "https://firestore.googleapis.com/v1/projects/$PROJECT/databases/(default)/documents"
    private val JSON = "application/json".toMediaType()
    private val http = OkHttpClient.Builder().callTimeout(20, TimeUnit.SECONDS).build()

    @Volatile var adminToken: String = ""
    @Volatile private var tokenAt = 0L
    private var devId = ""

    @SuppressLint("HardwareIds")
    fun deviceId(ctx: Context): String {
        if (devId.isNotEmpty()) return devId
        val id = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
        devId = id; return id
    }

    // ---- state ----
    fun isActive(): Boolean = Prefs.licAdmin || System.currentTimeMillis() < Prefs.licExpires
    fun isAdmin(): Boolean = Prefs.licAdmin
    fun label(): String = when {
        Prefs.licAdmin -> "Admin - unlimited"
        isActive() -> "${Prefs.licKind.ifEmpty { "License" }} - " + remaining(Prefs.licExpires - System.currentTimeMillis()) + " left"
        else -> "Not active"
    }
    private fun remaining(ms: Long): String {
        val m = ms / 60000
        return if (m >= 1440L * 3650) "Lifetime" else if (m >= 1440) "${m / 1440} days" else if (m >= 60) "${m / 60} hr" else "${maxOf(m, 0)} min"
    }
    fun hasAdmin(): Boolean = adminToken.isNotEmpty() || Prefs.licRefresh.isNotEmpty()
    fun kindLabel(days: Int) = if (days >= 3650) "Lifetime key" else "$days-day key"
    fun logout() { Prefs.licRefresh = ""; Prefs.licAdmin = false; Prefs.licExpires = 0L; Prefs.licKey = ""; Prefs.licKind = ""; adminToken = "" }

    // ---- low level ----
    private class Reply(val code: Int, val body: String, val serverNow: Long)
    private fun call(req: Request): Reply {
        http.newCall(req).execute().use { r ->
            val now = r.headers.getDate("Date")?.time ?: System.currentTimeMillis()
            return Reply(r.code, r.body?.string() ?: "", now)
        }
    }
    private fun fsInt(v: Long) = JSONObject().put("integerValue", v.toString())
    private fun fsStr(v: String) = JSONObject().put("stringValue", v)
    private fun JSONObject.long(name: String): Long =
        optJSONObject("fields")?.optJSONObject(name)?.let { it.optString("integerValue", "0").toLongOrNull() ?: 0L } ?: 0L
    private fun JSONObject.str(name: String): String =
        optJSONObject("fields")?.optJSONObject(name)?.optString("stringValue", "") ?: ""
    private fun err(e: Exception) = Res(false, if (e is java.io.IOException) "Internet check karo bhai" else "Error: ${e.message}")

    // ---- trial: one per device, 10 minutes, tracked server-side so reinstall doesn't reset it ----
    suspend fun startTrial(ctx: Context): Res = withContext(Dispatchers.IO) {
        try {
            val id = deviceId(ctx)
            val get = call(Request.Builder().url("$BASE/trials/$id?key=$API_KEY").build())
            val started: Long
            val now = get.serverNow
            if (get.code == 200) {
                started = JSONObject(get.body).long("startedAt")
            } else if (get.code == 404) {
                val body = JSONObject().put("fields", JSONObject().put("startedAt", fsInt(now))).toString()
                val c = call(Request.Builder().url("$BASE/trials?documentId=$id&key=$API_KEY").post(body.toRequestBody(JSON)).build())
                if (c.code != 200) return@withContext Res(false, "Trial start nahi hua (${c.code})")
                started = now
            } else return@withContext Res(false, "Server error (${get.code})")
            val exp = started + TRIAL_MS
            if (now >= exp) return@withContext Res(false, "Trial khatam ho chuka hai. Key lo aur Connect Makima karo.")
            // convert server expiry to device clock so the local countdown is right
            Prefs.licExpires = System.currentTimeMillis() + (exp - now)
            Prefs.licKind = "Trial"; Prefs.licAdmin = false
            Res(true, "Trial shuru - ${(exp - now) / 60000 + 1} min bache")
        } catch (e: Exception) { err(e) }
    }

    // ---- activate a key (7 / 31 days) ----
    suspend fun activate(ctx: Context, raw: String): Res = withContext(Dispatchers.IO) {
        try {
            val code = raw.trim().uppercase().replace(" ", "")
            if (code.length < 6 || code.contains("/")) return@withContext Res(false, "Key galat hai")
            val id = deviceId(ctx)
            val g = call(Request.Builder().url("$BASE/keys/$code?key=$API_KEY").build())
            if (g.code == 404) return@withContext Res(false, "Ye key exist nahi karti")
            if (g.code != 200) return@withContext Res(false, "Server error (${g.code})")
            val doc = JSONObject(g.body)
            val days = doc.long("days").toInt()
            val owner = doc.str("deviceId")
            var exp = doc.long("expiresAt")
            val now = g.serverNow
            if (owner.isEmpty()) {
                exp = now + days * DAY
                val body = JSONObject().put("fields", JSONObject().put("deviceId", fsStr(id)).put("expiresAt", fsInt(exp))).toString()
                val u = call(Request.Builder().url("$BASE/keys/$code?updateMask.fieldPaths=deviceId&updateMask.fieldPaths=expiresAt&currentDocument.exists=true&key=$API_KEY")
                    .patch(body.toRequestBody(JSON)).build())
                if (u.code != 200) return@withContext Res(false, "Key activate nahi hui (${u.code}) - kisi aur ne abhi use kar li ho sakti hai")
            } else if (owner != id) return@withContext Res(false, "Ye key kisi aur phone par use ho chuki hai")
            if (now >= exp) return@withContext Res(false, "Is key ki validity khatam ho chuki hai")
            Prefs.licExpires = System.currentTimeMillis() + (exp - now)
            Prefs.licKey = code; Prefs.licKind = kindLabel(days); Prefs.licAdmin = false
            Res(true, if (days >= 3650) "Makima connected - Lifetime key" else "Makima connected - $days din ki key")
        } catch (e: Exception) { err(e) }
    }

    /** Re-check a saved key against the server (stops a key that was revoked/deleted). Returns false only when the server clearly says it's gone. */
    suspend fun recheck(ctx: Context): Boolean = withContext(Dispatchers.IO) {
        try {
            if (Prefs.licAdmin || Prefs.licKey.isEmpty()) return@withContext true
            val g = call(Request.Builder().url("$BASE/keys/${Prefs.licKey}?key=$API_KEY").build())
            if (g.code == 404) { Prefs.licExpires = 0L; return@withContext false }
            if (g.code == 200) {
                val d = JSONObject(g.body)
                if (d.str("deviceId") != deviceId(ctx)) { Prefs.licExpires = 0L; return@withContext false }
                Prefs.licExpires = System.currentTimeMillis() + (d.long("expiresAt") - g.serverNow)
            }
            true
        } catch (e: Exception) { true }   // offline: keep running on the saved expiry
    }

    // ---- admin ----
    suspend fun adminLogin(email: String, pass: String): Res = withContext(Dispatchers.IO) {
        try {
            val e = email.trim().lowercase()
            if (e != ADMIN_EMAIL) return@withContext Res(false, "Ye admin email nahi hai")
            val body = JSONObject().put("email", e).put("password", pass).put("returnSecureToken", true).toString()
            val r = call(Request.Builder().url("https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=$API_KEY")
                .post(body.toRequestBody(JSON)).build())
            if (r.code != 200) {
                val m = runCatching { JSONObject(r.body).getJSONObject("error").getString("message") }.getOrDefault("login failed")
                return@withContext Res(false, "Admin login fail: $m")
            }
            val j = JSONObject(r.body)
            if (!j.optString("email").equals(ADMIN_EMAIL, true)) return@withContext Res(false, "Ye admin account nahi hai")
            adminToken = j.getString("idToken"); tokenAt = System.currentTimeMillis(); Prefs.licRefresh = j.optString("refreshToken")
            Prefs.licAdmin = true; Prefs.licKind = "Admin"; Prefs.lastEmail = e
            Res(true, "Admin login ho gaya - unlimited")
        } catch (e: Exception) { err(e) }
    }

    /** Keeps the admin session alive (Firebase tokens last 1 hour) so the key panel works any time inside the app. */
    private fun ensureToken(force: Boolean = false): Boolean {
        if (!force && adminToken.isNotEmpty() && System.currentTimeMillis() - tokenAt < 50 * 60 * 1000L) return true
        val rt = Prefs.licRefresh
        if (rt.isEmpty()) return adminToken.isNotEmpty()
        val r = call(Request.Builder().url("https://securetoken.googleapis.com/v1/token?key=$API_KEY")
            .post("grant_type=refresh_token&refresh_token=$rt".toRequestBody("application/x-www-form-urlencoded".toMediaType())).build())
        if (r.code != 200) return false
        val j = JSONObject(r.body)
        adminToken = j.getString("id_token"); tokenAt = System.currentTimeMillis()
        j.optString("refresh_token").takeIf { it.isNotEmpty() }?.let { Prefs.licRefresh = it }
        return true
    }
    private fun adminCall(build: (String) -> Request): Reply {
        ensureToken()
        var r = call(build(adminToken))
        if (r.code == 401 && ensureToken(true)) r = call(build(adminToken))
        return r
    }

    private const val ALPHA = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    private fun newCode(): String {
        val r = SecureRandom()
        fun part() = (1..4).map { ALPHA[r.nextInt(ALPHA.length)] }.joinToString("")
        return "MKM-${part()}-${part()}-${part()}"
    }

    suspend fun createKey(days: Int): Pair<Res, String> = withContext(Dispatchers.IO) {
        try {
            if (!hasAdmin()) return@withContext Res(false, "Pehle admin login karo") to ""
            val code = newCode()
            val body = JSONObject().put("fields", JSONObject()
                .put("days", fsInt(days.toLong())).put("deviceId", fsStr("")).put("expiresAt", fsInt(0))
                .put("createdAt", fsInt(System.currentTimeMillis()))).toString()
            val r = adminCall { t -> Request.Builder().url("$BASE/keys?documentId=$code").header("Authorization", "Bearer $t")
                .post(body.toRequestBody(JSON)).build() }
            if (r.code == 200) Res(true, "Key ban gayi") to code
            else Res(false, if (r.code == 401 || r.code == 403) "Permission nahi / session expire - dobara admin login karo (rules check karo)" else "Key nahi bani (${r.code})") to ""
        } catch (e: Exception) { err(e) to "" }
    }

    suspend fun listKeys(): Pair<Res, List<KeyRow>> = withContext(Dispatchers.IO) {
        try {
            if (!hasAdmin()) return@withContext Res(false, "Pehle admin login karo") to emptyList()
            val r = adminCall { t -> Request.Builder().url("$BASE/keys?pageSize=300").header("Authorization", "Bearer $t").build() }
            if (r.code != 200) return@withContext Res(false, "List nahi mili (${r.code})") to emptyList()
            val arr = JSONObject(r.body).optJSONArray("documents") ?: JSONArray()
            val out = (0 until arr.length()).map {
                val d = arr.getJSONObject(it)
                KeyRow(d.getString("name").substringAfterLast('/'), d.long("days").toInt(), d.str("deviceId").isNotEmpty(), d.long("expiresAt"))
            }.sortedBy { it.used }
            Res(true, "") to out
        } catch (e: Exception) { err(e) to emptyList() }
    }

    suspend fun deleteKey(code: String): Res = withContext(Dispatchers.IO) {
        try {
            val r = adminCall { t -> Request.Builder().url("$BASE/keys/$code").header("Authorization", "Bearer $t").delete().build() }
            if (r.code == 200) Res(true, "Delete ho gayi") else Res(false, "Delete fail (${r.code})")
        } catch (e: Exception) { err(e) }
    }
}
