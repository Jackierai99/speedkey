package com.makimaos.app
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.graphics.drawable.Icon
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.sin

/** Keeps the mic alive in the background and shows a small draggable orb over other apps. */
class OverlayService : Service() {
    companion object {
        var instance: OverlayService? = null
        const val ACTION_STOP = "com.makimaos.app.STOP"
        const val CH = "makimaos_listen"
    }
    private var wm: WindowManager? = null
    private var orb: OrbView? = null
    private var orbLp: WindowManager.LayoutParams? = null
    private var capBox: LinearLayout? = null
    private var capUserTv: TextView? = null
    private var capReplyTv: TextView? = null
    private var capLp: WindowManager.LayoutParams? = null
    private val main = Handler(Looper.getMainLooper())
    private val hideCap = Runnable { removeCaption() }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onCreate() { super.onCreate(); instance = this }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { AppHolder.app?.disableHandsFree(); stopSelf(); return START_NOT_STICKY }
        startFg()
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "Makima listening", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, CH)
            .setContentTitle("MakimaOS is listening")
            .setContentText("Bolo, main sun rahi hoon. Tap to open.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_media_pause), "Stop", stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(7, n)
    }

    fun showOrb() {
        if (orb != null || !Settings.canDrawOverlays(this)) return
        val w = getSystemService(Context.WINDOW_SERVICE) as WindowManager; wm = w
        val d = resources.displayMetrics.density
        val size = (64 * d).toInt()
        val p = WindowManager.LayoutParams(size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        p.gravity = Gravity.TOP or Gravity.START
        p.x = if (Prefs.orbX >= 0) Prefs.orbX else resources.displayMetrics.widthPixels - size - (12 * d).toInt()
        p.y = if (Prefs.orbY >= 0) Prefs.orbY else (220 * d).toInt()
        orbLp = p
        val v = OrbView(this, size)
        var sx = 0; var sy = 0; var dx = 0f; var dy = 0f; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = p.x; sy = p.y; dx = e.rawX; dy = e.rawY; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val mx = (e.rawX - dx).toInt(); val my = (e.rawY - dy).toInt()
                    if (abs(mx) > 8 || abs(my) > 8) moved = true
                    if (moved) { p.x = sx + mx; p.y = sy + my; try { w.updateViewLayout(v, p) } catch (_: Exception) {}; placeCaption() }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) { Prefs.orbX = p.x; Prefs.orbY = p.y }
                    else startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
                    true
                }
                else -> false
            }
        }
        try { w.addView(v, p); orb = v } catch (_: Exception) {}
    }

    fun hideOrb() {
        removeCaption()
        orb?.let { try { wm?.removeView(it) } catch (_: Exception) {} }; orb = null
    }

    // ---- subtitles under the bubble: what you said + what Makima replies ----
    fun setCaption(u: String, r: String) {
        main.post {
            val w = wm
            if (orb == null || w == null || !Prefs.captions || (u.isBlank() && r.isBlank())) { removeCaption(); return@post }
            val d = resources.displayMetrics.density
            if (capBox == null) {
                val box = LinearLayout(this)
                box.orientation = LinearLayout.VERTICAL
                box.setPadding((12 * d).toInt(), (8 * d).toInt(), (12 * d).toInt(), (8 * d).toInt())
                val bg = GradientDrawable()
                bg.cornerRadius = 14 * d
                bg.setColor(0xE6140409.toInt())
                bg.setStroke(maxOf(1, (1 * d).toInt()), 0xFFFF2D5A.toInt())
                box.background = bg
                val tu = TextView(this); tu.setTextColor(0xFFFF8FA8.toInt()); tu.textSize = 12f; tu.maxLines = 2
                val tr = TextView(this); tr.setTextColor(Color.WHITE); tr.textSize = 14f; tr.maxLines = 5
                box.addView(tu); box.addView(tr)
                val dm = resources.displayMetrics
                val width = minOf(dm.widthPixels - (24 * d).toInt(), (300 * d).toInt())
                val lp = WindowManager.LayoutParams(width, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT)
                lp.gravity = Gravity.TOP or Gravity.START
                capUserTv = tu; capReplyTv = tr; capLp = lp; capBox = box
                try { w.addView(box, lp) } catch (_: Exception) { capBox = null; return@post }
            }
            capUserTv?.text = if (u.isBlank()) "" else "You: $u"
            capUserTv?.visibility = if (u.isBlank()) View.GONE else View.VISIBLE
            capReplyTv?.text = r
            capReplyTv?.visibility = if (r.isBlank()) View.GONE else View.VISIBLE
            placeCaption()
            main.removeCallbacks(hideCap)
            main.postDelayed(hideCap, minOf(25000L, 6000L + r.length * 60L))
        }
    }

    private fun placeCaption() {
        val box = capBox ?: return
        val lp = capLp ?: return
        val w = wm ?: return
        val dm = resources.displayMetrics
        val d = dm.density
        val width = lp.width
        box.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
        val h = box.measuredHeight
        val ol = orbLp
        val ox = ol?.x ?: (dm.widthPixels - width) / 2
        val oy = ol?.y ?: (200 * d).toInt()
        val os = (64 * d).toInt()
        val margin = (12 * d).toInt()
        var x = ox + os / 2 - width / 2
        x = x.coerceIn(margin, maxOf(margin, dm.widthPixels - width - margin))
        var y = oy + os + (4 * d).toInt()
        if (y + h > dm.heightPixels - (70 * d).toInt()) y = oy - h - (4 * d).toInt()
        lp.x = x; lp.y = maxOf(y, (30 * d).toInt())
        try { w.updateViewLayout(box, lp) } catch (_: Exception) {}
    }

    private fun removeCaption() {
        main.removeCallbacks(hideCap)
        capBox?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        capBox = null; capUserTv = null; capReplyTv = null; capLp = null
    }

    override fun onDestroy() {
        hideOrb(); instance = null
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else @Suppress("DEPRECATION") stopForeground(true)
        super.onDestroy()
    }
}

class OrbView(ctx: Context, private val size: Int) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3f * d; color = 0xFFFF2D5A.toInt() }
    private val logo: BitmapShader = run {
        val o = BitmapFactory.Options().apply { inSampleSize = 4 }
        val b = BitmapFactory.decodeResource(ctx.resources, R.drawable.logo, o)
        BitmapShader(Bitmap.createScaledBitmap(b, size, size, true), Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
    }

    override fun onDraw(c: Canvas) {
        val app = AppHolder.app
        val mode = app?.mode ?: Mode.IDLE
        val t = System.nanoTime() / 1e9
        val pulse = (sin(t * 6) * 0.5 + 0.5).toFloat()
        val cx = size / 2f
        val r = cx - 7f * d
        paint.shader = null; paint.color = 0xFF14040A.toInt(); c.drawCircle(cx, cx, r, paint)
        paint.shader = logo; c.drawCircle(cx, cx, r * 0.92f, paint); paint.shader = null
        when (mode) {
            Mode.LISTEN -> { ring.alpha = 255; c.drawCircle(cx, cx, r + (app?.level ?: 0f) * 5f * d, ring) }
            Mode.SPEAK -> { ring.alpha = 255; c.drawCircle(cx, cx, r + pulse * 4f * d, ring) }
            Mode.THINK -> { ring.alpha = 255; c.drawArc(cx - r, cx - r, cx + r, cx + r, (t * 300 % 360).toFloat(), 110f, false, ring) }
            Mode.IDLE -> { ring.alpha = 110; c.drawCircle(cx, cx, r, ring) }
        }
        postInvalidateOnAnimation()
    }
}
