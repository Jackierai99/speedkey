package com.makimaos.app
import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject

class Msg(val user: Boolean, val text: String, val ts: Long = System.currentTimeMillis(), fav: Boolean = false) {
    var fav by mutableStateOf(fav)
}
enum class Screen { HOME, CHAT, SETTINGS, MEMORY, FAVORITES, HISTORY, PROFILE }
enum class Mode { IDLE, LISTEN, THINK, SPEAK }

class AppState(val ctx: Context) {
    val theme = MakimaTheme
    var screen by mutableStateOf(Screen.HOME)
    val messages = mutableStateListOf<Msg>()
    var listening by mutableStateOf(false)
    var thinking by mutableStateOf(false)
    var handsFree by mutableStateOf(false)
    var pendingHands = false
    var partial by mutableStateOf("")
    var bubble by mutableStateOf("")
    var level by mutableStateOf(0f)
    var mood: String? = null          // set by the AI with {{mood:angry|happy|tease|sad}}; picks her body clip while speaking
    var askMic: () -> Unit = {}
    var askPerms: () -> Unit = {}
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    val mouth = Mouth(ctx, scope)
    private var fails = 0
    private var buf = ""
    // ---- feelings / silence watcher (v2.3)
    @Volatile private var lastActivity = System.currentTimeMillis()   // last time anyone spoke (silence watcher)
    @Volatile private var lastTurn = System.currentTimeMillis()       // end of the last real conversation turn
    @Volatile private var silenceStage = 0
    @Volatile private var proactiveBusy = false
    private var flushJob: Job? = null

    private val ears = Ears(ctx,
        onPartial = { partial = (buf + " " + it).trim(); caption(partial, ""); userSpoke() },
        onFinal = { text ->
            listening = false; fails = 0
            buf = (buf + " " + text).trim(); partial = buf
            userSpoke()
            flushJob?.cancel()
            if (handsFree) {
                // keep listening in case she is still mid-sentence; reply only after a quiet gap (shorter once the sentence is long enough)
                scheduleFlush(waitMs())
                scope.launch { delay(150); if (handsFree && !listening && !thinking && !mouth.speaking) startListening() }
            } else flush()
        },
        onEnd = { code ->
            listening = false
            if (buf.isEmpty()) partial = ""
            if (handsFree) {
                val quiet = code == 6 || code == 7      // normal silence / nothing recognised
                if (quiet) fails = 0 else fails++
                if (buf.isNotEmpty() && flushJob == null) scheduleFlush(waitMs())
                if (code == 9) { disableHandsFree(); bubble = "Mic permission chahiye, Boss."; askMic() }
                else if (fails < 15) scope.launch {
                    // never give up quickly: back off a little on network / busy errors, then keep listening
                    delay(if (quiet) 250L else minOf(900L + fails * 350L, 5000L))
                    if (handsFree && !listening && !thinking && !mouth.speaking) startListening()
                } else { disableHandsFree(); bubble = "Mic me dikkat aa rahi hai, hands-free band kar diya." }
            } else if (buf.isNotEmpty()) flush()
        },
        onLevel = { level = it })

    val mode: Mode get() = when {
        listening -> Mode.LISTEN
        thinking -> Mode.THINK
        mouth.speaking -> Mode.SPEAK
        else -> Mode.IDLE
    }

    init {
        mouth.onDone = {
            if (proactiveBusy) proactiveBusy = false          // her own unprompted line must not restart the silence clock
            else { lastActivity = System.currentTimeMillis(); lastTurn = lastActivity }
            if (handsFree && !listening && !thinking) startListening()
        }
        loadHistory()
        startWatcher()
    }

    private fun waitMs(): Long {
        val words = buf.trim().split(Regex("\\s+")).size
        return (Prefs.waitSec * 1000 * (if (words >= 4) 0.6f else 1f)).toLong()
    }
    private fun userSpoke() { lastActivity = System.currentTimeMillis(); silenceStage = 0 }

    // ------------------------------------------------ she notices when you go quiet (bored -> annoyed -> angry -> sulking)
    private val stageAt = intArrayOf(0, 45, 100, 200, 360, 600)      // seconds of silence for stage 1..5
    private fun startWatcher() {
        scope.launch {
            while (isActive) {
                delay(4000)
                try { watchSilence() } catch (_: Exception) {}
            }
        }
    }
    private fun watchSilence() {
        if (!Prefs.humanMode || !Prefs.proactive || !handsFree || !Prefs.autoSpeak) return
        if (thinking || mouth.speaking || proactiveBusy || screenIsBusy()) return
        if (buf.isNotEmpty() || partial.isNotBlank() || Feelings.quietNow()) return
        val sec = (System.currentTimeMillis() - lastActivity) / 1000
        val next = silenceStage + 1
        if (next > 5 || sec < stageAt[next]) return
        silenceStage = next
        if (sec > stageAt[next] + 120) return          // way overdue (phone slept): skip silently, never nag late
        val stage = next
        scope.launch {
            val ask = withContext(Dispatchers.IO) { Brain.askAlone(Feelings.silencePrompt(stage, maxOf(1, (sec / 60).toInt()))) }
            // she may have been spoken to while the brain was thinking
            if (!handsFree || thinking || mouth.speaking || buf.isNotEmpty() || partial.isNotBlank() || silenceStage != stage) return@launch
            val local = Feelings.localLine(stage)
            val line = ask?.second ?: local.first
            val m = ask?.first ?: local.second
            Feelings.onSilence(stage)
            proactiveBusy = true
            ears.stop(); listening = false
            mood = m
            bubble = line; caption(null, line)
            messages.add(Msg(false, line)); save()
            mouth.speak(line, m ?: Feelings.voiceMood())
        }
    }
    private fun screenIsBusy() = screen == Screen.SETTINGS || screen == Screen.PROFILE

    private fun scheduleFlush(ms: Long) {
        flushJob?.cancel()
        flushJob = scope.launch { delay(ms); flush() }
    }
    private fun flush() {
        // never cut in while she is still speaking
        if (listening && partial.isNotBlank() && partial != buf) { scheduleFlush(600); return }
        val t = buf.trim(); buf = ""; flushJob = null; partial = ""
        if (t.isNotEmpty()) { ears.stop(); listening = false; send(t) }
    }

    // ---------------------------------------------------------------- history
    private fun loadHistory() {
        try {
            val a = JSONArray(Prefs.history)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                messages.add(Msg(o.getBoolean("u"), o.getString("t"), o.optLong("ts"), o.optBoolean("f")))
            }
        } catch (_: Exception) {}
    }
    fun save() {
        if (!Prefs.saveHistory) { Prefs.history = "[]"; return }
        val a = JSONArray()
        messages.takeLast(300).forEach { a.put(JSONObject().put("u", it.user).put("t", it.text).put("ts", it.ts).put("f", it.fav)) }
        Prefs.history = a.toString()
    }
    fun clearHistory() { messages.clear(); save() }
    fun toggleFav(m: Msg) { m.fav = !m.fav; save() }

    // ------------------------------------------------------------------ voice
    fun say(t: String, m: String? = null) { bubble = t; mouth.speak(t, m) }
    fun sampleVoice() = say("Main Makima hoon, ${Prefs.userName}. Ab se meri awaaz yehi hogi.")

    private fun hasMic() = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    fun toggleListen() {
        if (listening) { ears.stop(); listening = false; return }
        startListening()
    }
    fun startListening() {
        if (!hasMic()) { askMic(); return }
        mouth.stop(); listening = true; ears.start()
        Brain.warm()
    }

    // ------------------------------------------- always-listening (hands-free)
    fun toggleHandsFree() { if (handsFree) disableHandsFree() else requestHandsFree() }
    fun requestHandsFree() {
        if (!hasMic()) { pendingHands = true; askMic(); return }
        enableHandsFree()
    }
    fun enableHandsFree() {
        handsFree = true; fails = 0; buf = ""
        try { ContextCompat.startForegroundService(ctx, Intent(ctx, OverlayService::class.java)) } catch (_: Exception) {}
        val now = System.currentTimeMillis()
        val gapH = if (Prefs.lastSeen > 0) (now - Prefs.lastSeen) / 3600000 else 0L
        Prefs.lastSeen = now; lastActivity = now; silenceStage = 0
        val gr = if (Prefs.humanMode && Prefs.autoSpeak && !Feelings.quietNow()) Feelings.greeting(gapH, Prefs.userName) else null
        bubble = if (Settings.canDrawOverlays(ctx)) "Main sun rahi hoon, ${Prefs.userName}. Bolo."
                 else "Main sun rahi hoon. Bahar bubble ke liye Settings me Floating bubble permission do."
        if (gr != null) {
            // she greets you first like a person would; the mic opens by itself when she finishes
            proactiveBusy = true; mood = gr.second; bubble = gr.first
            mouth.speak(gr.first, gr.second)
        } else startListening()
    }
    fun disableHandsFree() {
        handsFree = false; flushJob?.cancel(); flushJob = null; buf = ""; partial = ""
        ears.stop(); listening = false
        try { ctx.stopService(Intent(ctx, OverlayService::class.java)) } catch (_: Exception) {}
        bubble = "Hands-free band."
    }

    // ------------------------------------------------------------------- chat
    private var capUser = ""
    private var capReply = ""
    /** Small subtitle shown under the floating Makima bubble while another app is open. */
    fun caption(u: String?, r: String?) {
        if (u != null) capUser = u
        if (r != null) capReply = r
        OverlayService.instance?.setCaption(capUser, capReply)
    }

    private val stopWords = setOf("stop", "ruko", "ruk jao", "ruk ja", "chup", "chup ho jao", "chup raho", "cancel", "band karo", "bas", "bas karo",
        "रुको", "रुक जाओ", "चुप", "चुप हो जाओ", "बस", "बस करो")

    private fun finishLocal(reply: String) {
        bubble = reply; caption(null, reply)
        messages.add(Msg(false, reply)); thinking = false; save()
        if (Prefs.autoSpeak) say(reply) else { bubble = reply; if (handsFree) startListening() }
    }

    fun send(text: String) {
        if (text.isBlank()) return
        val now = System.currentTimeMillis()
        val gap = (now - lastTurn) / 1000
        proactiveBusy = false; silenceStage = 0; lastActivity = now; Prefs.lastSeen = now
        if (Prefs.humanMode) Feelings.onUser(text, gap)
        messages.add(Msg(true, text)); thinking = true; bubble = ""
        mood = if (Prefs.humanMode) Feelings.voiceMood() else null      // her current feeling; the AI can override it with a {{mood:..}} tag
        caption(text, "")
        scope.launch {
            val low = text.lowercase().trim().trimEnd('.', '!', ' ')
            if (low in stopWords) { mouth.stop(); finishLocal("Theek hai, ruk gayi."); return@launch }
            val local = if (Prefs.phoneControl) (try { withContext(Dispatchers.IO) { Cmd.tryHandle(ctx, text) } } catch (e: Exception) { "Boss, command me error: ${e.message}" }) else null
            if (local != null) { finishLocal(local); return@launch }

            val speak = Prefs.autoSpeak
            val agent = Prefs.phoneControl
            var hist = messages.takeLast(Prefs.ctxTurns.coerceIn(2, 40)).map { (if (it.user) "user" else "model") to it.text }
                .dropWhile { it.first != "user" }
            if (speak) mouth.startStream()
            val said = StringBuilder()
            var failText: String? = null

            withContext(Dispatchers.IO) {
                fun emit(c: String) {
                    if (c.isBlank()) return
                    said.append(' ').append(c)
                    val shown = said.toString().trim()
                    scope.launch { thinking = false; bubble = shown; caption(null, shown) }
                    if (speak) mouth.feed(c, mood)
                }
                var step = 0
                while (step < 8) {
                    step++
                    val flt = Agent.Filter(ctx)
                    val st = Feelings.Stripper { m -> mood = m }
                    var got = false
                    val reply = try {
                        Brain.askStream(hist) { s ->
                            got = true
                            emit(if (agent) flt.feed(s) else st.feed(s))
                        }
                    } catch (e: Exception) { "Boss, error: ${Brain.nice(e)}" }
                    emit(if (agent) flt.finish() else st.finish())
                    if (!got) { failText = reply; break }
                    val obs = if (agent) flt.observations() else emptyList()
                    if (obs.isNotEmpty()) {
                        // the AI asked to see the screen / an action failed: give it the result and let it continue
                        hist = hist + ("model" to reply) + ("user" to ("[PHONE RESULT]\n" + obs.joinToString("\n")))
                        continue
                    }
                    break
                }
            }

            var finalText = said.toString().trim()
            val ft = failText
            if (ft != null) { finalText = ft; if (speak) mouth.feed(ft, null) }
            else if (finalText.isEmpty()) { finalText = "Ho gaya, ${Prefs.userName}."; if (speak) mouth.feed(finalText, mood) }
            bubble = finalText; caption(null, finalText)
            if (speak) mouth.endStream()
            messages.add(Msg(false, finalText)); thinking = false; save()
            if (!speak && handsFree) startListening()
        }
    }

    fun pause() { if (handsFree) disableHandsFree(); ears.stop(); listening = false; mouth.stop() }
    fun release() {
        ears.stop(); mouth.release(); scope.cancel()
        try { ctx.stopService(Intent(ctx, OverlayService::class.java)) } catch (_: Exception) {}
    }
}
