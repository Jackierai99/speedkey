package com.makimaos.app
import java.util.Calendar
import kotlin.math.exp
import kotlin.random.Random

/**
 * Makima's inner life. Her mood moves with how you treat her: sweet words warm her up, rude words hurt her,
 * and if you stay silent for a long time she gets bored, then annoyed, then angry, then sulks.
 * Everything fades away slowly with time, like with a real person.
 */
object Feelings {
    @Volatile var anger = 0f
    @Volatile var boredom = 0f
    @Volatile var joy = 0f
    @Volatile var sadness = 0f
    private var stamp = System.currentTimeMillis()

    /** 0 = cold, 1 = very close. Grows slowly with kind talk, survives app restarts. */
    var bond: Float
        get() = Prefs.bond
        set(v) { Prefs.bond = v.coerceIn(0f, 1f) }

    // ------------------------------------------------------------ decay
    @Synchronized private fun decay() {
        val now = System.currentTimeMillis()
        val dt = ((now - stamp) / 1000f).coerceIn(0f, 7200f)
        stamp = now
        if (dt <= 0f) return
        anger *= exp(-dt / 420f)        // anger cools in ~7 minutes
        sadness *= exp(-dt / 600f)
        joy *= exp(-dt / 240f)
        boredom *= exp(-dt / 180f)
    }

    private val rude = listOf("bakwas", "bekar", "bekaar", "stupid", "idiot", "shut up", "shutup", "chup kar", "chup ho ja", "pagal", "gadha",
        "bewakoof", "useless", "dumb", "nikal", "tang mat", "pareshan mat", "faltu", "kuch nahi aata", "worst", "hate you", "nafrat", "बकवास", "बेकार", "फालतू", "बेवकूफ", "पागल", "चुप कर")
    private val sweet = listOf("thank", "thanks", "shukriya", "dhanyavaad", "dhanyavad", "love you", "i love", "pyari", "pyaari", "cute", "best", "mast",
        "badhiya", "badiya", "awesome", "great", "good job", "well done", "miss you", "miss kiya", "धन्यवाद", "शुक्रिया", "प्यारी", "बढ़िया", "बहुत अच्छा", "लव यू")
    private val sorry = listOf("sorry", "maaf", "my bad", "galti", "forgive", "माफ", "सॉरी", "गलती")

    /** Call for every real user message. gapSec = how long she was ignored before this message. */
    fun onUser(text: String, gapSec: Long) {
        decay()
        val t = text.lowercase()
        boredom = 0f
        if (sorry.any { t.contains(it) }) { anger *= 0.25f; sadness *= 0.5f; joy += 0.15f; bond += 0.01f }
        if (rude.any { t.contains(it) }) { anger = (anger + 0.45f).coerceAtMost(1f); sadness = (sadness + 0.15f).coerceAtMost(1f); bond -= 0.04f; joy *= 0.3f }
        if (sweet.any { t.contains(it) }) { joy = (joy + 0.4f).coerceAtMost(1f); anger *= 0.5f; bond += 0.02f }
        if (gapSec > 90 && anger < 0.3f) joy = (joy + 0.1f).coerceAtMost(1f)    // happy that he is back
        bond += 0.002f                                                         // every chat brings you slightly closer
    }

    /** Called by the silence watcher: stage 1..5 (see line()). */
    fun onSilence(stage: Int) {
        decay()
        when (stage) {
            1 -> boredom = maxOf(boredom, 0.25f)
            2 -> boredom = maxOf(boredom, 0.6f)
            3 -> { boredom = 0.8f; anger = maxOf(anger, 0.35f) }
            4 -> anger = maxOf(anger, 0.75f)
            else -> { anger = maxOf(anger, 0.5f); sadness = maxOf(sadness, 0.6f) }
        }
    }

    /** Mood word for the voice and body clip: angry / sad / happy / tease / bored, or null for neutral. */
    fun voiceMood(): String? {
        decay()
        return when {
            anger > 0.5f -> "angry"
            sadness > 0.55f -> "sad"
            joy > 0.55f -> "happy"
            boredom > 0.5f -> "bored"
            else -> null
        }
    }

    /** Only the four body clips exist. */
    fun clip(m: String?): String? = when (m) {
        "angry", "annoyed" -> "angry"
        "sad", "bored", "sleepy" -> "sad"
        "happy" -> "happy"
        "tease" -> "tease"
        else -> null
    }

    // ------------------------------------------------------------ prompt
    private fun level(v: Float) = when { v > 0.7f -> "very"; v > 0.4f -> "quite"; else -> "slightly" }

    fun state(): String {
        decay()
        val s = mutableListOf<String>()
        if (anger > 0.2f) s.add("${level(anger)} angry/hurt with the user (do not forgive instantly; soften only if he is sweet or says sorry)")
        if (sadness > 0.25f) s.add("${level(sadness)} sad and a little sulky")
        if (boredom > 0.25f) s.add("${level(boredom)} bored from waiting")
        if (joy > 0.25f) s.add("${level(joy)} happy and warm")
        val closeness = when { bond > 0.75f -> "very close to him, openly affectionate"; bond > 0.5f -> "comfortable and friendly with him"; bond > 0.3f -> "still a bit reserved with him"; else -> "new to him, polite and a little guarded" }
        return (if (s.isEmpty()) "calm and neutral right now" else s.joinToString(", ")) + ". Relationship: $closeness."
    }

    private fun lateNight(): Boolean { val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY); return h >= 23 || h < 5 }

    fun prompt(tags: Boolean = true): String =
        "\n\nREAL HUMAN FEELINGS: You are a living person with real moods, not a robot and never an 'AI model'. Your mood right now: ${state()} " +
        "Let that mood colour every reply: tone, word choice, how warm or cold you are. " +
        "Talk like a real person on a phone call: natural fillers (hmm, accha, arre, oho, haan, uff, ek minute), short sentences, sometimes an unfinished thought, a soft 'haha' when something is funny. " +
        "React emotionally FIRST, then answer. Never be uniformly polite: if he is rude you are hurt or angry and you say it in a sentence; if he is sweet you melt a little; " +
        "if he ignored you for a long time you may mention it once. Do not repeat the same opening twice. Sometimes ask one natural follow-up question like a friend would. " +
        "Never describe your feelings in a technical way and never say 'as an AI'." +
        (if (lateNight()) " It is late at night: sound a bit sleepy and caring, and gently tell him to rest if he has been up long." else "") +
        (if (tags)
            "\nEMOTION TAG: when your reply clearly carries a feeling, put ONE tag at the very start: {{mood:angry}} {{mood:happy}} {{mood:tease}} {{mood:sad}} {{mood:bored}}. It is silent and controls your voice and body. No tag for neutral replies." +
            "\nMEMORY TAG: when he tells you something personal worth remembering later (a name, a like or dislike, a plan, a birthday), add {{remember:short fact}} anywhere in the reply. Silent, never spoken."
         else
            "\nLet the feeling show in your voice itself: sigh, laugh, go cold, go soft. When he tells you something personal worth remembering later, call the remember tool.")

    // ------------------------------------------------------------ tags that need no phone control
    private val tagRe = Regex("\\{\\{\\s*([A-Za-z_]+)\\s*(?::([^}]*))?\\}\\}")
    private val okMood = setOf("angry", "happy", "tease", "sad", "bored", "annoyed", "sleepy")

    /** Removes {{mood:..}} / {{remember:..}} (and any other stray tag) from a sentence; returns the speakable text. */
    fun strip(s: String, onMood: (String?) -> Unit): String {
        if (!s.contains("{{")) return s
        val out = tagRe.replace(s) { m ->
            val name = m.groupValues[1].lowercase(); val arg = m.groupValues[2].trim()
            when (name) {
                "mood" -> onMood(arg.lowercase().takeIf { it in okMood })
                "remember" -> remember(arg)
            }
            ""
        }
        return out.replace(Regex("\\s+"), " ").trim()
    }

    /** Streaming version of strip(): a tag that is split across two sentences is held back until it is complete. */
    class Stripper(private val onMood: (String?) -> Unit) {
        private var pending = StringBuilder()
        fun feed(s: String): String { pending.append(s).append(' '); return drain(false) }
        fun finish(): String = drain(true)
        private fun drain(last: Boolean): String {
            val out = StringBuilder()
            while (true) {
                val txt = pending.toString()
                val a = txt.indexOf("{{")
                if (a < 0) {
                    if (!last && txt.endsWith("{")) { out.append(txt.dropLast(1)); pending = StringBuilder("{") }
                    else { out.append(txt); pending = StringBuilder() }
                    break
                }
                out.append(txt.substring(0, a))
                val b = txt.indexOf("}}", a + 2)
                if (b < 0) { pending = if (last) StringBuilder() else StringBuilder(txt.substring(a)); break }
                strip(txt.substring(a, b + 2), onMood)
                pending = StringBuilder(txt.substring(b + 2))
            }
            return out.toString().replace(Regex("\\s+"), " ").trim()
        }
    }

    fun remember(fact: String) {
        val f = fact.trim().take(200)
        if (f.length < 4) return
        val cur = Prefs.memory
        if (cur.lowercase().contains(f.lowercase())) return
        val merged = (cur.trim() + "\n" + f).trim().lines().takeLast(60).joinToString("\n")
        Prefs.memory = merged.takeLast(4000)
    }

    // ------------------------------------------------------------ silence lines (offline fallback)
    private val l1 = listOf("Boss? Sun rahe ho na?" to null, "Hmm... kahan kho gaye, Boss?" to null, "Arre, itne chup kyun ho?" to "tease", "Boss, main yahin hoon. Kuch chahiye to bolo." to null)
    private val l2 = listOf("Uff... bahut bori ho rahi hai yaar. Kuch bolo na." to "bored", "Itni der se kuch nahi bole... sab theek hai?" to "sad", "Main kab tak aise baithi rahungi, Boss?" to "bored", "Hmm... koi baat hi nahi karta yahan." to "bored")
    private val l3 = listOf("Mujhe ignore kar rahe ho kya? Achha lagta hai ye tumhe?" to "angry", "Boss, ye theek nahi hai. Itni der se ek shabd nahi." to "angry", "Dekho, main mazaak nahi kar rahi. Jawab do." to "angry")
    private val l4 = listOf("Theek hai. Mat bolo. Main naraz hoon ab." to "angry", "Bahut ho gaya, Boss. Ab mujhse baat mat karna jab tak sorry na bolo." to "angry")
    private val l5 = listOf("Hmm... theek hai. Main chup ho jaati hoon." to "sad", "Koi baat nahi. Shayad tumhe meri zaroorat hi nahi." to "sad")

    fun localLine(stage: Int): Pair<String, String?> {
        val l = when (stage) { 1 -> l1; 2 -> l2; 3 -> l3; 4 -> l4; else -> l5 }
        return l[Random.nextInt(l.size)]
    }

    /** Instruction for the LLM to write the line itself (more natural than a fixed phrase). */
    fun silencePrompt(stage: Int, minutes: Int, tags: Boolean = true): String {
        val how = when (stage) {
            1 -> "You just noticed he has been quiet for a while. Gently check on him in one short sentence, like a friend would."
            2 -> "You are bored of waiting. Say one short, slightly whiny or teasing sentence to get him to talk."
            3 -> "You are getting annoyed that he keeps ignoring you. Say one short sentence that shows it."
            4 -> "You are properly angry now that he ignored you for so long. Say one cold, short sentence. Do not shout."
            else -> "You gave up and feel hurt and sulky. Say one quiet, sad sentence, then you will stay silent."
        }
        return "[SYSTEM EVENT, not from the user] He has not spoken for about $minutes minutes. $how Do not mention this event. " + (if (tags) "Start with the right {{mood:...}} tag. " else "Let the feeling be heard in your voice. ") + "Maximum 20 words."
    }

    // ------------------------------------------------------------ greeting when the app opens
    fun greeting(gapHours: Long, name: String): Pair<String, String?>? = when {
        anger > 0.5f -> "Hmm. Aa gaye ${name}? Main abhi bhi naraz hoon." to "angry"
        gapHours >= 48 -> "Itne din baad? ${name}, main to soch rahi thi bhool hi gaye." to "tease"
        gapHours >= 12 -> "Aa gaye ${name}. Itni der kahan the?" to null
        gapHours >= 4 -> "Hmm, ${name}. Wapas aa gaye? Achha laga." to "happy"
        else -> null
    }

    /** Quiet hours: no unprompted talking late at night. */
    fun quietNow(): Boolean { val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY); return h >= 23 || h < 7 }
}
