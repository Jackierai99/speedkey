package com.makimaos.app

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material.icons.sharp.*
import androidx.compose.material.icons.twotone.*
import androidx.compose.ui.graphics.vector.ImageVector

/** Every icon in the app goes through here, so the chosen Style Pack restyles all of them at once. */
object PackIcons {
    val Add: ImageVector get() = when (Packs.index) { 1 -> Icons.Outlined.Add; 2 -> Icons.Rounded.Add; 3 -> Icons.Sharp.Add; 4 -> Icons.TwoTone.Add; else -> Icons.Filled.Add }
    val Apps: ImageVector get() = when (Packs.index) { 1 -> Icons.Outlined.Apps; 2 -> Icons.Rounded.Apps; 3 -> Icons.Sharp.Apps; 4 -> Icons.TwoTone.Apps; else -> Icons.Filled.Apps }
    val ArrowBack: ImageVector get() = when (Packs.index) { 1 -> Icons.Outlined.ArrowBack; 2 -> Icons.Rounded.ArrowBack; 3 -> Icons.Sharp.ArrowBack; 4 -> Icons.TwoTone.ArrowBack; else -> Icons.Filled.ArrowBack }
    val Bluetooth: ImageVector get() = when (Packs.index) { 1 -> Icons.Outlined.Bluetooth; 2 -> Icons.Rounded.Bluetooth; 3 -> Icons.Sharp.Bluetooth; 4 -> Icons.TwoTone.Bluetooth; else -> Icons.Filled.Bluetooth }
    val ChatBubbleOutline: ImageVector get() = when (Packs.index) { 1 -> Icons.Outlined.ChatBubbleOutline; 2 -> Icons.Rounded.ChatBubbleOutline; 3 -> Icons.Sharp.ChatBubbleOutline; 4 -> Icons.TwoTone.ChatBubbleOutline; else -> Icons.Filled.ChatBubbleOutline }
    val Check: ImageVector get() = when (Packs.index) { 1 -> Icons.Outlined.Check; 2 -> Icons.Rounded.Check; 3 -> Icons.Sharp.Check; 4 -> Icons.TwoTone.Check; else -> Icons.Filled.Check }
    val CheckCircle: ImageVector get() = when (Packs.index) { 1 -> Icons.Outlined.CheckCircle; 2 -> Icons.Rounded.CheckCircle; 3 -> Icons.Sharp.CheckCircle; 4 -> Icons.TwoTone.CheckCircle; else -> Icons.Filled.CheckCircle }
    val ChevronRight: ImageVector get() = when (Packs.index) { 1 -> Icons.Outlined.ChevronRight; 2 -> Icons.Rounded.ChevronRight; 3 -> Icons.Sharp.ChevronRight; 4 -> Icons.TwoTone.ChevronRight; else -> Icons.Filled.ChevronRight }
    val Delete: ImageVector get() = when (Packs.index) { 1 -> Icons.Outlined.Delete; 2 -> Icons.Rounded.Delete; 3 -> Icons.Sharp.Delete; 4 -> Icons.TwoTone.Delete; else -> Icons.Filled.Delete }
    val Edit: ImageVector get() = when (Packs.index) { 1 -> Icons.Outlined.Edit; 2 -> Icons.Rounded.Edit; 3 -> Icons.Sharp.Edit; 4 -> Icons.TwoTone.Edit; else -> Icons.Filled.Edit }
    val Favorite: ImageVector get() = when (Packs.index) { 1 -> Icons.Outlined.Favorite; 2 -> Icons.Rounded.Favorite; 3 -> Icons.Sharp.Favorite; 4 -> Icons.TwoTone.Favorite; else -> Icons.Filled.Favorite }
    val FlashOff: ImageVector get() = when (Packs.index) { 1 -> Icons.Outlined.FlashOff; 2 -> Icons.Rounded.FlashOff; 3 -> Icons.Sharp.FlashOff; 4 -> Icons.TwoTone.FlashOff; else -> Icons.Filled.FlashOff }
    val FlashOn: ImageVector get() = when (Packs.index) { 1 -> Icons.Outlined.FlashOn; 2 -> Icons.Rounded.FlashOn; 3 -> Icons.Sharp.FlashOn; 4 -> Icons.TwoTone.FlashOn; else -> Icons.Filled.FlashOn }
    val GraphicEq: ImageVector get() = when (Packs.index) { 1 -> Icons.Outlined.GraphicEq; 2 -> Icons.Rounded.GraphicEq; 3 -> Icons.Sharp.GraphicEq; 4 -> Icons.TwoTone.GraphicEq; else -> Icons.Filled.GraphicEq }
    val History: ImageVector get() = when (Packs.index) { 1 -> Icons.Outlined.History; 2 -> Icons.Rounded.History; 3 -> Icons.Sharp.History; 4 -> Icons.TwoTone.History; else -> Icons.Filled.History }
    val Home: ImageVector get() = when (Packs.index) { 1 -> Icons.Outlined.Home; 2 -> Icons.Rounded.Home; 3 -> Icons.Sharp.Home; 4 -> Icons.TwoTone.Home; else -> Icons.Filled.Home }
    val Lock: ImageVector get() = when (Packs.index) { 1 -> Icons.Outlined.Lock; 2 -> Icons.Rounded.Lock; 3 -> Icons.Sharp.Lock; 4 -> Icons.TwoTone.Lock; else -> Icons.Filled.Lock }
    val Mic: ImageVector get() = when (Packs.index) { 1 -> Icons.Outlined.Mic; 2 -> Icons.Rounded.Mic; 3 -> Icons.Sharp.Mic; 4 -> Icons.TwoTone.Mic; else -> Icons.Filled.Mic }
    val Notifications: ImageVector get() = when (Packs.index) { 1 -> Icons.Outlined.Notifications; 2 -> Icons.Rounded.Notifications; 3 -> Icons.Sharp.Notifications; 4 -> Icons.TwoTone.Notifications; else -> Icons.Filled.Notifications }
    val Person: ImageVector get() = when (Packs.index) { 1 -> Icons.Outlined.Person; 2 -> Icons.Rounded.Person; 3 -> Icons.Sharp.Person; 4 -> Icons.TwoTone.Person; else -> Icons.Filled.Person }
    val PhotoCamera: ImageVector get() = when (Packs.index) { 1 -> Icons.Outlined.PhotoCamera; 2 -> Icons.Rounded.PhotoCamera; 3 -> Icons.Sharp.PhotoCamera; 4 -> Icons.TwoTone.PhotoCamera; else -> Icons.Filled.PhotoCamera }
    val PlayArrow: ImageVector get() = when (Packs.index) { 1 -> Icons.Outlined.PlayArrow; 2 -> Icons.Rounded.PlayArrow; 3 -> Icons.Sharp.PlayArrow; 4 -> Icons.TwoTone.PlayArrow; else -> Icons.Filled.PlayArrow }
    val RecordVoiceOver: ImageVector get() = when (Packs.index) { 1 -> Icons.Outlined.RecordVoiceOver; 2 -> Icons.Rounded.RecordVoiceOver; 3 -> Icons.Sharp.RecordVoiceOver; 4 -> Icons.TwoTone.RecordVoiceOver; else -> Icons.Filled.RecordVoiceOver }
    val Refresh: ImageVector get() = when (Packs.index) { 1 -> Icons.Outlined.Refresh; 2 -> Icons.Rounded.Refresh; 3 -> Icons.Sharp.Refresh; 4 -> Icons.TwoTone.Refresh; else -> Icons.Filled.Refresh }
    val Send: ImageVector get() = when (Packs.index) { 1 -> Icons.Outlined.Send; 2 -> Icons.Rounded.Send; 3 -> Icons.Sharp.Send; 4 -> Icons.TwoTone.Send; else -> Icons.Filled.Send }
    val Settings: ImageVector get() = when (Packs.index) { 1 -> Icons.Outlined.Settings; 2 -> Icons.Rounded.Settings; 3 -> Icons.Sharp.Settings; 4 -> Icons.TwoTone.Settings; else -> Icons.Filled.Settings }
    val Share: ImageVector get() = when (Packs.index) { 1 -> Icons.Outlined.Share; 2 -> Icons.Rounded.Share; 3 -> Icons.Sharp.Share; 4 -> Icons.TwoTone.Share; else -> Icons.Filled.Share }
    val SkipNext: ImageVector get() = when (Packs.index) { 1 -> Icons.Outlined.SkipNext; 2 -> Icons.Rounded.SkipNext; 3 -> Icons.Sharp.SkipNext; 4 -> Icons.TwoTone.SkipNext; else -> Icons.Filled.SkipNext }
    val Star: ImageVector get() = when (Packs.index) { 1 -> Icons.Outlined.Star; 2 -> Icons.Rounded.Star; 3 -> Icons.Sharp.Star; 4 -> Icons.TwoTone.Star; else -> Icons.Filled.Star }
    val StarBorder: ImageVector get() = when (Packs.index) { 1 -> Icons.Outlined.StarBorder; 2 -> Icons.Rounded.StarBorder; 3 -> Icons.Sharp.StarBorder; 4 -> Icons.TwoTone.StarBorder; else -> Icons.Filled.StarBorder }
    val Tune: ImageVector get() = when (Packs.index) { 1 -> Icons.Outlined.Tune; 2 -> Icons.Rounded.Tune; 3 -> Icons.Sharp.Tune; 4 -> Icons.TwoTone.Tune; else -> Icons.Filled.Tune }
    val Visibility: ImageVector get() = when (Packs.index) { 1 -> Icons.Outlined.Visibility; 2 -> Icons.Rounded.Visibility; 3 -> Icons.Sharp.Visibility; 4 -> Icons.TwoTone.Visibility; else -> Icons.Filled.Visibility }
    val VolumeDown: ImageVector get() = when (Packs.index) { 1 -> Icons.Outlined.VolumeDown; 2 -> Icons.Rounded.VolumeDown; 3 -> Icons.Sharp.VolumeDown; 4 -> Icons.TwoTone.VolumeDown; else -> Icons.Filled.VolumeDown }
    val VolumeOff: ImageVector get() = when (Packs.index) { 1 -> Icons.Outlined.VolumeOff; 2 -> Icons.Rounded.VolumeOff; 3 -> Icons.Sharp.VolumeOff; 4 -> Icons.TwoTone.VolumeOff; else -> Icons.Filled.VolumeOff }
    val VolumeUp: ImageVector get() = when (Packs.index) { 1 -> Icons.Outlined.VolumeUp; 2 -> Icons.Rounded.VolumeUp; 3 -> Icons.Sharp.VolumeUp; 4 -> Icons.TwoTone.VolumeUp; else -> Icons.Filled.VolumeUp }
    val VpnKey: ImageVector get() = when (Packs.index) { 1 -> Icons.Outlined.VpnKey; 2 -> Icons.Rounded.VpnKey; 3 -> Icons.Sharp.VpnKey; 4 -> Icons.TwoTone.VpnKey; else -> Icons.Filled.VpnKey }
    val Wifi: ImageVector get() = when (Packs.index) { 1 -> Icons.Outlined.Wifi; 2 -> Icons.Rounded.Wifi; 3 -> Icons.Sharp.Wifi; 4 -> Icons.TwoTone.Wifi; else -> Icons.Filled.Wifi }
    val Call: ImageVector get() = when (Packs.index) { 1 -> Icons.Outlined.Call; 2 -> Icons.Rounded.Call; 3 -> Icons.Sharp.Call; 4 -> Icons.TwoTone.Call; else -> Icons.Filled.Call }
}
