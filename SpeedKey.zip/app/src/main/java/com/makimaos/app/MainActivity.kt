package com.makimaos.app
import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.core.view.WindowCompat
import kotlinx.coroutines.delay

enum class Stage { SPLASH, MANUAL, GATE, ADMIN, LOCK, APP }

class MainActivity : ComponentActivity() {
    private var app: AppState? = null
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val a = AppHolder.get(applicationContext); app = a
        setContent {
            val mic = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
                if (ok) { WakeService.start(applicationContext); if (a.pendingHands) { a.pendingHands = false; a.enableHandsFree() } else a.startListening() }
                else a.pendingHands = false
            }
            val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
            LaunchedEffect(Unit) {
                a.askMic = { mic.launch(Manifest.permission.RECORD_AUDIO) }
                a.askPerms = {
                    val l = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE)
                    if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
                    perms.launch(l.toTypedArray())
                }
            }
            var stage by remember { mutableStateOf(Stage.SPLASH) }
            // while the app is open: re-verify the license; the moment it runs out (trial end / key expired / revoked) go back to the gate
            LaunchedEffect(stage) {
                if (stage != Stage.APP) return@LaunchedEffect
                if (!AppHolder.autoStarted) {
                    AppHolder.autoStarted = true
                    if (Prefs.autoHands && !a.handsFree) a.requestHandsFree()
                }
                var tick = 0
                while (true) {
                    if (!License.isActive() || (tick % 20 == 19 && !License.recheck(applicationContext))) {
                        a.pause(); a.screen = Screen.HOME; stage = Stage.GATE; break
                    }
                    tick++; delay(3000)
                }
            }
            // sleep timer: hands-free switches itself off after the chosen time
            LaunchedEffect(a.handsFree) {
                if (a.handsFree && Prefs.sleepMin > 0) {
                    delay(Prefs.sleepMin * 60_000L)
                    if (a.handsFree) { a.disableHandsFree(); a.bubble = "Sleep timer khatam, main so rahi hoon." }
                }
            }
            // "Hey Makima" heard in the background -> open hands-free as soon as the app is unlocked and ready
            LaunchedEffect(AppHolder.wakePending, stage) {
                if (AppHolder.wakePending && stage == Stage.APP) {
                    AppHolder.wakePending = false
                    if (System.currentTimeMillis() - AppHolder.wakeAt < 30_000L) { a.screen = Screen.HOME; if (!a.handsFree) a.requestHandsFree() }
                }
            }
            BackHandler(stage == Stage.APP && a.screen != Screen.HOME) { a.screen = Screen.HOME }
            BackHandler(stage == Stage.ADMIN) { stage = Stage.GATE }
            when (stage) {
                Stage.SPLASH -> SplashScreen {
                    stage = if (License.isActive()) (if (Prefs.pinHash.isNotEmpty()) Stage.LOCK else Stage.APP) else if (!Prefs.onboarded) Stage.MANUAL else Stage.GATE
                }
                Stage.MANUAL -> ManualScreen { Prefs.onboarded = true; stage = Stage.GATE }
                Stage.GATE -> GateScreen(onEnter = { stage = Stage.APP }, onAdmin = { stage = Stage.ADMIN })
                Stage.ADMIN -> AdminScreen(onBack = { stage = Stage.GATE }, onEnter = { stage = Stage.APP })
                Stage.LOCK -> LockScreen(onUnlock = { stage = Stage.APP }, onForgot = { Prefs.pinHash = ""; License.logout(); stage = Stage.GATE })
                Stage.APP -> AppContent(a)
            }
        }
    }

    @Composable
    private fun AppContent(a: AppState) {
        run {
            when (a.screen) {
                Screen.HOME -> HomeScreen(a)
                Screen.CHAT -> ChatScreen(a)
                Screen.SETTINGS -> SettingsScreen(a)
                Screen.MEMORY -> MemoryScreen(a)
                Screen.FAVORITES -> FavoritesScreen(a)
                Screen.HISTORY -> HistoryScreen(a)
                Screen.PROFILE -> ProfileScreen(a)
                Screen.KEYS -> KeysPanelScreen(onBack = { a.screen = Screen.HOME })
                Screen.TOOLS -> ToolsScreen(a)
                Screen.NOTES -> NotesScreen(a)
            }
        }
    }
    override fun onStart() {
        super.onStart(); AppHolder.fg = true; Agent.refreshApps(); OverlayService.instance?.hideOrb()
        if (License.isActive()) { WakeService.start(applicationContext); app?.prewarmLive() }
    }
    override fun onStop() {
        AppHolder.fg = false
        val svc = OverlayService.instance
        if (app?.handsFree == true && svc != null) svc.showOrb() else app?.pause()
        super.onStop()
    }
    override fun onDestroy() {
        if (isFinishing && app?.handsFree != true) { app?.release(); AppHolder.app = null }
        super.onDestroy()
    }
}
