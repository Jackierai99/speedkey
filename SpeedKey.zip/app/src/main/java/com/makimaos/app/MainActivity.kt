package com.makimaos.app
import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.core.view.WindowCompat

class MainActivity : ComponentActivity() {
    private var app: AppState? = null
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val a = AppHolder.get(applicationContext); app = a
        setContent {
            val mic = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
                if (ok) { if (a.pendingHands) { a.pendingHands = false; a.enableHandsFree() } else a.startListening() }
                else a.pendingHands = false
            }
            val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
            LaunchedEffect(Unit) {
                a.askMic = { mic.launch(Manifest.permission.RECORD_AUDIO) }
                a.askPerms = {
                    val l = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE)
                    if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
                    perms.launch(l.toTypedArray())
                }
                if (!AppHolder.autoStarted) {
                    AppHolder.autoStarted = true
                    if (Prefs.autoHands && !a.handsFree) a.requestHandsFree()
                }
            }
            BackHandler(a.screen != Screen.HOME) { a.screen = Screen.HOME }
            when (a.screen) {
                Screen.HOME -> HomeScreen(a)
                Screen.CHAT -> ChatScreen(a)
                Screen.SETTINGS -> SettingsScreen(a)
                Screen.MEMORY -> MemoryScreen(a)
                Screen.FAVORITES -> FavoritesScreen(a)
                Screen.HISTORY -> HistoryScreen(a)
                Screen.PROFILE -> ProfileScreen(a)
            }
        }
    }
    override fun onStart() { super.onStart(); Agent.refreshApps(); OverlayService.instance?.hideOrb() }
    override fun onStop() {
        val svc = OverlayService.instance
        if (app?.handsFree == true && svc != null) svc.showOrb() else app?.pause()
        super.onStop()
    }
    override fun onDestroy() {
        if (isFinishing && app?.handsFree != true) { app?.release(); AppHolder.app = null }
        super.onDestroy()
    }
}
