package com.makimaos.app

/** Built-in Gemini key so end users never have to enter one. Stored scrambled (not plain text); decoded at runtime. */
object Secrets {
    private const val G = "1b0b741b386208146c16350f6d6837032a056b393f1737322f173b000e0939296e232e2c08230b2320303918690b6938172f6b772d"
    fun gemini(): String {
        val b = ByteArray(G.length / 2) { i -> (G.substring(i * 2, i * 2 + 2).toInt(16) xor 0x5A).toByte() }
        return String(b, Charsets.UTF_8)
    }
}
