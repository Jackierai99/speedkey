package com.makimaos.app

/** Built-in Gemini key so end users never have to enter one. Stored scrambled (not plain text); decoded at runtime. */
object Secrets {
    private const val G = "1b0b741b386208146c102a2f2c31162b3e156313136d230c1014623309301329346e3c202929626c3612682a3f0811112832156e2d"
    fun gemini(): String {
        val b = ByteArray(G.length / 2) { i -> (G.substring(i * 2, i * 2 + 2).toInt(16) xor 0x5A).toByte() }
        return String(b, Charsets.UTF_8)
    }
}
