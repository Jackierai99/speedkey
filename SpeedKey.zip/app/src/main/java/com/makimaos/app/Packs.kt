package com.makimaos.app

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/** One style pack = an icon style for the whole app + a centre "Live" logo design + a phone app icon. Colours come separately from the 10 themes. */
class PackDef(val name: String, val style: String)

object Packs {
    val defs = listOf(
        PackDef("Jadui Jeb", "Solid icons"),
        PackDef("Reticle", "Outline icons"),
        PackDef("Rose", "Rounded icons"),
        PackDef("Butterfly", "Sharp icons"),
        PackDef("Flame", "Duo-tone icons")
    )

    private var idx by mutableIntStateOf(-1)
    var index: Int
        get() { if (idx < 0) idx = Prefs.pack.coerceIn(0, defs.lastIndex); return idx }
        set(v) { idx = v.coerceIn(0, defs.lastIndex); Prefs.pack = idx }

    /** Switches the launcher icon: enables the chosen activity-alias and disables the others. */
    fun applyIcon(ctx: Context, sel: Int) {
        try {
            val pm = ctx.packageManager
            pm.setComponentEnabledSetting(
                ComponentName(ctx.packageName, "com.makimaos.app.AliasP$sel"),
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP
            )
            for (i in defs.indices) {
                if (i == sel) continue
                pm.setComponentEnabledSetting(
                    ComponentName(ctx.packageName, "com.makimaos.app.AliasP$i"),
                    PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP
                )
            }
        } catch (_: Exception) { }
    }
}

/**
 * Draws the emblem of a pack. r = visual radius, t = time in seconds (drives the animation).
 * 0 = magic pocket, 1 = reticle, 2 = rose, 3 = butterfly, 4 = flame.
 */
fun DrawScope.packEmblem(pack: Int, c: Offset, r: Float, color: Color, sw: Float, t: Float) {
    when (pack) {
        1 -> reticleEmblem(c, r, color, sw, t)
        2 -> roseEmblem(c, r, color, sw, t)
        3 -> butterflyEmblem(c, r, color, sw, t)
        4 -> flameEmblem(c, r, color, sw, t)
        else -> pocketEmblem(c, r, color, sw, t)
    }
}

private fun DrawScope.reticleEmblem(c: Offset, r: Float, col: Color, sw: Float, t: Float) {
    drawCircle(col, r * 0.92f, c, style = Stroke(sw))
    drawCircle(col.copy(alpha = col.alpha * 0.8f), r * 0.55f, c, style = Stroke(sw * 0.8f))
    drawCircle(col, r * 0.11f, c)
    for (k in 0 until 4) {
        val a = k * 1.5707964f
        val ca = cos(a); val sa = sin(a)
        drawLine(col, Offset(c.x + ca * r * 0.55f, c.y + sa * r * 0.55f), Offset(c.x + ca * r * 1.0f, c.y + sa * r * 1.0f), sw, StrokeCap.Round)
    }
    val spin = (t * 90f) % 360f
    val tl = Offset(c.x - r * 0.74f, c.y - r * 0.74f)
    val sz = Size(r * 1.48f, r * 1.48f)
    drawArc(col, spin, 70f, false, tl, sz, style = Stroke(sw * 1.5f, cap = StrokeCap.Round))
    drawArc(col, spin + 180f, 70f, false, tl, sz, style = Stroke(sw * 1.5f, cap = StrokeCap.Round))
}

private fun DrawScope.roseEmblem(c: Offset, r: Float, col: Color, sw: Float, t: Float) {
    val br = 1f + 0.03f * sin(t * 2f)
    for (k in 0 until 8) {
        withTransform({ rotate(k * 45f + t * 6f, c) }) {
            drawOval(col, Offset(c.x - r * 0.17f * br, c.y - r * 0.95f * br), Size(r * 0.34f * br, r * 0.62f * br), style = Stroke(sw))
        }
    }
    for (k in 0 until 8) {
        withTransform({ rotate(k * 45f + 22.5f - t * 6f, c) }) {
            drawOval(col.copy(alpha = col.alpha * 0.85f), Offset(c.x - r * 0.12f, c.y - r * 0.58f), Size(r * 0.24f, r * 0.42f), style = Stroke(sw * 0.8f))
        }
    }
    drawCircle(col, r * 0.09f, c)
}

private fun DrawScope.butterflyEmblem(c: Offset, r: Float, col: Color, sw: Float, t: Float) {
    val flap = 0.78f + 0.22f * abs(cos(t * 3.2f))
    withTransform({ scale(flap, 1f, c) }) {
        for (sgn in listOf(1f, -1f)) {
            val fx = { x: Float -> c.x + sgn * x * r }
            val fy = { y: Float -> c.y + y * r }
            val up = Path().apply {
                moveTo(fx(0.04f), fy(-0.05f))
                cubicTo(fx(0.35f), fy(-0.95f), fx(1.0f), fy(-0.85f), fx(0.95f), fy(-0.25f))
                cubicTo(fx(0.9f), fy(0.05f), fx(0.45f), fy(0.1f), fx(0.04f), fy(0.0f))
                close()
            }
            val lo = Path().apply {
                moveTo(fx(0.04f), fy(0.05f))
                cubicTo(fx(0.55f), fy(0.05f), fx(0.85f), fy(0.3f), fx(0.7f), fy(0.7f))
                cubicTo(fx(0.55f), fy(1.0f), fx(0.2f), fy(0.8f), fx(0.04f), fy(0.2f))
                close()
            }
            drawPath(up, col, style = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
            drawPath(lo, col, style = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
            drawCircle(col.copy(alpha = col.alpha * 0.5f), r * 0.1f, Offset(fx(0.6f), fy(-0.35f)))
        }
    }
    drawLine(col, Offset(c.x, c.y - r * 0.35f), Offset(c.x, c.y + r * 0.6f), sw * 1.6f, StrokeCap.Round)
    drawLine(col, Offset(c.x, c.y - r * 0.35f), Offset(c.x - r * 0.22f, c.y - r * 0.7f), sw, StrokeCap.Round)
    drawLine(col, Offset(c.x, c.y - r * 0.35f), Offset(c.x + r * 0.22f, c.y - r * 0.7f), sw, StrokeCap.Round)
}

private fun flamePath(c: Offset, r: Float, k: Float, dy: Float): Path {
    val x = { v: Float -> c.x + v * r * k }
    val y = { v: Float -> c.y + (v * k + dy) * r }
    return Path().apply {
        moveTo(x(0.05f), y(-1.0f))
        cubicTo(x(0.1f), y(-0.55f), x(0.72f), y(-0.35f), x(0.68f), y(0.25f))
        cubicTo(x(0.66f), y(0.72f), x(0.32f), y(0.98f), x(0f), y(0.98f))
        cubicTo(x(-0.32f), y(0.98f), x(-0.66f), y(0.72f), x(-0.68f), y(0.25f))
        cubicTo(x(-0.7f), y(-0.05f), x(-0.5f), y(-0.3f), x(-0.3f), y(-0.45f))
        cubicTo(x(-0.32f), y(-0.2f), x(-0.2f), y(-0.05f), x(-0.05f), y(0f))
        cubicTo(x(-0.1f), y(-0.4f), x(-0.05f), y(-0.75f), x(0.05f), y(-1.0f))
        close()
    }
}

private fun DrawScope.flameEmblem(c: Offset, r: Float, col: Color, sw: Float, t: Float) {
    val fl = 1f + 0.035f * sin(t * 9f) + 0.02f * sin(t * 13.7f)
    val sway = sin(t * 3f) * 3f
    val base = Offset(c.x, c.y + r * 0.98f)
    withTransform({ rotate(sway, base); scale(1f, fl, base) }) {
        drawPath(flamePath(c, r, 1f, 0f), col, style = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawPath(flamePath(c, r, 0.5f, 0.45f), col.copy(alpha = col.alpha * 0.9f), style = Stroke(sw * 0.8f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}
