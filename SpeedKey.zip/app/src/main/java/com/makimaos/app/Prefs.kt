package com.makimaos.app
import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private lateinit var sp: SharedPreferences
    fun init(c: Context) { sp = c.getSharedPreferences("makimaos", Context.MODE_PRIVATE) }

    val providers: List<String> get() = Brain.provs.map { it.name }
    val personas = listOf("Makima Classic", "Sweet", "Strict", "Playful", "Professional")
    val langs = listOf("Hinglish", "English", "Hindi", "Auto")
    val lengths = listOf("Short", "Medium", "Detailed")
    val micLangs = listOf("Hindi", "English (IN)", "English (US)")
    val micTags = listOf("hi-IN", "en-IN", "en-US")
    val openaiVoices = listOf("shimmer", "sage", "coral", "nova", "ballad")
    /** Six female Gemini voices, the closest to Makima's calm, low, composed tone. id = Gemini voice name. */
    class VoiceDef(val id: String, val name: String, val tag: String, val icon: String, val color: Long)
    val voiceDefs = listOf(
        VoiceDef("Gacrux", "Empress", "Mature - calm authority", "\uD83D\uDC51", 0xFFFF2D5A),
        VoiceDef("Kore", "Controller", "Firm - cold command", "\uD83C\uDFAF", 0xFFA855F7),
        VoiceDef("Vindemiatrix", "Silk", "Gentle - soft control", "\uD83C\uDF39", 0xFFFF3DCB),
        VoiceDef("Despina", "Velvet", "Smooth - silky calm", "\uD83E\uDD8B", 0xFF22B8FF),
        VoiceDef("Sulafat", "Ember", "Warm - caring tone", "\uD83D\uDD25", 0xFFFF6A3D),
        VoiceDef("Achernar", "Whisper", "Soft - quiet and close", "\uD83C\uDF19", 0xFF6C7BFF))
    val geminiVoiceInfo = voiceDefs.map { it.id to it.tag }
    val geminiVoices = geminiVoiceInfo.map { it.first }
    var themeIdx: Int
        get() = sp.getInt("theme", 0)
        set(v) { sp.edit().putInt("theme", v).apply() }
    var pack: Int
        get() = sp.getInt("pack", 0)
        set(v) { sp.edit().putInt("pack", v).apply() }

    // ---- API keys (provider is auto-detected, model is auto-selected; several keys per provider rotate on limits) ----
    private val keyIdx = HashMap<String, Int>()
    fun keys(p: String): List<String> {
        val own = (sp.getString("key_$p", "") ?: "").split("\n").map { it.trim() }.filter { it.isNotEmpty() }
        // built-in Gemini key: used whenever the user has not added one of their own
        return if (own.isEmpty() && p == "Gemini") listOf(Secrets.gemini()) else own
    }
    fun key(p: String): String {
        val l = keys(p)
        if (l.isEmpty()) return ""
        return l[(keyIdx[p] ?: 0) % l.size]
    }
    fun keyCount(p: String): Int = keys(p).size
    fun addKeyTo(p: String, v: String) {
        val k = v.trim()
        val rest = keys(p).filter { it != k }
        sp.edit().putString("key_$p", (listOf(k) + rest).take(6).joinToString("\n")).apply()
        keyIdx[p] = 0
    }
    fun setKey(p: String, v: String) = addKeyTo(p, v)
    fun rotateKey(p: String): Boolean {
        val n = keyCount(p)
        if (n < 2) return false
        keyIdx[p] = ((keyIdx[p] ?: 0) + 1) % n
        return true
    }
    fun model(p: String): String = sp.getString("model_$p", "") ?: ""
    fun setModel(p: String, v: String) { sp.edit().putString("model_$p", v.trim()).apply() }
    fun removeKey(p: String) { keyIdx.remove(p); sp.edit().remove("key_$p").remove("model_$p").apply() }
    fun active(): List<String> = providers.filter { key(it).isNotBlank() }
    var primary: String
        get() = sp.getString("primary", "") ?: ""
        set(v) { sp.edit().putString("primary", v).apply() }
    fun primaryName(): String = primary.takeIf { it.isNotBlank() && key(it).isNotBlank() } ?: active().firstOrNull() ?: ""
    var ttsModel: String
        get() = sp.getString("tts_model", "") ?: ""
        set(v) { sp.edit().putString("tts_model", v).apply() }

    // ---- persona / language ----
    var userName: String
        get() = sp.getString("name", "Boss") ?: "Boss"
        set(v) { sp.edit().putString("name", v).apply() }
    var persona: Int
        get() = sp.getInt("persona", 0)
        set(v) { sp.edit().putInt("persona", v).apply() }
    var lang: Int
        get() = sp.getInt("lang", 0)
        set(v) { sp.edit().putInt("lang", v).apply() }
    var len: Int
        get() = sp.getInt("len", 0)
        set(v) { sp.edit().putInt("len", v).apply() }
    var custom: String
        get() = sp.getString("custom", "") ?: ""
        set(v) { sp.edit().putString("custom", v).apply() }
    var memory: String
        get() = sp.getString("memory", "") ?: ""
        set(v) { sp.edit().putString("memory", v).apply() }

    // ---- voice ----
    var autoSpeak: Boolean
        get() = sp.getBoolean("autoSpeak", true)
        set(v) { sp.edit().putBoolean("autoSpeak", v).apply() }
    var premium: Boolean
        get() = sp.getBoolean("premium", true)
        set(v) { sp.edit().putBoolean("premium", v).apply() }
    var geminiVoice: String
        get() = (sp.getString("gvoice", "Gacrux") ?: "Gacrux").let { if (it in geminiVoices) it else "Gacrux" }
        set(v) { sp.edit().putString("gvoice", v).apply() }
    var openaiVoice: String
        get() = sp.getString("ovoice", "shimmer") ?: "shimmer"
        set(v) { sp.edit().putString("ovoice", v).apply() }
    var voice: Int
        get() = sp.getInt("voice", 0)
        set(v) { sp.edit().putInt("voice", v).apply() }
    var speed: Float
        get() = sp.getFloat("speed", 1f)
        set(v) { sp.edit().putFloat("speed", v).apply() }
    var pitch: Float
        get() = sp.getFloat("pitch", 1f)
        set(v) { sp.edit().putFloat("pitch", v).apply() }
    var micLang: Int
        get() = sp.getInt("micLang", 0)
        set(v) { sp.edit().putInt("micLang", v).apply() }

    // ---- behaviour ----
    var failover: Boolean
        get() = sp.getBoolean("failover", true)
        set(v) { sp.edit().putBoolean("failover", v).apply() }
    /** the robotic phone text-to-speech voice. OFF by default: live mode speaks only with Gemini's own voice. */
    var phoneTts: Boolean
        get() = sp.getBoolean("phoneTts", false)
        set(v) { sp.edit().putBoolean("phoneTts", v).apply() }
    var phoneControl: Boolean
        get() = sp.getBoolean("phoneControl", true)
        set(v) { sp.edit().putBoolean("phoneControl", v).apply() }
    var saveHistory: Boolean
        get() = sp.getBoolean("saveHistory", true)
        set(v) { sp.edit().putBoolean("saveHistory", v).apply() }
    var ctxTurns: Int
        get() = sp.getInt("ctxTurns", 12)
        set(v) { sp.edit().putInt("ctxTurns", v).apply() }
    var autoHands: Boolean
        get() = sp.getBoolean("autoHands", true)
        set(v) { sp.edit().putBoolean("autoHands", v).apply() }
    var waitSec: Float
        get() = sp.getFloat("waitSec", 0.6f)
        set(v) { sp.edit().putFloat("waitSec", v).apply() }
    // ---- feelings / speed (v2.3) ----
    val voiceModes = listOf("Fast (hybrid)", "Best quality", "Phone voice")
    var voiceMode: Int          // 0 = AI voice, but phone voice covers the first sentence if the AI voice is slow; 1 = AI voice only; 2 = phone voice only (instant)
        get() = sp.getInt("voiceMode", 0)
        set(v) { sp.edit().putInt("voiceMode", v).apply() }
    var liveMode: Boolean       // real live voice (Gemini Live API): voice in, voice out, interruptible, with phone control
        get() = sp.getBoolean("liveMode", true)
        set(v) { sp.edit().putBoolean("liveMode", v).apply() }
    var liveModel: String
        get() = sp.getString("liveModel", "") ?: ""
        set(v) { sp.edit().putString("liveModel", v).apply() }
    var humanMode: Boolean
        get() = sp.getBoolean("humanMode", true)
        set(v) { sp.edit().putBoolean("humanMode", v).apply() }
    var proactive: Boolean
        get() = sp.getBoolean("proactive", true)
        set(v) { sp.edit().putBoolean("proactive", v).apply() }
    var bond: Float
        get() = sp.getFloat("bond", 0.4f)
        set(v) { sp.edit().putFloat("bond", v).apply() }
    var lastSeen: Long
        get() = sp.getLong("lastSeen", 0L)
        set(v) { sp.edit().putLong("lastSeen", v).apply() }
    var orbX: Int
        get() = sp.getInt("orbX", -1)
        set(v) { sp.edit().putInt("orbX", v).apply() }
    var orbY: Int
        get() = sp.getInt("orbY", -1)
        set(v) { sp.edit().putInt("orbY", v).apply() }
    var captions: Boolean
        get() = sp.getBoolean("captions", true)
        set(v) { sp.edit().putBoolean("captions", v).apply() }
    var autoOn: Boolean
        get() = sp.getBoolean("autoOn", false)
        set(v) { sp.edit().putBoolean("autoOn", v).apply() }
    var autoMode: Int                       // 0 = everybody, 1 = only the listed names
        get() = sp.getInt("autoMode", 0)
        set(v) { sp.edit().putInt("autoMode", v).apply() }
    var autoNames: String
        get() = sp.getString("autoNames", "") ?: ""
        set(v) { sp.edit().putString("autoNames", v).apply() }
    var autoGroups: Boolean
        get() = sp.getBoolean("autoGroups", false)
        set(v) { sp.edit().putBoolean("autoGroups", v).apply() }
    var autoOnlyAway: Boolean
        get() = sp.getBoolean("autoOnlyAway", false)
        set(v) { sp.edit().putBoolean("autoOnlyAway", v).apply() }
    var autoUi: Boolean
        get() = sp.getBoolean("autoUi", true)
        set(v) { sp.edit().putBoolean("autoUi", v).apply() }
    var autoOther: Boolean
        get() = sp.getBoolean("autoOther", false)
        set(v) { sp.edit().putBoolean("autoOther", v).apply() }
    var autoDeepRead: Boolean               // open the chat and read older messages before replying (phone must be unlocked)
        get() = sp.getBoolean("autoDeepRead", true)
        set(v) { sp.edit().putBoolean("autoDeepRead", v).apply() }
    var autoDelay: Int
        get() = sp.getInt("autoDelay", 6)
        set(v) { sp.edit().putInt("autoDelay", v).apply() }
    var autoOrders: String
        get() = sp.getString("autoOrders", "") ?: ""
        set(v) { sp.edit().putString("autoOrders", v).apply() }
    var autoLog: String
        get() = sp.getString("autoLog", "[]") ?: "[]"
        set(v) { sp.edit().putString("autoLog", v).apply() }
    var history: String
        get() = sp.getString("history", "[]") ?: "[]"
        set(v) { sp.edit().putString("history", v).apply() }

    // ---- license / onboarding (v2.4) ----
    var onboarded: Boolean
        get() = sp.getBoolean("onboarded", false)
        set(v) { sp.edit().putBoolean("onboarded", v).apply() }
    var licAdmin: Boolean
        get() = sp.getBoolean("licAdmin", false)
        set(v) { sp.edit().putBoolean("licAdmin", v).apply() }
    var licExpires: Long
        get() = sp.getLong("licExpires", 0L)
        set(v) { sp.edit().putLong("licExpires", v).apply() }
    var licKey: String
        get() = sp.getString("licKey", "") ?: ""
        set(v) { sp.edit().putString("licKey", v).apply() }
    var licKind: String
        get() = sp.getString("licKind", "") ?: ""
        set(v) { sp.edit().putString("licKind", v).apply() }
    var licRefresh: String
        get() = sp.getString("licRefresh", "") ?: ""
        set(v) { sp.edit().putString("licRefresh", v).apply() }
    /** admin password, AES-GCM encrypted with an Android Keystore key (see Vault in License.kt) */
    var licPass: String
        get() = sp.getString("licPass", "") ?: ""
        set(v) { sp.edit().putString("licPass", v).apply() }
    // ---- phone unlock: type 0 = PIN, 1 = pattern (dot numbers 1-9), 2 = password; data is encrypted with Vault ----
    var unlockOn: Boolean
        get() = sp.getBoolean("unlockOn", false)
        set(v) { sp.edit().putBoolean("unlockOn", v).apply() }
    var unlockType: Int
        get() = sp.getInt("unlockType", 0)
        set(v) { sp.edit().putInt("unlockType", v).apply() }
    var unlockData: String
        get() = sp.getString("unlockData", "") ?: ""
        set(v) { sp.edit().putString("unlockData", v).apply() }
    // ---- v3: wake word, lock, sleep timer, notes ----
    var wakeWord: Boolean                   // "Hey Makima" wakes her from the background
        get() = sp.getBoolean("wakeWord", false)
        set(v) { sp.edit().putBoolean("wakeWord", v).apply() }
    var pinHash: String
        get() = sp.getString("pinHash", "") ?: ""
        set(v) { sp.edit().putString("pinHash", v).apply() }
    var sleepMin: Int                       // 0 = off; hands-free stops by itself after this many minutes
        get() = sp.getInt("sleepMin", 0)
        set(v) { sp.edit().putInt("sleepMin", v).apply() }
    var notes: String                       // JSON array of {t: text, d: done}
        get() = sp.getString("notes", "[]") ?: "[]"
        set(v) { sp.edit().putString("notes", v).apply() }
    var lastEmail: String
        get() = sp.getString("lastEmail", "") ?: ""
        set(v) { sp.edit().putString("lastEmail", v).apply() }
}
