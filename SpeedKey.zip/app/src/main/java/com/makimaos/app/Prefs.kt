package com.makimaos.app
import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private lateinit var sp: SharedPreferences
    fun init(c: Context) { sp = c.getSharedPreferences("makimaos", Context.MODE_PRIVATE) }

    val providers: List<String> get() = Brain.provs.map { it.name }
    val personas = listOf("Makima Classic", "Sweet", "Strict", "Playful", "Professional")
    val langs = listOf("Hinglish", "English", "Hindi", "Auto")
    val lengths = listOf("Short", "Medium", "Detailed")
    val micLangs = listOf("Hindi", "English (IN)", "English (US)")
    val micTags = listOf("hi-IN", "en-IN", "en-US")
    val openaiVoices = listOf("shimmer", "sage", "coral", "nova", "ballad")
    val geminiVoiceInfo = listOf("Zephyr" to "Bright", "Puck" to "Upbeat", "Charon" to "Informative", "Kore" to "Firm", "Fenrir" to "Excitable",
        "Leda" to "Youthful", "Orus" to "Firm", "Aoede" to "Breezy", "Callirrhoe" to "Easy-going", "Autonoe" to "Bright",
        "Enceladus" to "Breathy", "Iapetus" to "Clear", "Umbriel" to "Easy-going", "Algieba" to "Smooth", "Despina" to "Smooth",
        "Erinome" to "Clear", "Algenib" to "Gravelly", "Rasalgethi" to "Informative", "Laomedeia" to "Upbeat", "Achernar" to "Soft",
        "Alnilam" to "Firm", "Schedar" to "Even", "Gacrux" to "Mature", "Pulcherrima" to "Forward", "Achird" to "Friendly",
        "Zubenelgenubi" to "Casual", "Vindemiatrix" to "Gentle", "Sadachbia" to "Lively", "Sadaltager" to "Knowledgeable", "Sulafat" to "Warm")
    val geminiVoices = geminiVoiceInfo.map { it.first }
    var themeIdx: Int
        get() = sp.getInt("theme", 0)
        set(v) { sp.edit().putInt("theme", v).apply() }

    // ---- API keys (provider is auto-detected, model is auto-selected; several keys per provider rotate on limits) ----
    private val keyIdx = HashMap<String, Int>()
    fun keys(p: String): List<String> =
        (sp.getString("key_$p", "") ?: "").split("\n").map { it.trim() }.filter { it.isNotEmpty() }
    fun key(p: String): String {
        val l = keys(p)
        if (l.isEmpty()) return ""
        return l[(keyIdx[p] ?: 0) % l.size]
    }
    fun keyCount(p: String): Int = keys(p).size
    fun addKeyTo(p: String, v: String) {
        val k = v.trim()
        val rest = keys(p).filter { it != k }
        sp.edit().putString("key_$p", (listOf(k) + rest).take(6).joinToString("\n")).apply()
        keyIdx[p] = 0
    }
    fun setKey(p: String, v: String) = addKeyTo(p, v)
    fun rotateKey(p: String): Boolean {
        val n = keyCount(p)
        if (n < 2) return false
        keyIdx[p] = ((keyIdx[p] ?: 0) + 1) % n
        return true
    }
    fun model(p: String): String = sp.getString("model_$p", "") ?: ""
    fun setModel(p: String, v: String) { sp.edit().putString("model_$p", v.trim()).apply() }
    fun removeKey(p: String) { keyIdx.remove(p); sp.edit().remove("key_$p").remove("model_$p").apply() }
    fun active(): List<String> = providers.filter { key(it).isNotBlank() }
    var primary: String
        get() = sp.getString("primary", "") ?: ""
        set(v) { sp.edit().putString("primary", v).apply() }
    fun primaryName(): String = primary.takeIf { it.isNotBlank() && key(it).isNotBlank() } ?: active().firstOrNull() ?: ""
    var ttsModel: String
        get() = sp.getString("tts_model", "") ?: ""
        set(v) { sp.edit().putString("tts_model", v).apply() }

    // ---- persona / language ----
    var userName: String
        get() = sp.getString("name", "Boss") ?: "Boss"
        set(v) { sp.edit().putString("name", v).apply() }
    var persona: Int
        get() = sp.getInt("persona", 0)
        set(v) { sp.edit().putInt("persona", v).apply() }
    var lang: Int
        get() = sp.getInt("lang", 0)
        set(v) { sp.edit().putInt("lang", v).apply() }
    var len: Int
        get() = sp.getInt("len", 0)
        set(v) { sp.edit().putInt("len", v).apply() }
    var custom: String
        get() = sp.getString("custom", "") ?: ""
        set(v) { sp.edit().putString("custom", v).apply() }
    var memory: String
        get() = sp.getString("memory", "") ?: ""
        set(v) { sp.edit().putString("memory", v).apply() }

    // ---- voice ----
    var autoSpeak: Boolean
        get() = sp.getBoolean("autoSpeak", true)
        set(v) { sp.edit().putBoolean("autoSpeak", v).apply() }
    var premium: Boolean
        get() = sp.getBoolean("premium", true)
        set(v) { sp.edit().putBoolean("premium", v).apply() }
    var geminiVoice: String
        get() = (sp.getString("gvoice", "Leda") ?: "Leda").let { if (it in geminiVoices) it else "Leda" }
        set(v) { sp.edit().putString("gvoice", v).apply() }
    var openaiVoice: String
        get() = sp.getString("ovoice", "shimmer") ?: "shimmer"
        set(v) { sp.edit().putString("ovoice", v).apply() }
    var voice: Int
        get() = sp.getInt("voice", 0)
        set(v) { sp.edit().putInt("voice", v).apply() }
    var speed: Float
        get() = sp.getFloat("speed", 1f)
        set(v) { sp.edit().putFloat("speed", v).apply() }
    var pitch: Float
        get() = sp.getFloat("pitch", 1f)
        set(v) { sp.edit().putFloat("pitch", v).apply() }
    var micLang: Int
        get() = sp.getInt("micLang", 0)
        set(v) { sp.edit().putInt("micLang", v).apply() }

    // ---- behaviour ----
    var failover: Boolean
        get() = sp.getBoolean("failover", true)
        set(v) { sp.edit().putBoolean("failover", v).apply() }
    var phoneControl: Boolean
        get() = sp.getBoolean("phoneControl", true)
        set(v) { sp.edit().putBoolean("phoneControl", v).apply() }
    var saveHistory: Boolean
        get() = sp.getBoolean("saveHistory", true)
        set(v) { sp.edit().putBoolean("saveHistory", v).apply() }
    var ctxTurns: Int
        get() = sp.getInt("ctxTurns", 12)
        set(v) { sp.edit().putInt("ctxTurns", v).apply() }
    var autoHands: Boolean
        get() = sp.getBoolean("autoHands", true)
        set(v) { sp.edit().putBoolean("autoHands", v).apply() }
    var waitSec: Float
        get() = sp.getFloat("waitSec", 0.6f)
        set(v) { sp.edit().putFloat("waitSec", v).apply() }
    // ---- feelings / speed (v2.3) ----
    val voiceModes = listOf("Fast (hybrid)", "Best quality", "Phone voice")
    var voiceMode: Int          // 0 = AI voice, but phone voice covers the first sentence if the AI voice is slow; 1 = AI voice only; 2 = phone voice only (instant)
        get() = sp.getInt("voiceMode", 0)
        set(v) { sp.edit().putInt("voiceMode", v).apply() }
    var liveMode: Boolean       // real live voice (Gemini Live API): voice in, voice out, interruptible, with phone control
        get() = sp.getBoolean("liveMode", true)
        set(v) { sp.edit().putBoolean("liveMode", v).apply() }
    var liveModel: String
        get() = sp.getString("liveModel", "") ?: ""
        set(v) { sp.edit().putString("liveModel", v).apply() }
    var humanMode: Boolean
        get() = sp.getBoolean("humanMode", true)
        set(v) { sp.edit().putBoolean("humanMode", v).apply() }
    var proactive: Boolean
        get() = sp.getBoolean("proactive", true)
        set(v) { sp.edit().putBoolean("proactive", v).apply() }
    var bond: Float
        get() = sp.getFloat("bond", 0.4f)
        set(v) { sp.edit().putFloat("bond", v).apply() }
    var lastSeen: Long
        get() = sp.getLong("lastSeen", 0L)
        set(v) { sp.edit().putLong("lastSeen", v).apply() }
    var orbX: Int
        get() = sp.getInt("orbX", -1)
        set(v) { sp.edit().putInt("orbX", v).apply() }
    var orbY: Int
        get() = sp.getInt("orbY", -1)
        set(v) { sp.edit().putInt("orbY", v).apply() }
    var captions: Boolean
        get() = sp.getBoolean("captions", true)
        set(v) { sp.edit().putBoolean("captions", v).apply() }
    var autoOn: Boolean
        get() = sp.getBoolean("autoOn", false)
        set(v) { sp.edit().putBoolean("autoOn", v).apply() }
    var autoMode: Int                       // 0 = everybody, 1 = only the listed names
        get() = sp.getInt("autoMode", 0)
        set(v) { sp.edit().putInt("autoMode", v).apply() }
    var autoNames: String
        get() = sp.getString("autoNames", "") ?: ""
        set(v) { sp.edit().putString("autoNames", v).apply() }
    var autoGroups: Boolean
        get() = sp.getBoolean("autoGroups", false)
        set(v) { sp.edit().putBoolean("autoGroups", v).apply() }
    var autoOnlyAway: Boolean
        get() = sp.getBoolean("autoOnlyAway", false)
        set(v) { sp.edit().putBoolean("autoOnlyAway", v).apply() }
    var autoUi: Boolean
        get() = sp.getBoolean("autoUi", true)
        set(v) { sp.edit().putBoolean("autoUi", v).apply() }
    var autoOther: Boolean
        get() = sp.getBoolean("autoOther", false)
        set(v) { sp.edit().putBoolean("autoOther", v).apply() }
    var autoDeepRead: Boolean               // open the chat and read older messages before replying (phone must be unlocked)
        get() = sp.getBoolean("autoDeepRead", true)
        set(v) { sp.edit().putBoolean("autoDeepRead", v).apply() }
    var autoDelay: Int
        get() = sp.getInt("autoDelay", 6)
        set(v) { sp.edit().putInt("autoDelay", v).apply() }
    var autoOrders: String
        get() = sp.getString("autoOrders", "") ?: ""
        set(v) { sp.edit().putString("autoOrders", v).apply() }
    var autoLog: String
        get() = sp.getString("autoLog", "[]") ?: "[]"
        set(v) { sp.edit().putString("autoLog", v).apply() }
    var history: String
        get() = sp.getString("history", "[]") ?: "[]"
        set(v) { sp.edit().putString("history", v).apply() }

    // ---- license / onboarding (v2.4) ----
    var onboarded: Boolean
        get() = sp.getBoolean("onboarded", false)
        set(v) { sp.edit().putBoolean("onboarded", v).apply() }
    var licAdmin: Boolean
        get() = sp.getBoolean("licAdmin", false)
        set(v) { sp.edit().putBoolean("licAdmin", v).apply() }
    var licExpires: Long
        get() = sp.getLong("licExpires", 0L)
        set(v) { sp.edit().putLong("licExpires", v).apply() }
    var licKey: String
        get() = sp.getString("licKey", "") ?: ""
        set(v) { sp.edit().putString("licKey", v).apply() }
    var licKind: String
        get() = sp.getString("licKind", "") ?: ""
        set(v) { sp.edit().putString("licKind", v).apply() }
    var licRefresh: String
        get() = sp.getString("licRefresh", "") ?: ""
        set(v) { sp.edit().putString("licRefresh", v).apply() }
    var lastEmail: String
        get() = sp.getString("lastEmail", "") ?: ""
        set(v) { sp.edit().putString("lastEmail", v).apply() }
}
