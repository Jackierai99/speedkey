package com.makimaos.app
import android.content.Intent
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.util.Calendar

private val AC: Color get() = MakimaTheme.accent

// ====================================================================== HUD (futuristic) building blocks
/** Opaque sci-fi backdrop: dark gradient, moving grid, scan line, rings and corner brackets. Used by splash, manual, gate, admin, lock. */
@Composable
fun HudBackdrop(content: @Composable BoxScope.() -> Unit) {
    val inf = rememberInfiniteTransition(label = "hud")
    val t by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(7000, easing = LinearEasing)), label = "scan")
    val breathe by inf.animateFloat(0.6f, 1f, infiniteRepeatable(tween(2200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "breathe")
    val acc = MakimaTheme.accent
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(MakimaTheme.bg1, MakimaTheme.bg0, Color.Black)))) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width; val h = size.height
            val step = 56f
            var x = 0f
            while (x < w) { drawLine(acc.copy(alpha = 0.06f), Offset(x, 0f), Offset(x, h), 1f); x += step }
            var y = (t * step) % step
            while (y < h) { drawLine(acc.copy(alpha = 0.06f), Offset(0f, y), Offset(w, y), 1f); y += step }
            val sy = h * t
            drawRect(Brush.verticalGradient(listOf(Color.Transparent, acc.copy(alpha = 0.14f), Color.Transparent), startY = sy - 90f, endY = sy + 90f),
                Offset(0f, sy - 90f), Size(w, 180f))
            for (r in listOf(110f, 190f, 280f)) drawCircle(acc.copy(alpha = 0.10f * breathe), r, Offset(w / 2f, h * 0.2f), style = Stroke(2f))
            val m = 22f; val L = 54f; val sw = 4f
            val c = acc.copy(alpha = 0.85f)
            drawLine(c, Offset(m, m), Offset(m + L, m), sw); drawLine(c, Offset(m, m), Offset(m, m + L), sw)
            drawLine(c, Offset(w - m, m), Offset(w - m - L, m), sw); drawLine(c, Offset(w - m, m), Offset(w - m, m + L), sw)
            drawLine(c, Offset(m, h - m), Offset(m + L, h - m), sw); drawLine(c, Offset(m, h - m), Offset(m, h - m - L), sw)
            drawLine(c, Offset(w - m, h - m), Offset(w - m - L, h - m), sw); drawLine(c, Offset(w - m, h - m), Offset(w - m, h - m - L), sw)
        }
        content()
    }
}

/** Solid dark panel with cut corners and a neon edge. */
@Composable
fun HudPanel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = CutCornerShape(topStart = 20.dp, bottomEnd = 20.dp)
    Column(modifier.clip(shape).background(MakimaTheme.panel(0.97f)).border(1.5.dp, AC.copy(alpha = 0.75f), shape).padding(16.dp), content = content)
}

// ====================================================================== APP LOCK
private fun sha(pin: String): String =
    MessageDigest.getInstance("SHA-256").digest(("makima:$pin").toByteArray()).joinToString("") { "%02x".format(it) }

@Composable
fun LockScreen(onUnlock: () -> Unit, onForgot: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    fun press(d: String) {
        if (pin.length >= 4) return
        pin += d
        if (pin.length == 4) {
            if (sha(pin) == Prefs.pinHash) onUnlock() else { msg = "Galat PIN"; pin = "" }
        }
    }
    HudBackdrop {
        Column(Modifier.fillMaxSize().systemBarsPadding().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(Icons.Default.Lock, null, tint = AC, modifier = Modifier.size(54.dp))
            Spacer(Modifier.height(10.dp))
            Text("SYSTEM LOCKED", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
            Text("PIN daalo, ${Prefs.userName}", color = AC, fontSize = 14.sp)
            Spacer(Modifier.height(22.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                for (i in 0 until 4) Box(Modifier.size(18.dp).clip(CircleShape).background(if (i < pin.length) AC else Color(0x33FFFFFF)).border(1.dp, AC, CircleShape))
            }
            Spacer(Modifier.height(10.dp))
            Text(msg, color = Color(0xFFFF8A8A), fontSize = 13.sp, modifier = Modifier.height(20.dp))
            Spacer(Modifier.height(10.dp))
            val rows = listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("", "0", "<"))
            rows.forEach { r ->
                Row(horizontalArrangement = Arrangement.spacedBy(18.dp), modifier = Modifier.padding(vertical = 7.dp)) {
                    r.forEach { k ->
                        if (k.isEmpty()) Spacer(Modifier.size(70.dp))
                        else Box(Modifier.size(70.dp).clip(CircleShape).background(MakimaTheme.panel(0.97f)).border(1.5.dp, AC.copy(alpha = 0.7f), CircleShape)
                            .clickable { msg = ""; if (k == "<") pin = pin.dropLast(1) else press(k) }, contentAlignment = Alignment.Center) {
                            Text(k, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            TextButton(onClick = onForgot) { Text("PIN bhool gaye? (license dobara daalni hogi)", color = Color(0x99FFFFFF), fontSize = 12.sp) }
        }
    }
}

/** Settings block: app PIN + hands-free sleep timer. */
@Composable
fun SecurityBlock(app: AppState) {
    var pinSet by remember { mutableStateOf(Prefs.pinHash.isNotEmpty()) }
    var input by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var sleep by remember { mutableStateOf(Prefs.sleepMin) }
    Text("App Lock", color = Color.White, fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp))
    Text(if (pinSet) "ON - app kholte hi 4 digit PIN poochhegi" else "OFF - 4 digit PIN lagao, bina PIN ke app nahi khulegi", color = Color(0x99FFFFFF), fontSize = 12.sp)
    if (!pinSet) {
        Field(input, { v -> input = v.filter { it.isDigit() }.take(4) }, "Naya 4 digit PIN", AC, secret = true, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
        Button(onClick = {
            if (input.length == 4) { Prefs.pinHash = sha(input); pinSet = true; input = ""; msg = "PIN lag gaya" } else msg = "Poore 4 digit daalo"
        }, colors = ButtonDefaults.buttonColors(containerColor = AC), modifier = Modifier.padding(top = 6.dp)) { Text("PIN lagao") }
    } else {
        Button(onClick = { Prefs.pinHash = ""; pinSet = false; msg = "PIN hat gaya" },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0x44FFFFFF)), modifier = Modifier.padding(top = 6.dp)) { Text("PIN hatao") }
    }
    if (msg.isNotEmpty()) Text(msg, color = Color(0xFF7CFFA0), fontSize = 12.sp)
    Text("Sleep timer (hands-free)", color = Color.White, fontSize = 14.sp, modifier = Modifier.padding(top = 12.dp, bottom = 4.dp))
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(0 to "Off", 15 to "15 min", 30 to "30 min", 60 to "1 hr", 120 to "2 hr").forEach { (m, n) ->
            Chip(n, sleep == m, AC) { sleep = m; Prefs.sleepMin = m }
        }
    }
    Text("Itne time baad Makima sunna apne aap band kar degi (battery bachegi).", color = Color(0x88FFFFFF), fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
}

// ====================================================================== CHAT EXPORT + SMART CHIPS
fun exportChat(app: AppState) {
    val sb = StringBuilder("MakimaOS chat\n\n")
    val f = java.text.SimpleDateFormat("d MMM HH:mm", java.util.Locale.getDefault())
    app.messages.forEach { sb.append(if (it.user) "You" else "Makima").append(" (").append(f.format(java.util.Date(it.ts))).append("): ").append(it.text).append("\n\n") }
    val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, sb.toString())
    try { app.ctx.startActivity(Intent.createChooser(i, "Chat share karo").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
}

private val smartPrompts = listOf(
    "Morning briefing" to "Mujhe aaj ki morning briefing do: time, battery, aur aaj ke liye 3 chhoti motivating baatein.",
    "Plan my day" to "Mere din ka ek simple plan banao. Pehle mujhse 2 sawaal poochho: aaj kya kaam hain aur kitna time hai.",
    "Screen padho" to "Meri screen padho aur short me batao ki isme kya hai.",
    "Motivate me" to "Mujhe ek short, tagdi motivation do, Makima style me.",
    "Joke" to "Ek chhota funny joke sunao.",
    "Summarize chat" to "Hamari ab tak ki baat ka 3 line me summary do."
)

@Composable
fun SmartChips(app: AppState) {
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        smartPrompts.forEach { (label, text) -> Chip(label, false, AC) { app.send(text) } }
    }
}

// ====================================================================== TOOLS HUB
private class Tool(val icon: ImageVector, val label: String, val go: () -> Unit)

@Composable
fun ToolsScreen(app: AppState) {
    val scope = rememberCoroutineScope()
    var status by remember { mutableStateOf("") }
    var torchOn by remember { mutableStateOf(false) }
    fun act(name: String, arg: String = "", ok: String = "Ho gaya") {
        scope.launch(Dispatchers.IO) {
            val r = Agent.run(app.ctx, name, arg)
            status = if (r.startsWith("OK")) ok else r.removePrefix("FAIL: ")
        }
    }
    fun ask(text: String) { app.screen = Screen.CHAT; app.send(text) }
    val tools = listOf(
        Tool(if (torchOn) Icons.Default.FlashOff else Icons.Default.FlashOn, if (torchOn) "Torch OFF" else "Torch ON") { torchOn = !torchOn; act("torch", if (torchOn) "on" else "off") },
        Tool(Icons.Default.VolumeUp, "Volume +") { act("volume", "up") },
        Tool(Icons.Default.VolumeDown, "Volume -") { act("volume", "down") },
        Tool(Icons.Default.VolumeOff, "Mute") { act("volume", "mute") },
        Tool(Icons.Default.PlayArrow, "Play/Pause") { act("media", "toggle") },
        Tool(Icons.Default.SkipNext, "Next song") { act("media", "next") },
        Tool(Icons.Default.PhotoCamera, "Screenshot") { act("screenshot", "", "Screenshot le liya") },
        Tool(Icons.Default.Notifications, "Notifications") { act("notifications") },
        Tool(Icons.Default.Tune, "Quick settings") { act("quick") },
        Tool(Icons.Default.Apps, "Recent apps") { act("recents") },
        Tool(Icons.Default.Wifi, "Wi-Fi") { act("wifi") },
        Tool(Icons.Default.Bluetooth, "Bluetooth") { act("bluetooth") },
        Tool(Icons.Default.Visibility, "Screen padho") { ask("Meri screen padho aur short me batao ki isme kya hai.") },
        Tool(Icons.Default.Edit, "Notes / Tasks") { app.screen = Screen.NOTES },
        Tool(Icons.Default.Share, "Chat export") { exportChat(app) },
        Tool(Icons.Default.Favorite, "Morning brief") { ask("Mujhe aaj ki morning briefing do: time, battery, aur aaj ke liye 3 chhoti motivating baatein.") },
        Tool(Icons.Default.Lock, "Lock screen") { act("lock") },
        Tool(Icons.Default.Lock, "Unlock phone") { act("unlock", "", "Unlock ho gaya") },
        Tool(Icons.Default.Home, "Home") { act("home") }
    )
    Page(app, "Tools") {
        Text("Ek tap me kaam. Zyada tar tools ke liye Accessibility ON honi chahiye.", color = Color(0x99FFFFFF), fontSize = 12.sp)
        if (status.isNotEmpty()) Text(status, color = Color(0xFF7CFFA0), fontSize = 13.sp, modifier = Modifier.padding(vertical = 4.dp))
        Column(Modifier.verticalScroll(rememberScrollState()).padding(top = 8.dp)) {
            tools.chunked(3).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { t ->
                        val shape = CutCornerShape(topStart = 14.dp, bottomEnd = 14.dp)
                        Column(Modifier.weight(1f).height(92.dp).clip(shape).background(MakimaTheme.panel(0.95f)).border(1.dp, AC.copy(alpha = 0.7f), shape)
                            .clickable { t.go() }.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                            Icon(t.icon, null, tint = AC, modifier = Modifier.size(30.dp))
                            Spacer(Modifier.height(6.dp))
                            Text(t.label, color = Color.White, fontSize = 12.sp, textAlign = TextAlign.Center, maxLines = 2)
                        }
                    }
                    repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
            Spacer(Modifier.height(30.dp))
        }
    }
}

// ====================================================================== NOTES / TASKS
private class Note(val text: String, done: Boolean) { var done by mutableStateOf(done) }

@Composable
fun NotesScreen(app: AppState) {
    val notes = remember {
        mutableStateListOf<Note>().apply {
            try { val a = JSONArray(Prefs.notes); for (i in 0 until a.length()) { val o = a.getJSONObject(i); add(Note(o.getString("t"), o.optBoolean("d"))) } } catch (_: Exception) {}
        }
    }
    var input by remember { mutableStateOf("") }
    fun save() {
        val a = JSONArray(); notes.forEach { a.put(JSONObject().put("t", it.text).put("d", it.done)) }; Prefs.notes = a.toString()
    }
    Page(app, "Notes / Tasks") {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Field(input, { input = it }, "Naya kaam ya note", AC, modifier = Modifier.weight(1f))
            IconButton(onClick = { if (input.isNotBlank()) { notes.add(0, Note(input.trim(), false)); input = ""; save() } }) { Icon(Icons.Default.Add, null, tint = AC) }
        }
        val pending = notes.filter { !it.done }
        if (pending.isNotEmpty()) {
            Button(onClick = {
                app.screen = Screen.CHAT
                app.send("Mere pending kaam ye hain: " + pending.joinToString("; ") { it.text } + ". Inhe priority me lagao aur ek chhota plan do.")
            }, colors = ButtonDefaults.buttonColors(containerColor = AC), modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) { Text("Makima se plan banwao (${pending.size})") }
        }
        if (notes.isEmpty()) Text("Abhi kuch nahi. Upar se kaam add karo.", color = Color(0x99FFFFFF), fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp))
        LazyColumn(Modifier.weight(1f).padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            itemsIndexed(notes) { _, n ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0x33FFFFFF)).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(n.done, { n.done = it; save() }, colors = CheckboxDefaults.colors(checkedColor = AC))
                    Text(n.text, color = if (n.done) Color(0x88FFFFFF) else Color.White, fontSize = 15.sp, modifier = Modifier.weight(1f))
                    IconButton(onClick = { notes.remove(n); save() }) { Icon(Icons.Default.Delete, null, tint = Color(0xFFFF8A8A)) }
                }
            }
        }
    }
}

// ====================================================================== STATS (Profile)
@Composable
fun StatsCard(app: AppState) {
    val mine = app.messages.filter { it.user }
    val dayMs = 24L * 60 * 60 * 1000
    val off = Calendar.getInstance().timeZone.rawOffset.toLong()
    fun day(ts: Long) = (ts + off) / dayMs
    val today = day(System.currentTimeMillis())
    val days = mine.map { day(it.ts) }.toSet()
    var streak = 0
    var d = if (today in days) today else today - 1
    while (d in days) { streak++; d-- }
    val todayCount = mine.count { day(it.ts) == today }
    val bond = Prefs.bond.coerceIn(0f, 1f)
    HudPanel(Modifier.fillMaxWidth().padding(top = 14.dp)) {
        Text("YOUR STATS", color = AC, fontSize = 13.sp, letterSpacing = 3.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            StatBox("Aaj", todayCount.toString())
            StatBox("Total", mine.size.toString())
            StatBox("Streak", "$streak din")
            StatBox("Fav", app.messages.count { it.fav }.toString())
        }
        Spacer(Modifier.height(12.dp))
        Text("Bond with Makima: ${(bond * 100).toInt()}%", color = Color.White, fontSize = 13.sp)
        Spacer(Modifier.height(4.dp))
        LinearProgressIndicator(progress = { bond }, color = AC, trackColor = Color(0x33FFFFFF), modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)))
    }
}

@Composable
private fun StatBox(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(label, color = Color(0xAAFFFFFF), fontSize = 11.sp)
    }
}

// ====================================================================== PHONE UNLOCK (settings)
@Composable
fun PatternPad(onDone: (String) -> Unit) {
    var seq by remember { mutableStateOf(listOf<Int>()) }
    var cur by remember { mutableStateOf<Offset?>(null) }
    var sizePx by remember { mutableStateOf(1f) }
    val acc = AC
    fun hit(o: Offset): Int {
        val c = sizePx / 3f
        val col = (o.x / c).toInt().coerceIn(0, 2); val row = (o.y / c).toInt().coerceIn(0, 2)
        val d = kotlin.math.hypot(o.x - (col + 0.5f) * c, o.y - (row + 0.5f) * c)
        return if (d < c * 0.34f) row * 3 + col else -1
    }
    Canvas(Modifier.size(240.dp).clip(RoundedCornerShape(16.dp)).background(Color(0x22FFFFFF)).onSizeChanged { sizePx = it.width.toFloat() }
        .pointerInput(Unit) {
            detectDragGestures(
                onDragStart = { o -> seq = emptyList(); cur = o; val h = hit(o); if (h >= 0) seq = listOf(h) },
                onDrag = { ch, _ -> cur = ch.position; val h = hit(ch.position); if (h >= 0 && h !in seq) seq = seq + h },
                onDragEnd = { cur = null; onDone(seq.joinToString("") { (it + 1).toString() }) },
                onDragCancel = { cur = null })
        }) {
        val c = size.width / 3f
        fun p(i: Int) = Offset((i % 3 + 0.5f) * c, (i / 3 + 0.5f) * c)
        for (k in 0 until seq.size - 1) drawLine(acc, p(seq[k]), p(seq[k + 1]), 8f)
        val last = seq.lastOrNull(); val cu = cur
        if (last != null && cu != null) drawLine(acc.copy(alpha = 0.5f), p(last), cu, 8f)
        for (i in 0 until 9) drawCircle(if (i in seq) acc else Color(0x99FFFFFF), if (i in seq) 16f else 11f, p(i))
    }
}

@Composable
fun UnlockBlock(app: AppState) {
    val scope = rememberCoroutineScope()
    var on by remember { mutableStateOf(Prefs.unlockOn) }
    var type by remember { mutableStateOf(Prefs.unlockType) }
    var input by remember { mutableStateOf("") }
    var pattern by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(Prefs.unlockData.isNotEmpty()) }
    var msg by remember { mutableStateOf("") }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("Phone unlock ON", color = Color.White, fontSize = 14.sp)
            Text("Bolo: \"phone unlock karo\" ya Tools me Unlock dabao - Makima screen jagakar lock khol degi", color = Color(0x99FFFFFF), fontSize = 12.sp)
        }
        Switch(on, { on = it; Prefs.unlockOn = it }, colors = SwitchDefaults.colors(checkedTrackColor = AC, checkedThumbColor = Color.White))
    }
    Text("Lock ka type", color = Color.White, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp, bottom = 4.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("PIN", "Pattern", "Password").forEachIndexed { i, n -> Chip(n, type == i, AC) { type = i; Prefs.unlockType = i; input = ""; pattern = "" } }
    }
    when (type) {
        0 -> Field(input, { v -> input = v.filter { it.isDigit() }.take(16) }, "Phone ka PIN", AC, secret = true, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
        2 -> Field(input, { input = it }, "Phone ka password", AC, secret = true, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
        else -> Column(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Neeche apna unlock pattern draw karo (kam se kam 4 dot)", color = Color(0xAAFFFFFF), fontSize = 12.sp)
            Spacer(Modifier.height(6.dp))
            PatternPad { pattern = it }
            if (pattern.isNotEmpty()) Text("Pattern: " + pattern.toCharArray().joinToString(" - "), color = AC, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
        }
    }
    Button(onClick = {
        val v = if (type == 1) pattern else input
        if ((type == 1 && v.length < 4) || (type == 0 && v.length < 4) || (type == 2 && v.isEmpty())) { msg = "Pehle sahi lock daalo" }
        else { Prefs.unlockData = Vault.enc(v); Prefs.unlockType = type; saved = true; input = ""; msg = "Lock save ho gaya (phone me encrypted)" }
    }, colors = ButtonDefaults.buttonColors(containerColor = AC), modifier = Modifier.padding(top = 8.dp)) { Text("Lock save karo") }
    if (saved) {
        Text("Saved: " + listOf("PIN", "Pattern", "Password")[Prefs.unlockType.coerceIn(0, 2)], color = Color(0xFF7CFFA0), fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
            OutlinedButton(onClick = {
                msg = "Screen lock ho rahi hai, 3 second me unlock try hoga..."
                scope.launch(Dispatchers.IO) {
                    Agent.run(app.ctx, "lock", ""); Thread.sleep(3000)
                    val r = Agent.run(app.ctx, "unlock", ""); msg = r.removePrefix("FAIL: ")
                }
            }) { Text("Test (lock karke unlock)", color = Color.White) }
            OutlinedButton(onClick = { Prefs.unlockData = ""; saved = false; on = false; Prefs.unlockOn = false; msg = "Saved lock hata diya" }) { Text("Hatao", color = Color(0xFFFF8A8A)) }
        }
    }
    if (msg.isNotEmpty()) Text(msg, color = Color(0xFFFFD6DD), fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
    Text("Dhyan do: ye ON ho to jo bhi phone ke paas \"unlock karo\" bole wo phone khol sakta hai. Lock phone me Android Keystore se encrypted rehta hai, kahin bheja nahi jata. Accessibility ON honi chahiye; fingerprint/face se ye nahi hota, aur kuch phones lock screen ko accessibility se chhupate hain - wahan ye kaam nahi karega.",
        color = Color(0x88FFFFFF), fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
}
