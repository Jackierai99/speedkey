package com.makimaos.app
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Keeps one AppState alive so listening continues when the activity is closed. */
object AppHolder {
    var app: AppState? = null
    var autoStarted = false
    @Volatile var fg = false                 // MainActivity is on screen
    var wakePending by mutableStateOf(false) // "Hey Makima" was heard: switch hands-free on as soon as the app is ready
    @Volatile var wakeAt = 0L
    fun get(ctx: Context): AppState {
        app?.let { return it }
        Prefs.init(ctx.applicationContext)
        return AppState(ctx.applicationContext).also { app = it }
    }
}
