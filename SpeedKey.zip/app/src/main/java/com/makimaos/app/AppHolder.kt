package com.makimaos.app
import android.content.Context

/** Keeps one AppState alive so listening continues when the activity is closed. */
object AppHolder {
    var app: AppState? = null
    var autoStarted = false
    fun get(ctx: Context): AppState {
        app?.let { return it }
        Prefs.init(ctx.applicationContext)
        return AppState(ctx.applicationContext).also { app = it }
    }
}
