package com.makimaos.app
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.PowerManager
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

/** Lets Makima see the screen and tap / type / scroll in any app. */
class MakimaAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: MakimaAccessibilityService? = null }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun norm(s: CharSequence?): String = (s?.toString() ?: "").lowercase().trim()

    private fun walk(n: AccessibilityNodeInfo?, depth: Int = 0, f: (AccessibilityNodeInfo) -> Unit) {
        if (n == null || depth > 45) return
        f(n)
        for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1, f)
    }

    private fun roots(): List<AccessibilityNodeInfo> {
        val l = mutableListOf<AccessibilityNodeInfo>()
        rootInActiveWindow?.let { l.add(it) }
        if (l.isEmpty()) {
            try { for (w in windows) w.root?.let { l.add(it) } } catch (_: Exception) {}
        }
        return l
    }

    fun activePackage(): String? = rootInActiveWindow?.packageName?.toString()

    // ------------------------------------------------------------------ find
    fun findNode(label: String, exactOnly: Boolean = false): AccessibilityNodeInfo? {
        val q = norm(label)
        if (q.isEmpty()) return null
        for (root in roots()) {
            var best: AccessibilityNodeInfo? = null
            var bestScore = 0
            walk(root) { n ->
                val t = norm(n.text); val d = norm(n.contentDescription)
                val id = (n.viewIdResourceName ?: "").lowercase()
                var s = 0
                if (t == q || d == q) s = 100
                else if (!exactOnly) {
                    if (t.startsWith(q) || d.startsWith(q)) s = 80
                    else if (t.contains(q) || d.contains(q)) s = 60
                    else if (id.endsWith("/$q")) s = 50
                }
                if (s > 0 && n.isVisibleToUser) {
                    if (n.isClickable || n.isEditable) s += 5
                    if (s > bestScore) { best = n; bestScore = s }
                }
            }
            if (best != null) return best
        }
        return null
    }

    private fun clickableParent(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var c: AccessibilityNodeInfo? = node
        var guard = 0
        while (c != null && !c.isClickable && guard < 10) { c = c.parent; guard++ }
        return if (c != null && c.isClickable) c else null
    }

    private fun centerTap(n: AccessibilityNodeInfo, hold: Long): Boolean {
        val r = Rect(); n.getBoundsInScreen(r)
        if (r.width() <= 0 || r.height() <= 0) return false
        return tapAt(r.centerX().toFloat(), r.centerY().toFloat(), hold)
    }

    // ------------------------------------------------------------------ actions
    fun tap(label: String): Boolean {
        val node = findNode(label) ?: return false
        val c = clickableParent(node)
        if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        return centerTap(node, 60)
    }

    fun longPress(label: String): Boolean {
        val node = findNode(label) ?: return false
        var c: AccessibilityNodeInfo? = node
        var g = 0
        while (c != null && !c.isLongClickable && g < 10) { c = c.parent; g++ }
        if (c != null && c.isLongClickable && c.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK)) return true
        return centerTap(node, 800)
    }

    fun clickDescContains(sub: String): Boolean {
        val q = sub.lowercase()
        for (root in roots()) {
            var hit: AccessibilityNodeInfo? = null
            walk(root) { n ->
                if (hit == null && n.isVisibleToUser && norm(n.contentDescription).contains(q)) hit = n
            }
            val h = hit
            if (h != null) {
                val c = clickableParent(h)
                if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                if (centerTap(h, 60)) return true
            }
        }
        return false
    }

    fun tapAt(x: Float, y: Float, hold: Long = 60): Boolean {
        val p = Path().apply { moveTo(x, y) }
        val ok = dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, maxOf(1L, hold))).build(), null, null)
        try { Thread.sleep(hold + 250) } catch (_: InterruptedException) {}
        return ok
    }

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, dur: Long = 320): Boolean {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val ok = dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, dur)).build(), null, null)
        try { Thread.sleep(dur + 300) } catch (_: InterruptedException) {}
        return ok
    }

    /** dir: down / up (page content) or left / right (next / previous page). */
    fun scroll(dir: String): Boolean {
        val d = dir.lowercase().trim()
        val root = rootInActiveWindow
        if (root != null && (d == "down" || d == "up")) {
            var target: AccessibilityNodeInfo? = null
            var area = 0
            walk(root) { n ->
                if (n.isScrollable && n.isVisibleToUser) {
                    val r = Rect(); n.getBoundsInScreen(r)
                    val a = r.width() * r.height()
                    if (a > area) { area = a; target = n }
                }
            }
            val t = target
            if (t != null && t.performAction(if (d == "down") AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)) {
                try { Thread.sleep(400) } catch (_: InterruptedException) {}
                return true
            }
        }
        val m = resources.displayMetrics
        val w = m.widthPixels.toFloat(); val h = m.heightPixels.toFloat()
        return when (d) {
            "down" -> swipe(w / 2, h * 0.72f, w / 2, h * 0.28f)
            "up" -> swipe(w / 2, h * 0.28f, w / 2, h * 0.72f)
            "left" -> swipe(w * 0.25f, h / 2, w * 0.75f, h / 2)
            "right" -> swipe(w * 0.75f, h / 2, w * 0.25f, h / 2)
            else -> false
        }
    }

    // ------------------------------------------------------------------ smart scrolling (v4)
    /** Short fingerprint of what is readable on screen: tells us whether a scroll really moved anything. */
    private fun screenSig(): String {
        val root = rootInActiveWindow ?: return ""
        val sb = StringBuilder(); var c = 0
        walk(root) { n ->
            if (c < 80 && n.isVisibleToUser) {
                val t = (n.text?.toString() ?: n.contentDescription?.toString() ?: "").take(30)
                if (t.isNotBlank()) { sb.append(t).append('|'); c++ }
            }
        }
        return sb.toString()
    }

    /** The biggest scrollable area on screen (a list, a feed ...) or the whole content area. */
    private fun scrollArea(): Rect {
        val m = resources.displayMetrics
        var r = Rect(0, (m.heightPixels * 0.12f).toInt(), m.widthPixels, (m.heightPixels * 0.92f).toInt())
        val root = rootInActiveWindow ?: return r
        var best: Rect? = null; var area = 0
        walk(root) { n ->
            if (n.isScrollable && n.isVisibleToUser) {
                val b = Rect(); n.getBoundsInScreen(b)
                val a = b.width() * b.height()
                if (a > area) { area = a; best = b }
            }
        }
        val b = best
        if (b != null && area.toFloat() > m.widthPixels * m.heightPixels * 0.12f) r = b
        return r
    }

    private fun scrollGesture(d: String, fast: Boolean): Boolean {
        val r = scrollArea()
        val cx = (r.left + r.right) / 2f; val cy = (r.top + r.bottom) / 2f
        val h = r.height().toFloat(); val w = r.width().toFloat()
        val dur = if (fast) 170L else 380L
        return when (d) {
            "down" -> swipe(cx, r.top + h * 0.80f, cx, r.top + h * 0.20f, dur)
            "up" -> swipe(cx, r.top + h * 0.20f, cx, r.top + h * 0.80f, dur)
            "left" -> swipe(r.left + w * 0.2f, cy, r.left + w * 0.8f, cy, dur)
            "right" -> swipe(r.left + w * 0.8f, cy, r.left + w * 0.2f, cy, dur)
            else -> false
        }
    }

    private fun scrollByAction(d: String): Boolean {
        val root = rootInActiveWindow ?: return false
        var target: AccessibilityNodeInfo? = null; var area = 0
        walk(root) { n ->
            if (n.isScrollable && n.isVisibleToUser) {
                val b = Rect(); n.getBoundsInScreen(b)
                val a = b.width() * b.height()
                if (a > area) { area = a; target = n }
            }
        }
        val t = target ?: return false
        val act = when (d) {
            "down", "right" -> AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
            "up", "left" -> AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            else -> return false
        }
        val ok = t.performAction(act)
        try { Thread.sleep(450) } catch (_: InterruptedException) {}
        return ok
    }

    /** One scroll step. True only if the screen really changed (gesture first, then the node's own scroll action as a backup). */
    private fun scrollStep(d: String, fast: Boolean): Boolean {
        val before = screenSig()
        var ok = scrollGesture(d, fast)
        try { Thread.sleep(150) } catch (_: InterruptedException) {}
        var after = screenSig()
        if (before.isNotEmpty() && after == before) { ok = scrollByAction(d); after = screenSig() }
        return ok && !(before.isNotEmpty() && after == before)
    }

    /** arg: down / up / left / right, optional count (down:3), or top / bottom to run to the end of the list. */
    fun scrollSmart(arg: String): String {
        val a = arg.lowercase().trim()
        val times = Regex("(\\d+)").find(a)?.value?.toIntOrNull()?.coerceIn(1, 15) ?: 1
        val edge = when {
            Regex("\\b(top|start|shuru)\\b").containsMatchIn(a) -> "up"
            Regex("\\b(bottom|end)\\b").containsMatchIn(a) -> "down"
            else -> null
        }
        val d = edge ?: when {
            a.contains("up") || a.contains("upar") || a.contains("ऊपर") -> "up"
            a.contains("left") -> "left"
            a.contains("right") -> "right"
            else -> "down"
        }
        val n = if (edge != null) 14 else times
        var moved = 0
        for (i in 0 until n) {
            if (!scrollStep(d, edge != null)) {
                return if (moved > 0 || edge != null) "OK: scrolled $d ($moved moves, end reached)"
                else "FAIL: screen did not move (already at the end, or nothing scrollable here). Try the other direction, {{swipe:...}} or {{screen}}."
            }
            moved++
        }
        return "OK: scrolled $d $moved time(s)"
    }

    /** Scrolls (down first, then up) until the text is visible on screen. */
    fun scrollTo(label: String): String {
        if (findNode(label) != null) return "OK: '$label' already visible"
        for (d in listOf("down", "up")) {
            for (i in 0 until 14) {
                if (!scrollStep(d, false)) break
                if (findNode(label) != null) return "OK: '$label' found (scrolled $d)"
            }
        }
        return "FAIL: '$label' not found after scrolling both ways. Use {{screen}} to read what is there, try another label / synonym / the Settings search bar, or {{research:...}}."
    }

    fun swipeXY(x1: Float, y1: Float, x2: Float, y2: Float): Boolean = swipe(x1, y1, x2, y2, 350)

    private fun focusedInput(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (f != null && f.isEditable) return f
        var first: AccessibilityNodeInfo? = null
        walk(root) { n -> if (first == null && n.isEditable && n.isVisibleToUser) first = n }
        val n = first
        if (n != null) {
            n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        }
        return n
    }

    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = focusedInput(root) ?: return false
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        val ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
        try { Thread.sleep(300) } catch (_: InterruptedException) {}
        return ok
    }

    /** Types the text and reads the box back, so the AI knows it really contains exactly what was dictated. */
    fun typeVerified(text: String): String {
        if (!typeText(text)) return "FAIL: no text box found. Tap the text box first."
        val root = rootInActiveWindow ?: return "OK: typed (could not verify)"
        val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return "OK: typed (could not verify)"
        if (Build.VERSION.SDK_INT >= 26 && node.isShowingHintText) return "FAIL: text box is still empty, tap it and type again"
        val cur = node.text?.toString()?.trim() ?: return "OK: typed (could not verify)"
        return if (cur == text.trim()) "OK: typed exactly" else if (cur.isBlank()) "FAIL: text box is empty after typing, tap it and retry"
               else "OK: box now contains: \"${cur.take(200)}\" (retype if this is not exactly what he said)"
    }

    // ------------------------------------------------------------------ phone unlock (type: 0 PIN, 1 pattern, 2 password)
    private fun tapExact(label: String): Boolean {
        val node = findNode(label, true) ?: return false
        val c = clickableParent(node)
        if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        return centerTap(node, 60)
    }

    private fun enterPin(pin: String): String {
        for (d in pin) {
            var ok = tapExact(d.toString())
            if (!ok) {
                val n = rootInActiveWindow?.findAccessibilityNodeInfosByViewId("com.android.systemui:id/key$d")?.firstOrNull()
                if (n != null) { val c = clickableParent(n); ok = (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) || centerTap(n, 60) }
            }
            if (!ok) return "FAIL: lock screen par '$d' wala button nahi mila"
            try { Thread.sleep(120) } catch (_: InterruptedException) {}
        }
        // most phones need Enter/OK after the digits; some submit by themselves
        val enter = rootInActiveWindow?.findAccessibilityNodeInfosByViewId("com.android.systemui:id/key_enter")?.firstOrNull()
        if (enter != null) { val c = clickableParent(enter); if (c != null) c.performAction(AccessibilityNodeInfo.ACTION_CLICK) else centerTap(enter, 60) }
        else if (!tapExact("enter") && !tapExact("ok")) pressEnter()
        return "OK"
    }

    private fun drawPattern(seq: String): String {
        if (seq.length < 4) return "FAIL: pattern save nahi hai"
        var rect: Rect? = null
        for (root in roots()) walk(root) { n ->
            if (rect == null && ((n.className?.toString() ?: "").contains("LockPatternView") || (n.viewIdResourceName ?: "").endsWith("lockPatternView"))) {
                val r = Rect(); n.getBoundsInScreen(r); if (r.width() > 0) rect = r
            }
        }
        val m = resources.displayMetrics
        val r = rect ?: Rect((m.widthPixels * 0.1f).toInt(), (m.heightPixels * 0.40f).toInt(), (m.widthPixels * 0.9f).toInt(), (m.heightPixels * 0.40f + m.widthPixels * 0.8f).toInt())
        val cw = r.width() / 3f; val ch = r.height() / 3f
        val path = Path()
        seq.forEachIndexed { i, c ->
            val idx = (c - '1').coerceIn(0, 8)
            val x = r.left + (idx % 3 + 0.5f) * cw; val y = r.top + (idx / 3 + 0.5f) * ch
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        val dur = (seq.length * 220L).coerceIn(700L, 2500L)
        val ok = dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, dur)).build(), null, null)
        try { Thread.sleep(dur + 400) } catch (_: InterruptedException) {}
        return if (ok) "OK" else "FAIL: pattern gesture nahi chala"
    }

    private fun enterPassword(pw: String): String {
        val r = typeVerified(pw)
        if (r.startsWith("FAIL")) return r
        try { Thread.sleep(200) } catch (_: InterruptedException) {}
        pressEnter()
        return "OK"
    }

    /** Wakes the screen, opens the lock screen keypad and enters the saved PIN / pattern / password. Returns "OK..." or "FAIL: ...". */
    fun unlockPhone(type: Int, secret: String): String {
        if (secret.isEmpty()) return "FAIL: Settings me pehle lock save karo"
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!pm.isInteractive) {
            @Suppress("DEPRECATION")
            val wl = pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE, "makimaos:unlock")
            wl.acquire(6000)
            try { Thread.sleep(1000) } catch (_: InterruptedException) {}
        }
        if (!km.isKeyguardLocked) return "OK: phone pehle se unlock hai"
        val m = resources.displayMetrics
        val w = m.widthPixels.toFloat(); val h = m.heightPixels.toFloat()
        swipe(w / 2, h * 0.85f, w / 2, h * 0.25f, 350)
        try { Thread.sleep(700) } catch (_: InterruptedException) {}
        val res = when (type) { 0 -> enterPin(secret); 1 -> drawPattern(secret); else -> enterPassword(secret) }
        try { Thread.sleep(800) } catch (_: InterruptedException) {}
        return if (!km.isKeyguardLocked) "OK: unlock ho gaya" else if (res.startsWith("FAIL")) res else "FAIL: lock screen abhi bhi band hai - saved lock ya screen check karo"
    }

    fun paste(): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = focusedInput(root) ?: return false
        return node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
    }

    fun pressEnter(): Boolean {
        val root = rootInActiveWindow ?: return false
        val f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (f != null && Build.VERSION.SDK_INT >= 30) {
            if (f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)) {
                try { Thread.sleep(400) } catch (_: InterruptedException) {}
                return true
            }
        }
        for (l in listOf("search", "send", "go", "done", "submit")) {
            val n = findNode(l, true) ?: continue
            val c = clickableParent(n)
            if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            if (centerTap(n, 60)) return true
        }
        return false
    }

    // ------------------------------------------------------------------ read screen
    fun dump(): String {
        val root = rootInActiveWindow ?: return "FAIL: screen not readable right now (no active window)."
        val dm = resources.displayMetrics
        val sb = StringBuilder("Foreground app: ").append(root.packageName).append('\n')
        var count = 0
        walk(root) { n ->
            if (count < 70 && n.isVisibleToUser) {
                val t = (n.text?.toString() ?: "").take(70)
                val d = (n.contentDescription?.toString() ?: "").take(70)
                if (t.isNotBlank() || d.isNotBlank() || n.isEditable) {
                    val r = Rect(); n.getBoundsInScreen(r)
                    val kind = if (n.isEditable) "input" else if (n.isClickable) "tap" else if (n.isScrollable) "scroll" else "text"
                    val label = (if (t.isNotBlank()) t else d).replace("\n", " ")
                    sb.append("- ").append(kind).append(": \"").append(label).append("\" @")
                        .append(String.format(Locale.US, "%.2f,%.2f", r.centerX().toFloat() / dm.widthPixels, r.centerY().toFloat() / dm.heightPixels))
                        .append('\n')
                    count++
                }
            }
        }
        if (count == 0) sb.append("(no readable text on screen; it may be a game, video or protected screen)")
        return sb.toString().take(4500)
    }
}
