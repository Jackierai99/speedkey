package com.makimaos.app
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

/** Lets Makima see the screen and tap / type / scroll in any app. */
class MakimaAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: MakimaAccessibilityService? = null }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun norm(s: CharSequence?): String = (s?.toString() ?: "").lowercase().trim()

    private fun walk(n: AccessibilityNodeInfo?, depth: Int = 0, f: (AccessibilityNodeInfo) -> Unit) {
        if (n == null || depth > 45) return
        f(n)
        for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1, f)
    }

    private fun roots(): List<AccessibilityNodeInfo> {
        val l = mutableListOf<AccessibilityNodeInfo>()
        rootInActiveWindow?.let { l.add(it) }
        if (l.isEmpty()) {
            try { for (w in windows) w.root?.let { l.add(it) } } catch (_: Exception) {}
        }
        return l
    }

    fun activePackage(): String? = rootInActiveWindow?.packageName?.toString()

    // ------------------------------------------------------------------ find
    fun findNode(label: String, exactOnly: Boolean = false): AccessibilityNodeInfo? {
        val q = norm(label)
        if (q.isEmpty()) return null
        for (root in roots()) {
            var best: AccessibilityNodeInfo? = null
            var bestScore = 0
            walk(root) { n ->
                val t = norm(n.text); val d = norm(n.contentDescription)
                val id = (n.viewIdResourceName ?: "").lowercase()
                var s = 0
                if (t == q || d == q) s = 100
                else if (!exactOnly) {
                    if (t.startsWith(q) || d.startsWith(q)) s = 80
                    else if (t.contains(q) || d.contains(q)) s = 60
                    else if (id.endsWith("/$q")) s = 50
                }
                if (s > 0 && n.isVisibleToUser) {
                    if (n.isClickable || n.isEditable) s += 5
                    if (s > bestScore) { best = n; bestScore = s }
                }
            }
            if (best != null) return best
        }
        return null
    }

    private fun clickableParent(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var c: AccessibilityNodeInfo? = node
        var guard = 0
        while (c != null && !c.isClickable && guard < 10) { c = c.parent; guard++ }
        return if (c != null && c.isClickable) c else null
    }

    private fun centerTap(n: AccessibilityNodeInfo, hold: Long): Boolean {
        val r = Rect(); n.getBoundsInScreen(r)
        if (r.width() <= 0 || r.height() <= 0) return false
        return tapAt(r.centerX().toFloat(), r.centerY().toFloat(), hold)
    }

    // ------------------------------------------------------------------ actions
    fun tap(label: String): Boolean {
        val node = findNode(label) ?: return false
        val c = clickableParent(node)
        if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        return centerTap(node, 60)
    }

    fun longPress(label: String): Boolean {
        val node = findNode(label) ?: return false
        var c: AccessibilityNodeInfo? = node
        var g = 0
        while (c != null && !c.isLongClickable && g < 10) { c = c.parent; g++ }
        if (c != null && c.isLongClickable && c.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK)) return true
        return centerTap(node, 800)
    }

    fun clickDescContains(sub: String): Boolean {
        val q = sub.lowercase()
        for (root in roots()) {
            var hit: AccessibilityNodeInfo? = null
            walk(root) { n ->
                if (hit == null && n.isVisibleToUser && norm(n.contentDescription).contains(q)) hit = n
            }
            val h = hit
            if (h != null) {
                val c = clickableParent(h)
                if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                if (centerTap(h, 60)) return true
            }
        }
        return false
    }

    fun tapAt(x: Float, y: Float, hold: Long = 60): Boolean {
        val p = Path().apply { moveTo(x, y) }
        val ok = dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, maxOf(1L, hold))).build(), null, null)
        try { Thread.sleep(hold + 250) } catch (_: InterruptedException) {}
        return ok
    }

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, dur: Long = 320): Boolean {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val ok = dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, dur)).build(), null, null)
        try { Thread.sleep(dur + 300) } catch (_: InterruptedException) {}
        return ok
    }

    /** dir: down / up (page content) or left / right (next / previous page). */
    fun scroll(dir: String): Boolean {
        val d = dir.lowercase().trim()
        val root = rootInActiveWindow
        if (root != null && (d == "down" || d == "up")) {
            var target: AccessibilityNodeInfo? = null
            var area = 0
            walk(root) { n ->
                if (n.isScrollable && n.isVisibleToUser) {
                    val r = Rect(); n.getBoundsInScreen(r)
                    val a = r.width() * r.height()
                    if (a > area) { area = a; target = n }
                }
            }
            val t = target
            if (t != null && t.performAction(if (d == "down") AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)) {
                try { Thread.sleep(400) } catch (_: InterruptedException) {}
                return true
            }
        }
        val m = resources.displayMetrics
        val w = m.widthPixels.toFloat(); val h = m.heightPixels.toFloat()
        return when (d) {
            "down" -> swipe(w / 2, h * 0.72f, w / 2, h * 0.28f)
            "up" -> swipe(w / 2, h * 0.28f, w / 2, h * 0.72f)
            "left" -> swipe(w * 0.25f, h / 2, w * 0.75f, h / 2)
            "right" -> swipe(w * 0.75f, h / 2, w * 0.25f, h / 2)
            else -> false
        }
    }

    private fun focusedInput(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (f != null && f.isEditable) return f
        var first: AccessibilityNodeInfo? = null
        walk(root) { n -> if (first == null && n.isEditable && n.isVisibleToUser) first = n }
        val n = first
        if (n != null) {
            n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        }
        return n
    }

    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = focusedInput(root) ?: return false
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        val ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
        try { Thread.sleep(300) } catch (_: InterruptedException) {}
        return ok
    }

    fun paste(): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = focusedInput(root) ?: return false
        return node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
    }

    fun pressEnter(): Boolean {
        val root = rootInActiveWindow ?: return false
        val f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (f != null && Build.VERSION.SDK_INT >= 30) {
            if (f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)) {
                try { Thread.sleep(400) } catch (_: InterruptedException) {}
                return true
            }
        }
        for (l in listOf("search", "send", "go", "done", "submit")) {
            val n = findNode(l, true) ?: continue
            val c = clickableParent(n)
            if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            if (centerTap(n, 60)) return true
        }
        return false
    }

    // ------------------------------------------------------------------ read screen
    fun dump(): String {
        val root = rootInActiveWindow ?: return "FAIL: screen not readable right now (no active window)."
        val dm = resources.displayMetrics
        val sb = StringBuilder("Foreground app: ").append(root.packageName).append('\n')
        var count = 0
        walk(root) { n ->
            if (count < 70 && n.isVisibleToUser) {
                val t = (n.text?.toString() ?: "").take(70)
                val d = (n.contentDescription?.toString() ?: "").take(70)
                if (t.isNotBlank() || d.isNotBlank() || n.isEditable) {
                    val r = Rect(); n.getBoundsInScreen(r)
                    val kind = if (n.isEditable) "input" else if (n.isClickable) "tap" else if (n.isScrollable) "scroll" else "text"
                    val label = (if (t.isNotBlank()) t else d).replace("\n", " ")
                    sb.append("- ").append(kind).append(": \"").append(label).append("\" @")
                        .append(String.format(Locale.US, "%.2f,%.2f", r.centerX().toFloat() / dm.widthPixels, r.centerY().toFloat() / dm.heightPixels))
                        .append('\n')
                    count++
                }
            }
        }
        if (count == 0) sb.append("(no readable text on screen; it may be a game, video or protected screen)")
        return sb.toString().take(4500)
    }
}
