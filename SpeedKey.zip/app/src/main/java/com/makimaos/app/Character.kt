package com.makimaos.app
import android.content.Context
import android.graphics.ImageDecoder
import android.graphics.drawable.Animatable2
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.Drawable
import android.widget.FrameLayout
import android.widget.ImageView

/**
 * Makima's body: short pre-rendered clips (animated WebP with transparent background, res/raw/dm_*.webp).
 * Every clip starts and ends in the same standing pose, so clips can follow each other without a visible jump.
 * What she is doing (listening / thinking / speaking / idle) and the mood tag from the AI decide which clip plays.
 */
class CharacterView(ctx: Context, private val app: AppState, onTap: () -> Unit) : FrameLayout(ctx) {
    companion object {
        private val names = listOf("idle", "blink", "listen", "talk1", "talk2", "talk3", "think_finger", "think_chin",
            "walk_left", "walk_right", "angry", "happy", "tease", "sad", "success", "success2", "surprise", "sulk", "laugh")
        /** True when at least res/raw/dm_idle.webp exists. */
        fun available(c: Context) = c.resources.getIdentifier("dm_idle", "raw", c.packageName) != 0
    }
    // clips are found by name (res/raw/dm_<name>.webp); any clip that is missing simply falls back to idle
    private val ids: Map<String, Int> = names.mapNotNull { n ->
        val id = context.resources.getIdentifier("dm_$n", "raw", context.packageName)
        if (id != 0) n to id else null
    }.toMap()
    private val thinkOrder = listOf("think_finger", "walk_left", "think_chin", "walk_right")
    private val talkOrder = listOf("talk1", "talk2", "talk3")
    private val happyOrder = listOf("happy", "laugh", "success", "success2")
    private var happyIdx = 0

    private var front = newView()
    private var back = newView()
    private var current = ""
    private var lastMode: Mode? = null
    private var token = 0
    private var thinkIdx = 0
    private var talkIdx = 0
    private var idleCount = 0
    private var moodPlayed: String? = null

    init {
        addView(back); addView(front)
        back.alpha = 0f
        setOnClickListener { onTap() }
        play("idle", 0L)
    }

    private fun newView() = ImageView(context).apply {
        scaleType = ImageView.ScaleType.FIT_CENTER
        layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
    }

    /** Called from Compose whenever the assistant state changes. */
    fun setMode(m: Mode) {
        if (m == lastMode) return
        lastMode = m
        play(pick(m), 220L)
    }

    private fun pick(m: Mode): String {
        if (app.mood == null) moodPlayed = null
        return when (m) {
            Mode.LISTEN -> "listen"
            Mode.THINK -> thinkOrder[thinkIdx++ % thinkOrder.size]
            Mode.SPEAK -> {
                var md = Feelings.clip(app.mood)
                if (md == "happy") md = happyOrder[happyIdx++ % happyOrder.size]
                if (md == "angry" && happyIdx % 2 == 1) md = "sulk"
                if (md != null && md != moodPlayed && ids.containsKey(md)) { moodPlayed = md; md }
                else talkOrder[talkIdx++ % talkOrder.size]
            }
            Mode.IDLE -> {
                idleCount++
                if (idleCount % 4 == 0) "blink" else "idle"
            }
        }
    }

    private fun play(name: String, fadeMs: Long) {
        val res = ids[name] ?: ids["idle"] ?: return
        val d: Drawable = try {
            ImageDecoder.decodeDrawable(ImageDecoder.createSource(resources, res))
        } catch (_: Throwable) { return }
        val my = ++token
        current = name
        if (d is AnimatedImageDrawable) {
            d.repeatCount = 0
            d.registerAnimationCallback(object : Animatable2.AnimationCallback() {
                override fun onAnimationEnd(drawable: Drawable?) {
                    // the clip finished: continue with the next one for whatever she is doing right now
                    if (my == token) post { play(pick(app.mode), 140L) }
                }
            })
        }
        val old = front
        val fresh = back
        // cancel first: a cancelled fade-out runs its end action, which must not touch the new drawable
        fresh.animate().cancel()
        old.animate().cancel()
        fresh.setImageDrawable(d)
        fresh.alpha = 0f
        fresh.bringToFront()
        (d as? AnimatedImageDrawable)?.start()
        fresh.animate().alpha(1f).setDuration(fadeMs).start()
        old.animate().alpha(0f).setDuration(fadeMs).withEndAction {
            (old.drawable as? AnimatedImageDrawable)?.stop()
            if (old !== front) old.setImageDrawable(null)
        }.start()
        front = fresh
        back = old
    }

    override fun onDetachedFromWindow() {
        token++
        (front.drawable as? AnimatedImageDrawable)?.stop()
        (back.drawable as? AnimatedImageDrawable)?.stop()
        super.onDetachedFromWindow()
    }
}
