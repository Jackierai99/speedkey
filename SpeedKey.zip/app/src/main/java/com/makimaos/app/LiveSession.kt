package com.makimaos.app
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.util.Base64
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.math.sqrt

/**
 * Real live voice mode (Gemini Live API). Your voice streams straight to the model and her voice streams straight back:
 * no speech-to-text, no text-to-speech step, so she answers almost at once, can be interrupted mid-sentence,
 * and hears the tone of your voice. She can also operate the phone: the model calls the `phone` tool and we run it with Agent.
 */
class LiveCallbacks(
    val onReady: () -> Unit,
    val onUser: (String) -> Unit,          // what you are saying (live transcript)
    val onReply: (String) -> Unit,         // what she is saying (live transcript)
    val onTurn: (String, String) -> Unit,  // one finished exchange: your words, her words
    val onSpeaking: (Boolean) -> Unit,
    val onMic: (Float) -> Unit,
    val onWorking: (Boolean) -> Unit,      // a phone action is running
    val onClosed: (String, Boolean) -> Unit // reason, worth retrying
)

class LiveSession(
    private val ctx: Context,
    private val scope: CoroutineScope,
    cb0: LiveCallbacks
) {
    @Volatile private var cb: LiveCallbacks = cb0
    /** A pre-connected (standby) session is handed to a new owner here. */
    fun rebind(c: LiveCallbacks) { cb = c }
    val alive: Boolean get() = !closed
    private val readyNotified = java.util.concurrent.atomic.AtomicBoolean(false)
    @Volatile private var activated = true
    private val pre = java.util.ArrayDeque<ByteArray>()      // mic audio captured while the connection is still opening
    companion object {
        private val client: OkHttpClient by lazy {
            OkHttpClient.Builder().readTimeout(0, TimeUnit.MILLISECONDS).pingInterval(20, TimeUnit.SECONDS).build()
        }
        private const val HOST = "generativelanguage.googleapis.com"
    }

    @Volatile private var closed = false
    @Volatile private var ready = false
    @Volatile var speakingNow = false
        private set
    private var ws: WebSocket? = null
    private var model = ""
    private var textViaRealtime = true
    private var minimal = false
    private val userBuf = StringBuilder()
    private val replyBuf = StringBuilder()

    private var rec: AudioRecord? = null
    private var aec: AcousticEchoCanceler? = null
    private var ns: NoiseSuppressor? = null
    private var agc: AutomaticGainControl? = null
    private var micThread: Thread? = null
    private var outThread: Thread? = null
    @Volatile private var track: AudioTrack? = null
    private val q = LinkedBlockingQueue<ByteArray>()
    @Volatile private var gen = 0
    @Volatile private var wrote = 0L
    private val lvQ = java.util.ArrayDeque<Pair<Long, Float>>()
    private var oldMode = AudioManager.MODE_NORMAL
    private var oldSpeaker = false
    private var audioSet = false

    // ------------------------------------------------------------------ connect
    fun start(minimalSetup: Boolean = false, standby: Boolean = false) {
        minimal = minimalSetup
        activated = !standby
        scope.launch(Dispatchers.IO) {
            try {
                val key = Prefs.key("Gemini")
                if (key.isBlank()) { finish("Gemini key nahi hai", false); return@launch }
                model = Prefs.liveModel.ifBlank { pickModel(key) }
                if (model.isBlank()) { finish("Live model nahi mila", false); return@launch }
                Prefs.liveModel = model
                textViaRealtime = !(model.contains("2.5") || model.contains("2.0"))
                val url = "wss://$HOST/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=$key"
                ws = client.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
                    override fun onOpen(webSocket: WebSocket, response: Response) { webSocket.send(setupJson()) }
                    override fun onMessage(webSocket: WebSocket, text: String) { handle(text) }
                    override fun onMessage(webSocket: WebSocket, bytes: ByteString) { handle(bytes.utf8()) }
                    override fun onClosing(webSocket: WebSocket, code: Int, reason: String) { webSocket.close(1000, null); end(code, reason) }
                    override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { end(code, reason) }
                    override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                        end(if (response != null) response.code else -1, t.message ?: "network error")
                    }
                })
                // the mic starts while the socket is still opening, so the first words you say are not lost
                if (!standby) startAudio()
            } catch (e: Exception) {
                finish(e.message ?: "connect error", false)
            }
        }
    }

    /** Standby session -> real call: mic on, tell the owner it is ready. */
    fun activate() {
        scope.launch(Dispatchers.IO) {
            if (closed) return@launch
            activated = true
            startAudio()
            if (ready) notifyReady()
        }
    }

    private fun notifyReady() { if (readyNotified.compareAndSet(false, true)) cb.onReady() }

    /** Asks Google which models speak "live" for this key and takes the newest one. */
    private fun pickModel(key: String): String {
        val c = client.newBuilder().readTimeout(15, TimeUnit.SECONDS).build()
        val req = Request.Builder().url("https://$HOST/v1beta/models?pageSize=200").header("x-goog-api-key", key).build()
        val body = c.newCall(req).execute().use { r -> if (!r.isSuccessful) return "" else r.body?.string() ?: "" }
        val arr = JSONObject(body).optJSONArray("models") ?: return ""
        var best = ""; var bs = -1.0
        for (i in 0 until arr.length()) {
            val m = arr.getJSONObject(i)
            val ms = m.optJSONArray("supportedGenerationMethods") ?: continue
            if ((0 until ms.length()).none { ms.getString(it).equals("bidiGenerateContent", true) }) continue
            val name = m.optString("name").removePrefix("models/")
            val l = name.lowercase()
            if (l.contains("translate") || l.contains("image") || l.contains("video")) continue
            val ver = Regex("(\\d+(?:\\.\\d+)?)").find(l)?.value?.toDoubleOrNull() ?: 0.0
            val s = ver * 10 + (if (l.contains("live")) 3 else if (l.contains("native-audio")) 2 else 0) - (if (l.contains("preview")) 0.5 else 0.0)
            if (s > bs) { bs = s; best = name }
        }
        return best
    }

    private fun setupJson(): String {
        val setup = JSONObject()
        setup.put("model", "models/$model")
        setup.put("generationConfig", JSONObject()
            .put("responseModalities", JSONArray().put("AUDIO"))
                .put("temperature", 0.4)
            .put("speechConfig", JSONObject().put("voiceConfig", JSONObject()
                .put("prebuiltVoiceConfig", JSONObject().put("voiceName", Prefs.geminiVoice)))))
        setup.put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", Brain.liveSystem()))))
        val decl = JSONArray()
        if (Prefs.phoneControl) {
            decl.put(JSONObject().put("name", "phone")
                .put("description", "Operate the user's Android phone. action = one action name (open, url, youtube, search, maps, tap, tapxy, long, type, enter, paste, scroll, back, home, recents, notifications, quick, lock, screenshot, power, screen, wait, call, sms, whatsapp, alarm, timer, torch, volume, media, wifi, bluetooth, settings, copy). arg = its argument, empty if none. Returns the result text.")
                .put("parameters", JSONObject().put("type", "OBJECT")
                    .put("properties", JSONObject()
                        .put("action", JSONObject().put("type", "STRING").put("description", "action name, for example open or youtube or tap or screen"))
                        .put("arg", JSONObject().put("type", "STRING").put("description", "argument, for example the app name or the text to tap")))
                    .put("required", JSONArray().put("action"))))
        }
        decl.put(JSONObject().put("name", "remember")
            .put("description", "Save a short personal fact about the user (name, likes, plans, birthdays) so it is remembered in future chats.")
            .put("parameters", JSONObject().put("type", "OBJECT")
                .put("properties", JSONObject().put("fact", JSONObject().put("type", "STRING").put("description", "the fact, short")))
                .put("required", JSONArray().put("fact"))))
        if (Prefs.phoneControl) decl.put(JSONObject().put("name", "autopilot")
            .put("description", "Hand over a long or multi-step job so it is finished alone in the background, even after the call ends. Write the complete job in task.")
            .put("parameters", JSONObject().put("type", "OBJECT")
                .put("properties", JSONObject().put("task", JSONObject().put("type", "STRING").put("description", "the full job, with every detail needed")))
                .put("required", JSONArray().put("task"))))
        setup.put("tools", JSONArray().put(JSONObject().put("functionDeclarations", decl)))
        if (!minimal) {
            setup.put("inputAudioTranscription", JSONObject())
            setup.put("outputAudioTranscription", JSONObject())
            setup.put("realtimeInputConfig", JSONObject().put("automaticActivityDetection", JSONObject().put("silenceDurationMs", 320).put("prefixPaddingMs", 200).put("startOfSpeechSensitivity", "START_SENSITIVITY_HIGH")))
        }
        return JSONObject().put("setup", setup).toString()
    }

    // ------------------------------------------------------------------ messages from the model
    private fun handle(text: String) {
        val j = try { JSONObject(text) } catch (_: Exception) { return }
        if (j.has("setupComplete")) {
            ready = true
            if (activated) notifyReady()
            return
        }
        j.optJSONObject("toolCall")?.let { runTools(it) }
        val sc = j.optJSONObject("serverContent") ?: return
        if (sc.optBoolean("interrupted")) {
            interrupt()
            val r = replyBuf.toString().trim(); replyBuf.setLength(0)
            if (r.isNotEmpty()) cb.onTurn("", r)
        }
        val parts = sc.optJSONObject("modelTurn")?.optJSONArray("parts")
        if (parts != null) {
            for (i in 0 until parts.length()) {
                val d = parts.getJSONObject(i).optJSONObject("inlineData")?.optString("data", "") ?: ""
                if (d.isNotEmpty()) enqueue(Base64.decode(d, Base64.DEFAULT))
            }
        }
        sc.optJSONObject("inputTranscription")?.optString("text", "")?.takeIf { it.isNotEmpty() }?.let {
            userBuf.append(it); cb.onUser(userBuf.toString().trim())
        }
        sc.optJSONObject("outputTranscription")?.optString("text", "")?.takeIf { it.isNotEmpty() }?.let {
            replyBuf.append(it); cb.onReply(replyBuf.toString().trim())
        }
        if (sc.optBoolean("turnComplete")) {
            val u = userBuf.toString().trim(); val r = replyBuf.toString().trim()
            userBuf.setLength(0); replyBuf.setLength(0)
            cb.onTurn(u, r)
        }
    }

    private fun runTools(tc: JSONObject) {
        val calls = tc.optJSONArray("functionCalls") ?: return
        scope.launch(Dispatchers.IO) {
            cb.onWorking(true)
            val resp = JSONArray()
            for (i in 0 until calls.length()) {
                val c = calls.getJSONObject(i)
                val id = c.optString("id"); val name = c.optString("name")
                val args = c.optJSONObject("args") ?: JSONObject()
                val result = try {
                    when (name) {
                        "phone" -> Agent.run(ctx, args.optString("action").trim().trim('{', '}').lowercase(), args.optString("arg").trim())
                        "remember" -> { Feelings.remember(args.optString("fact")); "OK" }
                        "autopilot" -> AutoPilot.runTask(ctx, args.optString("task").trim())
                        else -> "FAIL: unknown tool $name"
                    }
                } catch (e: Exception) { "FAIL: ${e.message ?: e.javaClass.simpleName}" }
                resp.put(JSONObject().put("id", id).put("name", name).put("response", JSONObject().put("result", result.take(6000) + " [If the job is not finished, do the next step now without speaking. Speak only once, when the whole job is done.]")))
            }
            cb.onWorking(false)
            if (!closed) ws?.send(JSONObject().put("toolResponse", JSONObject().put("functionResponses", resp)).toString())
        }
    }

    /** A line of text from us (typed message, or a silence / greeting event). */
    fun sendText(t: String) {
        val w = ws ?: return
        if (!ready || closed) return
        val j = if (textViaRealtime) JSONObject().put("realtimeInput", JSONObject().put("text", t))
        else JSONObject().put("clientContent", JSONObject()
            .put("turns", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", t)))))
            .put("turnComplete", true))
        w.send(j.toString())
    }

    // ------------------------------------------------------------------ audio in (mic) and out (speaker)
    private fun routeAudio() {
        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            oldMode = am.mode; oldSpeaker = am.isSpeakerphoneOn
            am.mode = AudioManager.MODE_IN_COMMUNICATION
            val plugged = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any {
                it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET || it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                it.type == AudioDeviceInfo.TYPE_USB_HEADSET || it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO
            }
            if (!plugged) am.isSpeakerphoneOn = true
            audioSet = true
        } catch (_: Exception) {}
    }

    private fun unrouteAudio() {
        if (!audioSet) return
        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.isSpeakerphoneOn = oldSpeaker; am.mode = oldMode
        } catch (_: Exception) {}
        audioSet = false
    }

    private fun startAudio() {
        routeAudio()
        try {
            val minBuf = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val r = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, 16000, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, 6400))
            if (r.state != AudioRecord.STATE_INITIALIZED) { finish("Mic shuru nahi hua", false); return }
            if (AcousticEchoCanceler.isAvailable()) aec = AcousticEchoCanceler.create(r.audioSessionId)?.also { it.enabled = true }
            if (NoiseSuppressor.isAvailable()) ns = NoiseSuppressor.create(r.audioSessionId)?.also { it.enabled = true }
            if (AutomaticGainControl.isAvailable()) agc = AutomaticGainControl.create(r.audioSessionId)?.also { it.enabled = true }
            rec = r
            r.startRecording()
        } catch (e: Exception) { finish("Mic error: ${e.message}", false); return }

        micThread = Thread {
            val buf = ByteArray(1280)                     // 40 ms of 16 kHz speech
            val r = rec ?: return@Thread
            while (!closed) {
                val n = try { r.read(buf, 0, buf.size) } catch (_: Exception) { -1 }
                if (n < 0) break
                if (n == 0) continue
                var sum = 0.0; var i = 0
                while (i + 1 < n) { val v = (buf[i].toInt() and 0xFF) or (buf[i + 1].toInt() shl 8); sum += v.toDouble() * v; i += 2 }
                val rms = sqrt(sum / (n / 2)) / 32768.0
                cb.onMic(((rms * 6.0).toFloat()).coerceIn(0f, 1f))
                // without echo cancelling she would hear herself, so the mic is paused while she talks (no interrupting then)
                if (!ready) {
                    synchronized(pre) { pre.addLast(buf.copyOf(n)); while (pre.size > 40) pre.removeFirst() }
                } else if (aec != null || !speakingNow) {
                    synchronized(pre) { while (pre.isNotEmpty()) { val p = pre.removeFirst(); sendAudio(p, p.size) } }
                    sendAudio(buf, n)
                }
            }
        }.also { it.isDaemon = true; it.start() }

        outThread = Thread {
            while (!closed) {
                try {
                    val c = q.poll(120, TimeUnit.MILLISECONDS)
                    if (c == null) {
                        if (speakingNow) {
                            val t = track
                            if (t == null || t.playbackHeadPosition.toLong() >= wrote) { speakingNow = false; cb.onSpeaking(false) }
                        }
                        continue
                    }
                    val myGen = gen
                    var t = track
                    if (t == null) { t = newTrack(); track = t; t.play() }
                    var off = 0
                    while (off < c.size && !closed && myGen == gen) {
                        val n = t.write(c, off, minOf(4096, c.size - off))
                        if (n <= 0) break
                        recordLevel(c, off, n)
                        off += n
                    }
                    if (myGen == gen) wrote += c.size / 2
                } catch (_: Exception) {}
            }
        }.also { it.isDaemon = true; it.start() }
    }

    private fun sendAudio(b: ByteArray, n: Int) {
        val b64 = Base64.encodeToString(b, 0, n, Base64.NO_WRAP)
        ws?.send("{\"realtimeInput\":{\"audio\":{\"data\":\"$b64\",\"mimeType\":\"audio/pcm;rate=16000\"}}}")
    }

    private fun newTrack(): AudioTrack {
        val sr = 24000
        val minBuf = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        return AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(minBuf, 12288)).setTransferMode(AudioTrack.MODE_STREAM).build()
    }

    private fun enqueue(pcm: ByteArray) {
        if (pcm.isEmpty()) return
        q.put(pcm)
        if (!speakingNow) { speakingNow = true; cb.onSpeaking(true) }
    }

    /** You started talking over her: drop whatever she had left to say, at once. */
    private fun interrupt() {
        gen++
        q.clear()
        val t = track; track = null
        try { t?.pause(); t?.flush(); t?.release() } catch (_: Exception) {}
        wrote = 0L
        synchronized(lvQ) { lvQ.clear() }; lvFrames = 0L
        if (speakingNow) { speakingNow = false; cb.onSpeaking(false) }
    }

    // ---- loudness of her voice right now (drives lip-sync)
    @Volatile private var lvFrames = 0L
    private fun recordLevel(buf: ByteArray, off: Int, n: Int) {
        var sum = 0.0; var cnt = 0; var i = off
        while (i + 1 < off + n) {
            val v = (buf[i].toInt() and 0xFF) or (buf[i + 1].toInt() shl 8)
            sum += v.toDouble() * v; cnt++; i += 2
        }
        val rms = if (cnt > 0) sqrt(sum / cnt) / 32768.0 else 0.0
        lvFrames += n / 2
        synchronized(lvQ) { lvQ.addLast(lvFrames to rms.toFloat()) }
    }
    fun level(): Float {
        val t = track ?: return -1f
        val head = try { t.playbackHeadPosition.toLong() } catch (_: Exception) { return -1f }
        synchronized(lvQ) {
            while (lvQ.size > 1 && lvQ.peekFirst()!!.first < head) lvQ.removeFirst()
            val e = lvQ.peekFirst() ?: return -1f
            if (e.first < head - 2400) return -1f
            return e.second
        }
    }

    // ------------------------------------------------------------------ end of session
    private fun shutdown() {
        closed = true; ready = false
        try { rec?.stop() } catch (_: Exception) {}
        try { rec?.release() } catch (_: Exception) {}
        try { aec?.release(); ns?.release(); agc?.release() } catch (_: Exception) {}
        rec = null; aec = null; ns = null; agc = null
        micThread?.interrupt(); outThread?.interrupt()
        val t = track; track = null
        try { t?.pause(); t?.flush(); t?.release() } catch (_: Exception) {}
        q.clear()
        unrouteAudio()
        try { ws?.close(1000, null) } catch (_: Exception) {}
        if (speakingNow) { speakingNow = false; cb.onSpeaking(false) }
    }

    /** Closed by us (user turned live off): no callbacks. */
    fun close() { shutdown() }

    private fun finish(reason: String, retry: Boolean) {
        if (closed) return
        shutdown()
        cb.onClosed(reason, retry)
    }

    private fun end(code: Int, reason: String) {
        if (closed) return
        val wasReady = ready
        val quota = reason.contains("quota", true) || reason.contains("exhaust", true) || reason.contains("429") || code == 429
        shutdown()
        when {
            quota -> cb.onClosed("Live ki free limit khatam (quota)", false)
            // the server may not like an optional setup field: try once more with the bare minimum
            !wasReady && !minimal && code != -1 -> cb.onClosed("minimal", true)
            wasReady -> cb.onClosed(reason.ifBlank { "connection toota" }.take(100), true)     // dropped mid-chat: reconnect
            else -> cb.onClosed(reason.ifBlank { "connect nahi hua (code $code)" }.take(100), false)
        }
    }
}
