package com.makimaos.app
import android.content.Context
import android.os.BatteryManager

/** Instant, offline commands (no AI needed). Anything it cannot clearly handle goes to the AI agent. */
object Cmd {
    private val openWords = setOf("open", "launch", "start", "khol", "kholo", "kholna", "खोल", "खोलो", "ओपन", "चालू", "chalu", "chalao", "chala", "चलाओ", "चला", "run")
    private val noise = setOf("makima", "doraemon", "doremon", "please", "plz", "app", "the", "ko", "na", "do", "de", "dena", "karo", "kar", "ek", "zara", "jaldi", "mere", "liye", "mujhe", "ji", "boss",
        "जरा", "करो", "कर", "दो", "को", "ऐप", "जी")
    private val alias = mapOf("व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp", "यूट्यूब" to "youtube", "इंस्टाग्राम" to "instagram",
        "क्रोम" to "chrome", "कैमरा" to "camera", "सेटिंग" to "settings", "सेटिंग्स" to "settings", "गैलरी" to "gallery",
        "फोन" to "phone", "मैप्स" to "maps", "जीमेल" to "gmail", "स्पॉटिफाई" to "spotify", "टेलीग्राम" to "telegram", "फेसबुक" to "facebook",
        "गूगल" to "google", "गुगल" to "google")

    private fun act(ctx: Context, name: String, arg: String, ok: String): String {
        val r = Agent.run(ctx, name, arg)
        return when {
            r.startsWith("OK") -> ok
            r.contains("Accessibility service is OFF") -> "Boss, pehle Settings me Doraemon OS Accessibility Service enable karo."
            else -> "Boss, " + r.removePrefix("FAIL: ")
        }
    }

    fun tryHandle(ctx: Context, raw: String): String? {
        val t = raw.lowercase().trim()
        fun has(vararg k: String) = k.any { t.contains(it) }

        Regex("(remember that|remember|yaad rakh(?:na|o)?|याद रख(?:ना|ो)?)", RegexOption.IGNORE_CASE).find(raw)?.let { m ->
            if (m.range.first < 4) {
                val fact = raw.removeRange(m.range).trim().trim('.', ',')
                if (fact.length > 2) { Prefs.memory = (Prefs.memory + "\n" + fact).trim(); return "Theek hai Boss, yaad rakh liya." }
            }
        }
        if (has("unlock", "अनलॉक") && has("phone", "mobile", "screen", "फोन", "मोबाइल", "फ़ोन") || t == "unlock" || t == "unlock karo") return act(ctx, "unlock", "", "Phone unlock kar diya, Boss.")
        if (has("go home", "home screen", "home jao", "होम स्क्रीन", "home par jao")) return act(ctx, "home", "", "Ho gaya Boss.")
        if (has("go back", "back jao", "peeche jao", "पीछे जाओ", "wapas jao", "back karo")) return act(ctx, "back", "", "Peeche aa gayi.")
        if (has("recent apps", "recents")) return act(ctx, "recents", "", "Recent apps, Boss.")
        if (has("notification")) return act(ctx, "notifications", "", "Notifications khol di.")
        if (has("screenshot")) return act(ctx, "screenshot", "", "Screenshot le liya.")
        if (has("scroll down", "neeche scroll", "scroll neeche", "नीचे स्क्रॉल")) return act(ctx, "scroll", "down", "Scroll down.")
        if (has("scroll up", "upar scroll", "scroll upar", "ऊपर स्क्रॉल")) return act(ctx, "scroll", "up", "Scroll up.")
        Regex("^(click|tap|press|dabao|dabana|दबाओ)\\s+(on\\s+)?(.+)$").find(t)?.let { m ->
            val label = m.groupValues[3].trim()
            return act(ctx, "tap", label, "Maine $label dabaya, Boss.")
        }
        if (has("torch", "flashlight", "टॉर्च")) {
            val off = has(" off", "band", "बंद")
            return act(ctx, "torch", if (off) "off" else "on", if (off) "Torch band, Boss." else "Torch on, Boss.")
        }
        if (has("volume up", "volume badha", "awaaz badha", "volume increase")) return act(ctx, "volume", "up", "Volume badha diya.")
        if (has("volume down", "volume kam", "awaaz kam", "volume decrease")) return act(ctx, "volume", "down", "Volume kam kar diya.")
        if (has("wifi settings", "wifi on", "wifi off", "wifi chalu", "wifi band")) return act(ctx, "wifi", "", "Wifi settings khol di.")
        if (has("bluetooth settings", "bluetooth on", "bluetooth off", "bluetooth chalu", "bluetooth band")) return act(ctx, "bluetooth", "", "Bluetooth settings khol di.")
        Regex("(call|dial)\\s+(\\+?[0-9 ]{5,})").find(t)?.let { m ->
            val num = m.groupValues[2].replace(" ", "")
            return act(ctx, "call", num, "Calling $num, Boss.")
        }
        if (has("battery") && has("kitni", "kitna", "level", "percent", "how much", "status", "kya")) {
            val b = Agent.batteryPct(ctx)
            if (b >= 0) return "Battery $b percent hai, ${Prefs.userName}."
        }
        if (has("time kya", "what time", "kitne baje", "samay kya", "टाइम क्या", "कितने बजे")) return "Abhi ${Agent.timeNow()} hue hain, ${Prefs.userName}."

        // "<app> kholo" - only when the words clearly name ONE installed app; anything else (search, play...) goes to the AI
        val tokens = t.split(Regex("\\s+"))
        if (tokens.any { it in openWords }) {
            val q = tokens.filter { it !in openWords && it !in noise }.joinToString(" ") { alias[it] ?: it }.trim()
            if (q.isNotEmpty() && q.split(" ").size <= 3) {
                val hit = Agent.findApp(ctx, q, strict = true)
                if (hit != null) {
                    val r = Agent.run(ctx, "open", hit.label)
                    return if (r.startsWith("OK")) "${hit.label} khol rahi hoon, Boss." else null
                }
            }
        }
        return null
    }
}
