package com.makimaos.app

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Handwriting-style font for titles in the paper-sketch themes. */
val sketchFont: FontFamily get() = if (MakimaTheme.light) FontFamily.Cursive else FontFamily.Default

/** Border that looks hand drawn (two slightly shifted pencil lines) in the paper themes; a normal border otherwise. */
fun Modifier.sketchBorder(width: Dp, color: Color, shape: Shape): Modifier =
    if (!MakimaTheme.light) this.border(width, color, shape)
    else this.drawWithCache {
        val outline = shape.createOutline(size, layoutDirection, this)
        val path = Path()
        when (outline) {
            is Outline.Rounded -> path.addRoundRect(outline.roundRect)
            is Outline.Rectangle -> path.addRect(outline.rect)
            is Outline.Generic -> path.addPath(outline.path)
        }
        val sw = width.toPx()
        onDrawWithContent {
            drawContent()
            drawPath(path, color, style = Stroke(sw))
            withTransform({ rotate(0.5f, center); translate(1.6f, -1.2f) }) {
                drawPath(path, color.copy(alpha = color.alpha * 0.5f), style = Stroke(sw * 0.8f))
            }
        }
    }

fun Modifier.sketchBorder(width: Dp, brush: Brush, shape: Shape): Modifier = this.border(width, brush, shape)

/** Notebook paper (cream, ruled blue lines, red margin) for the light themes; the usual dark gradient otherwise. */
fun DrawScope.drawPaper() {
    if (!MakimaTheme.light) {
        drawRect(Brush.verticalGradient(listOf(MakimaTheme.bg1, MakimaTheme.bg0, Color.Black)))
        return
    }
    drawRect(Brush.verticalGradient(listOf(MakimaTheme.bg0, MakimaTheme.bg1)))
    val step = 30.dp.toPx()
    val line = Color(0xFF8FB3E8).copy(alpha = 0.30f)
    var y = 96.dp.toPx()
    while (y < size.height) { drawLine(line, Offset(0f, y), Offset(size.width, y), 1.2f); y += step }
    val mx = 44.dp.toPx()
    drawLine(Color(0xFFE59A9A).copy(alpha = 0.55f), Offset(mx, 0f), Offset(mx, size.height), 1.6f)
}

fun Modifier.paper(): Modifier = this.drawBehind { drawPaper() }

// ------------------------------------------------------------------ the "magic pocket" (our own original mascot)

private fun pouchPath(c: Offset, r: Float): Path {
    val x = { v: Float -> c.x + v * r }
    val y = { v: Float -> c.y + v * r }
    return Path().apply {
        moveTo(x(-0.95f), y(-0.35f))
        cubicTo(x(-1.05f), y(0.35f), x(-0.6f), y(1.0f), x(0f), y(1.0f))
        cubicTo(x(0.6f), y(1.0f), x(1.05f), y(0.35f), x(0.95f), y(-0.35f))
    }
}

private fun starPath(c: Offset, r: Float): Path = Path().apply {
    for (i in 0 until 10) {
        val a = -1.5707964f + i * 0.62831855f
        val rr = if (i % 2 == 0) r else r * 0.45f
        val px = c.x + cos(a) * rr; val py = c.y + sin(a) * rr
        if (i == 0) moveTo(px, py) else lineTo(px, py)
    }
    close()
}

/** A line drawn twice, slightly shifted, like a pencil going over it again. */
private fun DrawScope.pencil(path: Path, col: Color, w: Float, pivot: Offset) {
    drawPath(path, col, style = Stroke(w, cap = StrokeCap.Round, join = StrokeJoin.Round))
    withTransform({ translate(2f, -1.5f); rotate(0.8f, pivot) }) {
        drawPath(path, col.copy(alpha = col.alpha * 0.5f), style = Stroke(w * 0.7f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

/** Pack 0 emblem: the pocket with two little stars floating out of it. */
fun DrawScope.pocketEmblem(c: Offset, r: Float, col: Color, sw: Float, t: Float) {
    val cc = Offset(c.x, c.y + r * 0.15f)
    pencil(pouchPath(cc, r * 0.85f), col, sw, cc)
    drawOval(col, Offset(cc.x - r * 0.81f, cc.y - r * 0.85f * 0.57f), Size(r * 1.62f, r * 0.85f * 0.44f), style = Stroke(sw))
    for (i in 0 until 2) {
        val ph = (t * 0.4f + i * 0.5f) % 1f
        val sc = Offset(cc.x + (i * 2 - 1) * r * 0.28f + sin(t * 2f + i) * r * 0.05f, cc.y - r * 0.6f - ph * r * 0.7f)
        withTransform({ rotate(ph * 90f, sc) }) {
            drawPath(starPath(sc, r * 0.2f), col.copy(alpha = col.alpha * (1f - ph * 0.8f)), style = Stroke(sw * 0.8f, join = StrokeJoin.Round))
        }
    }
}

/** Placeholder hero for the home screen until real character clips (res/raw/dm_*.webp) are added. Reacts to what the assistant is doing. */
@Composable
fun SketchPocket(mode: Mode, modifier: Modifier = Modifier) {
    val inf = rememberInfiniteTransition(label = "pocket")
    val t by inf.animateFloat(0f, 600f, infiniteRepeatable(tween(600000, easing = LinearEasing)), label = "pt")
    val ink = MakimaTheme.ink
    val acc = MakimaTheme.accent
    Canvas(modifier) {
        val r = min(size.width, size.height) * 0.34f
        val bob = sin(t * 2.2f) * r * 0.03f
        val c = Offset(size.width / 2f, size.height * 0.52f + bob)
        val sw = 4.5f
        // soft fill
        val body = pouchPath(c, r)
        val fill = Path().apply { addPath(body); lineTo(c.x + r * 0.95f, c.y - r * 0.35f); close() }
        drawPath(fill, acc.copy(alpha = 0.13f))
        pencil(body, ink, sw, c)
        drawOval(ink, Offset(c.x - r * 0.95f, c.y - r * 0.57f), Size(r * 1.9f, r * 0.44f), style = Stroke(sw))
        // stitched seam
        val seam = Path().apply {
            moveTo(c.x - r * 0.8f, c.y - r * 0.05f)
            cubicTo(c.x - r * 0.7f, c.y + r * 0.55f, c.x + r * 0.7f, c.y + r * 0.55f, c.x + r * 0.8f, c.y - r * 0.05f)
        }
        drawPath(seam, ink.copy(alpha = 0.55f), style = Stroke(sw * 0.6f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f))))
        // face
        val blink = (t % 4f) < 0.14f
        val ey = c.y + r * 0.22f
        for (sgn in listOf(-1f, 1f)) {
            val ex = c.x + sgn * r * 0.3f
            if (blink) drawLine(ink, Offset(ex - r * 0.09f, ey), Offset(ex + r * 0.09f, ey), sw, StrokeCap.Round)
            else drawCircle(ink, r * 0.085f, Offset(ex, ey - (if (mode == Mode.LISTEN) r * 0.03f else 0f)))
        }
        val my = c.y + r * 0.45f
        when (mode) {
            Mode.SPEAK -> {
                val o = 0.05f + abs(sin(t * 11f)) * 0.13f
                drawOval(ink, Offset(c.x - r * 0.11f, my - r * o / 2f), Size(r * 0.22f, r * o), style = Stroke(sw * 0.8f))
            }
            Mode.THINK -> {
                drawCircle(ink, r * 0.05f, Offset(c.x, my), style = Stroke(sw * 0.7f))
                for (i in 0 until 3) {
                    val on = ((t * 2f).toInt() % 4) > i
                    drawCircle(ink.copy(alpha = if (on) 0.9f else 0.2f), r * 0.045f, Offset(c.x + r * (0.55f + i * 0.16f), c.y - r * (0.95f + i * 0.13f)))
                }
            }
            Mode.LISTEN -> {
                for (side in listOf(-1f, 1f)) for (k in 1..2) {
                    drawArc(ink.copy(alpha = 0.7f - k * 0.2f), if (side < 0) 150f else -30f, 60f, false,
                        Offset(c.x + side * r * (0.95f + k * 0.18f) - r * 0.3f, c.y - r * 0.1f - r * 0.3f), Size(r * 0.6f, r * 0.6f),
                        style = Stroke(sw * 0.7f, cap = StrokeCap.Round))
                }
                drawLine(ink, Offset(c.x - r * 0.08f, my), Offset(c.x + r * 0.08f, my), sw * 0.8f, StrokeCap.Round)
            }
            else -> {
                val smile = Path().apply {
                    moveTo(c.x - r * 0.14f, my - r * 0.02f)
                    quadraticBezierTo(c.x, my + r * 0.1f, c.x + r * 0.14f, my - r * 0.02f)
                }
                drawPath(smile, ink, style = Stroke(sw * 0.8f, cap = StrokeCap.Round))
            }
        }
        // stars popping out of the pocket
        val n = if (mode == Mode.THINK) 4 else 3
        for (i in 0 until n) {
            val ph = (t * 0.33f + i.toFloat() / n) % 1f
            val sc = Offset(c.x + (i - (n - 1) / 2f) * r * 0.42f + sin(t * 1.7f + i * 2f) * r * 0.08f, c.y - r * 0.45f - ph * r * 1.1f)
            withTransform({ rotate(ph * 120f - 30f, sc) }) {
                drawPath(starPath(sc, r * 0.17f), acc.copy(alpha = 1f - ph), style = Stroke(sw * 0.8f, join = StrokeJoin.Round))
            }
        }
    }
}
