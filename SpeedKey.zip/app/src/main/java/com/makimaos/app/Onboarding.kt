package com.makimaos.app
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val RED = MakimaTheme.accent

@Composable
private fun Backdrop(content: @Composable BoxScope.() -> Unit) {
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Image(painterResource(R.drawable.bg_main), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xCC000000), Color(0x99100208), Color(0xEE000000)))))
        content()
    }
}

@Composable
private fun RedButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Button(onClick = onClick, enabled = enabled, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = RED, disabledContainerColor = Color(0x55FF2D5A))) {
        Text(text, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color.White)
    }
}

// ------------------------------------------------------------------ 1. LOADING
@Composable
fun SplashScreen(onDone: () -> Unit) {
    val t = rememberInfiniteTransition(label = "pulse")
    val pulse by t.animateFloat(0.92f, 1.08f, infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "s")
    val glow by t.animateFloat(0.5f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "a")
    LaunchedEffect(Unit) { delay(2600); onDone() }
    Backdrop {
        Column(Modifier.fillMaxSize().systemBarsPadding().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Image(painterResource(R.drawable.logo), null, Modifier.size(150.dp).scale(pulse).clip(CircleShape).border(2.dp, RED, CircleShape))
            Spacer(Modifier.height(28.dp))
            Text("Wait for waking up Makima...", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, modifier = Modifier.alpha(glow))
            Spacer(Modifier.height(18.dp))
            LinearProgressIndicator(color = RED, trackColor = Color(0x33FFFFFF), modifier = Modifier.width(180.dp).clip(RoundedCornerShape(50)))
        }
    }
}

// ------------------------------------------------------------------ 2. USER MANUAL (3 pages)
private class ManualPage(val title: String, val body: List<String>)
private val manual = listOf(
    ManualPage("Welcome to MakimaOS", listOf("Makima tumhari personal AI assistant hai - bolo aur wo sunegi, samjhegi aur jawab degi.", "Home screen par mic dabao ya Hands-free on karo, phir bas baat karo.", "Hinglish, Hindi ya English - jaise comfortable ho waise bolo.")),
    ManualPage("Phone control", listOf("Accessibility ON karne ke baad Makima apps khol sakti hai, tap, scroll, alarm, torch aur volume control kar sakti hai.", "Try: \"YouTube pe gana lagao\", \"WhatsApp kholo\", \"7 baje ka alarm lagao\".", "Rukne ke liye bolo: stop.")),
    ManualPage("Setup & license", listOf("Settings me apni API key paste karo - provider aur model apne aap select ho jayenge.", "Aage license key daalke Connect Makima karo, ya 10 minute ka free trial lo.", "Memory me jo batao wo Makima yaad rakhegi."))
)

@Composable
fun ManualScreen(onDone: () -> Unit) {
    var page by remember { mutableStateOf(0) }
    val p = manual[page]
    Backdrop {
        Column(Modifier.fillMaxSize().systemBarsPadding().padding(24.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                manual.indices.forEach { i ->
                    Box(Modifier.padding(4.dp).size(if (i == page) 26.dp else 9.dp, 9.dp).clip(RoundedCornerShape(50)).background(if (i == page) RED else Color(0x55FFFFFF)))
                }
            }
            Spacer(Modifier.height(10.dp))
            Text("User manual ${page + 1}/${manual.size}", color = Color(0xAAFFFFFF), fontSize = 13.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
            Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Image(painterResource(R.drawable.logo), null, Modifier.size(96.dp).clip(CircleShape).border(2.dp, RED, CircleShape))
                Spacer(Modifier.height(20.dp))
                Text(p.title, color = RED, fontSize = 26.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Spacer(Modifier.height(18.dp))
                p.body.forEach {
                    Text(it, color = Color.White, fontSize = 16.sp, lineHeight = 23.sp, modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
                        .clip(RoundedCornerShape(14.dp)).background(Color(0x33FFFFFF)).padding(14.dp))
                }
            }
            RedButton(if (page == manual.lastIndex) "Continue" else "Next") { if (page == manual.lastIndex) onDone() else page++ }
        }
    }
}

// ------------------------------------------------------------------ 3. GATE (logo + key + Connect Makima)
@Composable
fun GateScreen(onEnter: () -> Unit, onAdmin: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var key by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf(if (Prefs.licExpires > 0L && !License.isActive()) "Tumhari license/trial khatam ho gayi hai. Nayi key daalo." else "") }
    var good by remember { mutableStateOf(false) }
    fun run(block: suspend () -> Res) {
        if (busy) return
        busy = true; msg = ""
        scope.launch {
            val r = block(); busy = false; msg = r.msg; good = r.ok
            if (r.ok) { delay(700); onEnter() }
        }
    }
    Backdrop {
        Column(Modifier.fillMaxSize().systemBarsPadding().imePadding().verticalScroll(rememberScrollState()).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(24.dp))
            Image(painterResource(R.drawable.logo), null, Modifier.size(140.dp).clip(CircleShape).border(2.dp, RED, CircleShape))
            Spacer(Modifier.height(16.dp))
            Text("MakimaOS", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
            Text("Your Personal AI Assistant", color = RED, fontSize = 16.sp)
            Spacer(Modifier.height(14.dp))
            Text("Voice se baat karo, apps chalao, kaam karwao. Makima sunti hai, samajhti hai aur turant action leti hai. Shuru karne ke liye apni key daalo.",
                color = Color(0xCCFFFFFF), fontSize = 14.sp, lineHeight = 20.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(24.dp))
            Field(key, { key = it.uppercase() }, "License key  (MKM-XXXX-XXXX-XXXX)", RED, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(14.dp))
            RedButton(if (busy) "Please wait..." else "Connect Makima", enabled = !busy && key.isNotBlank()) { run { License.activate(ctx, key) } }
            Spacer(Modifier.height(10.dp))
            OutlinedButton(onClick = { run { License.startTrial(ctx) } }, enabled = !busy, modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, RED)) { Text("Start free trial (10 minutes, one time)", color = Color.White) }
            if (msg.isNotEmpty()) { Spacer(Modifier.height(12.dp)); Text(msg, color = if (good) Color(0xFF7CFFA0) else Color(0xFFFF8A8A), textAlign = TextAlign.Center) }
            Spacer(Modifier.height(18.dp))
            TextButton(onClick = onAdmin) { Text("Admin login", color = Color(0x99FFFFFF)) }
        }
    }
}

// ------------------------------------------------------------------ 4. ADMIN (login + key generator)
@Composable
fun AdminScreen(onBack: () -> Unit, onEnter: () -> Unit) {
    val scope = rememberCoroutineScope()
    val clip = LocalClipboardManager.current
    var email by remember { mutableStateOf(Prefs.lastEmail.ifEmpty { License.ADMIN_EMAIL }) }
    var pass by remember { mutableStateOf("") }
    var loggedIn by remember { mutableStateOf(License.adminToken.isNotEmpty()) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    var newKey by remember { mutableStateOf("") }
    var keys by remember { mutableStateOf<List<KeyRow>>(emptyList()) }
    fun refresh() { scope.launch { val (r, l) = License.listKeys(); if (r.ok) keys = l else msg = r.msg } }
    LaunchedEffect(loggedIn) { if (loggedIn) refresh() }
    Backdrop {
        Column(Modifier.fillMaxSize().systemBarsPadding().imePadding().padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onBack) { Text("< Back", color = Color.White) }
                Spacer(Modifier.weight(1f))
                Text("Admin", color = RED, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f)); Spacer(Modifier.width(60.dp))
            }
            if (!loggedIn) {
                Spacer(Modifier.height(20.dp))
                Field(email, { email = it }, "Admin Gmail", RED, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp))
                Field(pass, { pass = it }, "Password", RED, secret = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(14.dp))
                RedButton(if (busy) "Please wait..." else "Login", enabled = !busy && pass.isNotBlank()) {
                    busy = true; msg = ""
                    scope.launch { val r = License.adminLogin(email, pass); busy = false; msg = r.msg; if (r.ok) loggedIn = true }
                }
            } else {
                Spacer(Modifier.height(8.dp))
                Text("Unlimited access ON. Neeche se keys banao.", color = Color(0xFF7CFFA0), fontSize = 14.sp)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.weight(1f)) { RedButton("New 7-day key", enabled = !busy) {
                        busy = true; scope.launch { val (r, c) = License.createKey(7); busy = false; msg = r.msg; if (r.ok) { newKey = c; refresh() } } } }
                    Box(Modifier.weight(1f)) { RedButton("New 31-day key", enabled = !busy) {
                        busy = true; scope.launch { val (r, c) = License.createKey(31); busy = false; msg = r.msg; if (r.ok) { newKey = c; refresh() } } } }
                }
                if (newKey.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0x44FF2D5A)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(newKey, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        TextButton(onClick = { clip.setText(AnnotatedString(newKey)); msg = "Copy ho gayi" }) { Text("Copy", color = Color.White) }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text("Saari keys (${keys.size})", color = Color(0xCCFFFFFF), fontSize = 14.sp)
                LazyColumn(Modifier.weight(1f)) {
                    items(keys) { k ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(12.dp)).background(Color(0x33FFFFFF)).padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f).clickable { clip.setText(AnnotatedString(k.code)); msg = "Copy ho gayi" }.padding(vertical = 8.dp)) {
                                Text(k.code, color = Color.White, fontSize = 14.sp)
                                Text("${k.days} days - " + if (k.used) "used" else "unused", color = if (k.used) Color(0xFFFFB74D) else Color(0xFF7CFFA0), fontSize = 12.sp)
                            }
                            TextButton(onClick = { scope.launch { val r = License.deleteKey(k.code); msg = r.msg; refresh() } }) { Text("Delete", color = Color(0xFFFF8A8A)) }
                        }
                    }
                }
                RedButton("Enter MakimaOS (Admin)") { onEnter() }
            }
            if (msg.isNotEmpty()) { Spacer(Modifier.height(8.dp)); Text(msg, color = Color(0xFFFFD6DD), fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()) }
        }
    }
}
