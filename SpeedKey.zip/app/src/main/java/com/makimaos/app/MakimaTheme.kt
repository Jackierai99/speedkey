package com.makimaos.app
import androidx.compose.ui.graphics.Color

/** Single UI theme (the red "Your Personal AI Assistant" screen). */
object MakimaTheme {
    val bg = R.drawable.bg_main
    val accent = Color(0xFFFF2D5A)
}
