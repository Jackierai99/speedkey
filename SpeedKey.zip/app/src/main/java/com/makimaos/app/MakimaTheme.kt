package com.makimaos.app
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color

/** One app theme out of 5 colour themes. Only colours change - icons, layout and animations stay the same. */
class ThemeDef(val name: String, val accent: Color, val soft: Color, val bg0: Color, val bg1: Color, val panel: Color)

object MakimaTheme {
    val themes = listOf(
        ThemeDef("Crimson",  Color(0xFFFF2D5A), Color(0xFFFF8FA8), Color(0xFF080306), Color(0xFF1C0610), Color(0xFF14040A)),
        ThemeDef("Violet",   Color(0xFFA855F7), Color(0xFFD2A8FF), Color(0xFF07030D), Color(0xFF16082A), Color(0xFF0E0418)),
        ThemeDef("Ocean",    Color(0xFF22B8FF), Color(0xFF9BDDFF), Color(0xFF030A0F), Color(0xFF06192A), Color(0xFF04101A)),
        ThemeDef("Emerald",  Color(0xFF1FD18B), Color(0xFF8CF0C6), Color(0xFF030D08), Color(0xFF062016), Color(0xFF04140D)),
        ThemeDef("Gold",     Color(0xFFFFB020), Color(0xFFFFD98A), Color(0xFF0C0803), Color(0xFF241705), Color(0xFF160E03))
    )
    private var idx by mutableIntStateOf(-1)
    var index: Int
        get() { if (idx < 0) idx = Prefs.themeIdx.coerceIn(0, themes.lastIndex); return idx }
        set(v) { idx = v.coerceIn(0, themes.lastIndex); Prefs.themeIdx = idx }
    val cur: ThemeDef get() = themes[index]

    val bg = R.drawable.bg_main
    val accent: Color get() = cur.accent
    val soft: Color get() = cur.soft
    val bg0: Color get() = cur.bg0
    val bg1: Color get() = cur.bg1
    fun panel(a: Float) = cur.panel.copy(alpha = a)
}
