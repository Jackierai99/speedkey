package com.makimaos.app
import android.Manifest
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.content.ContextCompat

/**
 * "Hey Makima" wake word. A small foreground service keeps a speech recogniser running while the app is NOT on screen
 * and NOT already in hands-free mode. When it hears "hey makima" / "ok makima" / "हे माकिमा" ... it brings the app to the
 * front, and the app switches hands-free (or live) mode on by itself.
 */
class WakeService : Service() {
    companion object {
        private const val CH = "makimaos_wake"
        private const val CH_TAP = "makimaos_wake_tap"

        // compared with spaces removed, lower case
        private val names = listOf("makima", "makeema", "mekima", "makeemah", "macima", "makhima", "maakima", "makyma",
            "मकीमा", "माकिमा", "मकिमा", "माकीमा", "मकीमाँ", "माकीमाँ", "माकीमां", "मकीमां", "माकीमॉ", "मैकिमा", "माकिमाँ", "माकिमां")

        fun isWake(raw: String): Boolean {
            val compact = raw.lowercase().replace(Regex("[^\\p{L}\\p{M}\\p{N}]"), "")
            return names.any { compact.contains(it) }
        }

        private fun hasMic(c: Context) = ContextCompat.checkSelfPermission(c, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

        /** Start the service if the wake word is on, licence is valid and the mic permission is granted. Must be called while the app is visible. */
        fun start(ctx: Context) {
            Prefs.init(ctx.applicationContext)
            if (!Prefs.wakeWord || !License.isActive() || !hasMic(ctx)) return
            try { ContextCompat.startForegroundService(ctx.applicationContext, Intent(ctx.applicationContext, WakeService::class.java)) } catch (_: Exception) {}
        }
        fun stop(ctx: Context) { try { ctx.applicationContext.stopService(Intent(ctx.applicationContext, WakeService::class.java)) } catch (_: Exception) {} }

        /** Called by the switches in Home / Settings. */
        fun setEnabled(app: AppState, on: Boolean) {
            Prefs.wakeWord = on
            if (!on) { stop(app.ctx); return }
            if (!hasMic(app.ctx)) { app.askMic(); return }
            start(app.ctx)
        }
    }

    private val h = Handler(Looper.getMainLooper())
    private var sr: SpeechRecognizer? = null
    private var alive = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() { super.onCreate(); Prefs.init(applicationContext) }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg()
        if (!alive) { alive = true; h.post(tick) }
        return START_NOT_STICKY
    }

    override fun onDestroy() { alive = false; h.removeCallbacksAndMessages(null); stopRec(); super.onDestroy() }

    private fun startFg() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "Hey Makima", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, CH)
            .setContentTitle("Hey Makima ON")
            .setContentText("\"Hey Makima\" bolo, main jaag jaungi.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(8, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(8, n)
    }

    private fun busy() = AppHolder.fg || AppHolder.app?.handsFree == true

    private val tick = object : Runnable {
        override fun run() {
            if (!alive) return
            if (!Prefs.wakeWord || !License.isActive()) { stopSelf(); return }
            if (busy()) stopRec() else if (sr == null) startRec()
            h.postDelayed(this, 1500)
        }
    }

    private fun stopRec() { try { sr?.cancel(); sr?.destroy() } catch (_: Exception) {}; sr = null }

    private fun restart(ms: Long) {
        stopRec()
        h.postDelayed({ if (alive && sr == null && !busy()) startRec() }, ms)
    }

    private fun startRec() {
        if (sr != null || !alive) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        sr = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rms: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(t: Int, b: Bundle?) {}
            override fun onError(e: Int) {
                when (e) {
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> { alive = false; stopSelf() }
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> restart(3000)
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> restart(250)
                    else -> restart(1500)
                }
            }
            override fun onResults(b: Bundle?) { check(b) { restart(250) } }
            override fun onPartialResults(b: Bundle?) { check(b) {} }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Prefs.micTags[Prefs.micLang.coerceIn(0, 2)])
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        try { r.startListening(i) } catch (_: Exception) { restart(2000) }
    }

    private fun check(b: Bundle?, noMatch: () -> Unit) {
        val list = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: emptyList<String>()
        if (list.any { isWake(it) }) onWake() else noMatch()
    }

    private fun onWake() {
        stopRec()
        AppHolder.wakeAt = System.currentTimeMillis()
        AppHolder.wakePending = true
        val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        if (Settings.canDrawOverlays(this)) {
            try { startActivity(i) } catch (_: Exception) {}
        } else {
            // Android blocks opening apps from the background without the "display over other apps" permission: show a tap-to-open alert instead
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CH_TAP, "Makima jaag gayi", NotificationManager.IMPORTANCE_HIGH))
            val pi = PendingIntent.getActivity(this, 3, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            nm.notify(9, Notification.Builder(this, CH_TAP).setContentTitle("Haan Boss?").setContentText("Tap karo, Makima sun rahi hai.")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentIntent(pi).setAutoCancel(true).build())
        }
        restart(4000)
    }
}
