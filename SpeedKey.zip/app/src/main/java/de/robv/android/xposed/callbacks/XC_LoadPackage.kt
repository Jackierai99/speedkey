package de.robv.android.xposed.callbacks

abstract class XC_LoadPackage {
    class LoadPackageParam { @JvmField var packageName: String = "" }
}
