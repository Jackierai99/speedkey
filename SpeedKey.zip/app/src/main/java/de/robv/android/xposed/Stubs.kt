package de.robv.android.xposed

interface IXposedHookLoadPackage {
    fun handleLoadPackage(p: de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam)
}

abstract class XC_MethodHook {
    open class MethodHookParam {
        @JvmField var thisObject: Any? = null
        @JvmField var args: Array<Any?> = arrayOf()
        open val result: Any? get() = null
    }
    protected open fun beforeHookedMethod(param: MethodHookParam) {}
    protected open fun afterHookedMethod(param: MethodHookParam) {}
}

object XposedBridge {
    @JvmStatic fun hookAllMethods(c: Class<*>, name: String, cb: XC_MethodHook): Set<Any?> = emptySet()
}
