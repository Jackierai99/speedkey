package com.makimaos.app
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.GraphicsLayerScope
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.min
import kotlin.math.roundToInt

private class Spot(val id: String, val x1: Int, val y1: Int, val x2: Int, val y2: Int)

// Coordinates are in the 940 x 1672 reference space of the home-screen artwork.
private val spots = listOf(
    Spot("eye", 40, 65, 160, 180), Spot("settings", 820, 75, 910, 165),
    Spot("pill", 210, 1072, 730, 1182),
    Spot("chat", 103, 1308, 243, 1440), Spot("mic", 368, 1260, 572, 1462), Spot("voice", 700, 1308, 840, 1440),
    Spot("home", 60, 1535, 210, 1655), Spot("fav", 300, 1535, 415, 1655),
    Spot("history", 525, 1535, 645, 1655), Spot("profile", 745, 1535, 870, 1655)
)

private fun act(a: AppState, id: String) {
    when (id) {
        "eye" -> a.say("Main yahin hoon, ${Prefs.userName}.")
        "settings" -> a.screen = Screen.SETTINGS
        "pill", "chat" -> a.screen = Screen.CHAT
        "mic" -> a.toggleHandsFree()
        "voice" -> a.screen = Screen.SETTINGS
        "fav" -> a.screen = Screen.FAVORITES
        "history" -> a.screen = Screen.HISTORY
        "profile" -> a.screen = Screen.PROFILE
    }
}

@Composable
fun HomeScreen(app: AppState) {
    val t = MakimaTheme
    val painter = painterResource(t.bg)
    val ctx = LocalContext.current
    // Optional extra poses: drop bg_listen.png / bg_speak.png (same layout) into res/drawable-nodpi and they crossfade in.
    val listenRes = remember { ctx.resources.getIdentifier("bg_listen", "drawable", ctx.packageName) }
    val speakRes = remember { ctx.resources.getIdentifier("bg_speak", "drawable", ctx.packageName) }
    val mode = app.mode

    val inf = rememberInfiniteTransition(label = "inf")
    val breathe by inf.animateFloat(1f, 1.010f, infiniteRepeatable(tween(3600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "breathe")
    val bob by inf.animateFloat(-1f, 1f, infiniteRepeatable(tween(420, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "bob")
    val sway by inf.animateFloat(-1f, 1f, infiniteRepeatable(tween(5200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "sway")
    val ripple by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1400, easing = LinearEasing)), label = "ripple")
    val pulse by inf.animateFloat(0.92f, 1.12f, infiniteRepeatable(tween(650), RepeatMode.Reverse), label = "pulse")
    val zoom by animateFloatAsState(when (mode) { Mode.LISTEN -> 1.03f; Mode.SPEAK -> 1.018f; Mode.THINK -> 1.008f; else -> 1f }, tween(500), label = "zoom")
    val tilt by animateFloatAsState(if (mode == Mode.LISTEN) -0.8f else 0f, tween(600), label = "tilt")
    val listenA by animateFloatAsState(if (mode == Mode.LISTEN) 1f else 0f, tween(450), label = "la")
    val speakA by animateFloatAsState(if (mode == Mode.SPEAK) 1f else 0f, tween(300), label = "sa")
    val d = LocalDensity.current

    BoxWithConstraints(Modifier.fillMaxSize().background(Color.Black)) {
        val w = constraints.maxWidth.toFloat(); val h = constraints.maxHeight.toFloat()
        val iw = painter.intrinsicSize.width; val ih = painter.intrinsicSize.height
        val s = min(w / iw, h / ih)
        val ox = (w - iw * s) / 2f; val oy = (h - ih * s) / 2f
        val unit = iw * s / 940f
        fun px(x: Float) = ox + x * unit
        fun py(y: Float) = oy + y * unit

        val layer: GraphicsLayerScope.() -> Unit = {
            transformOrigin = TransformOrigin(0.5f, 0.45f)
            val k = breathe * zoom
            scaleX = k; scaleY = k
            rotationZ = tilt + sway * 0.35f
            translationY = if (mode == Mode.SPEAK) bob * 3f else 0f
        }
        Image(painter, null, Modifier.fillMaxSize().graphicsLayer(layer), contentScale = ContentScale.Fit)
        if (listenRes != 0 && listenA > 0.01f)
            Image(painterResource(listenRes), null, Modifier.fillMaxSize().graphicsLayer(layer), contentScale = ContentScale.Fit, alpha = listenA)
        if (speakRes != 0 && speakA > 0.01f)
            Image(painterResource(speakRes), null, Modifier.fillMaxSize().graphicsLayer(layer), contentScale = ContentScale.Fit, alpha = speakA)

        // hide the status bar that is baked into the artwork
        Box(Modifier.align(Alignment.TopCenter).fillMaxWidth().height(with(d) { py(62f).toDp() })
            .background(Brush.verticalGradient(listOf(Color.Black, Color.Black, Color.Transparent))))

        Canvas(Modifier.fillMaxSize()) {
            val mic = Offset(px(470f), py(1360f))
            val face = Offset(px(470f), py(300f))
            val ear = Offset(px(368f), py(360f))
            if (mode == Mode.LISTEN) {
                // sound waves coming in at her ear
                for (i in 0..2) {
                    val f = (ripple + i / 3f) % 1f
                    drawCircle(t.accent.copy(alpha = (1f - f) * 0.6f), (22f + f * 150f) * unit, ear, style = Stroke(4f))
                }
            }
            if (mode == Mode.SPEAK) {
                val a = 0.14f + 0.14f * ((bob + 1f) / 2f)
                drawCircle(Brush.radialGradient(listOf(t.accent.copy(alpha = a), Color.Transparent), center = face, radius = 280f * unit), 280f * unit, face)
            }
            if (mode != Mode.IDLE) {
                val r = 100f * unit
                when (mode) {
                    Mode.THINK -> drawArc(t.accent, ripple * 360f, 110f, false, Offset(mic.x - r, mic.y - r), Size(r * 2, r * 2), style = Stroke(8f, cap = StrokeCap.Round))
                    else -> {
                        val rad = if (mode == Mode.LISTEN) r * (1f + app.level * 0.25f) else r * pulse
                        drawCircle(t.accent.copy(alpha = 0.9f), rad, mic, style = Stroke(7f))
                        drawCircle(t.accent.copy(alpha = 0.3f), rad * 1.25f, mic, style = Stroke(4f))
                    }
                }
            }
            if (app.handsFree) {
                drawCircle(t.accent.copy(alpha = 0.55f), 128f * unit * pulse, mic, style = Stroke(4f))
            }
        }

        for (sp in spots) {
            Box(
                Modifier
                    .offset { IntOffset(px(sp.x1.toFloat()).roundToInt(), py(sp.y1.toFloat()).roundToInt()) }
                    .size(with(d) { (px(sp.x2.toFloat()) - px(sp.x1.toFloat())).toDp() }, with(d) { (py(sp.y2.toFloat()) - py(sp.y1.toFloat())).toDp() })
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { act(app, sp.id) }
            )
        }

        // live text replaces the "Hello Boss..." pill while she is listening / thinking / talking
        val text = when {
            mode == Mode.LISTEN -> if (app.partial.isBlank()) "Listening, ${Prefs.userName}..." else app.partial
            mode == Mode.THINK -> "Thinking..."
            else -> app.bubble
        }
        if (text.isNotBlank()) {
            val shape = RoundedCornerShape(50)
            val pl = px(210f); val pt = py(1072f)
            Box(
                Modifier
                    .offset { IntOffset(pl.roundToInt(), pt.roundToInt()) }
                    .size(with(d) { (px(730f) - pl).toDp() }, with(d) { (py(1182f) - pt).toDp() })
                    .clip(shape).background(Color(0xFF14040A)).border(1.dp, t.accent, shape)
                    .clickable { if (mode == Mode.SPEAK) app.mouth.stop() else app.screen = Screen.CHAT }
                    .padding(horizontal = 20.dp),
                contentAlignment = Alignment.CenterStart
            ) { Text(text, color = Color.White, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis) }
        }
    }
}
