package com.makimaos.app
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import java.util.Locale

/**
 * Makima's voice. Sentences arrive while the AI is still writing; each one is turned into speech
 * (AI voice via the same key, phone voice as automatic fallback) and played back-to-back.
 */
class Mouth(ctx: Context, private val scope: CoroutineScope) {
    var speaking by mutableStateOf(false)
    var onDone: (() -> Unit)? = null
    private var ready = false
    @Volatile private var gen = 0
    private var sj: Job? = null
    private var streamScope: CoroutineScope? = null
    private var q: Channel<Pair<String, Deferred<ByteArray?>>>? = null
    @Volatile private var curTrack: AudioTrack? = null
    private val tts: TextToSpeech = TextToSpeech(ctx) { ready = it == TextToSpeech.SUCCESS }

    private fun finish(g: Int) { if (g == gen) { speaking = false; onDone?.invoke() } }
    private fun clean(t: String) = t.replace(Regex("[*_#`~>]"), " ").replace(Regex("[\\p{So}\\p{Cs}]"), "").trim()

    fun speak(text: String) { startStream(); feed(text); endStream() }

    fun startStream() {
        stop()
        val g = gen
        speaking = true
        val job = SupervisorJob(scope.coroutineContext[Job])
        sj = job
        val sc = CoroutineScope(scope.coroutineContext + job)
        streamScope = sc
        val ch = Channel<Pair<String, Deferred<ByteArray?>>>(Channel.UNLIMITED)
        q = ch
        sc.launch(Dispatchers.IO) { player(ch, g) }
    }

    fun feed(s: String) {
        val t = clean(s); if (t.isEmpty()) return
        val ch = q ?: return
        val sc = streamScope ?: return
        val prem = Prefs.premium && Brain.ttsAvailable()
        val d = sc.async(Dispatchers.IO) { if (prem) Brain.tts(t.take(500)) else null }
        ch.trySend(t to d)
    }

    fun endStream() { q?.close() }

    private fun newTrack(): AudioTrack {
        val sr = 24000
        val minBuf = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        return AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(minBuf, 16384)).setTransferMode(AudioTrack.MODE_STREAM).build()
    }

    private fun drain(t: AudioTrack, frames: Long, g: Int) {
        var waited = 0
        while (g == gen && t.playbackHeadPosition.toLong() < frames && waited < 6000) { Thread.sleep(40); waited += 40 }
    }

    private suspend fun player(ch: Channel<Pair<String, Deferred<ByteArray?>>>, g: Int) {
        var track: AudioTrack? = null
        var frames = 0L
        try {
            for ((text, d) in ch) {
                if (g != gen) return
                val pcm = d.await()
                if (g != gen) return
                if (pcm != null && pcm.size > 1) {
                    if (track == null) { track = newTrack(); curTrack = track; track.play() }
                    var off = 0
                    while (off < pcm.size && g == gen) {
                        val n = track.write(pcm, off, minOf(4096, pcm.size - off))
                        if (n <= 0) break
                        off += n
                    }
                    frames += pcm.size / 2
                } else {
                    track?.let { drain(it, frames, g) }
                    if (g != gen) return
                    systemSpeak(text, g)
                }
            }
            track?.let { drain(it, frames, g) }
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
        } finally {
            try { track?.stop() } catch (_: Exception) {}
            try { track?.release() } catch (_: Exception) {}
            if (curTrack === track) curTrack = null
        }
        withContext(Dispatchers.Main) { finish(g) }
    }

    private suspend fun systemSpeak(text: String, g: Int) {
        if (!ready) return
        val done = CompletableDeferred<Unit>()
        val deva = text.any { it in '\u0900'..'\u097F' }
        val loc = if (deva) Locale("hi", "IN") else Locale("en", "IN")
        tts.language = loc
        val cand = (tts.voices ?: emptySet()).filter { it.locale.language == loc.language && it.features?.contains("notInstalled") != true }
        val fem = cand.filter { it.name.contains("female", true) }.ifEmpty { cand }
        if (fem.isNotEmpty()) tts.voice = fem[Prefs.voice % fem.size]
        val (p0, r0) = when (Prefs.voice) { 0 -> 1.12f to 0.92f; 1 -> 1.3f to 1.0f; else -> 1.0f to 0.88f }
        tts.setPitch(p0 * Prefs.pitch); tts.setSpeechRate(r0 * Prefs.speed)
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { done.complete(Unit) }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { done.complete(Unit) }
        })
        tts.speak(text.take(3500), TextToSpeech.QUEUE_FLUSH, null, "mk")
        withTimeoutOrNull(60000) { done.await() }
    }

    fun stop() {
        gen++
        sj?.cancel(); sj = null; streamScope = null
        q?.close(); q = null
        try { curTrack?.pause(); curTrack?.flush() } catch (_: Exception) {}
        tts.stop(); speaking = false
    }
    fun release() { stop(); tts.shutdown() }
}

class Ears(private val ctx: Context, private val onPartial: (String) -> Unit, private val onFinal: (String) -> Unit,
           private val onEnd: (Int) -> Unit, private val onLevel: (Float) -> Unit) {
    private var sr: SpeechRecognizer? = null
    fun start() {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) { onEnd(-1); return }
        stop()
        sr = SpeechRecognizer.createSpeechRecognizer(ctx).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rms: Float) { onLevel(((rms + 2f) / 12f).coerceIn(0f, 1f)) }
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(e: Int) { onEnd(e) }
                override fun onResults(r: Bundle?) {
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                    if (t.isBlank()) onEnd(7) else onFinal(t)
                }
                override fun onPartialResults(r: Bundle?) {
                    r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { onPartial(it) }
                }
                override fun onEvent(t: Int, b: Bundle?) {}
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Prefs.micTags[Prefs.micLang.coerceIn(0, 2)])
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1600L)
        }
        sr?.startListening(i)
    }
    fun stop() { sr?.cancel(); sr?.destroy(); sr = null }
}
