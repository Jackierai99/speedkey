package com.makimaos.app
import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject

class Msg(val user: Boolean, val text: String, val ts: Long = System.currentTimeMillis(), fav: Boolean = false) {
    var fav by mutableStateOf(fav)
}
enum class Screen { HOME, CHAT, SETTINGS, MEMORY, FAVORITES, HISTORY, PROFILE }
enum class Mode { IDLE, LISTEN, THINK, SPEAK }

class AppState(val ctx: Context) {
    val theme = MakimaTheme
    var screen by mutableStateOf(Screen.HOME)
    val messages = mutableStateListOf<Msg>()
    var listening by mutableStateOf(false)
    var thinking by mutableStateOf(false)
    var handsFree by mutableStateOf(false)
    var pendingHands = false
    var partial by mutableStateOf("")
    var bubble by mutableStateOf("")
    var level by mutableStateOf(0f)
    var askMic: () -> Unit = {}
    var askPerms: () -> Unit = {}
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    val mouth = Mouth(ctx, scope)
    private var fails = 0
    private var buf = ""
    private var flushJob: Job? = null

    private val ears = Ears(ctx,
        onPartial = { partial = (buf + " " + it).trim() },
        onFinal = { text ->
            listening = false; fails = 0
            buf = (buf + " " + text).trim(); partial = buf
            flushJob?.cancel()
            if (handsFree) {
                // keep listening in case she is still mid-sentence; reply only after a quiet gap
                scheduleFlush((Prefs.waitSec * 1000).toLong())
                scope.launch { delay(150); if (handsFree && !listening && !thinking && !mouth.speaking) startListening() }
            } else flush()
        },
        onEnd = { code ->
            listening = false
            if (buf.isEmpty()) partial = ""
            if (handsFree) {
                val quiet = code == 6 || code == 7      // normal silence / nothing recognised
                if (quiet) fails = 0 else fails++
                if (buf.isNotEmpty() && flushJob == null) scheduleFlush((Prefs.waitSec * 1000).toLong())
                if (fails < 5) scope.launch {
                    delay(if (quiet) 250 else 1200)
                    if (handsFree && !listening && !thinking && !mouth.speaking) startListening()
                } else { disableHandsFree(); bubble = "Mic me dikkat aa rahi hai, hands-free band kar diya." }
            } else if (buf.isNotEmpty()) flush()
        },
        onLevel = { level = it })

    val mode: Mode get() = when {
        listening -> Mode.LISTEN
        thinking -> Mode.THINK
        mouth.speaking -> Mode.SPEAK
        else -> Mode.IDLE
    }

    init {
        mouth.onDone = { if (handsFree && !listening && !thinking) startListening() }
        loadHistory()
    }

    private fun scheduleFlush(ms: Long) {
        flushJob?.cancel()
        flushJob = scope.launch { delay(ms); flush() }
    }
    private fun flush() {
        // never cut in while she is still speaking
        if (listening && partial.isNotBlank() && partial != buf) { scheduleFlush(600); return }
        val t = buf.trim(); buf = ""; flushJob = null; partial = ""
        if (t.isNotEmpty()) { ears.stop(); listening = false; send(t) }
    }

    // ---------------------------------------------------------------- history
    private fun loadHistory() {
        try {
            val a = JSONArray(Prefs.history)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                messages.add(Msg(o.getBoolean("u"), o.getString("t"), o.optLong("ts"), o.optBoolean("f")))
            }
        } catch (_: Exception) {}
    }
    fun save() {
        if (!Prefs.saveHistory) { Prefs.history = "[]"; return }
        val a = JSONArray()
        messages.takeLast(300).forEach { a.put(JSONObject().put("u", it.user).put("t", it.text).put("ts", it.ts).put("f", it.fav)) }
        Prefs.history = a.toString()
    }
    fun clearHistory() { messages.clear(); save() }
    fun toggleFav(m: Msg) { m.fav = !m.fav; save() }

    // ------------------------------------------------------------------ voice
    fun say(t: String) { bubble = t; mouth.speak(t) }
    fun sampleVoice() = say("Main Makima hoon, ${Prefs.userName}. Ab se meri awaaz yehi hogi.")

    private fun hasMic() = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    fun toggleListen() {
        if (listening) { ears.stop(); listening = false; return }
        startListening()
    }
    fun startListening() {
        if (!hasMic()) { askMic(); return }
        mouth.stop(); listening = true; ears.start()
    }

    // ------------------------------------------- always-listening (hands-free)
    fun toggleHandsFree() { if (handsFree) disableHandsFree() else requestHandsFree() }
    fun requestHandsFree() {
        if (!hasMic()) { pendingHands = true; askMic(); return }
        enableHandsFree()
    }
    fun enableHandsFree() {
        handsFree = true; fails = 0; buf = ""
        try { ContextCompat.startForegroundService(ctx, Intent(ctx, OverlayService::class.java)) } catch (_: Exception) {}
        bubble = if (Settings.canDrawOverlays(ctx)) "Main sun rahi hoon, ${Prefs.userName}. Bolo."
                 else "Main sun rahi hoon. Bahar bubble ke liye Settings me Floating bubble permission do."
        startListening()
    }
    fun disableHandsFree() {
        handsFree = false; flushJob?.cancel(); flushJob = null; buf = ""; partial = ""
        ears.stop(); listening = false
        try { ctx.stopService(Intent(ctx, OverlayService::class.java)) } catch (_: Exception) {}
        bubble = "Hands-free band."
    }

    // ------------------------------------------------------------------- chat
    private fun finishLocal(reply: String) {
        messages.add(Msg(false, reply)); thinking = false; save()
        if (Prefs.autoSpeak) say(reply) else { bubble = reply; if (handsFree) startListening() }
    }

    fun send(text: String) {
        if (text.isBlank()) return
        messages.add(Msg(true, text)); thinking = true; bubble = ""
        scope.launch {
            val local = if (Prefs.phoneControl) (try { Cmd.tryHandle(ctx, text) } catch (e: Exception) { "Boss, command me error: ${e.message}" }) else null
            if (local != null) { finishLocal(local); return@launch }
            val speak = Prefs.autoSpeak
            val hist = messages.takeLast(Prefs.ctxTurns.coerceIn(2, 40)).map { (if (it.user) "user" else "model") to it.text }
                .dropWhile { it.first != "user" }
            if (speak) mouth.startStream()
            var emitted = false
            val reply = withContext(Dispatchers.IO) {
                try {
                    Brain.askStream(hist) { s ->
                        emitted = true
                        scope.launch { thinking = false; bubble = (bubble + " " + s).trim() }
                        if (speak) mouth.feed(s)
                    }
                } catch (e: Exception) { "Boss, error: ${e.message}" }
            }
            if (!emitted) { bubble = reply; if (speak) mouth.feed(reply) }
            if (speak) mouth.endStream()
            messages.add(Msg(false, reply)); thinking = false; save()
            if (!speak) { bubble = reply; if (handsFree) startListening() }
        }
    }

    fun pause() { if (handsFree) disableHandsFree(); ears.stop(); listening = false; mouth.stop() }
    fun release() {
        ears.stop(); mouth.release(); scope.cancel()
        try { ctx.stopService(Intent(ctx, OverlayService::class.java)) } catch (_: Exception) {}
    }
}
