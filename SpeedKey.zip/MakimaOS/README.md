# MakimaOS
Open in Android Studio, or push to GitHub: Actions -> Build APK -> download the MakimaOS-apk artifact.
Settings -> paste any API key (Gemini / Grok / DeepSeek / OpenAI / Groq). Provider and model are detected automatically.
Enable the Accessibility Service for phone control.
Optional: add bg_listen.png / bg_speak.png (same layout as bg_main.png) to app/src/main/res/drawable-nodpi for real pose animations.
