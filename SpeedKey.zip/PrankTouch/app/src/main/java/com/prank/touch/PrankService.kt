package com.prank.touch

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import kotlin.random.Random

class PrankService : AccessibilityService() {
    private lateinit var wm: WindowManager
    private var overlay: View? = null
    private lateinit var lp: WindowManager.LayoutParams
    private val handler = Handler(Looper.getMainLooper())
    private var active = false
    private var blocking = false
    private var lastUp = 0L

    override fun onServiceConnected() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        overlay = View(this).apply { setOnTouchListener { _, _ -> true } }
        wm.addView(overlay, lp)
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN && event.action == KeyEvent.ACTION_UP) {
            val now = System.currentTimeMillis()
            if (now - lastUp < 600) { lastUp = 0; toggle() } else lastUp = now
        }
        return false // volume normal kaam karta rahe
    }

    private fun setBlocking(b: Boolean) {
        blocking = b
        lp.flags = if (b) lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        else lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        try { wm.updateViewLayout(overlay, lp) } catch (_: Exception) {}
    }

    private val lagLoop = object : Runnable {
        override fun run() {
            if (!active) return
            // blocked zyada der, kabhi kabhi 80-250ms ke liye touch milta hai -> atak atak ke chalega
            if (blocking) { setBlocking(false); handler.postDelayed(this, Random.nextLong(80, 250)) }
            else { setBlocking(true); handler.postDelayed(this, Random.nextLong(400, 1200)) }
        }
    }

    private fun toggle() {
        val prefs = getSharedPreferences("p", MODE_PRIVATE)
        if (!active && !prefs.getBoolean("armed", false)) return // Start dabaya hi nahi
        active = !active
        handler.removeCallbacksAndMessages(null)
        if (!active) {
            overlay?.setBackgroundColor(android.graphics.Color.TRANSPARENT)
            setBlocking(false); return
        }
        when (prefs.getInt("mode", 0)) {
            1 -> setBlocking(true)                       // freeze
            2 -> {                                       // screen off jaisa (kala + touch band)
                overlay?.setBackgroundColor(android.graphics.Color.BLACK)
                setBlocking(true)
            }
            else -> lagLoop.run()                        // lag
        }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { wm.removeView(overlay) } catch (_: Exception) {}
        super.onDestroy()
    }
}
