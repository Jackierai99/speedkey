package com.prank.touch

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import kotlin.random.Random

class PrankService : AccessibilityService() {
    private lateinit var wm: WindowManager
    private var overlay: View? = null
    private lateinit var lp: WindowManager.LayoutParams
    private val handler = Handler(Looper.getMainLooper())
    private var active = false
    private var blocking = false
    private var lastUp = 0L

    override fun onServiceConnected() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        overlay = View(this).apply { setOnTouchListener { _, _ -> true } }
        wm.addView(overlay, lp)

        // Phone restart/reboot ke baad bhi agar prank ON (armed) tha, to wapas apne aap chalu ho jaye.
        // Band sirf Volume Down 2 baar dabane se hoga.
        val prefs = getSharedPreferences("p", MODE_PRIVATE)
        if (prefs.getBoolean("armed", false)) {
            active = true
            engageMode(prefs)
        }
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN && event.action == KeyEvent.ACTION_UP) {
            val now = System.currentTimeMillis()
            if (now - lastUp < 600) { lastUp = 0; toggle() } else lastUp = now
        }
        return false // volume normal kaam karta rahe
    }

    private fun setBlocking(b: Boolean) {
        blocking = b
        lp.flags = if (b) lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        else lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        try { wm.updateViewLayout(overlay, lp) } catch (_: Exception) {}
    }

    private var lagHeavy = false   // kabhi halka lag, kabhi heavy lag -> alag alag intensity
    private val lagLoop = object : Runnable {
        override fun run() {
            if (!active) return
            if (blocking) {
                setBlocking(false)
                // kabhi kabhi bahut hi kam samay ke liye touch milta hai, jaise app atak atak ke chal rahi ho
                handler.postDelayed(this, if (lagHeavy) Random.nextLong(40, 120) else Random.nextLong(100, 280))
            } else {
                // 1 me se 7 baar bada "hang spike" aata hai jaise app crash hone wali hai
                if (Random.nextInt(7) == 0) {
                    overlay?.setBackgroundColor(android.graphics.Color.argb(50, 0, 0, 0))
                    setBlocking(true)
                    handler.postDelayed({
                        overlay?.setBackgroundColor(android.graphics.Color.TRANSPARENT)
                    }, 900)
                    handler.postDelayed(this, Random.nextLong(1800, 3500))
                    return
                }
                // har round intensity badal jaati hai -> kabhi halka atakna, kabhi heavy atakna
                lagHeavy = Random.nextBoolean()
                setBlocking(true)
                handler.postDelayed(this, if (lagHeavy) Random.nextLong(700, 1600) else Random.nextLong(300, 700))
            }
        }
    }

    private val glitchColors = intArrayOf(
        android.graphics.Color.argb(90, 255, 0, 80),
        android.graphics.Color.argb(90, 0, 255, 180),
        android.graphics.Color.argb(90, 255, 230, 0),
        android.graphics.Color.TRANSPARENT
    )
    private val glitchLoop = object : Runnable {
        override fun run() {
            if (!active) return
            overlay?.setBackgroundColor(glitchColors[Random.nextInt(glitchColors.size)])
            // kabhi kabhi touch bhi achanak atak jaata hai
            if (Random.nextInt(100) < 35) {
                setBlocking(true)
                handler.postDelayed({ if (active) setBlocking(false) }, Random.nextLong(150, 500))
            }
            handler.postDelayed(this, Random.nextLong(80, 220))
        }
    }

    private val slowLoop = object : Runnable {
        override fun run() {
            if (!active) return
            // bahut der block, bahut thodi der touch -> phone bahut slow lagta hai
            if (blocking) { setBlocking(false); handler.postDelayed(this, Random.nextLong(60, 120)) }
            else { setBlocking(true); handler.postDelayed(this, Random.nextLong(1500, 3000)) }
        }
    }

    private fun toggle() {
        val prefs = getSharedPreferences("p", MODE_PRIVATE)
        if (!active && !prefs.getBoolean("armed", false)) return // Start dabaya hi nahi
        active = !active
        // armed state bhi yahin update, taaki reboot ke baad service ko pata rahe ki ON tha ya OFF
        prefs.edit().putBoolean("armed", active).apply()
        handler.removeCallbacksAndMessages(null)
        if (!active) {
            overlay?.setBackgroundColor(android.graphics.Color.TRANSPARENT)
            setBlocking(false); return
        }
        engageMode(prefs)
    }

    private fun engageMode(prefs: android.content.SharedPreferences) {
        handler.removeCallbacksAndMessages(null)
        when (prefs.getInt("mode", 0)) {
            1 -> setBlocking(true)                       // freeze
            2 -> {                                       // screen off jaisa (kala + touch band)
                overlay?.setBackgroundColor(android.graphics.Color.BLACK)
                setBlocking(true)
            }
            3 -> glitchLoop.run()                         // glitch
            4 -> slowLoop.run()                           // slow motion
            else -> lagLoop.run()                        // lag
        }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { wm.removeView(overlay) } catch (_: Exception) {}
        super.onDestroy()
    }
}
