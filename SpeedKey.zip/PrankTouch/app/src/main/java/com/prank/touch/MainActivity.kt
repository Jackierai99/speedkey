package com.prank.touch

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("p", MODE_PRIVATE)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        root.addView(TextView(this).apply { text = "Touch Prank"; textSize = 28f })
        root.addView(TextView(this).apply {
            textSize = 16f; setPadding(0, pad, 0, pad)
            text = "1) Neeche button dabake Accessibility me 'Touch Prank' ON karo.\n" +
                "2) Mode chuno.\n" +
                "3) START dabao. Phir Volume Down 2 baar = prank ON, dobara 2 baar = OFF."
        })
        val rg = RadioGroup(this)
        val lag = RadioButton(this).apply { text = "Lag mode (atak atak ke chalega)"; id = 100 }
        val frz = RadioButton(this).apply { text = "Freeze mode (touch bilkul band)"; id = 101 }
        val off = RadioButton(this).apply { text = "Screen OFF mode (poori screen kali, touch band)"; id = 102 }
        rg.addView(lag); rg.addView(frz); rg.addView(off)
        rg.check(when (p.getInt("mode", 0)) { 1 -> 101; 2 -> 102; else -> 100 })
        rg.setOnCheckedChangeListener { _, id ->
            p.edit().putInt("mode", when (id) { 101 -> 1; 102 -> 2; else -> 0 }).apply()
        }
        root.addView(rg)
        val start = Button(this)
        fun refresh() { start.text = if (p.getBoolean("armed", false)) "STOP (prank band)" else "START" }
        refresh()
        start.setOnClickListener {
            p.edit().putBoolean("armed", !p.getBoolean("armed", false)).apply(); refresh()
        }
        root.addView(start)
        root.addView(Button(this).apply {
            text = "Accessibility Settings kholo"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        setContentView(root)
    }
}
