1) GitHub par naya repo banao, is folder ki saari files upload karo.
2) Actions tab -> Build APK chalne do -> Artifacts se VortexDL-apk download karo.
