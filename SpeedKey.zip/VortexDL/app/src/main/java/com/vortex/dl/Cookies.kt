package com.vortex.dl

import android.content.Context
import android.webkit.CookieManager
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.File

// Optional YouTube sign-in: cookies from the login WebView are handed to yt-dlp
object Cookies {
    private fun file(c: Context) = File(c.filesDir, "youtube_cookies.txt")
    fun has(c: Context) = file(c).let { it.exists() && it.length() > 100 }

    fun apply(c: Context, r: YoutubeDLRequest) { if (has(c)) r.addOption("--cookies", file(c).absolutePath) }

    fun saveFromWebView(c: Context): Boolean {
        return try {
            val cm = CookieManager.getInstance()
            cm.flush()
            val exp = System.currentTimeMillis() / 1000 + 31536000
            val sb = StringBuilder("# Netscape HTTP Cookie File\n\n")
            var n = 0
            var signedIn = false
            for ((site, dom) in listOf("https://www.youtube.com" to ".youtube.com", "https://accounts.google.com" to ".google.com")) {
                val s = cm.getCookie(site) ?: continue
                s.split(";").forEach { part ->
                    val t = part.trim(); val i = t.indexOf('=')
                    if (i > 0) {
                        val name = t.substring(0, i).trim(); val v = t.substring(i + 1).trim()
                        if (name == "SID" || name == "LOGIN_INFO" || name == "SAPISID") signedIn = true
                        sb.append("$dom\tTRUE\t/\tTRUE\t$exp\t$name\t$v\n"); n++
                    }
                }
            }
            if (n == 0 || !signedIn) false else { file(c).writeText(sb.toString()); true }
        } catch (_: Throwable) { false }
    }

    fun clear(c: Context) {
        try {
            file(c).delete()
            CookieManager.getInstance().removeAllCookies(null); CookieManager.getInstance().flush()
        } catch (_: Throwable) {}
    }
}
