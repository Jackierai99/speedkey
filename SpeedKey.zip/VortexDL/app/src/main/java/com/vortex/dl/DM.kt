package com.vortex.dl

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.*
import java.util.UUID

class DlItem(val id: String, val title: String, val thumb: String?, val label: String) {
    var status by mutableStateOf("Starting")   // Starting, Downloading, Saving, Done, Failed, Cancelled
    var progress by mutableStateOf(0f)
    var speedMbps by mutableStateOf(0f)
    var doneBytes by mutableStateOf(0L)
    var totalBytes by mutableStateOf(0L)
    var eta by mutableStateOf("")
    var file by mutableStateOf("")
    var error by mutableStateOf("")
}

fun fmtEta(s: Int) = "%d:%02d left".format(s / 60, s % 60)

object DM {
    val items = mutableStateListOf<DlItem>()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var lastN = 0L

    fun isActive(i: DlItem) = i.status == "Starting" || i.status == "Downloading" || i.status == "Saving"
    fun activeCount() = items.count { isActive(it) }
    fun totalSpeed() = items.filter { isActive(it) }.sumOf { it.speedMbps.toDouble() }

    fun start(ctx: Context, url: String, title: String, thumb: String?, q: Quality) {
        val app = ctx.applicationContext
        val it = DlItem(UUID.randomUUID().toString(), title, thumb, q.label)
        items.add(0, it)
        ContextCompat.startForegroundService(app, Intent(app, DlService::class.java))
        scope.launch {
            try {
                val name = Downloader.download(app, url, q, it.id, { pct, done, total, spd, eta ->
                    if (it.status != "Cancelled") {
                        it.status = "Downloading"
                        if (pct >= 0) it.progress = pct
                        if (total > 0) it.totalBytes = total
                        if (done >= 0) it.doneBytes = done
                        if (spd >= 0) it.speedMbps = (spd * 8 / 1e6).toFloat()
                        if (eta > 0) it.eta = fmtEta(eta)
                        val now = System.currentTimeMillis()
                        if (now - lastN > 1000) {
                            lastN = now
                            try {
                                app.getSystemService(NotificationManager::class.java).notify(1,
                                    DlService.notif(app, "${activeCount()} active  •  %.1f Mbps".format(totalSpeed())))
                            } catch (_: Throwable) {}
                        }
                    }
                }, { st -> if (it.status != "Cancelled") { it.status = st; it.speedMbps = 0f } })
                it.progress = 1f; it.file = name; it.status = "Done"
            } catch (e: Throwable) {
                if (it.status != "Cancelled") { it.status = "Failed"; it.error = e.message?.take(160) ?: "Unknown error" }
            } finally {
                it.speedMbps = 0f
                if (activeCount() == 0) app.stopService(Intent(app, DlService::class.java))
            }
        }
    }

    fun cancel(i: DlItem) {
        Downloader.cancelled.add(i.id); i.status = "Cancelled"
        try { YoutubeDL.getInstance().destroyProcessById(i.id) } catch (_: Throwable) {}
    }
    fun clearFinished() { items.removeAll { !isActive(it) } }
}
