package com.vortex.dl

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.UUID

class DlItem(val id: String, val title: String, val thumb: String?, val label: String,
             val url: String, val q: Quality, val infoPath: String?, val exp: Long) {
    // Queued, Waiting (for Wi-Fi), Starting, Downloading, Processing, Saving, Paused, Done, Failed, Cancelled
    var status by mutableStateOf("Queued")
    var progress by mutableStateOf(0f)
    var speedMbps by mutableStateOf(0f)
    var doneBytes by mutableStateOf(0L)
    var totalBytes by mutableStateOf(0L)
    var eta by mutableStateOf("")
    var file by mutableStateOf("")
    var error by mutableStateOf("")
    var uri by mutableStateOf<Uri?>(null)
}

fun fmtEta(s: Int) = "%d:%02d left".format(s / 60, s % 60)

fun isWifi(c: Context): Boolean {
    val cm = c.getSystemService(ConnectivityManager::class.java)
    val n = cm.activeNetwork ?: return false
    val cap = cm.getNetworkCapabilities(n) ?: return false
    return cap.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || cap.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
}

object DM {
    val items = mutableStateListOf<DlItem>()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val gate = Mutex()
    private var lastN = 0L
    private lateinit var app: Context

    fun isActive(i: DlItem) = i.status in setOf("Queued", "Waiting", "Starting", "Downloading", "Processing", "Saving")
    private fun isRunning(i: DlItem) = i.status in setOf("Starting", "Downloading", "Processing", "Saving")
    fun activeCount() = items.count { isActive(it) }
    fun totalSpeed() = items.filter { isActive(it) }.sumOf { it.speedMbps.toDouble() }

    fun start(ctx: Context, url: String, title: String, thumb: String?, q: Quality, infoPath: String?, exp: Long) {
        app = ctx.applicationContext
        Prefs.init(app)
        val item = DlItem(UUID.randomUUID().toString(), title, thumb, q.label, url, q, infoPath, exp)
        items.add(0, item)
        launch(item, false)
    }

    fun resume(ctx: Context, i: DlItem) {
        app = ctx.applicationContext
        if (i.status == "Paused" || i.status == "Failed") launch(i, true)
    }

    fun pause(i: DlItem) {
        if (i.status != "Downloading" && i.status != "Starting") return
        Downloader.cancelled.add(i.id); i.status = "Paused"; i.speedMbps = 0f
        try { YoutubeDL.getInstance().destroyProcessById(i.id) } catch (_: Throwable) {}
    }

    fun cancel(i: DlItem) {
        Downloader.cancelled.add(i.id); i.status = "Cancelled"; i.speedMbps = 0f
        try { YoutubeDL.getInstance().destroyProcessById(i.id) } catch (_: Throwable) {}
        try { java.io.File(app.cacheDir, "dl/${i.id}").deleteRecursively() } catch (_: Throwable) {}
    }

    fun clearFinished() { items.removeAll { it.status == "Done" || it.status == "Failed" || it.status == "Cancelled" } }

    private fun launch(item: DlItem, resume: Boolean) {
        Downloader.cancelled.remove(item.id)
        item.status = "Queued"; item.error = ""; item.speedMbps = 0f
        ContextCompat.startForegroundService(app, Intent(app, DlService::class.java))
        scope.launch {
            try {
                gate.withLock {
                    if (Prefs.wifiOnly) while (!isWifi(app) && (item.status == "Queued" || item.status == "Waiting")) { item.status = "Waiting"; delay(3000) }
                    while (items.count { isRunning(it) } >= Prefs.maxParallel && (item.status == "Queued" || item.status == "Waiting")) { item.status = "Queued"; delay(500) }
                    if (item.status == "Queued" || item.status == "Waiting") item.status = "Starting"
                }
                if (item.status != "Starting") return@launch
                val res = Downloader.download(app, item.url, item.q, item.id, item.infoPath, item.exp, resume, { pct, done, total, spd, eta ->
                    if (item.status == "Starting" || item.status == "Downloading") {
                        item.status = "Downloading"
                        if (pct >= 0) item.progress = pct
                        if (total > 0) item.totalBytes = total
                        if (done >= 0) item.doneBytes = done
                        if (spd >= 0) item.speedMbps = (spd * 8 / 1e6).toFloat()
                        if (eta > 0) item.eta = fmtEta(eta)
                        val now = System.currentTimeMillis()
                        if (now - lastN > 1000) {
                            lastN = now
                            try {
                                app.getSystemService(NotificationManager::class.java).notify(1, DlService.notif(app,
                                    "${activeCount()} active  •  %.1f Mbps".format(totalSpeed()), (item.progress * 100).toInt()))
                            } catch (_: Throwable) {}
                        }
                    }
                }, { st -> if (isRunning(item)) { item.status = st; item.speedMbps = 0f; item.eta = "" } },
                   { p -> if (isRunning(item)) item.progress = p })
                item.progress = 1f; item.file = res.name; item.uri = res.uri; item.status = "Done"
                if (Prefs.notifyDone) notifyDone(item.title, true)
            } catch (e: Throwable) {
                if (item.status != "Cancelled" && item.status != "Paused") {
                    item.status = "Failed"; item.error = e.message?.take(160) ?: "Unknown error"
                    if (Prefs.notifyDone) notifyDone(item.title, false)
                }
            } finally {
                if (item.status != "Downloading") item.speedMbps = 0f
                if (activeCount() == 0) app.stopService(Intent(app, DlService::class.java))
            }
        }
    }

    private fun notifyDone(title: String, ok: Boolean) {
        try {
            val nm = app.getSystemService(NotificationManager::class.java)
            if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("done", "Completed", NotificationManager.IMPORTANCE_DEFAULT))
            val pi = PendingIntent.getActivity(app, 0, Intent(app, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            nm.notify((System.nanoTime() % 100000).toInt() + 100, NotificationCompat.Builder(app, "done")
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle(if (ok) "Download complete" else "Download failed").setContentText(title)
                .setAutoCancel(true).setContentIntent(pi).build())
        } catch (_: Throwable) {}
    }
}
