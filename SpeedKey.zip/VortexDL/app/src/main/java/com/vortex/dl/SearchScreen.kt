package com.vortex.dl

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

class SearchState {
    var q by mutableStateOf("")
    var results by mutableStateOf<List<SearchItem>>(emptyList())
    var loading by mutableStateOf(false)
    var msg by mutableStateOf("")
}

fun fmtDur(s: Int): String =
    if (s <= 0) "" else if (s >= 3600) "%d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60) else "%d:%02d".format(s / 60, s % 60)

@Composable
fun SearchScreen(ss: SearchState, scope: CoroutineScope, onPick: (SearchItem) -> Unit) {
    val ctx = LocalContext.current
    fun go() {
        val q = ss.q.trim()
        if (q.isEmpty() || ss.loading) return
        if (q.startsWith("http")) { ss.msg = "Paste links on the Home tab"; return }
        ss.loading = true; ss.msg = ""
        scope.launch {
            try {
                val r = Downloader.search(ctx, q)
                ss.results = r
                if (r.isEmpty()) ss.msg = "No results"
            } finally { ss.loading = false }
        }
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(14.dp))
        Text("Search", fontSize = 24.sp, fontWeight = FontWeight.Black, color = Color.White)
        Spacer(Modifier.height(10.dp))
        Box(Modifier.fillMaxWidth().border(1.5.dp, Neon, RoundedCornerShape(18.dp)).clip(RoundedCornerShape(18.dp)).background(Card).padding(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextField(ss.q, { ss.q = it }, Modifier.weight(1f), placeholder = { Text("Search videos & songs...") }, singleLine = true,
                    colors = TextFieldDefaults.colors(focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search), keyboardActions = KeyboardActions(onSearch = { go() }))
                IconButton({ go() }) { Icon(Icons.Default.Search, "Search", tint = Gold) }
            }
        }
        if (ss.loading) Row(Modifier.padding(vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            CircularProgressIndicator(Modifier.size(20.dp), color = Violet, strokeWidth = 2.dp)
            Spacer(Modifier.width(10.dp)); Text("Searching...", color = Color.LightGray)
        }
        if (ss.msg.isNotEmpty()) Text(ss.msg, color = Color.Gray, modifier = Modifier.padding(top = 16.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(vertical = 14.dp)) {
            items(ss.results, key = { it.id }) { r ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Card).clickable { onPick(r) }.padding(10.dp)) {
                    Box {
                        AsyncImage(r.thumb, null, Modifier.size(128.dp, 72.dp).clip(RoundedCornerShape(10.dp)), contentScale = ContentScale.Crop)
                        if (r.duration > 0) Text(fmtDur(r.duration), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.align(Alignment.BottomEnd).padding(4.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xCC000000)).padding(horizontal = 4.dp, vertical = 1.dp))
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(r.title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(r.channel, color = Color.Gray, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }
        }
    }
}
