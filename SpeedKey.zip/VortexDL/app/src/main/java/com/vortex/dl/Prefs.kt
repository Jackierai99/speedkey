package com.vortex.dl

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

object Prefs {
    private var sp: SharedPreferences? = null
    var folder by mutableStateOf("VortexDL")
    var askQuality by mutableStateOf(true)
    var defQuality by mutableStateOf("1080p")
    var maxParallel by mutableStateOf(2)
    var connections by mutableStateOf(16)
    var speedLimit by mutableStateOf(0)       // MB/s, 0 = unlimited
    var wifiOnly by mutableStateOf(false)
    var notifyDone by mutableStateOf(true)
    var subs by mutableStateOf(false)
    var clipDetect by mutableStateOf(true)
    var compat by mutableStateOf(true)         // H.264 + AAC: plays in every gallery/player

    fun init(c: Context) {
        if (sp != null) return
        val s = c.applicationContext.getSharedPreferences("vortex", 0); sp = s
        folder = s.getString("folder", "VortexDL") ?: "VortexDL"
        askQuality = s.getBoolean("ask", true)
        defQuality = s.getString("defq", "1080p") ?: "1080p"
        maxParallel = s.getInt("par", 2)
        connections = s.getInt("conn", 16)
        speedLimit = s.getInt("limit", 0)
        wifiOnly = s.getBoolean("wifi", false)
        notifyDone = s.getBoolean("notify", true)
        subs = s.getBoolean("subs", false)
        clipDetect = s.getBoolean("clip", true)
        compat = s.getBoolean("compat", true)
    }

    fun save() {
        sp?.edit()?.putString("folder", folder)?.putBoolean("ask", askQuality)?.putString("defq", defQuality)
            ?.putInt("par", maxParallel)?.putInt("conn", connections)?.putInt("limit", speedLimit)
            ?.putBoolean("wifi", wifiOnly)?.putBoolean("notify", notifyDone)?.putBoolean("subs", subs)?.putBoolean("clip", clipDetect)?.putBoolean("compat", compat)?.apply()
    }

    fun folderName() = folder.replace(Regex("[^A-Za-z0-9 _-]"), "").trim().ifEmpty { "VortexDL" }
}
