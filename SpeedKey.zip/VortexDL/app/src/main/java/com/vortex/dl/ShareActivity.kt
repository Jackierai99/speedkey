package com.vortex.dl

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

// Popup that opens right over YouTube when you tap Share -> Vortex DL
class ShareActivity : ComponentActivity() {
    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
    private fun has(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val t = intent.getStringExtra(android.content.Intent.EXTRA_TEXT) ?: ""
        val link = Regex("https?://\\S+").find(t)?.value ?: t
        val need = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33 && !has(Manifest.permission.POST_NOTIFICATIONS)) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT <= 28 && !has(Manifest.permission.WRITE_EXTERNAL_STORAGE)) need.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if (need.isNotEmpty()) perms.launch(need.toTypedArray())
        val hs = HomeState().also { it.url = link }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Violet, background = Bg, surface = Card)) {
                val scope = rememberCoroutineScope()
                LaunchedEffect(Unit) { fetch(applicationContext, scope, hs, link) }
                val none = remember { MutableInteractionSource() }
                Box(Modifier.fillMaxSize().background(Color(0xAA000000)).clickable(none, null) { finish() }, contentAlignment = Alignment.BottomCenter) {
                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp)).background(Bg)
                        .border(1.5.dp, Neon, RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp))
                        .clickable(remember { MutableInteractionSource() }, null) {}.padding(16.dp).padding(bottom = 12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Image(painterResource(R.drawable.logo), null, Modifier.size(38.dp).clip(CircleShape).border(1.5.dp, Neon, CircleShape), contentScale = ContentScale.Crop)
                            Spacer(Modifier.width(10.dp))
                            Text("Vortex DL", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                            IconButton({ finish() }) { Icon(Icons.Default.Close, "Close", tint = Color.Gray) }
                        }
                        Spacer(Modifier.height(10.dp))
                        Column(Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState())) {
                            if (hs.info == null) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 24.dp)) {
                                    CircularProgressIndicator(Modifier.size(22.dp), color = Violet, strokeWidth = 2.dp)
                                    Spacer(Modifier.width(12.dp))
                                    Text(if (hs.msg.isEmpty()) "Reading video..." else hs.msg, color = if (hs.msg.isEmpty()) Color.LightGray else Red)
                                }
                            }
                            VideoCard(hs) {
                                if (Build.VERSION.SDK_INT <= 28 && !has(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                                    perms.launch(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE)); return@VideoCard
                                }
                                startDownload(applicationContext, hs)
                                Toast.makeText(this@ShareActivity, "Download started • see Vortex DL", Toast.LENGTH_SHORT).show()
                                finish()
                            }
                        }
                    }
                }
            }
        }
    }
}
