package com.vortex.dl

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

data class Info(val title: String, val thumb: String?, val uploader: String?)
data class Quality(val label: String, val audio: Boolean, val value: Int)

val VIDEO_Q = listOf(Quality("4K", false, 2160), Quality("1440p", false, 1440), Quality("1080p", false, 1080),
    Quality("720p", false, 720), Quality("480p", false, 480), Quality("360p", false, 360), Quality("144p", false, 144))
val AUDIO_Q = listOf(Quality("MP3 320k", true, 320), Quality("MP3 256k", true, 256),
    Quality("MP3 192k", true, 192), Quality("MP3 128k", true, 128), Quality("MP3 64k", true, 64))

object Downloader {
    private var ready = false
    private fun init(c: Context) {
        if (ready) return
        YoutubeDL.getInstance().init(c)
        FFmpeg.getInstance().init(c)
        ready = true
    }

    suspend fun update(c: Context) = withContext(Dispatchers.IO) {
        try { init(c); YoutubeDL.getInstance().updateYoutubeDL(c) } catch (_: Throwable) {}
    }

    suspend fun info(c: Context, url: String): Info = withContext(Dispatchers.IO) {
        init(c)
        val i = YoutubeDL.getInstance().getInfo(url)
        Info(i.title ?: "Video", i.thumbnail, i.uploader)
    }

    suspend fun download(c: Context, url: String, q: Quality, onProgress: (Float, String) -> Unit): String =
        withContext(Dispatchers.IO) {
            init(c)
            val tmp = File(c.cacheDir, "dl").apply { deleteRecursively(); mkdirs() }
            val r = YoutubeDLRequest(url)
            r.addOption("-o", tmp.absolutePath + "/%(title).80s.%(ext)s")
            r.addOption("--no-playlist")
            r.addOption("-N", "16")
            r.addOption("--http-chunk-size", "10M")
            r.addOption("--no-mtime")
            if (q.audio) {
                r.addOption("-x"); r.addOption("--audio-format", "mp3"); r.addOption("--audio-quality", "${q.value}K")
            } else {
                r.addOption("-f", "bv*[height<=${q.value}]+ba/b[height<=${q.value}]/b")
                r.addOption("--merge-output-format", "mp4")
            }
            YoutubeDL.getInstance().execute(r, "vortex") { p, eta, _ ->
                onProgress((p / 100f).coerceIn(0f, 1f), if (eta > 0) "${eta}s left" else "")
            }
            val f = tmp.listFiles()?.filter { it.isFile && !it.name.endsWith(".part") }?.maxByOrNull { it.length() }
                ?: error("Download failed")
            val name = f.name
            save(c, f, q.audio)
            name
        }

    private fun save(c: Context, f: File, audio: Boolean) {
        val mime = if (audio) "audio/mpeg" else "video/mp4"
        if (Build.VERSION.SDK_INT >= 29) {
            val v = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, f.name); put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/VortexDL")
            }
            val u = c.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)!!
            c.contentResolver.openOutputStream(u)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
        } else {
            val d = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "VortexDL").apply { mkdirs() }
            f.copyTo(File(d, f.name), true)
        }
        f.delete()
    }
}
