package com.vortex.dl

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.yausername.aria2c.Aria2c
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap

data class Info(val title: String, val thumb: String?, val uploader: String?)
data class Quality(val label: String, val audio: Boolean, val value: Int)
class Sizes(val video: Map<Int, Long>, val audio: Long, val duration: Int)
class Meta(val info: Info, val sizes: Sizes, val maxH: Int, val path: String)
class Result(val name: String, val uri: Uri?)
data class SearchItem(val id: String, val title: String, val channel: String, val duration: Int, val thumb: String)
class SearchHit(val url: String, val title: String, val channel: String, val duration: Int, val thumb: String)

val VIDEO_Q = listOf(Quality("4K", false, 2160), Quality("1440p", false, 1440), Quality("1080p", false, 1080),
    Quality("720p", false, 720), Quality("480p", false, 480), Quality("360p", false, 360), Quality("144p", false, 144))
val AUDIO_Q = listOf(Quality("MP3 320k", true, 320), Quality("MP3 256k", true, 256),
    Quality("MP3 192k", true, 192), Quality("MP3 128k", true, 128), Quality("MP3 64k", true, 64))

fun fmtSize(b: Long): String = when {
    b <= 0 -> "—"
    b >= (1L shl 30) -> "%.2f GB".format(b / 1073741824.0)
    else -> "%.0f MB".format(b / 1048576.0)
}

object Downloader {
    private var ready = false
    private var aria = false
    val cancelled: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private val metaCache = ConcurrentHashMap<String, Meta>()
    private val inflight: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private val bg = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun cached(url: String): Meta? = metaCache[url.trim()]

    // starts reading a link in the background (clipboard / pasted link) so qualities are ready before you tap
    fun prefetch(c: Context, url: String) {
        val u = url.trim()
        if (metaCache.containsKey(u) || !inflight.add(u)) return
        bg.launch { try { if (innertube(c.applicationContext, u) == null) meta(c.applicationContext, u, true) } finally { inflight.remove(u) } }
    }

    suspend fun search(c: Context, q: String): List<SearchItem> = withContext(Dispatchers.IO) {
        try {
            init(c)
            val r = YoutubeDLRequest("ytsearch15:$q")
            r.addOption("--flat-playlist"); r.addOption("--dump-json"); r.addOption("--no-warnings")
            r.addOption("--force-ipv4"); Cookies.apply(c, r)
            val out = YoutubeDL.getInstance().execute(r, "search-" + System.nanoTime(), null).out
            out.lines().filter { it.startsWith("{") }.mapNotNull { line ->
                try {
                    val j = JSONObject(line)
                    val id = j.getString("id")
                    val ch = (j.optString("channel", "").ifEmpty { j.optString("uploader", "") }).let { if (it == "null") "" else it }
                    SearchItem(id, j.optString("title", "Video"), ch, j.optInt("duration", 0), "https://i.ytimg.com/vi/$id/mqdefault.jpg")
                } catch (_: Throwable) { null }
            }
        } catch (_: Throwable) { emptyList() }
    }

    @Synchronized
    private fun init(c: Context) {
        if (ready) return
        YoutubeDL.getInstance().init(c)
        FFmpeg.getInstance().init(c)
        try { Aria2c.getInstance().init(c); aria = true } catch (_: Throwable) {}
        ready = true
    }

    suspend fun warm(c: Context) = withContext(Dispatchers.IO) {
        try { File(c.cacheDir, "info").deleteRecursively(); File(c.cacheDir, "dl").deleteRecursively(); init(c) } catch (_: Throwable) {}
    }

    suspend fun update(c: Context) = withContext(Dispatchers.IO) {
        try { init(c); YoutubeDL.getInstance().updateYoutubeDL(c) } catch (_: Throwable) {}
    }

    suspend fun search(c: Context, q: String): List<SearchHit> = withContext(Dispatchers.IO) {
        try {
            init(c)
            val r = YoutubeDLRequest("ytsearch12:$q")
            r.addOption("--flat-playlist"); r.addOption("--dump-single-json"); r.addOption("--no-warnings")
            val out = YoutubeDL.getInstance().execute(r, "search-" + System.nanoTime(), null).out
            val e = JSONObject(out.substring(out.indexOf('{'))).optJSONArray("entries") ?: return@withContext emptyList()
            (0 until e.length()).mapNotNull {
                val o = e.getJSONObject(it)
                val id = o.optString("id", "")
                if (id.length != 11) null else SearchHit("https://www.youtube.com/watch?v=$id", o.optString("title", "Video"),
                    o.optString("channel", "").let { s -> if (s.isEmpty() || s == "null") o.optString("uploader", "") else s }.let { s -> if (s == "null") "" else s },
                    o.optInt("duration", 0), "https://i.ytimg.com/vi/$id/mqdefault.jpg")
            }
        } catch (_: Throwable) { emptyList() }
    }

    // instant title + thumbnail (one tiny HTTP call)
    suspend fun quick(url: String): Info? = withContext(Dispatchers.IO) {
        try {
            val u = URL("https://www.youtube.com/oembed?format=json&url=" + URLEncoder.encode(url, "UTF-8"))
            val cn = u.openConnection() as HttpURLConnection
            cn.connectTimeout = 6000; cn.readTimeout = 6000
            val j = JSONObject(cn.inputStream.bufferedReader().readText())
            Info(j.getString("title"), j.optString("thumbnail_url"), j.optString("author_name"))
        } catch (_: Throwable) { null }
    }

    private fun codec(f: JSONObject, k: String): String =
        f.optString(k, "none").let { if (it == "null" || it.isEmpty()) "none" else it }

    // builds qualities + sizes from a yt-dlp style info dict and saves it so the download can start from it instantly
    private fun buildMeta(c: Context, url: String, j: JSONObject, json: String, tag: String): Meta? {
        val fm = j.optJSONArray("formats") ?: return null
        val dur = j.optInt("duration", 0)
        val list = (0 until fm.length()).map { fm.getJSONObject(it) }
        fun sz(f: JSONObject): Long { val a = f.optLong("filesize", 0); return if (a > 0) a else f.optLong("filesize_approx", 0) }
        var audio = list.filter { codec(it, "vcodec") == "none" && codec(it, "acodec") != "none" }.maxOfOrNull { sz(it) } ?: 0L
        if (audio <= 0 && dur > 0) audio = 128L * 125L * dur
        val vids = list.filter { codec(it, "vcodec") != "none" && it.optInt("height", 0) > 0 && it.optString("protocol", "https") == "https" }
        val map = HashMap<Int, Long>()
        VIDEO_Q.forEachIndexed { idx, q ->
            val low = VIDEO_Q.getOrNull(idx + 1)?.value ?: 0
            val cand = vids.filter { it.optInt("height") <= q.value && it.optInt("height") > low }
            if (cand.isNotEmpty()) {
                val mh = cand.maxOf { it.optInt("height") }
                val top = cand.filter { it.optInt("height") == mh }.maxByOrNull { sz(it) }!!
                map[q.value] = sz(top) + if (codec(top, "acodec") == "none") audio else 0L
            }
        }
        if (map.isEmpty()) return null
        val f = File(c.cacheDir, "info/" + System.nanoTime() + tag + ".json").apply { parentFile!!.mkdirs(); writeText(json) }
        val th = j.optString("thumbnail", "").takeIf { it.isNotEmpty() && it != "null" }
        val up = j.optString("uploader", "").takeIf { it != "null" }
        val m = Meta(Info(j.optString("title", "Video"), th, up), Sizes(map, audio, dur), vids.maxOf { it.optInt("height") }, f.absolutePath)
        val old = metaCache[url.trim()]
        if (old == null || m.maxH > old.maxH) metaCache[url.trim()] = m
        return m
    }

    // slower but very reliable: yt-dlp reads the link
    suspend fun meta(c: Context, url: String, fast: Boolean): Meta? = withContext(Dispatchers.IO) {
        try {
            init(c)
            val r = YoutubeDLRequest(url)
            r.addOption("--dump-single-json"); r.addOption("--no-playlist"); r.addOption("--no-warnings")
            r.addOption("--force-ipv4"); Cookies.apply(c, r)
            if (fast) r.addOption("--extractor-args", "youtube:player_client=android_vr")
            val out = YoutubeDL.getInstance().execute(r, "meta-" + System.nanoTime(), null).out
            val json = out.substring(out.indexOf('{'))
            buildMeta(c, url, JSONObject(json), json, "")
        } catch (_: Throwable) { null }
    }

    // FASTEST: asks YouTube directly (about 1 second, no Python). If YouTube changes something this just returns null
    // and the yt-dlp readers above take over.
    suspend fun innertube(c: Context, url: String): Meta? = withContext(Dispatchers.IO) {
        try {
            val id = Regex("(?:youtu\\.be/|[?&]v=|/shorts/|/embed/|/live/)([\\w-]{11})").find(url)?.groupValues?.get(1)
                ?: return@withContext null
            val ua = "com.google.android.apps.youtube.vr.oculus/1.60.19 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip"
            val client = JSONObject().put("clientName", "ANDROID_VR").put("clientVersion", "1.60.19").put("deviceMake", "Oculus")
                .put("deviceModel", "Quest 3").put("osName", "Android").put("osVersion", "12L").put("androidSdkVersion", 32)
                .put("hl", "en").put("gl", "US").put("timeZone", "UTC").put("utcOffsetMinutes", 0)
            val body = JSONObject().put("context", JSONObject().put("client", client)).put("videoId", id)
                .put("contentCheckOk", true).put("racyCheckOk", true)
            val cn = URL("https://www.youtube.com/youtubei/v1/player?prettyPrint=false").openConnection() as HttpURLConnection
            cn.requestMethod = "POST"; cn.doOutput = true; cn.connectTimeout = 8000; cn.readTimeout = 8000
            cn.setRequestProperty("Content-Type", "application/json"); cn.setRequestProperty("User-Agent", ua)
            cn.setRequestProperty("X-YouTube-Client-Name", "28"); cn.setRequestProperty("X-YouTube-Client-Version", "1.60.19")
            cn.outputStream.use { it.write(body.toString().toByteArray()) }
            if (cn.responseCode != 200) return@withContext null
            val resp = JSONObject(cn.inputStream.bufferedReader().readText())
            if (resp.optJSONObject("playabilityStatus")?.optString("status") != "OK") return@withContext null
            val sd = resp.optJSONObject("streamingData") ?: return@withContext null
            val vd = resp.optJSONObject("videoDetails")
            val out = JSONArray()
            fun add(src: JSONArray?) {
                if (src == null) return
                for (i in 0 until src.length()) {
                    val f = src.getJSONObject(i)
                    val u = f.optString("url", "")
                    if (u.isEmpty()) continue
                    val at = f.optJSONObject("audioTrack")
                    if (at != null && !at.optBoolean("audioIsDefault", true)) continue
                    val mime = f.optString("mimeType", "")
                    val type = mime.substringBefore(";").trim()
                    val cod = Regex("codecs=\"([^\"]+)\"").find(mime)?.groupValues?.get(1)?.split(",")?.map { it.trim() } ?: emptyList()
                    val isV = type.startsWith("video"); val isA = type.startsWith("audio")
                    if (!isV && !isA) continue
                    val ext = when (type) { "video/mp4" -> "mp4"; "video/webm" -> "webm"; "audio/mp4" -> "m4a"; "audio/webm" -> "webm"; else -> "mp4" }
                    val o = JSONObject().put("format_id", f.optInt("itag").toString()).put("url", u).put("ext", ext)
                        .put("vcodec", if (isV) cod.getOrElse(0) { "avc1" } else "none")
                        .put("acodec", if (isA) cod.getOrElse(0) { "mp4a" } else cod.getOrElse(1) { "none" })
                        .put("width", f.optInt("width", 0)).put("height", f.optInt("height", 0)).put("fps", f.optInt("fps", 0))
                        .put("tbr", f.optInt("bitrate", 0) / 1000.0).put("protocol", "https")
                        .put("http_headers", JSONObject().put("User-Agent", ua))
                        .put("downloader_options", JSONObject().put("http_chunk_size", 10485760))
                    val cl = f.optString("contentLength", "").toLongOrNull() ?: 0L
                    if (cl > 0) o.put("filesize", cl)
                    out.put(o)
                }
            }
            add(sd.optJSONArray("adaptiveFormats")); add(sd.optJSONArray("formats"))
            if (out.length() == 0) return@withContext null
            val thumbs = vd?.optJSONObject("thumbnail")?.optJSONArray("thumbnails")
            val j = JSONObject().put("_type", "video").put("id", id).put("title", vd?.optString("title", "Video") ?: "Video")
                .put("uploader", vd?.optString("author", "") ?: "").put("duration", (vd?.optString("lengthSeconds", "0") ?: "0").toIntOrNull() ?: 0)
                .put("thumbnail", thumbs?.optJSONObject(thumbs.length() - 1)?.optString("url", "") ?: "")
                .put("extractor", "youtube").put("extractor_key", "Youtube")
                .put("webpage_url", "https://www.youtube.com/watch?v=$id").put("original_url", url).put("formats", out)
            buildMeta(c, url, j, j.toString(), "_it")
        } catch (_: Throwable) { null }
    }

    private fun bytes(v: String, u: String): Long {
        val m = when (u.firstOrNull()) { 'K' -> 1024.0; 'M' -> 1048576.0; 'G' -> 1073741824.0; 'T' -> 1099511627776.0; else -> 1.0 }
        return (v.toDouble() * m).toLong()
    }
    private val RX_YT = Regex("""of\s+~?\s*([\d.]+)\s*([KMGT]?i?B)(?:\s+at\s+([\d.]+)\s*([KMGT]?i?B)/s)?""")
    private val RX_AR = Regex("""([\d.]+)([KMGT]?i?B)/([\d.]+)([KMGT]?i?B)\((\d+)%\)""")
    private val RX_ARS = Regex("""DL:([\d.]+)([KMGT]?i?B)""")

    suspend fun download(
        c: Context, url: String, q: Quality, id: String, infoPath: String?, exp: Long, resume: Boolean, boost: Boolean,
        onProg: (Float, Long, Long, Double, Int) -> Unit, onStage: (String) -> Unit, onSave: (Float) -> Unit
    ): Result = withContext(Dispatchers.IO) {
        init(c)
        val tmp = File(c.cacheDir, "dl/$id").apply { if (!resume) deleteRecursively(); mkdirs() }
        val haveInfo = infoPath != null && File(infoPath).exists()

        fun run(useAria: Boolean, useInfo: Boolean) {
            var base = 0L; var curTotal = 0L; var lastPct = 0f; var processing = false
            val r = if (useInfo) YoutubeDLRequest(emptyList<String>()) else YoutubeDLRequest(url)
            if (useInfo) r.addOption("--load-info-json", infoPath!!)
            r.addOption("-o", tmp.absolutePath + "/%(title).80s.%(ext)s")
            r.addOption("--no-playlist"); r.addOption("--newline"); r.addOption("--no-mtime"); r.addOption("--no-warnings")
            r.addOption("--retries", "10"); r.addOption("--fragment-retries", "10"); r.addOption("--socket-timeout", "15")
            r.addOption("--force-ipv4"); Cookies.apply(c, r)
            val cn = if (boost) 16 else Prefs.connections.coerceIn(1, 16)
            if (Prefs.speedLimit > 0 && !boost) r.addOption("--limit-rate", "${Prefs.speedLimit}M")
            if (useAria) {
                r.addOption("--downloader", "libaria2c.so")
                r.addOption("--external-downloader-args", "aria2c:-x $cn -s $cn -k 1M --file-allocation=none --summary-interval=1")
            } else r.addOption("-N", "$cn")
            if (Prefs.subs && !q.audio) {
                r.addOption("--write-subs"); r.addOption("--write-auto-subs"); r.addOption("--sub-langs", "en,hi"); r.addOption("--embed-subs")
            }
            if (q.audio) {
                r.addOption("-f", "ba/b")
                r.addOption("-x"); r.addOption("--audio-format", "mp3"); r.addOption("--audio-quality", "${q.value}K")
            } else {
                if (Prefs.compat) r.addOption("-f", "bv*[height<=${q.value}][vcodec^=avc1]+ba[ext=m4a]/bv*[height<=${q.value}]+ba/b[height<=${q.value}]/b")
                else r.addOption("-f", "bv*[height<=${q.value}]+ba/b[height<=${q.value}]/b")
                r.addOption("--merge-output-format", "mp4")
            }
            YoutubeDL.getInstance().execute(r, id) { p, eta, line ->
                if (!processing && ("[Merger]" in line || "[ExtractAudio]" in line || "[VideoConvertor]" in line || "[Fixup" in line)) {
                    processing = true; onStage("Processing")
                }
                if (!processing) {
                    var pct = if (p >= 0) p / 100f else -1f
                    var done = -1L; var total = -1L; var spd = -1.0
                    val ar = RX_AR.find(line)
                    if (ar != null) {
                        val g = ar.groupValues
                        done = bytes(g[1], g[2]); total = bytes(g[3], g[4]); pct = g[5].toFloat() / 100f
                    } else {
                        RX_YT.find(line)?.let {
                            val g = it.groupValues
                            total = bytes(g[1], g[2])
                            if (pct >= 0) done = (total * pct).toLong()
                            if (g[3].isNotEmpty()) spd = bytes(g[3], g[4]).toDouble()
                        }
                    }
                    RX_ARS.find(line)?.let { spd = bytes(it.groupValues[1], it.groupValues[2]).toDouble() }
                    if (pct >= 0 && pct + 0.3f < lastPct) base += curTotal      // a new stream (audio) started
                    if (total > 0) curTotal = total
                    if (pct >= 0) lastPct = pct
                    if (pct >= 0 || total > 0 || spd >= 0) {
                        val dn = if (done >= 0) base + done else -1L
                        val tot = if (exp > 0) exp else base + curTotal
                        val overall = if (exp > 0 && dn >= 0) (dn.toFloat() / exp).coerceIn(0f, 0.99f) else pct
                        onProg(overall, dn, tot, spd, eta.toInt())
                    }
                }
            }
        }

        val attempts = buildList {
            val inner = haveInfo && infoPath!!.endsWith("_it.json")
            if (haveInfo) { add(Pair(aria, true)); if (aria && !inner) add(Pair(false, true)) }
            add(Pair(false, false))
        }
        var err: Throwable? = null; var ok = false
        for ((useAria, useInfo) in attempts) {
            try { run(useAria, useInfo); ok = true; break }
            catch (e: Throwable) { if (id in cancelled) throw e; err = e; tmp.deleteRecursively(); tmp.mkdirs() }
        }
        if (!ok) throw (err ?: Exception("Download failed"))
        val f = tmp.listFiles()?.filter { it.isFile && !it.name.endsWith(".part") && !it.name.endsWith(".aria2") && !it.name.endsWith(".ytdl") }
            ?.maxByOrNull { it.length() } ?: error("Download failed")
        val name = f.name
        onStage("Saving")
        val uri = save(c, f, q.audio, onSave)
        tmp.deleteRecursively()
        Result(name, uri)
    }

    suspend fun saveThumb(c: Context, url: String, name: String): Boolean = withContext(Dispatchers.IO) {
        try {
            fun get(u: String): ByteArray? = try {
                val cn = URL(u).openConnection() as HttpURLConnection
                cn.connectTimeout = 8000; cn.readTimeout = 8000
                if (cn.responseCode == 200) cn.inputStream.readBytes() else null
            } catch (_: Throwable) { null }
            val id = Regex("/vi(?:_webp)?/([\\w-]{11})/").find(url)?.groupValues?.get(1)
            val bytes = (if (id != null) get("https://i.ytimg.com/vi/$id/maxresdefault.jpg") ?: get("https://i.ytimg.com/vi/$id/hqdefault.jpg") else null)
                ?: get(url) ?: return@withContext false
            val fname = name.replace(Regex("[^A-Za-z0-9 _-]"), "").trim().take(60).ifEmpty { "thumbnail" } + ".jpg"
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, fname); put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/" + Prefs.folderName())
                }
                val u = c.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)!!
                c.contentResolver.openOutputStream(u)!!.use { it.write(bytes) }
            } else {
                val d = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), Prefs.folderName()).apply { mkdirs() }
                File(d, fname).writeBytes(bytes)
            }
            true
        } catch (_: Throwable) { false }
    }

    private fun save(c: Context, f: File, audio: Boolean, onPct: (Float) -> Unit): Uri? {
        val len = f.length().coerceAtLeast(1L)
        fun copy(o: OutputStream) {
            f.inputStream().use { i ->
                val buf = ByteArray(1 shl 20); var n = 0L; var r = i.read(buf)
                while (r >= 0) { o.write(buf, 0, r); n += r; onPct(n.toFloat() / len); r = i.read(buf) }
            }
        }
        val mime = if (audio) "audio/mpeg" else "video/mp4"
        var uri: Uri? = null
        if (Build.VERSION.SDK_INT >= 29) {
            val v = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, f.name); put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + Prefs.folderName())
            }
            uri = c.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)!!
            c.contentResolver.openOutputStream(uri)!!.use { copy(it) }
        } else {
            val d = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), Prefs.folderName()).apply { mkdirs() }
            File(d, f.name).outputStream().use { copy(it) }
        }
        f.delete()
        return uri
    }
}
