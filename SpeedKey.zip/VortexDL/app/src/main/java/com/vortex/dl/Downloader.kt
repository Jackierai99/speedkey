package com.vortex.dl

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.yausername.aria2c.Aria2c
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap

data class Info(val title: String, val thumb: String?, val uploader: String?)
data class Quality(val label: String, val audio: Boolean, val value: Int)
class Sizes(val video: Map<Int, Long>, val audio: Long, val duration: Int)
class Meta(val info: Info, val sizes: Sizes, val maxH: Int, val path: String)
class Result(val name: String, val uri: Uri?)

val VIDEO_Q = listOf(Quality("4K", false, 2160), Quality("1440p", false, 1440), Quality("1080p", false, 1080),
    Quality("720p", false, 720), Quality("480p", false, 480), Quality("360p", false, 360), Quality("144p", false, 144))
val AUDIO_Q = listOf(Quality("MP3 320k", true, 320), Quality("MP3 256k", true, 256),
    Quality("MP3 192k", true, 192), Quality("MP3 128k", true, 128), Quality("MP3 64k", true, 64))

fun fmtSize(b: Long): String = when {
    b <= 0 -> "—"
    b >= (1L shl 30) -> "%.2f GB".format(b / 1073741824.0)
    else -> "%.0f MB".format(b / 1048576.0)
}

object Downloader {
    private var ready = false
    private var aria = false
    val cancelled: MutableSet<String> = ConcurrentHashMap.newKeySet()

    @Synchronized
    private fun init(c: Context) {
        if (ready) return
        YoutubeDL.getInstance().init(c)
        FFmpeg.getInstance().init(c)
        try { Aria2c.getInstance().init(c); aria = true } catch (_: Throwable) {}
        ready = true
    }

    suspend fun warm(c: Context) = withContext(Dispatchers.IO) {
        try { File(c.cacheDir, "info").deleteRecursively(); init(c) } catch (_: Throwable) {}
    }

    suspend fun update(c: Context) = withContext(Dispatchers.IO) {
        try { init(c); YoutubeDL.getInstance().updateYoutubeDL(c) } catch (_: Throwable) {}
    }

    // instant title + thumbnail (one tiny HTTP call)
    suspend fun quick(url: String): Info? = withContext(Dispatchers.IO) {
        try {
            val u = URL("https://www.youtube.com/oembed?format=json&url=" + URLEncoder.encode(url, "UTF-8"))
            val cn = u.openConnection() as HttpURLConnection
            cn.connectTimeout = 6000; cn.readTimeout = 6000
            val j = JSONObject(cn.inputStream.bufferedReader().readText())
            Info(j.getString("title"), j.optString("thumbnail_url"), j.optString("author_name"))
        } catch (_: Throwable) { null }
    }

    private fun codec(f: JSONObject, k: String): String =
        f.optString(k, "none").let { if (it == "null" || it.isEmpty()) "none" else it }

    // one extraction -> sizes of every quality + saved info.json (download starts instantly from it, no 2nd extraction)
    suspend fun meta(c: Context, url: String, fast: Boolean): Meta? = withContext(Dispatchers.IO) {
        try {
            init(c)
            val r = YoutubeDLRequest(url)
            r.addOption("--dump-single-json"); r.addOption("--no-playlist"); r.addOption("--no-warnings")
            if (fast) r.addOption("--extractor-args", "youtube:player_client=android_vr")
            val out = YoutubeDL.getInstance().execute(r, "meta-" + System.nanoTime(), null).out
            val json = out.substring(out.indexOf('{'))
            val j = JSONObject(json)
            val fm = j.optJSONArray("formats") ?: return@withContext null
            val dur = j.optInt("duration", 0)
            val list = (0 until fm.length()).map { fm.getJSONObject(it) }
            fun sz(f: JSONObject): Long { val a = f.optLong("filesize", 0); return if (a > 0) a else f.optLong("filesize_approx", 0) }
            var audio = list.filter { codec(it, "vcodec") == "none" && codec(it, "acodec") != "none" }.maxOfOrNull { sz(it) } ?: 0L
            if (audio <= 0 && dur > 0) audio = 128L * 125L * dur
            val vids = list.filter { codec(it, "vcodec") != "none" && it.optInt("height", 0) > 0 && it.optString("protocol", "https") == "https" }
            val map = HashMap<Int, Long>()
            VIDEO_Q.forEachIndexed { idx, q ->
                val low = VIDEO_Q.getOrNull(idx + 1)?.value ?: 0
                val cand = vids.filter { it.optInt("height") <= q.value && it.optInt("height") > low }
                if (cand.isNotEmpty()) {
                    val mh = cand.maxOf { it.optInt("height") }
                    val top = cand.filter { it.optInt("height") == mh }.maxByOrNull { sz(it) }!!
                    map[q.value] = sz(top) + if (codec(top, "acodec") == "none") audio else 0L
                }
            }
            if (map.isEmpty()) return@withContext null
            val f = File(c.cacheDir, "info/" + System.nanoTime() + ".json").apply { parentFile!!.mkdirs(); writeText(json) }
            val th = j.optString("thumbnail", "").takeIf { it.isNotEmpty() && it != "null" }
            val up = j.optString("uploader", "").takeIf { it != "null" }
            Meta(Info(j.optString("title", "Video"), th, up), Sizes(map, audio, dur), vids.maxOf { it.optInt("height") }, f.absolutePath)
        } catch (_: Throwable) { null }
    }

    private fun bytes(v: String, u: String): Long {
        val m = when (u.firstOrNull()) { 'K' -> 1024.0; 'M' -> 1048576.0; 'G' -> 1073741824.0; 'T' -> 1099511627776.0; else -> 1.0 }
        return (v.toDouble() * m).toLong()
    }
    private val RX_YT = Regex("""of\s+~?\s*([\d.]+)\s*([KMGT]?i?B)(?:\s+at\s+([\d.]+)\s*([KMGT]?i?B)/s)?""")
    private val RX_AR = Regex("""([\d.]+)([KMGT]?i?B)/([\d.]+)([KMGT]?i?B)\((\d+)%\)""")
    private val RX_ARS = Regex("""DL:([\d.]+)([KMGT]?i?B)""")

    suspend fun download(
        c: Context, url: String, q: Quality, id: String, infoPath: String?, exp: Long,
        onProg: (Float, Long, Long, Double, Int) -> Unit, onStage: (String) -> Unit, onSave: (Float) -> Unit
    ): Result = withContext(Dispatchers.IO) {
        init(c)
        val tmp = File(c.cacheDir, "dl/$id").apply { deleteRecursively(); mkdirs() }
        val haveInfo = infoPath != null && File(infoPath).exists()

        fun run(useAria: Boolean, useInfo: Boolean) {
            var base = 0L; var curTotal = 0L; var lastPct = 0f; var processing = false
            val r = if (useInfo) YoutubeDLRequest(emptyList<String>()) else YoutubeDLRequest(url)
            if (useInfo) r.addOption("--load-info-json", infoPath!!)
            r.addOption("-o", tmp.absolutePath + "/%(title).80s.%(ext)s")
            r.addOption("--no-playlist"); r.addOption("--newline"); r.addOption("--no-mtime"); r.addOption("--no-warnings")
            r.addOption("--retries", "10"); r.addOption("--fragment-retries", "10"); r.addOption("--socket-timeout", "15")
            if (useAria) {
                r.addOption("--downloader", "libaria2c.so")
                r.addOption("--external-downloader-args", "aria2c:-x 16 -s 16 -k 1M --file-allocation=none --summary-interval=1")
            } else r.addOption("-N", "16")
            if (q.audio) {
                r.addOption("-f", "ba/b")
                r.addOption("-x"); r.addOption("--audio-format", "mp3"); r.addOption("--audio-quality", "${q.value}K")
            } else {
                r.addOption("-f", "bv*[height<=${q.value}]+ba/b[height<=${q.value}]/b")
                r.addOption("--merge-output-format", "mp4")
            }
            YoutubeDL.getInstance().execute(r, id) { p, eta, line ->
                if (!processing && ("[Merger]" in line || "[ExtractAudio]" in line || "[VideoConvertor]" in line || "[Fixup" in line)) {
                    processing = true; onStage("Processing")
                }
                if (!processing) {
                    var pct = if (p >= 0) p / 100f else -1f
                    var done = -1L; var total = -1L; var spd = -1.0
                    val ar = RX_AR.find(line)
                    if (ar != null) {
                        val g = ar.groupValues
                        done = bytes(g[1], g[2]); total = bytes(g[3], g[4]); pct = g[5].toFloat() / 100f
                    } else {
                        RX_YT.find(line)?.let {
                            val g = it.groupValues
                            total = bytes(g[1], g[2])
                            if (pct >= 0) done = (total * pct).toLong()
                            if (g[3].isNotEmpty()) spd = bytes(g[3], g[4]).toDouble()
                        }
                    }
                    RX_ARS.find(line)?.let { spd = bytes(it.groupValues[1], it.groupValues[2]).toDouble() }
                    if (pct >= 0 && pct + 0.3f < lastPct) base += curTotal      // a new stream (audio) started
                    if (total > 0) curTotal = total
                    if (pct >= 0) lastPct = pct
                    if (pct >= 0 || total > 0 || spd >= 0) {
                        val dn = if (done >= 0) base + done else -1L
                        val tot = if (exp > 0) exp else base + curTotal
                        val overall = if (exp > 0 && dn >= 0) (dn.toFloat() / exp).coerceIn(0f, 0.99f) else pct
                        onProg(overall, dn, tot, spd, eta.toInt())
                    }
                }
            }
        }

        val attempts = buildList {
            if (haveInfo) { if (aria) add(Pair(true, true)); add(Pair(false, true)) }
            add(Pair(false, false))
        }
        var err: Throwable? = null; var ok = false
        for ((useAria, useInfo) in attempts) {
            try { run(useAria, useInfo); ok = true; break }
            catch (e: Throwable) { if (id in cancelled) throw e; err = e; tmp.deleteRecursively(); tmp.mkdirs() }
        }
        if (!ok) throw (err ?: Exception("Download failed"))
        val f = tmp.listFiles()?.filter { it.isFile && !it.name.endsWith(".part") && !it.name.endsWith(".aria2") && !it.name.endsWith(".ytdl") }
            ?.maxByOrNull { it.length() } ?: error("Download failed")
        val name = f.name
        onStage("Saving")
        val uri = save(c, f, q.audio, onSave)
        tmp.deleteRecursively()
        Result(name, uri)
    }

    private fun save(c: Context, f: File, audio: Boolean, onPct: (Float) -> Unit): Uri? {
        val len = f.length().coerceAtLeast(1L)
        fun copy(o: OutputStream) {
            f.inputStream().use { i ->
                val buf = ByteArray(1 shl 20); var n = 0L; var r = i.read(buf)
                while (r >= 0) { o.write(buf, 0, r); n += r; onPct(n.toFloat() / len); r = i.read(buf) }
            }
        }
        val mime = if (audio) "audio/mpeg" else "video/mp4"
        var uri: Uri? = null
        if (Build.VERSION.SDK_INT >= 29) {
            val v = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, f.name); put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/VortexDL")
            }
            uri = c.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)!!
            c.contentResolver.openOutputStream(uri)!!.use { copy(it) }
        } else {
            val d = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "VortexDL").apply { mkdirs() }
            File(d, f.name).outputStream().use { copy(it) }
        }
        f.delete()
        return uri
    }
}
