package com.vortex.dl

import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var updating by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Settings", fontSize = 24.sp, fontWeight = FontWeight.Black, color = Color.White)

        Section("Download")
        SwitchRow("Ask quality every time", "Off = one tap on Share starts the download with your default quality", Prefs.askQuality) { Prefs.askQuality = it; Prefs.save() }
        ChoiceRow("Default quality", "Used when asking is off, and pre-selected otherwise", listOf("Best", "1080p", "720p", "480p", "360p", "MP3 320k", "MP3 128k").map { it to it }, Prefs.defQuality) { Prefs.defQuality = it; Prefs.save() }
        Card3 {
            Text("Save folder name", color = Color.White, fontWeight = FontWeight.SemiBold)
            Text("Files go to Downloads/${Prefs.folderName()}", color = Color.Gray, fontSize = 12.sp)
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(Prefs.folder, { Prefs.folder = it.take(30); Prefs.save() }, singleLine = true, modifier = Modifier.fillMaxWidth())
        }
        SwitchRow("Embed subtitles", "English / Hindi subtitles inside the video, when available", Prefs.subs) { Prefs.subs = it; Prefs.save() }

        Section("Speed")
        ChoiceRow("Connections per download", "More connections = faster (max 16)", listOf("4" to 4, "8" to 8, "16" to 16), Prefs.connections) { Prefs.connections = it; Prefs.save() }
        ChoiceRow("Downloads at the same time", "Extra downloads wait in the queue", listOf("1" to 1, "2" to 2, "3" to 3, "5" to 5), Prefs.maxParallel) { Prefs.maxParallel = it; Prefs.save() }
        ChoiceRow("Speed limit", "Keep some internet for other apps", listOf("Unlimited" to 0, "1 MB/s" to 1, "2 MB/s" to 2, "5 MB/s" to 5, "10 MB/s" to 10), Prefs.speedLimit) { Prefs.speedLimit = it; Prefs.save() }

        Section("Network & alerts")
        SwitchRow("Wi-Fi only", "Downloads wait until you connect to Wi-Fi", Prefs.wifiOnly) { Prefs.wifiOnly = it; Prefs.save() }
        SwitchRow("Notify when complete", "Show a notification when a download finishes or fails", Prefs.notifyDone) { Prefs.notifyDone = it; Prefs.save() }
        SwitchRow("Detect copied links", "Show a quick download card when a YouTube link is in your clipboard", Prefs.clipDetect) { Prefs.clipDetect = it; Prefs.save() }

        Section("Engine")
        Card3 {
            Text("Update download engine", color = Color.White, fontWeight = FontWeight.SemiBold)
            Text("If downloads stop working after a YouTube change, tap this", color = Color.Gray, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            NeonButton(if (updating) "Updating..." else "Update now", androidx.compose.material.icons.Icons.Default.Refresh, !updating) {
                updating = true
                scope.launch {
                    Downloader.update(ctx); updating = false
                    Toast.makeText(ctx, "Engine update finished", Toast.LENGTH_SHORT).show()
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("Vortex DL 1.0  •  yt-dlp + aria2 + ffmpeg", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun Section(t: String) {
    Text(t.uppercase(), color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 20.dp, bottom = 8.dp))
}

@Composable
private fun Card3(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().padding(bottom = 10.dp).clip(RoundedCornerShape(16.dp)).background(Card).padding(14.dp), content = content)
}

@Composable
private fun SwitchRow(title: String, sub: String, on: Boolean, change: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(bottom = 10.dp).clip(RoundedCornerShape(16.dp)).background(Card).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
            Text(sub, color = Color.Gray, fontSize = 12.sp)
        }
        Switch(on, change, colors = SwitchDefaults.colors(checkedTrackColor = Violet))
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun <T> ChoiceRow(title: String, sub: String, options: List<Pair<String, T>>, current: T, pick: (T) -> Unit) {
    Card3 {
        Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
        Text(sub, color = Color.Gray, fontSize = 12.sp)
        Spacer(Modifier.height(10.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { (label, v) ->
                val on = v == current
                Text(label, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clip(RoundedCornerShape(50))
                        .background(if (on) Brush.horizontalGradient(listOf(Violet, Red)) else Brush.horizontalGradient(listOf(Chip, Chip)))
                        .clickable { pick(v) }.padding(horizontal = 14.dp, vertical = 8.dp))
            }
        }
    }
}
