package com.vortex.dl

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.launch

val Bg = Color(0xFF05050A); val Card = Color(0xFF0E0E1A)
val Violet = Color(0xFF8A2BFF); val Blue = Color(0xFF2B6BFF); val Red = Color(0xFFFF2B3D); val Gold = Color(0xFFFFC21A)
val Neon = Brush.horizontalGradient(listOf(Blue, Violet, Red))
val Chip = Color(0xFF1B1B2B)

class MainActivity : ComponentActivity() {
    private var shared by mutableStateOf("")
    private fun grab(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) {
            val t = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
            shared = Regex("https?://\\S+").find(t)?.value ?: t
        }
    }
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        grab(intent)
        if (Build.VERSION.SDK_INT >= 33)
            registerForActivityResult(ActivityResultContracts.RequestPermission()) {}.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Violet, background = Bg, surface = Card)) {
                Screen(shared) { shared = "" }
            }
        }
    }
    override fun onNewIntent(i: Intent) { super.onNewIntent(i); grab(i) }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Screen(sharedUrl: String, consume: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clip = LocalClipboardManager.current
    var url by remember { mutableStateOf("") }
    var info by remember { mutableStateOf<Info?>(null) }
    var audioTab by remember { mutableStateOf(false) }
    var sel by remember { mutableStateOf(VIDEO_Q[2]) }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf(0f) }
    var eta by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var ok by remember { mutableStateOf(false) }

    fun fetch(u: String) {
        scope.launch {
            msg = ""; ok = false; info = null; busy = true
            try { info = Downloader.info(ctx, u.trim()) } catch (e: Throwable) { msg = "Link error: ${e.message?.take(120)}" }
            busy = false
        }
    }
    LaunchedEffect(Unit) { Downloader.update(ctx) }
    LaunchedEffect(sharedUrl) { if (sharedUrl.isNotBlank()) { url = sharedUrl; consume(); fetch(sharedUrl) } }

    val glow by rememberInfiniteTransition(label = "g").animateFloat(0.4f, 1f,
        infiniteRepeatable(tween(1800), RepeatMode.Reverse), label = "a")

    Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Image(painterResource(R.drawable.logo), "Vortex DL",
            Modifier.size(170.dp).shadow(30.dp, RoundedCornerShape(85.dp), spotColor = Violet.copy(alpha = glow)))
        Spacer(Modifier.height(8.dp))
        Text("Vortex DL", fontSize = 30.sp, fontWeight = FontWeight.Black, color = Color.White)
        Text("Paste a link or share from YouTube", color = Color.Gray, fontSize = 13.sp)
        Spacer(Modifier.height(20.dp))

        Box(Modifier.fillMaxWidth().border(1.5.dp, Neon, RoundedCornerShape(18.dp)).clip(RoundedCornerShape(18.dp)).background(Card).padding(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextField(url, { url = it }, Modifier.weight(1f), placeholder = { Text("https://youtu.be/...") }, singleLine = true,
                    colors = TextFieldDefaults.colors(focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = { fetch(url) }))
                IconButton({ clip.getText()?.text?.let { url = it; fetch(it) } }) { Icon(Icons.Default.ContentPaste, "Paste", tint = Gold) }
            }
        }
        Spacer(Modifier.height(12.dp))
        NeonButton(if (busy && info == null) "Checking..." else "Fetch Video", Icons.Default.Search, url.isNotBlank() && !busy) { fetch(url) }

        if (msg.isNotEmpty()) Text(msg, color = if (ok) Color(0xFF2BFF7A) else Red, modifier = Modifier.padding(top = 12.dp), fontSize = 13.sp)

        info?.let { i ->
            Spacer(Modifier.height(20.dp))
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Card).padding(14.dp)) {
                AsyncImage(i.thumb, null, Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(14.dp)))
                Spacer(Modifier.height(10.dp))
                Text(i.title, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                i.uploader?.let { Text(it, color = Color.Gray, fontSize = 12.sp) }
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Tab("Video", !audioTab, Modifier.weight(1f)) { audioTab = false; sel = VIDEO_Q[2] }
                    Tab("MP3", audioTab, Modifier.weight(1f)) { audioTab = true; sel = AUDIO_Q[0] }
                }
                Spacer(Modifier.height(10.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    (if (audioTab) AUDIO_Q else VIDEO_Q).forEach { q ->
                        val on = q == sel
                        Text(q.label, color = if (on) Color.White else Color.LightGray, fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
                            modifier = Modifier.clip(RoundedCornerShape(50))
                                .background(if (on) Brush.horizontalGradient(listOf(Violet, Red)) else Brush.horizontalGradient(listOf(Chip, Chip)))
                                .clickable { sel = q }.padding(horizontal = 14.dp, vertical = 8.dp))
                    }
                }
                Spacer(Modifier.height(16.dp))
                if (busy) {
                    LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)), color = Violet, trackColor = Chip)
                    Text("${(progress * 100).toInt()}%  $eta", color = Gold, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                } else NeonButton("Download", Icons.Default.Download, true) {
                    scope.launch {
                        busy = true; progress = 0f; msg = ""; ok = false
                        try {
                            val n = Downloader.download(ctx, url.trim(), sel) { p, e -> progress = p; eta = e }
                            msg = "Saved in Downloads/VortexDL: $n"; ok = true
                        } catch (e: Throwable) { msg = "Failed: ${e.message?.take(150)}" }
                        busy = false
                    }
                }
            }
        }
        Spacer(Modifier.height(30.dp))
    }
}

@Composable
fun Tab(t: String, on: Boolean, m: Modifier, click: () -> Unit) =
    Box(m.clip(RoundedCornerShape(12.dp)).background(if (on) Violet.copy(alpha = .35f) else Chip).clickable { click() }.padding(10.dp),
        contentAlignment = Alignment.Center) { Text(t, color = Color.White, fontWeight = FontWeight.Bold) }

@Composable
fun NeonButton(t: String, icon: ImageVector, enabled: Boolean, click: () -> Unit) =
    Row(Modifier.fillMaxWidth().height(52.dp).alpha(if (enabled) 1f else .5f).clip(RoundedCornerShape(16.dp)).background(Neon)
        .clickable(enabled) { click() }, Arrangement.Center, Alignment.CenterVertically) {
        Icon(icon, null, tint = Color.White); Spacer(Modifier.width(8.dp))
        Text(t, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
