package com.vortex.dl

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

val Bg = Color(0xFF05050A); val Card = Color(0xFF0E0E1A)
val Violet = Color(0xFF8A2BFF); val Blue = Color(0xFF2B6BFF); val Red = Color(0xFFFF2B3D); val Gold = Color(0xFFFFC21A)
val Green = Color(0xFF2BFF7A); val Chip = Color(0xFF1B1B2B)
val Neon = Brush.horizontalGradient(listOf(Blue, Violet, Red))

class HomeState {
    var url by mutableStateOf("")
    var info by mutableStateOf<Info?>(null)
    var sizes by mutableStateOf<Sizes?>(null)
    var audioTab by mutableStateOf(false)
    var sel by mutableStateOf(VIDEO_Q[2])
    var busy by mutableStateOf(false)
    var msg by mutableStateOf("")
    var token = 0
}

class MainActivity : ComponentActivity() {
    private var shared by mutableStateOf("")
    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
    private fun grab(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) {
            val t = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
            shared = Regex("https?://\\S+").find(t)?.value ?: t
        }
    }
    private fun has(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED
    private fun storageOk(): Boolean {
        if (Build.VERSION.SDK_INT > 28 || has(Manifest.permission.WRITE_EXTERNAL_STORAGE)) return true
        perms.launch(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE)); return false
    }
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        grab(intent)
        val need = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33 && !has(Manifest.permission.POST_NOTIFICATIONS)) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT <= 28 && !has(Manifest.permission.WRITE_EXTERNAL_STORAGE)) need.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if (need.isNotEmpty()) perms.launch(need.toTypedArray())
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Violet, background = Bg, surface = Card)) {
                App(shared, { shared = "" }, { storageOk() })
            }
        }
    }
    override fun onNewIntent(i: Intent) { super.onNewIntent(i); grab(i) }
}

fun fetch(ctx: Context, scope: CoroutineScope, hs: HomeState, raw: String) {
    val u = raw.trim()
    if (!u.startsWith("http")) { hs.msg = "Paste a valid link"; return }
    hs.msg = ""; hs.info = null; hs.sizes = null; hs.busy = true
    val t = ++hs.token
    scope.launch { Downloader.quick(u)?.let { if (t == hs.token && hs.info == null) hs.info = it } }
    scope.launch {
        try {
            val (i, s) = Downloader.full(ctx, u)
            if (t == hs.token) { hs.sizes = s; if (hs.info == null) hs.info = i }
        } catch (e: Throwable) {
            if (t == hs.token && hs.info == null) hs.msg = "Link error: ${e.message?.take(120)}"
        }
        if (t == hs.token) hs.busy = false
    }
}

@Composable
fun App(shared: String, consume: () -> Unit, storageOk: () -> Boolean) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val hs = remember { HomeState() }
    var tab by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) { Downloader.warm(ctx); delay(30000); Downloader.update(ctx) }
    LaunchedEffect(shared) { if (shared.isNotBlank()) { hs.url = shared; consume(); tab = 0; fetch(ctx, scope, hs, shared) } }

    Scaffold(containerColor = Bg, bottomBar = {
        NavigationBar(containerColor = Card) {
            val c = NavigationBarItemDefaults.colors(selectedIconColor = Violet, selectedTextColor = Violet,
                indicatorColor = Violet.copy(alpha = .2f), unselectedIconColor = Color.Gray, unselectedTextColor = Color.Gray)
            NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Default.Home, null) }, label = { Text("Home") }, colors = c)
            NavigationBarItem(tab == 1, { tab = 1 }, {
                BadgedBox(badge = { val n = DM.activeCount(); if (n > 0) Badge { Text("$n") } }) { Icon(Icons.Default.Download, null) }
            }, label = { Text("Downloads") }, colors = c)
        }
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize().background(Bg)) {
            if (tab == 0) HomeScreen(hs, { fetch(ctx, scope, hs, it) }) {
                val i = hs.info
                if (i != null) {
                    if (!storageOk()) hs.msg = "Allow storage permission, then tap Download again"
                    else { hs.msg = ""; DM.start(ctx, hs.url.trim(), i.title, i.thumb, hs.sel); tab = 1 }
                }
            } else DownloadsScreen()
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeScreen(hs: HomeState, onFetch: (String) -> Unit, onDownload: () -> Unit) {
    val clip = LocalClipboardManager.current
    val glow by rememberInfiniteTransition(label = "g").animateFloat(0.4f, 1f,
        infiniteRepeatable(tween(1800), RepeatMode.Reverse), label = "a")
    val list = (if (hs.audioTab) AUDIO_Q else VIDEO_Q).let { l ->
        val m = hs.sizes?.video
        if (!hs.audioTab && m != null && m.isNotEmpty()) l.filter { m.containsKey(it.value) } else l
    }
    LaunchedEffect(hs.sizes, hs.audioTab, hs.info) {
        if (hs.sel !in list) hs.sel = list.firstOrNull { hs.audioTab || it.value <= 1080 } ?: list.first()
    }
    fun sizeOf(q: Quality): String {
        val s = hs.sizes ?: return "…"
        return if (q.audio) (if (s.duration > 0) "~" + fmtSize(q.value * 125L * s.duration) else "—")
        else "~" + fmtSize(s.video[q.value] ?: 0L)
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Image(painterResource(R.drawable.logo), "Vortex DL",
            Modifier.size(170.dp).shadow(30.dp, CircleShape, spotColor = Violet.copy(alpha = glow))
                .clip(CircleShape).border(2.dp, Neon, CircleShape), contentScale = ContentScale.Crop)
        Spacer(Modifier.height(8.dp))
        Text("Vortex DL", fontSize = 30.sp, fontWeight = FontWeight.Black, color = Color.White)
        Text("Paste a link or share from YouTube", color = Color.Gray, fontSize = 13.sp)
        Spacer(Modifier.height(20.dp))

        Box(Modifier.fillMaxWidth().border(1.5.dp, Neon, RoundedCornerShape(18.dp)).clip(RoundedCornerShape(18.dp)).background(Card).padding(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextField(hs.url, { hs.url = it }, Modifier.weight(1f), placeholder = { Text("https://youtu.be/...") }, singleLine = true,
                    colors = TextFieldDefaults.colors(focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = { onFetch(hs.url) }))
                IconButton({ clip.getText()?.text?.let { hs.url = it; onFetch(it) } }) { Icon(Icons.Default.ContentPaste, "Paste", tint = Gold) }
            }
        }
        Spacer(Modifier.height(12.dp))
        NeonButton(if (hs.busy && hs.info == null) "Checking..." else "Fetch Video", Icons.Default.Search, hs.url.isNotBlank() && !(hs.busy && hs.info == null)) { onFetch(hs.url) }

        if (hs.msg.isNotEmpty()) Text(hs.msg, color = Red, modifier = Modifier.padding(top = 12.dp), fontSize = 13.sp)

        hs.info?.let { i ->
            Spacer(Modifier.height(20.dp))
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Card).padding(14.dp)) {
                AsyncImage(i.thumb, null, Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(14.dp)), contentScale = ContentScale.Crop)
                Spacer(Modifier.height(10.dp))
                Text(i.title, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                i.uploader?.takeIf { it.isNotBlank() }?.let { Text(it, color = Color.Gray, fontSize = 12.sp) }
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Tab("Video", !hs.audioTab, Modifier.weight(1f)) { hs.audioTab = false }
                    Tab("MP3", hs.audioTab, Modifier.weight(1f)) { hs.audioTab = true }
                }
                Spacer(Modifier.height(10.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    list.forEach { q -> QChip(q, sizeOf(q), q == hs.sel) { hs.sel = q } }
                }
                Spacer(Modifier.height(16.dp))
                NeonButton("Download  •  ${hs.sel.label}  •  ${sizeOf(hs.sel)}", Icons.Default.Download, true) { onDownload() }
            }
        }
        Spacer(Modifier.height(30.dp))
    }
}

@Composable
fun DownloadsScreen() {
    val all = DM.items
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(14.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Downloads", fontSize = 24.sp, fontWeight = FontWeight.Black, color = Color.White, modifier = Modifier.weight(1f))
            if (all.any { !DM.isActive(it) }) TextButton({ DM.clearFinished() }) { Text("Clear", color = Gold) }
        }
        Spacer(Modifier.height(8.dp))
        val sp = DM.totalSpeed()
        Column(Modifier.fillMaxWidth().border(1.5.dp, Neon, RoundedCornerShape(18.dp)).clip(RoundedCornerShape(18.dp)).background(Card).padding(16.dp)) {
            Text("LIVE SPEED", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text("%.1f Mbps".format(sp), color = Gold, fontSize = 34.sp, fontWeight = FontWeight.Black)
            Text("%.2f MB/s   •   ${DM.activeCount()} active".format(sp / 8.0), color = Color.LightGray, fontSize = 13.sp)
        }
        if (all.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("No downloads yet", color = Color.Gray) }
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(vertical = 14.dp)) {
            items(all, key = { it.id }) { DlCard(it) }
        }
    }
}

@Composable
fun DlCard(d: DlItem) {
    val active = DM.isActive(d)
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Card).padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AsyncImage(d.thumb, null, Modifier.size(100.dp, 56.dp).clip(RoundedCornerShape(10.dp)), contentScale = ContentScale.Crop)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(d.title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                Text(d.label + "  •  " + d.status, fontSize = 12.sp,
                    color = when (d.status) { "Done" -> Green; "Failed", "Cancelled" -> Red; else -> Gold })
            }
            if (active) IconButton({ DM.cancel(d) }) { Icon(Icons.Default.Close, "Cancel", tint = Color.Gray) }
        }
        if (active) {
            Spacer(Modifier.height(10.dp))
            LinearProgressIndicator(progress = { d.progress }, modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)), color = Violet, trackColor = Chip)
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth()) {
                Text("${(d.progress * 100).toInt()}%  •  ${fmtSize(d.doneBytes)} / ${fmtSize(d.totalBytes)}", color = Color.LightGray, fontSize = 12.sp, modifier = Modifier.weight(1f))
                Text("%.1f Mbps".format(d.speedMbps), color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            if (d.eta.isNotEmpty()) Text(d.eta, color = Color.Gray, fontSize = 11.sp)
        }
        if (d.status == "Done") Text("Saved in Downloads/VortexDL  •  ${fmtSize(d.totalBytes)}", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
        if (d.status == "Failed") Text(d.error, color = Red, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
    }
}

@Composable
fun QChip(q: Quality, size: String, on: Boolean, click: () -> Unit) =
    Column(Modifier.clip(RoundedCornerShape(14.dp))
        .background(if (on) Brush.horizontalGradient(listOf(Violet, Red)) else Brush.horizontalGradient(listOf(Chip, Chip)))
        .clickable { click() }.padding(horizontal = 14.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(q.label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Text(size, color = if (on) Color.White else Gold, fontSize = 11.sp)
    }

@Composable
fun Tab(t: String, on: Boolean, m: Modifier, click: () -> Unit) =
    Box(m.clip(RoundedCornerShape(12.dp)).background(if (on) Violet.copy(alpha = .35f) else Chip).clickable { click() }.padding(10.dp),
        contentAlignment = Alignment.Center) { Text(t, color = Color.White, fontWeight = FontWeight.Bold) }

@Composable
fun NeonButton(t: String, icon: ImageVector, enabled: Boolean, click: () -> Unit) =
    Row(Modifier.fillMaxWidth().height(52.dp).alpha(if (enabled) 1f else .5f).clip(RoundedCornerShape(16.dp)).background(Neon)
        .clickable(enabled) { click() }, Arrangement.Center, Alignment.CenterVertically) {
        Icon(icon, null, tint = Color.White); Spacer(Modifier.width(8.dp))
        Text(t, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1)
    }
