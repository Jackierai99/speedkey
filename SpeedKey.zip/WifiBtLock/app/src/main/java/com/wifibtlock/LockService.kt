package com.wifibtlock

import android.accessibilityservice.AccessibilityService
import android.bluetooth.BluetoothAdapter
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.wifi.WifiManager
import android.view.accessibility.AccessibilityEvent

@Suppress("DEPRECATION")
class LockService : AccessibilityService() {
    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { enforce() }
    }

    override fun onServiceConnected() {
        val f = IntentFilter().apply {
            addAction(WifiManager.WIFI_STATE_CHANGED_ACTION)
            addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
        }
        registerReceiver(rx, f)
        enforce()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) { enforce() }
    override fun onInterrupt() {}
    override fun onDestroy() { try { unregisterReceiver(rx) } catch (_: Throwable) {}; super.onDestroy() }

    private fun enforce() {
        if (!getSharedPreferences("p", 0).getBoolean("acc_lock", false)) return
        try {
            val w = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            if (w.isWifiEnabled || w.wifiState == WifiManager.WIFI_STATE_ENABLING) w.isWifiEnabled = false
        } catch (_: Throwable) {}
        try {
            val b = BluetoothAdapter.getDefaultAdapter()
            if (b != null && (b.isEnabled || b.state == BluetoothAdapter.STATE_TURNING_ON)) b.disable()
        } catch (_: Throwable) {}
    }
}
