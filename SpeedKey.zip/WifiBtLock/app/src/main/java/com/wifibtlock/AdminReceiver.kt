package com.wifibtlock
import android.app.admin.DeviceAdminReceiver
class AdminReceiver : DeviceAdminReceiver()
