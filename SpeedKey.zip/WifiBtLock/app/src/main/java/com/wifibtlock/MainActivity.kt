package com.wifibtlock

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.bluetooth.BluetoothAdapter
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.wifi.WifiManager
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

@Suppress("DEPRECATION")
class MainActivity : Activity() {
    private val restrictions = listOf("no_change_wifi_state", "no_config_wifi", "no_bluetooth", "no_config_bluetooth")
    private lateinit var dpm: DevicePolicyManager
    private lateinit var admin: ComponentName
    private lateinit var doStatus: TextView
    private lateinit var doSwitch: Switch
    private lateinit var accStatus: TextView
    private lateinit var accSwitch: Switch
    private var busy = false

    private fun tv(t: String, size: Float = 15f) = TextView(this).apply { text = t; textSize = size; setPadding(0, 16, 0, 16) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        admin = ComponentName(this, AdminReceiver::class.java)
        val prefs = getSharedPreferences("p", 0)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 64, 48, 64) }
        root.addView(tv("WiFi / Bluetooth Lock", 24f))

        root.addView(tv("तरीका 1: Device Owner (पक्का)", 18f))
        doSwitch = Switch(this).apply { text = "Lock ON  " }
        doStatus = tv("")
        root.addView(doSwitch); root.addView(doStatus)

        root.addView(tv("तरीका 2: Accessibility (आसान)", 18f))
        accSwitch = Switch(this).apply { text = "Lock ON  " }
        accStatus = tv("")
        val open = Button(this).apply {
            text = "Accessibility सेटिंग खोलो"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        root.addView(accSwitch); root.addView(accStatus); root.addView(open)
        setContentView(ScrollView(this).apply { addView(root) })

        doSwitch.setOnCheckedChangeListener { _, on ->
            if (busy) return@setOnCheckedChangeListener
            if (on) lockDo() else unlockDo()
            refresh()
        }
        accSwitch.setOnCheckedChangeListener { _, on ->
            if (busy) return@setOnCheckedChangeListener
            prefs.edit().putBoolean("acc_lock", on).apply()
            if (on) {
                try { (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled = false } catch (_: Throwable) {}
                try { BluetoothAdapter.getDefaultAdapter()?.disable() } catch (_: Throwable) {}
                if (!accEnabled()) startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            refresh()
        }
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun accEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains("$packageName/")
    }

    private fun refresh() {
        busy = true
        val isOwner = dpm.isDeviceOwnerApp(packageName)
        doSwitch.isEnabled = isOwner
        if (!isOwner) {
            doSwitch.isChecked = false
            doStatus.text = "Device Owner नहीं है। LADB/ADB से यह चलाओ:\ndpm set-device-owner com.wifibtlock/.AdminReceiver"
        } else {
            doSwitch.isChecked = dpm.getUserRestrictions(admin).getBoolean("no_bluetooth", false)
            doStatus.text = if (doSwitch.isChecked) "🔒 लॉक ON — पैनल/सेटिंग से ऑन नहीं होंगे" else "🔓 लॉक OFF"
        }
        val on = getSharedPreferences("p", 0).getBoolean("acc_lock", false)
        accSwitch.isChecked = on
        accStatus.text = (if (on) "🔒 लॉक ON" else "🔓 लॉक OFF") +
            (if (accEnabled()) "\nसर्विस: चालू ✅" else "\nसर्विस: बंद ❌ — सेटिंग में 'WiFi BT Lock' को ऑन करो")
        busy = false
    }

    private fun lockDo() {
        try { (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled = false } catch (_: Throwable) {}
        try { BluetoothAdapter.getDefaultAdapter()?.disable() } catch (_: Throwable) {}
        restrictions.forEach { try { dpm.addUserRestriction(admin, it) } catch (_: Throwable) {} }
    }

    private fun unlockDo() { restrictions.forEach { try { dpm.clearUserRestriction(admin, it) } catch (_: Throwable) {} } }
}
