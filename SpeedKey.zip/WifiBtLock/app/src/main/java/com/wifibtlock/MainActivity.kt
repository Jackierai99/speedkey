package com.wifibtlock

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.bluetooth.BluetoothAdapter
import android.content.ComponentName
import android.content.Context
import android.net.wifi.WifiManager
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {
    private val restrictions = listOf(
        "no_change_wifi_state",   // Android 13+: WiFi on/off blocked everywhere
        "no_config_wifi",         // older Android: WiFi settings blocked
        "no_bluetooth",           // Bluetooth fully disabled, cannot be turned on
        "no_config_bluetooth"
    )

    private lateinit var dpm: DevicePolicyManager
    private lateinit var admin: ComponentName
    private lateinit var status: TextView
    private lateinit var toggle: Switch

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        admin = ComponentName(this, AdminReceiver::class.java)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(64, 64, 64, 64)
        }
        status = TextView(this).apply { textSize = 18f; gravity = Gravity.CENTER }
        toggle = Switch(this).apply { textSize = 22f; text = "WiFi/Bluetooth Lock  " }
        root.addView(toggle); root.addView(status)
        setContentView(root)

        if (!dpm.isDeviceOwnerApp(packageName)) {
            toggle.isEnabled = false
            status.text = "Device Owner नहीं है।\nकंप्यूटर से यह कमांड चलाओ:\n\nadb shell dpm set-device-owner com.wifibtlock/.AdminReceiver"
            return
        }
        toggle.isChecked = dpm.getUserRestrictions(admin).getBoolean("no_bluetooth", false)
        render()
        toggle.setOnCheckedChangeListener { _, on -> if (on) lock() else unlock(); render() }
    }

    private fun lock() {
        try { @Suppress("DEPRECATION") (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled = false } catch (_: Throwable) {}
        try { @Suppress("DEPRECATION") BluetoothAdapter.getDefaultAdapter()?.disable() } catch (_: Throwable) {}
        restrictions.forEach { try { dpm.addUserRestriction(admin, it) } catch (_: Throwable) {} }
    }

    private fun unlock() {
        restrictions.forEach { try { dpm.clearUserRestriction(admin, it) } catch (_: Throwable) {} }
    }

    private fun render() {
        status.text = if (toggle.isChecked) "🔒 लॉक ON — WiFi/Bluetooth ऑन नहीं होंगे"
        else "🔓 लॉक OFF — अब सेटिंग/पैनल से ऑन कर सकते हो"
    }
}
