1) GitHub पर upload करो -> Actions -> APK डाउनलोड करो और install करो।
2) फ़ोन से सारे अकाउंट (Google आदि) अस्थायी हटाओ, USB debugging ON करो।
3) कंप्यूटर से: adb shell dpm set-device-owner com.wifibtlock/.AdminReceiver
4) ऐप खोलो -> स्विच ON = WiFi/BT लॉक, OFF = फिर से ऑन हो सकेंगे।
(अकाउंट वापस जोड़ सकते हो।) Uninstall करने से पहले लॉक OFF करो।
