WiFi BT Lock - दो तरीके
1) GitHub पर upload -> Actions -> APK डाउनलोड -> install।
तरीका 2 (Accessibility): ऐप खोलो -> "Accessibility सेटिंग खोलो" -> WiFi BT Lock सर्विस ON -> ऐप में स्विच ON।
तरीका 1 (Device Owner): अकाउंट हटाओ, Wireless debugging + LADB से:
dpm set-device-owner com.wifibtlock/.AdminReceiver
