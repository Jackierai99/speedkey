# MakimaOS
Open in Android Studio, or push to GitHub: Actions -> Build APK -> download the MakimaOS-apk artifact.
Settings -> paste any API key (Gemini / Grok / DeepSeek / OpenAI / Groq). Provider and model are detected automatically.
Enable the Accessibility Service for phone control.
Optional: add bg_listen.png / bg_speak.png (same layout as bg_main.png) to app/src/main/res/drawable-nodpi for real pose animations.

## v2.0
- AI agent: Makima now operates the phone herself (open apps, YouTube search + auto-play, tap, type, scroll, read screen, calls, alarms, settings...). Needs the Accessibility service ON.
- Floating subtitles under the bubble (what you said + her reply) while another app is open.
- Keys: paste one or many keys; auto provider detect; keys rotate on rate limit; retries and non-stream fallback when the connection drops.
- Home screen artwork no longer moves.
