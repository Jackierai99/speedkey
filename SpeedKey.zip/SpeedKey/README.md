# MakimaOS
Open in Android Studio, or push to GitHub: Actions -> Build APK -> download the MakimaOS-apk artifact.
Settings -> paste any API key (Gemini / Grok / DeepSeek / OpenAI / Groq). Provider and model are detected automatically.
Enable the Accessibility Service for phone control.
Optional: add bg_listen.png / bg_speak.png (same layout as bg_main.png) to app/src/main/res/drawable-nodpi for real pose animations.

## v2.0
- AI agent: Makima now operates the phone herself (open apps, YouTube search + auto-play, tap, type, scroll, read screen, calls, alarms, settings...). Needs the Accessibility service ON.
- Floating subtitles under the bubble (what you said + her reply) while another app is open.
- Keys: paste one or many keys; auto provider detect; keys rotate on rate limit; retries and non-stream fallback when the connection drops.
- Home screen artwork no longer moves.

## v2.1 - animated Makima
- Home screen now has a live layered character (cut from the character sheet), standing in the centre:
  - blinks, breathes, braid sways, head moves slightly
  - LISTENING: head tilts toward you, soft smile, sound waves at her ear
  - THINKING: head tilts the other way, three dots
  - SPEAKING: mouth changes shape with the loudness of her real voice (lip-sync); with the phone's own voice it follows a natural talking rhythm
  - tap her to hear "Main yahin hoon"
- Sprites live in res/drawable-nodpi/rig_*.png. Positions are the constants at the top of HomeScreen.kt (spHead, spMouth, spEyes, ...).
- Buttons (chat, mic, voice, nav bar) are now real Compose widgets instead of being baked into the picture.
