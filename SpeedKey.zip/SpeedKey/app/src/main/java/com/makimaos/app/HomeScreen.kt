package com.makimaos.app
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

// ---------------------------------------------------------------------------------------------
// Layered "Live2D-style" puppet. Every layer is a cut-out of the character sheet; positions are in
// a 700 x 900 design space (sprites are stored at 2x resolution). The head group pivots around the
// neck, the braid swings from the shoulder, the torso breathes, eyes blink, and the mouth swaps
// between viseme frames driven by the loudness of her real voice.
// ---------------------------------------------------------------------------------------------
private class Sp(val x: Float, val y: Float, val w: Float, val h: Float)

private val spTorso = Sp(175f, 270f, 351f, 402f)
private val spBraid = Sp(212f, 200f, 111f, 273f)
private val spHead = Sp(240f, 20f, 220f, 320f)
private val spMouth = Sp(318f, 204f, 79f, 41f)
private val spEyes = Sp(285f, 148f, 141f, 35f)

private const val DESIGN_X = 150f   // visible part of the design space
private const val DESIGN_W = 400f
private const val DESIGN_H = 690f

private class Rig {
    var t = 0f
    var lvl = 0f          // smoothed voice loudness 0..1
    var vis = 0           // mouth frame: 0 closed, 1 smile, 2/3/5/6 = opening sizes
    var eye = 0           // 0 open, 1 half, 2 closed
    var rot = 0f; var dx = 0f; var dy = 0f
    var braid = 0f; var breath = 0f; var glow = 0.25f
    private var blinkIn = 2.2f
    private var blinkT = -1f

    fun step(dt: Float, app: AppState) {
        t += dt
        val mode = app.mode

        // ---- mouth: real loudness when her premium voice plays, a natural syllable rhythm otherwise
        var raw = 0f
        if (mode == Mode.SPEAK) {
            val r = app.mouth.level()
            raw = if (r >= 0f) min(1f, r * 4.5f) else {
                val a = abs(sin(t * 9.5f)) * 0.55f + abs(sin(t * 5.1f + 1f)) * 0.35f
                a * (0.55f + 0.45f * abs(sin(t * 1.7f)))
            }
        }
        val kk = if (raw > lvl) 36f else 12f
        lvl += (raw - lvl) * (1f - exp(-dt * kk))
        vis = when {
            mode == Mode.SPEAK -> when { lvl < 0.08f -> 0; lvl < 0.22f -> 2; lvl < 0.42f -> 3; lvl < 0.65f -> 5; else -> 6 }
            mode == Mode.LISTEN -> 1
            mode == Mode.IDLE && sin(t * 0.35f) > 0.55f -> 1
            else -> 0
        }

        // ---- head pose per state
        val sway = sin(t * 0.7f)
        var tr = sway * 0.8f; var tx = sin(t * 0.5f) * 1.2f; var ty = 0f
        when (mode) {
            Mode.LISTEN -> { tr = 5f + sway * 0.6f; tx = 5f; ty = 4f + app.level * 3f }
            Mode.THINK -> { tr = -4f + sway * 0.5f; tx = -3f; ty = -3f }
            Mode.SPEAK -> { tr = sin(t * 2.3f) * 1.4f; tx = sin(t * 1.3f) * 1.5f; ty = lvl * 3.5f }
            else -> {}
        }
        val a = 1f - exp(-dt * 4.5f)
        rot += (tr - rot) * a; dx += (tx - dx) * a; dy += (ty - dy) * a
        braid = sin(t * 1.5f + 0.8f) * 1.8f - rot * 0.6f + (if (mode == Mode.SPEAK) sin(t * 11f) * lvl * 1.2f else 0f)
        breath = sin(t * 1.8f) * 0.006f + lvl * 0.004f
        val gt = when (mode) { Mode.LISTEN -> 0.45f; Mode.THINK -> 0.35f; Mode.SPEAK -> 0.3f + lvl * 0.3f; else -> 0.22f }
        glow += (gt - glow) * (1f - exp(-dt * 3f))

        // ---- blink
        blinkIn -= dt
        if (blinkT < 0f && blinkIn <= 0f) blinkT = 0f
        if (blinkT >= 0f) {
            blinkT += dt
            eye = when {
                blinkT < 0.05f -> 1
                blinkT < 0.13f -> 2
                blinkT < 0.19f -> 1
                else -> { blinkT = -1f; blinkIn = 2.2f + abs(sin(t * 37.1f)) * 3.6f; 0 }
            }
        } else eye = 0
    }
}

private fun DrawScope.eyeEmblem(c: Offset, w: Float, color: Color, sw: Float) {
    val h = w * 0.42f
    val p = Path().apply {
        moveTo(c.x - w, c.y)
        quadraticBezierTo(c.x, c.y - h * 1.8f, c.x + w, c.y)
        quadraticBezierTo(c.x, c.y + h * 1.8f, c.x - w, c.y)
        close()
    }
    drawPath(p, color, style = Stroke(sw, cap = StrokeCap.Round))
    drawCircle(color, h * 0.95f, c, style = Stroke(sw))
    drawCircle(color, h * 0.35f, c)
    drawLine(color, Offset(c.x, c.y - h * 2.6f), Offset(c.x, c.y - h * 1.6f), sw, StrokeCap.Round)
    drawLine(color, Offset(c.x, c.y + h * 2.6f), Offset(c.x, c.y + h * 1.6f), sw, StrokeCap.Round)
}

@Composable
fun HomeScreen(app: AppState) {
    val t = MakimaTheme
    val rig = remember { Rig() }
    val tick = remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { n ->
                if (last != 0L) rig.step(((n - last) / 1_000_000_000f).coerceIn(0f, 0.05f), app)
                last = n
                tick.longValue = n
            }
        }
    }

    val torso = ImageBitmap.imageResource(R.drawable.rig_torso)
    val braid = ImageBitmap.imageResource(R.drawable.rig_braid)
    val head = ImageBitmap.imageResource(R.drawable.rig_head)
    val eyesHalf = ImageBitmap.imageResource(R.drawable.rig_eyes_half)
    val eyesClosed = ImageBitmap.imageResource(R.drawable.rig_eyes_closed)
    val m1 = ImageBitmap.imageResource(R.drawable.rig_mouth1)
    val m2 = ImageBitmap.imageResource(R.drawable.rig_mouth2)
    val m3 = ImageBitmap.imageResource(R.drawable.rig_mouth3)
    val m5 = ImageBitmap.imageResource(R.drawable.rig_mouth5)
    val m6 = ImageBitmap.imageResource(R.drawable.rig_mouth6)

    val mode = app.mode
    val inf = rememberInfiniteTransition(label = "inf")
    val ripple by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1400, easing = LinearEasing)), label = "ripple")
    val pulse by inf.animateFloat(0.92f, 1.12f, infiniteRepeatable(tween(650), RepeatMode.Reverse), label = "pulse")

    Box(Modifier.fillMaxSize().background(Color(0xFF080306))) {
        // ------------------------------------------------ stage: background + animated character
        Canvas(
            Modifier.fillMaxSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                if (mode == Mode.SPEAK) app.mouth.stop() else app.say("Main yahin hoon, ${Prefs.userName}.")
            }
        ) {
            val tk = tick.longValue            // re-draw every frame
            val w = size.width; val h = size.height
            drawRect(Brush.verticalGradient(listOf(Color(0xFF0A0306), Color(0xFF1C0610), Color(0xFF0A0306))))

            val areaTop = h * 0.10f; val areaH = h * 0.62f
            val s = min(w / DESIGN_W, areaH / DESIGN_H)
            val ox = (w - DESIGN_W * s) / 2f - DESIGN_X * s
            val oy = areaTop + (areaH - DESIGN_H * s) / 2f
            fun px(x: Float) = ox + x * s
            fun py(y: Float) = oy + y * s

            // big faint eye emblem + red glow behind her
            eyeEmblem(Offset(w / 2f, py(250f)), w * 0.62f, t.accent.copy(alpha = 0.10f), 5f)
            drawCircle(
                Brush.radialGradient(listOf(t.accent.copy(alpha = rig.glow), Color.Transparent), Offset(w / 2f, py(260f)), 330f * s),
                330f * s, Offset(w / 2f, py(260f))
            )
            // drifting petals
            for (i in 0 until 12) {
                val ph = i * 1.7f
                val fx = ((i * 83) % 100) / 100f
                val yy = ((rig.t * (0.03f + (i % 4) * 0.012f) + i * 0.137f) % 1f)
                val xx = w * (fx + 0.04f * sin(rig.t * 0.6f + ph))
                val rot = rig.t * 40f + i * 30f
                withTransform({ rotate(rot, Offset(xx, h * yy)) }) {
                    drawOval(t.accent.copy(alpha = 0.22f), Offset(xx - 4f, h * yy - 8f), Size(8f + (i % 3) * 3f, 16f + (i % 3) * 5f))
                }
            }

            fun place(img: ImageBitmap, sp: Sp) {
                drawImage(
                    img,
                    dstOffset = IntOffset(px(sp.x).roundToInt(), py(sp.y).roundToInt()),
                    dstSize = IntSize(ceil(sp.w * s).toInt(), ceil(sp.h * s).toInt()),
                    filterQuality = FilterQuality.High
                )
            }

            val neck = Offset(px(350f), py(305f))
            // torso: breathes, leans slightly with the head
            withTransform({
                scale(1f, 1f + rig.breath, Offset(px(350f), py(670f)))
                rotate(rig.rot * 0.2f, Offset(px(350f), py(670f)))
            }) { place(torso, spTorso) }
            // braid swings from the shoulder
            withTransform({
                translate(rig.dx * 0.4f * s, rig.dy * 0.4f * s)
                rotate(rig.braid, Offset(px(spBraid.x + spBraid.w * 0.5f), py(spBraid.y + 6f)))
            }) { place(braid, spBraid) }
            // head: base + eyes + mouth, pivoting around the neck
            withTransform({
                translate(rig.dx * s, rig.dy * s)
                rotate(rig.rot, neck)
            }) {
                place(head, spHead)
                when (rig.eye) { 1 -> place(eyesHalf, spEyes); 2 -> place(eyesClosed, spEyes) }
                when (rig.vis) { 1 -> place(m1, spMouth); 2 -> place(m2, spMouth); 3 -> place(m3, spMouth); 5 -> place(m5, spMouth); 6 -> place(m6, spMouth) }
            }

            // state effects
            if (mode == Mode.LISTEN) {
                val ear = Offset(px(447f + rig.dx), py(172f + rig.dy))
                for (i in 0..2) {
                    val f = (ripple + i / 3f) % 1f
                    drawCircle(t.accent.copy(alpha = (1f - f) * 0.6f), (14f + f * 105f) * s, ear, style = Stroke(3f))
                }
            }
            if (mode == Mode.THINK) {
                for (i in 0..2) {
                    val f = ((rig.t * 1.6f - i * 0.33f) % 1f + 1f) % 1f
                    drawCircle(t.accent.copy(alpha = 0.25f + 0.65f * (1f - f)), 7f * s, Offset(px(478f + i * 22f), py(70f - i * 12f)))
                }
            }
            if (tk == Long.MIN_VALUE) drawCircle(Color.Transparent, 0f, Offset.Zero)
        }

        // ------------------------------------------------ UI on top
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            // header
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Canvas(Modifier.size(46.dp)) { eyeEmblem(center, size.width * 0.46f, t.accent, 3.5f) }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text("Makima", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Medium)
                        Text("OS", color = t.accent, fontSize = 26.sp, fontWeight = FontWeight.Bold, fontStyle = FontStyle.Italic)
                    }
                    Text("Your Personal AI Assistant", color = Color(0xCCFFFFFF), fontSize = 12.sp, fontStyle = FontStyle.Italic)
                }
                Box(
                    Modifier.size(46.dp).clip(CircleShape).background(Color(0x9914040A)).border(1.dp, t.accent, CircleShape)
                        .clickable { app.screen = Screen.SETTINGS },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.Settings, null, tint = Color.White, modifier = Modifier.size(24.dp)) }
            }

            Spacer(Modifier.weight(1f))

            // live text pill
            val text = when {
                mode == Mode.LISTEN -> if (app.partial.isBlank()) "Listening, ${Prefs.userName}..." else app.partial
                mode == Mode.THINK -> "Thinking..."
                else -> app.bubble
            }
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                val shape = RoundedCornerShape(50)
                Row(
                    Modifier.fillMaxWidth(0.86f).height(62.dp).clip(shape).background(Color(0xE614040A)).border(1.dp, t.accent, shape)
                        .clickable { if (mode == Mode.SPEAK) app.mouth.stop() else app.screen = Screen.CHAT }
                        .padding(horizontal = 18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.GraphicEq, null, tint = t.accent, modifier = Modifier.size(30.dp))
                    Spacer(Modifier.width(14.dp))
                    if (text.isBlank()) {
                        Column(Modifier.weight(1f)) {
                            Text("Hello ${Prefs.userName}...", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                            Text("How can I help you today?", color = t.accent, fontSize = 12.sp)
                        }
                    } else {
                        Text(text, color = Color.White, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    }
                    Icon(Icons.Default.ChevronRight, null, tint = t.accent, modifier = Modifier.size(24.dp))
                }
            }

            // chat / mic / voice
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                RoundAction(Icons.Default.ChatBubbleOutline, "Chat") { app.screen = Screen.CHAT }
                MicButton(app, mode, pulse, ripple)
                RoundAction(Icons.Default.RecordVoiceOver, "Voice") { app.screen = Screen.SETTINGS }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 40.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f).height(1.dp).background(t.accent.copy(alpha = 0.7f)))
                Text(if (app.handsFree) "Hands-free ON" else "Tap to Speak", color = Color.White, fontSize = 15.sp, modifier = Modifier.padding(horizontal = 14.dp))
                Box(Modifier.weight(1f).height(1.dp).background(t.accent.copy(alpha = 0.7f)))
            }
            Spacer(Modifier.height(12.dp))

            // bottom navigation
            val navShape = RoundedCornerShape(30.dp)
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp).padding(bottom = 8.dp).clip(navShape)
                    .background(Color(0xE612040A)).border(1.dp, t.accent.copy(alpha = 0.5f), navShape).padding(vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                NavItem(Icons.Default.Home, "Home", true) { app.screen = Screen.HOME }
                NavItem(Icons.Default.Star, "Favorites", false) { app.screen = Screen.FAVORITES }
                NavItem(Icons.Default.History, "History", false) { app.screen = Screen.HISTORY }
                NavItem(Icons.Default.Person, "Profile", false) { app.screen = Screen.PROFILE }
            }
        }
    }
}

@Composable
private fun RoundAction(icon: ImageVector, label: String, onClick: () -> Unit) {
    val acc = MakimaTheme.accent
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(62.dp).clip(CircleShape).background(Color(0xCC14040A)).border(1.dp, acc, CircleShape)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = acc, modifier = Modifier.size(28.dp)) }
        Spacer(Modifier.height(4.dp))
        Text(label, color = Color.White, fontSize = 12.sp)
    }
}

@Composable
private fun NavItem(icon: ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    val acc = MakimaTheme.accent
    val c = if (selected) acc else Color.White
    Column(
        Modifier.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick).padding(horizontal = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = c, modifier = Modifier.size(26.dp))
        Text(label, color = c, fontSize = 11.sp)
    }
}

@Composable
private fun MicButton(app: AppState, mode: Mode, pulse: Float, ripple: Float) {
    val acc = MakimaTheme.accent
    Box(Modifier.size(150.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val c = center
            val base = size.minDimension * 0.32f
            when (mode) {
                Mode.THINK -> drawArc(acc, ripple * 360f, 110f, false, Offset(c.x - base * 1.2f, c.y - base * 1.2f), Size(base * 2.4f, base * 2.4f), style = Stroke(8f, cap = StrokeCap.Round))
                Mode.LISTEN, Mode.SPEAK -> {
                    val rad = if (mode == Mode.LISTEN) base * 1.2f * (1f + app.level * 0.25f) else base * 1.2f * pulse
                    drawCircle(acc.copy(alpha = 0.9f), rad, c, style = Stroke(6f))
                    drawCircle(acc.copy(alpha = 0.3f), rad * 1.25f, c, style = Stroke(4f))
                }
                else -> {}
            }
            if (app.handsFree) drawCircle(acc.copy(alpha = 0.55f), base * 1.55f * pulse, c, style = Stroke(4f))
        }
        Box(
            Modifier.size(94.dp).clip(CircleShape)
                .background(Brush.radialGradient(listOf(Color(0xFF3A0A18), Color(0xFF14040A))))
                .border(3.dp, acc, CircleShape)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { app.toggleHandsFree() },
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Default.Mic, null, tint = Color(0xFFFF6E8F), modifier = Modifier.size(46.dp)) }
    }
}
