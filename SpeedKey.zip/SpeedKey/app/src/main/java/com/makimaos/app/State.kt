package com.makimaos.app
import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject

class Msg(val user: Boolean, val text: String, val ts: Long = System.currentTimeMillis(), fav: Boolean = false) {
    var fav by mutableStateOf(fav)
}
enum class Screen { HOME, CHAT, SETTINGS, MEMORY, FAVORITES, HISTORY, PROFILE }
enum class Mode { IDLE, LISTEN, THINK, SPEAK }

class AppState(val ctx: Context) {
    val theme = MakimaTheme
    var screen by mutableStateOf(Screen.HOME)
    val messages = mutableStateListOf<Msg>()
    var listening by mutableStateOf(false)
    var thinking by mutableStateOf(false)
    var handsFree by mutableStateOf(false)
    var pendingHands = false
    var partial by mutableStateOf("")
    var bubble by mutableStateOf("")
    var level by mutableStateOf(0f)
    var askMic: () -> Unit = {}
    var askPerms: () -> Unit = {}
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    val mouth = Mouth(ctx, scope)
    private var fails = 0
    private var buf = ""
    private var flushJob: Job? = null

    private val ears = Ears(ctx,
        onPartial = { partial = (buf + " " + it).trim(); caption(partial, "") },
        onFinal = { text ->
            listening = false; fails = 0
            buf = (buf + " " + text).trim(); partial = buf
            flushJob?.cancel()
            if (handsFree) {
                // keep listening in case she is still mid-sentence; reply only after a quiet gap
                scheduleFlush((Prefs.waitSec * 1000).toLong())
                scope.launch { delay(150); if (handsFree && !listening && !thinking && !mouth.speaking) startListening() }
            } else flush()
        },
        onEnd = { code ->
            listening = false
            if (buf.isEmpty()) partial = ""
            if (handsFree) {
                val quiet = code == 6 || code == 7      // normal silence / nothing recognised
                if (quiet) fails = 0 else fails++
                if (buf.isNotEmpty() && flushJob == null) scheduleFlush((Prefs.waitSec * 1000).toLong())
                if (code == 9) { disableHandsFree(); bubble = "Mic permission chahiye, Boss."; askMic() }
                else if (fails < 15) scope.launch {
                    // never give up quickly: back off a little on network / busy errors, then keep listening
                    delay(if (quiet) 250L else minOf(900L + fails * 350L, 5000L))
                    if (handsFree && !listening && !thinking && !mouth.speaking) startListening()
                } else { disableHandsFree(); bubble = "Mic me dikkat aa rahi hai, hands-free band kar diya." }
            } else if (buf.isNotEmpty()) flush()
        },
        onLevel = { level = it })

    val mode: Mode get() = when {
        listening -> Mode.LISTEN
        thinking -> Mode.THINK
        mouth.speaking -> Mode.SPEAK
        else -> Mode.IDLE
    }

    init {
        mouth.onDone = { if (handsFree && !listening && !thinking) startListening() }
        loadHistory()
    }

    private fun scheduleFlush(ms: Long) {
        flushJob?.cancel()
        flushJob = scope.launch { delay(ms); flush() }
    }
    private fun flush() {
        // never cut in while she is still speaking
        if (listening && partial.isNotBlank() && partial != buf) { scheduleFlush(600); return }
        val t = buf.trim(); buf = ""; flushJob = null; partial = ""
        if (t.isNotEmpty()) { ears.stop(); listening = false; send(t) }
    }

    // ---------------------------------------------------------------- history
    private fun loadHistory() {
        try {
            val a = JSONArray(Prefs.history)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                messages.add(Msg(o.getBoolean("u"), o.getString("t"), o.optLong("ts"), o.optBoolean("f")))
            }
        } catch (_: Exception) {}
    }
    fun save() {
        if (!Prefs.saveHistory) { Prefs.history = "[]"; return }
        val a = JSONArray()
        messages.takeLast(300).forEach { a.put(JSONObject().put("u", it.user).put("t", it.text).put("ts", it.ts).put("f", it.fav)) }
        Prefs.history = a.toString()
    }
    fun clearHistory() { messages.clear(); save() }
    fun toggleFav(m: Msg) { m.fav = !m.fav; save() }

    // ------------------------------------------------------------------ voice
    fun say(t: String) { bubble = t; mouth.speak(t) }
    fun sampleVoice() = say("Main Makima hoon, ${Prefs.userName}. Ab se meri awaaz yehi hogi.")

    private fun hasMic() = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    fun toggleListen() {
        if (listening) { ears.stop(); listening = false; return }
        startListening()
    }
    fun startListening() {
        if (!hasMic()) { askMic(); return }
        mouth.stop(); listening = true; ears.start()
    }

    // ------------------------------------------- always-listening (hands-free)
    fun toggleHandsFree() { if (handsFree) disableHandsFree() else requestHandsFree() }
    fun requestHandsFree() {
        if (!hasMic()) { pendingHands = true; askMic(); return }
        enableHandsFree()
    }
    fun enableHandsFree() {
        handsFree = true; fails = 0; buf = ""
        try { ContextCompat.startForegroundService(ctx, Intent(ctx, OverlayService::class.java)) } catch (_: Exception) {}
        bubble = if (Settings.canDrawOverlays(ctx)) "Main sun rahi hoon, ${Prefs.userName}. Bolo."
                 else "Main sun rahi hoon. Bahar bubble ke liye Settings me Floating bubble permission do."
        startListening()
    }
    fun disableHandsFree() {
        handsFree = false; flushJob?.cancel(); flushJob = null; buf = ""; partial = ""
        ears.stop(); listening = false
        try { ctx.stopService(Intent(ctx, OverlayService::class.java)) } catch (_: Exception) {}
        bubble = "Hands-free band."
    }

    // ------------------------------------------------------------------- chat
    private var capUser = ""
    private var capReply = ""
    /** Small subtitle shown under the floating Makima bubble while another app is open. */
    fun caption(u: String?, r: String?) {
        if (u != null) capUser = u
        if (r != null) capReply = r
        OverlayService.instance?.setCaption(capUser, capReply)
    }

    private val stopWords = setOf("stop", "ruko", "ruk jao", "ruk ja", "chup", "chup ho jao", "chup raho", "cancel", "band karo", "bas", "bas karo",
        "रुको", "रुक जाओ", "चुप", "चुप हो जाओ", "बस", "बस करो")

    private fun finishLocal(reply: String) {
        bubble = reply; caption(null, reply)
        messages.add(Msg(false, reply)); thinking = false; save()
        if (Prefs.autoSpeak) say(reply) else { bubble = reply; if (handsFree) startListening() }
    }

    fun send(text: String) {
        if (text.isBlank()) return
        messages.add(Msg(true, text)); thinking = true; bubble = ""
        caption(text, "")
        scope.launch {
            val low = text.lowercase().trim().trimEnd('.', '!', ' ')
            if (low in stopWords) { mouth.stop(); finishLocal("Theek hai, ruk gayi."); return@launch }
            val local = if (Prefs.phoneControl) (try { withContext(Dispatchers.IO) { Cmd.tryHandle(ctx, text) } } catch (e: Exception) { "Boss, command me error: ${e.message}" }) else null
            if (local != null) { finishLocal(local); return@launch }

            val speak = Prefs.autoSpeak
            val agent = Prefs.phoneControl
            var hist = messages.takeLast(Prefs.ctxTurns.coerceIn(2, 40)).map { (if (it.user) "user" else "model") to it.text }
                .dropWhile { it.first != "user" }
            if (speak) mouth.startStream()
            val said = StringBuilder()
            var failText: String? = null

            withContext(Dispatchers.IO) {
                fun emit(c: String) {
                    if (c.isBlank()) return
                    said.append(' ').append(c)
                    val shown = said.toString().trim()
                    scope.launch { thinking = false; bubble = shown; caption(null, shown) }
                    if (speak) mouth.feed(c)
                }
                var step = 0
                while (step < 8) {
                    step++
                    val flt = Agent.Filter(ctx)
                    var got = false
                    val reply = try {
                        Brain.askStream(hist) { s ->
                            got = true
                            emit(if (agent) flt.feed(s) else s)
                        }
                    } catch (e: Exception) { "Boss, error: ${Brain.nice(e)}" }
                    if (agent) emit(flt.finish())
                    if (!got) { failText = reply; break }
                    val obs = if (agent) flt.observations() else emptyList()
                    if (obs.isNotEmpty()) {
                        // the AI asked to see the screen / an action failed: give it the result and let it continue
                        hist = hist + ("model" to reply) + ("user" to ("[PHONE RESULT]\n" + obs.joinToString("\n")))
                        continue
                    }
                    break
                }
            }

            var finalText = said.toString().trim()
            val ft = failText
            if (ft != null) { finalText = ft; if (speak) mouth.feed(ft) }
            else if (finalText.isEmpty()) { finalText = "Ho gaya, ${Prefs.userName}."; if (speak) mouth.feed(finalText) }
            bubble = finalText; caption(null, finalText)
            if (speak) mouth.endStream()
            messages.add(Msg(false, finalText)); thinking = false; save()
            if (!speak && handsFree) startListening()
        }
    }

    fun pause() { if (handsFree) disableHandsFree(); ears.stop(); listening = false; mouth.stop() }
    fun release() {
        ears.stop(); mouth.release(); scope.cancel()
        try { ctx.stopService(Intent(ctx, OverlayService::class.java)) } catch (_: Exception) {}
    }
}
