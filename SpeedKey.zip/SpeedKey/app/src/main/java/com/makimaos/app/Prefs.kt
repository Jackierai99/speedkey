package com.makimaos.app
import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private lateinit var sp: SharedPreferences
    fun init(c: Context) { sp = c.getSharedPreferences("makimaos", Context.MODE_PRIVATE) }

    val providers: List<String> get() = Brain.provs.map { it.name }
    val personas = listOf("Makima Classic", "Sweet", "Strict", "Playful", "Professional")
    val langs = listOf("Hinglish", "English", "Hindi", "Auto")
    val lengths = listOf("Short", "Medium", "Detailed")
    val micLangs = listOf("Hindi", "English (IN)", "English (US)")
    val micTags = listOf("hi-IN", "en-IN", "en-US")
    val openaiVoices = listOf("shimmer", "sage", "coral", "nova", "ballad")
    val geminiVoices = listOf("Gacrux", "Vindemiatrix", "Sulafat", "Despina", "Kore", "Aoede", "Achernar", "Leda")

    // ---- API keys (provider is auto-detected, model is auto-selected; several keys per provider rotate on limits) ----
    private val keyIdx = HashMap<String, Int>()
    fun keys(p: String): List<String> =
        (sp.getString("key_$p", "") ?: "").split("\n").map { it.trim() }.filter { it.isNotEmpty() }
    fun key(p: String): String {
        val l = keys(p)
        if (l.isEmpty()) return ""
        return l[(keyIdx[p] ?: 0) % l.size]
    }
    fun keyCount(p: String): Int = keys(p).size
    fun addKeyTo(p: String, v: String) {
        val k = v.trim()
        val rest = keys(p).filter { it != k }
        sp.edit().putString("key_$p", (listOf(k) + rest).take(6).joinToString("\n")).apply()
        keyIdx[p] = 0
    }
    fun setKey(p: String, v: String) = addKeyTo(p, v)
    fun rotateKey(p: String): Boolean {
        val n = keyCount(p)
        if (n < 2) return false
        keyIdx[p] = ((keyIdx[p] ?: 0) + 1) % n
        return true
    }
    fun model(p: String): String = sp.getString("model_$p", "") ?: ""
    fun setModel(p: String, v: String) { sp.edit().putString("model_$p", v.trim()).apply() }
    fun removeKey(p: String) { keyIdx.remove(p); sp.edit().remove("key_$p").remove("model_$p").apply() }
    fun active(): List<String> = providers.filter { key(it).isNotBlank() }
    var primary: String
        get() = sp.getString("primary", "") ?: ""
        set(v) { sp.edit().putString("primary", v).apply() }
    fun primaryName(): String = primary.takeIf { it.isNotBlank() && key(it).isNotBlank() } ?: active().firstOrNull() ?: ""
    var ttsModel: String
        get() = sp.getString("tts_model", "") ?: ""
        set(v) { sp.edit().putString("tts_model", v).apply() }

    // ---- persona / language ----
    var userName: String
        get() = sp.getString("name", "Boss") ?: "Boss"
        set(v) { sp.edit().putString("name", v).apply() }
    var persona: Int
        get() = sp.getInt("persona", 0)
        set(v) { sp.edit().putInt("persona", v).apply() }
    var lang: Int
        get() = sp.getInt("lang", 0)
        set(v) { sp.edit().putInt("lang", v).apply() }
    var len: Int
        get() = sp.getInt("len", 0)
        set(v) { sp.edit().putInt("len", v).apply() }
    var custom: String
        get() = sp.getString("custom", "") ?: ""
        set(v) { sp.edit().putString("custom", v).apply() }
    var memory: String
        get() = sp.getString("memory", "") ?: ""
        set(v) { sp.edit().putString("memory", v).apply() }

    // ---- voice ----
    var autoSpeak: Boolean
        get() = sp.getBoolean("autoSpeak", true)
        set(v) { sp.edit().putBoolean("autoSpeak", v).apply() }
    var premium: Boolean
        get() = sp.getBoolean("premium", true)
        set(v) { sp.edit().putBoolean("premium", v).apply() }
    var geminiVoice: String
        get() = sp.getString("gvoice", "Gacrux") ?: "Gacrux"
        set(v) { sp.edit().putString("gvoice", v).apply() }
    var openaiVoice: String
        get() = sp.getString("ovoice", "shimmer") ?: "shimmer"
        set(v) { sp.edit().putString("ovoice", v).apply() }
    var voice: Int
        get() = sp.getInt("voice", 0)
        set(v) { sp.edit().putInt("voice", v).apply() }
    var speed: Float
        get() = sp.getFloat("speed", 1f)
        set(v) { sp.edit().putFloat("speed", v).apply() }
    var pitch: Float
        get() = sp.getFloat("pitch", 1f)
        set(v) { sp.edit().putFloat("pitch", v).apply() }
    var micLang: Int
        get() = sp.getInt("micLang", 0)
        set(v) { sp.edit().putInt("micLang", v).apply() }

    // ---- behaviour ----
    var failover: Boolean
        get() = sp.getBoolean("failover", true)
        set(v) { sp.edit().putBoolean("failover", v).apply() }
    var phoneControl: Boolean
        get() = sp.getBoolean("phoneControl", true)
        set(v) { sp.edit().putBoolean("phoneControl", v).apply() }
    var saveHistory: Boolean
        get() = sp.getBoolean("saveHistory", true)
        set(v) { sp.edit().putBoolean("saveHistory", v).apply() }
    var ctxTurns: Int
        get() = sp.getInt("ctxTurns", 12)
        set(v) { sp.edit().putInt("ctxTurns", v).apply() }
    var autoHands: Boolean
        get() = sp.getBoolean("autoHands", true)
        set(v) { sp.edit().putBoolean("autoHands", v).apply() }
    var waitSec: Float
        get() = sp.getFloat("waitSec", 1.2f)
        set(v) { sp.edit().putFloat("waitSec", v).apply() }
    var orbX: Int
        get() = sp.getInt("orbX", -1)
        set(v) { sp.edit().putInt("orbX", v).apply() }
    var orbY: Int
        get() = sp.getInt("orbY", -1)
        set(v) { sp.edit().putInt("orbY", v).apply() }
    var captions: Boolean
        get() = sp.getBoolean("captions", true)
        set(v) { sp.edit().putBoolean("captions", v).apply() }
    var history: String
        get() = sp.getString("history", "[]") ?: "[]"
        set(v) { sp.edit().putString("history", v).apply() }
}
