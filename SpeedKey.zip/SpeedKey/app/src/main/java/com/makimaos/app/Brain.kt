package com.makimaos.app
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Prov(val name: String, val base: String, val gemini: Boolean = false)

object Brain {
    var lastUsed = ""
    private var idErr = ""

    val provs = listOf(
        Prov("Gemini", "https://generativelanguage.googleapis.com/v1beta", true),
        Prov("Grok", "https://api.x.ai/v1"),
        Prov("DeepSeek", "https://api.deepseek.com"),
        Prov("OpenAI", "https://api.openai.com/v1"),
        Prov("Groq", "https://api.groq.com/openai/v1"),
        Prov("OpenRouter", "https://openrouter.ai/api/v1"),
        Prov("Mistral", "https://api.mistral.ai/v1")
    )
    fun prov(n: String) = provs.first { it.name == n }
    fun hasGemini() = Prefs.key("Gemini").isNotBlank()

    class HttpErr(val code: Int, msg: String) : Exception("HTTP $code: $msg")

    // ------------------------------------------------------------------ HTTP
    private fun errMsg(t: String): String {
        val m = try {
            val e = JSONObject(t).opt("error")
            when (e) { is JSONObject -> e.optString("message", t); is String -> e; else -> t }
        } catch (_: Exception) { t }
        return m.take(200)
    }

    /** Friendly, short explanation of a network / API failure. */
    fun nice(e: Throwable): String = when {
        e is java.net.UnknownHostException || e is java.net.ConnectException -> "Internet nahi chal raha"
        e is java.net.SocketTimeoutException -> "Server slow hai (timeout)"
        e is HttpErr && (e.code == 401 || e.code == 403) -> "Key galat ya band hai (${e.code})"
        e is HttpErr && e.code == 429 -> "Key ki limit khatam, thodi der baad"
        e is HttpErr && e.code >= 500 -> "Server down hai (${e.code})"
        else -> (e.message ?: e.javaClass.simpleName).take(160)
    }

    private fun http(method: String, url: String, headers: Map<String, String>, body: String?, readMs: Int = 45000): String {
        var last: Exception? = null
        for (attempt in 0..2) {
            try {
                return httpOnce(method, url, headers, body, readMs)
            } catch (e: HttpErr) {
                last = e
                val again = e.code == 500 || e.code == 502 || e.code == 503 || e.code == 504 || (e.code == 429 && attempt == 0)
                if (!again) throw e
            } catch (e: IOException) {
                last = e
            }
            try { Thread.sleep(if ((last as? HttpErr)?.code == 429) 1500L else 600L * (attempt + 1)) } catch (_: InterruptedException) {}
        }
        throw last ?: Exception("Network error")
    }

    private fun httpOnce(method: String, url: String, headers: Map<String, String>, body: String?, readMs: Int): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method; c.connectTimeout = 20000; c.readTimeout = readMs
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = c.responseCode
        val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw HttpErr(code, errMsg(text))
        return text
    }

    private fun auth(p: Prov, key: String): Map<String, String> =
        if (p.gemini) mapOf("x-goog-api-key" to key) else mapOf("Authorization" to "Bearer $key")

    // ------------------------------------------------- key -> provider -> model
    private fun listModels(p: Prov, key: String): List<String> {
        return if (p.gemini) {
            val res = http("GET", "${p.base}/models?pageSize=200", auth(p, key), null)
            val arr = JSONObject(res).optJSONArray("models") ?: JSONArray()
            (0 until arr.length()).map { arr.getJSONObject(it) }
                .filter { m ->
                    val ms = m.optJSONArray("supportedGenerationMethods")
                    ms != null && (0 until ms.length()).any { ms.getString(it) == "generateContent" }
                }
                .map { it.getString("name").removePrefix("models/") }
        } else {
            val res = http("GET", "${p.base}/models", auth(p, key), null)
            val arr = JSONObject(res).optJSONArray("data") ?: JSONArray()
            (0 until arr.length()).map { arr.getJSONObject(it).getString("id") }
        }
    }

    private fun ver(s: String) = Regex("(\\d+(?:\\.\\d+)?)").find(s)?.value?.toDoubleOrNull() ?: 0.0

    private fun pick(p: Prov, ids: List<String>): String? {
        val bad = Regex("image|imagine|vision|tts|audio|live|embed|moderation|whisper|transcribe|realtime|video|robotics|computer|guard|dall|search|diffusion|veo|imagen|aqa|learnlm|gemma|exp")
        val ok = ids.filter { !bad.containsMatchIn(it.lowercase()) }
        val r: String? = when (p.name) {
            "Gemini" -> {
                val g = ok.filter { it.startsWith("gemini-") }
                g.firstOrNull { it == "gemini-flash-latest" }
                    ?: g.filter { it.contains("flash") && !it.contains("lite") }
                        .maxWithOrNull(compareBy<String>({ ver(it) }, { !it.contains("preview") }))
                    ?: g.filter { it.contains("flash") }.maxByOrNull { ver(it) }
                    ?: g.maxByOrNull { ver(it) }
            }
            "DeepSeek" -> ok.firstOrNull { it == "deepseek-chat" } ?: ok.firstOrNull()
            "OpenRouter" -> ok.firstOrNull { it == "openai/gpt-4o-mini" } ?: ok.firstOrNull { it == "google/gemini-2.0-flash-001" } ?: ok.firstOrNull()
            "Mistral" -> ok.firstOrNull { it == "mistral-small-latest" } ?: ok.firstOrNull { it.startsWith("mistral-") } ?: ok.firstOrNull()
            "Grok" -> ok.filter { it.startsWith("grok") }
                .maxWithOrNull(compareBy<String>({ ver(it) }, { -it.length }))
            "OpenAI" -> {
                val skip = Regex("instruct|codex|chat-latest|pro|preview|\\d{4}-\\d{2}-\\d{2}")
                val l = ok.filter { it.startsWith("gpt-") && !skip.containsMatchIn(it) }
                l.filter { it.contains("mini") }.ifEmpty { l }
                    .maxWithOrNull(compareBy<String>({ ver(it) }, { -it.length }))
            }
            else -> ok.firstOrNull { it == "llama-3.3-70b-versatile" }
                ?: ok.firstOrNull { it.contains("llama") || it.contains("gpt-oss") }
                ?: ok.firstOrNull()
        }
        return r ?: ok.firstOrNull() ?: ids.firstOrNull()
    }

    /** Works out which provider a key belongs to by prefix, then by actually asking each API. */
    private fun guessProv(k: String): String? = when {
        k.startsWith("AIza") -> "Gemini"
        k.startsWith("xai-") -> "Grok"
        k.startsWith("gsk_") -> "Groq"
        k.startsWith("sk-or-") -> "OpenRouter"
        k.startsWith("sk-proj-") || k.startsWith("sk-svcacct-") || (k.startsWith("sk-") && k.length > 45) -> "OpenAI"
        k.startsWith("sk-") -> "DeepSeek"
        else -> null
    }

    private class Ident(val prov: Prov?, val ids: List<String>, val provisional: Prov?, val err: String)

    private fun identify(k: String): Ident {
        val guess = guessProv(k)
        val order = (listOfNotNull(guess) + provs.map { it.name }).distinct().map { prov(it) }
        var firstErr = ""
        var soft: Prov? = null
        for (p in order) {
            try {
                val ids = listModels(p, k)
                if (ids.isNotEmpty()) return Ident(p, ids, null, "")
            } catch (e: Exception) {
                if (firstErr.isEmpty()) firstErr = "${p.name}: ${nice(e)}"
                // sure about the provider, but the network / server hiccuped: keep the key, do not reject it
                val invalid = e is HttpErr && (e.code == 400 || e.code == 401 || e.code == 403 || e.code == 404)
                if (guess == p.name && !invalid && soft == null) soft = p
            }
        }
        return Ident(null, emptyList(), soft, firstErr)
    }

    private fun cleanKey(raw: String): String {
        var k = raw.trim().trim('"', '\'', '`', ',', ';')
        k = k.removePrefix("Bearer ").removePrefix("bearer ").trim()
        if (k.contains("=")) k = k.substringAfterLast("=")
        return k.replace(Regex("\\s"), "")
    }

    private fun addOne(raw: String): Pair<Boolean, String> {
        val k = cleanKey(raw)
        if (k.length < 12) return false to "Key bahut chhoti hai, poori copy karke paste karo."
        val hadKeys = Prefs.active().isNotEmpty()
        val r = identify(k)
        val p = r.prov
        if (p == null) {
            val sp = r.provisional
            if (sp != null) {
                Prefs.addKeyTo(sp.name, k)
                if (!hadKeys || Prefs.primary.isBlank()) Prefs.primary = sp.name
                return true to "${sp.name} key save ho gayi (check abhi nahi ho paya: ${r.err}). Model pehle use par apne aap chunega. activate ho gayi."
            }
            return false to "Key activate nahi hui. ${r.err.ifEmpty { "Internet ya key check karo." }}"
        }
        val m = pick(p, r.ids) ?: return false to "${p.name} key sahi hai par koi chat model nahi mila."
        Prefs.addKeyTo(p.name, k); Prefs.setModel(p.name, m)
        if (!hadKeys || Prefs.primary.isBlank()) Prefs.primary = p.name
        return true to "${p.name} activate ho gayi. Model: $m"
    }

    /** Paste one or several keys -> provider + model are detected and the keys are activated. */
    fun addKey(raw: String): Pair<Boolean, String> {
        val parts = raw.split(Regex("[\\s,;]+")).map { it.trim() }.filter { it.length >= 8 }
        if (parts.isEmpty()) return false to "Key bahut chhoti hai, poori copy karke paste karo."
        if (parts.size == 1) return addOne(parts[0])
        var ok = 0
        val msgs = mutableListOf<String>()
        for (x in parts) { val (g, m) = addOne(x); if (g) ok++; msgs.add(m) }
        return (ok > 0) to (if (ok > 0) "$ok key activate ho gayi. " else "") + msgs.joinToString(" | ")
    }

    fun refreshModel(pn: String): String {
        val p = prov(pn)
        val m = pick(p, listModels(p, Prefs.key(pn))) ?: throw Exception("Koi model nahi mila")
        Prefs.setModel(pn, m); return m
    }

    fun redetect(pn: String): String = try { "Model: " + refreshModel(pn) } catch (e: Exception) { "Failed: ${e.message}" }

    private fun model(pn: String) = Prefs.model(pn).ifBlank { refreshModel(pn) }

    // ------------------------------------------------------------- chat call
    private fun system(): String {
        val mem = Prefs.memory.trim()
        val persona = when (Prefs.persona) {
            0 -> "calm, composed, elegant, softly dominant, subtly teasing, caring in a quiet way"
            1 -> "warm, gentle, affectionate and encouraging, still elegant and composed"
            2 -> "strict, cold, commanding, disciplined and direct, with rare dry humor"
            3 -> "playful, witty, teasing and mischievous while staying graceful"
            else -> "polished, professional, concise and efficient, with a hint of Makima's elegance"
        }
        val lang = when (Prefs.lang) {
            0 -> "Reply in Hinglish (Hindi written in Roman letters mixed with English) unless the user writes only in English or in Devanagari, then match them."
            1 -> "Reply in English."
            2 -> "Reply in Hindi using Devanagari script."
            else -> "Reply in the same language and script the user used."
        }
        val len = when (Prefs.len) {
            0 -> "Keep replies short (1 to 3 sentences) because they are spoken aloud."
            1 -> "Keep replies moderate (3 to 5 sentences) because they are spoken aloud."
            else -> "Give detailed answers when the question needs it, but keep the wording easy to speak aloud."
        }
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", Locale.ENGLISH).format(Date())
        return "You are Makima from Chainsaw Man, acting as the personal AI voice assistant of your user, whom you call '${Prefs.userName}'. " +
            "Personality: $persona. $lang $len No markdown, no emojis, no lists. " +
            "Be genuinely helpful and accurate for every question. Current date and time: $now." +
            (if (Prefs.custom.isNotBlank()) "\nExtra instructions from the user: ${Prefs.custom.trim()}" else "") +
            (if (mem.isNotEmpty()) "\nFacts you know about the user:\n$mem" else "") +
            (if (Prefs.phoneControl) Agent.addon() else "")
    }

    private fun geminiBody(contents: JSONArray, model: String): String {
        val b = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system()))))
            .put("contents", contents)
        if (model.contains("2.5") && model.contains("flash"))
            b.put("generationConfig", JSONObject().put("thinkingConfig", JSONObject().put("thinkingBudget", 0)))
        return b.toString()
    }

    private fun callOnce(pn: String, msgs: List<Pair<String, String>>, model: String): String {
        val p = prov(pn); val key = Prefs.key(pn)
        return if (p.gemini) {
            val contents = JSONArray()
            msgs.forEach { (r, t) ->
                contents.put(JSONObject().put("role", if (r == "user") "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", t))))
            }
            val body = geminiBody(contents, model)
            val j = JSONObject(http("POST", "${p.base}/models/$model:generateContent", auth(p, key), body))
            val cands = j.optJSONArray("candidates")
            if (cands == null || cands.length() == 0)
                throw Exception("Gemini ne jawab roka: " + (j.optJSONObject("promptFeedback")?.optString("blockReason") ?: "khali"))
            val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts") ?: throw Exception("Khali jawab aaya")
            val sb = StringBuilder()
            for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
            sb.toString().trim().ifEmpty { throw Exception("Khali jawab aaya") }
        } else {
            val arr = JSONArray().put(JSONObject().put("role", "system").put("content", system()))
            msgs.forEach { (r, t) -> arr.put(JSONObject().put("role", if (r == "user") "user" else "assistant").put("content", t)) }
            val body = JSONObject().put("model", model).put("messages", arr).toString()
            val j = JSONObject(http("POST", "${p.base}/chat/completions", auth(p, key), body, 60000))
            j.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content", "").trim()
                .ifEmpty { throw Exception("Khali jawab aaya") }
        }
    }

    /** Rate-limited or rejected key -> switch to the next saved key of the same provider and retry. */
    private fun <T> withKeys(pn: String, f: () -> T): T {
        var tries = 0
        while (true) {
            try {
                return f()
            } catch (e: HttpErr) {
                val n = Prefs.keyCount(pn)
                if ((e.code == 429 || e.code == 401 || e.code == 403) && tries < n - 1 && Prefs.rotateKey(pn)) { tries++; continue }
                throw e
            }
        }
    }

    private fun call(pn: String, msgs: List<Pair<String, String>>): String = withKeys(pn) {
        try {
            callOnce(pn, msgs, model(pn))
        } catch (e: HttpErr) {
            // wrong / retired model -> find the right one automatically and retry once
            if (e.code == 400 || e.code == 404) callOnce(pn, msgs, refreshModel(pn)) else throw e
        }
    }

    fun ask(msgs: List<Pair<String, String>>): String {
        val first = Prefs.primaryName()
        val order = if (Prefs.failover) (listOf(first) + Prefs.active().filter { it != first }).filter { it.isNotBlank() }
                    else listOf(first).filter { it.isNotBlank() }
        if (order.isEmpty()) return "Boss, Settings me ek API key paste karo, bas. Baaki main sambhal lungi."
        var err = ""
        for (p in order) {
            try { val r = call(p, msgs); lastUsed = p; return r } catch (e: Exception) { err = "$p: ${nice(e)}" }
        }
        return "Boss, brain se jawab nahi aaya. $err"
    }

    fun test(p: String): String {
        if (Prefs.key(p).isBlank()) return "Pehle key daalo."
        return try { "Working (${Prefs.model(p)}): " + call(p, listOf("user" to "Reply with exactly the word OK")).take(40) }
        catch (e: Exception) { "Failed: ${e.message}" }
    }

    // ------------------------------------------------------ streaming (fast replies)
    private fun conn(url: String, headers: Map<String, String>, body: String, readMs: Int): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 20000; c.readTimeout = readMs; c.doOutput = true
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(body.toByteArray()) }
        val code = c.responseCode
        if (code !in 200..299) throw HttpErr(code, errMsg(c.errorStream?.bufferedReader()?.use { it.readText() } ?: ""))
        return c
    }

    private fun httpBytes(url: String, headers: Map<String, String>, body: String): ByteArray =
        conn(url, headers, body, 60000).inputStream.use { it.readBytes() }

    private fun streamOnce(pn: String, msgs: List<Pair<String, String>>, model: String, onChunk: (String) -> Unit) {
        val p = prov(pn); val key = Prefs.key(pn)
        val url: String; val body: String
        if (p.gemini) {
            val contents = JSONArray()
            msgs.forEach { (r, t) ->
                contents.put(JSONObject().put("role", if (r == "user") "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", t))))
            }
            body = geminiBody(contents, model)
            url = "${p.base}/models/$model:streamGenerateContent?alt=sse"
        } else {
            val arr = JSONArray().put(JSONObject().put("role", "system").put("content", system()))
            msgs.forEach { (r, t) -> arr.put(JSONObject().put("role", if (r == "user") "user" else "assistant").put("content", t)) }
            body = JSONObject().put("model", model).put("messages", arr).put("stream", true).toString()
            url = "${p.base}/chat/completions"
        }
        val c = conn(url, auth(p, key), body, 60000)
        c.inputStream.bufferedReader().use { r ->
            while (true) {
                val line = r.readLine() ?: break
                if (!line.startsWith("data:")) continue
                val data = line.removePrefix("data:").trim()
                if (data.isEmpty() || data == "[DONE]") continue
                val j = try { JSONObject(data) } catch (_: Exception) { continue }
                if (p.gemini) {
                    val parts = j.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts") ?: continue
                    for (i in 0 until parts.length()) {
                        val t = parts.getJSONObject(i).optString("text", "")
                        if (t.isNotEmpty()) onChunk(t)
                    }
                } else {
                    val t = j.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("delta")?.optString("content", "") ?: ""
                    if (t.isNotEmpty() && t != "null") onChunk(t)
                }
            }
        }
    }

    private fun stream(pn: String, msgs: List<Pair<String, String>>, onChunk: (String) -> Unit) {
        withKeys(pn) {
            try { streamOnce(pn, msgs, model(pn), onChunk) }
            catch (e: HttpErr) { if (e.code == 400 || e.code == 404) streamOnce(pn, msgs, refreshModel(pn), onChunk) else throw e }
        }
    }

    private fun splitSentences(buf: StringBuilder, all: Boolean, out: (String) -> Unit) {
        while (true) {
            var cut = -1
            for (i in buf.indices) {
                val ch = buf[i]
                if (ch == '\n') { cut = i + 1; break }
                if ((ch == '.' || ch == '!' || ch == '?' || ch == '\u0964') && i + 1 < buf.length && buf[i + 1].isWhitespace()) { cut = i + 1; break }
            }
            if (cut < 0) break
            val s = buf.substring(0, cut).trim(); buf.delete(0, cut)
            if (s.isNotEmpty()) out(s)
        }
        if (all) { val s = buf.toString().trim(); buf.setLength(0); if (s.isNotEmpty()) out(s) }
    }

    /** Streams the reply and hands over each finished sentence immediately so she can start speaking at once. */
    fun askStream(msgs: List<Pair<String, String>>, onSentence: (String) -> Unit): String {
        val first = Prefs.primaryName()
        val order = if (Prefs.failover) (listOf(first) + Prefs.active().filter { it != first }).filter { it.isNotBlank() }
                    else listOf(first).filter { it.isNotBlank() }
        if (order.isEmpty()) return "Boss, Settings me ek API key paste karo, bas. Baaki main sambhal lungi."
        var err = ""
        for (p in order) {
            val buf = StringBuilder(); val full = StringBuilder()
            var emitted = false; var hold = ""
            val out: (String) -> Unit = { s ->
                val t = (hold + " " + s).trim()
                if (t.length < 14) hold = t else { hold = ""; emitted = true; onSentence(t) }
            }
            try {
                stream(p, msgs) { chunk -> full.append(chunk); buf.append(chunk); splitSentences(buf, false, out) }
                splitSentences(buf, true, out)
                if (hold.isNotEmpty()) { emitted = true; onSentence(hold); hold = "" }
                val text = full.toString().trim()
                if (text.isEmpty()) throw Exception("Khali jawab aaya")
                lastUsed = p
                return text
            } catch (e: Exception) {
                err = "$p: ${nice(e)}"
                if (emitted) return full.toString().trim()
                // streaming broke before anything was said -> try the plain (non-stream) call once on the same provider
                try {
                    val r = call(p, msgs)
                    lastUsed = p
                    val b = StringBuilder(r)
                    splitSentences(b, true) { s -> onSentence(s) }
                    return r
                } catch (e2: Exception) { err = "$p: ${nice(e2)}" }
            }
        }
        return "Boss, brain se jawab nahi aaya. $err"
    }

    // ------------------------------------------------------------ voice (TTS)
    /** Same key powers the voice: Gemini or OpenAI keys can speak. Others fall back to the phone voice. */
    fun ttsProvider(): String? =
        listOf(Prefs.primaryName(), "Gemini", "OpenAI").firstOrNull { (it == "Gemini" || it == "OpenAI") && Prefs.key(it).isNotBlank() }
    fun ttsAvailable() = ttsProvider() != null

    private fun ttsModel(key: String): String {
        Prefs.ttsModel.takeIf { it.isNotBlank() }?.let { return it }
        val m = try {
            val ids = listModels(prov("Gemini"), key).filter { it.contains("tts") }
            ids.firstOrNull { it.contains("flash") } ?: ids.firstOrNull() ?: "gemini-2.5-flash-preview-tts"
        } catch (_: Exception) { "gemini-2.5-flash-preview-tts" }
        Prefs.ttsModel = m; return m
    }

    private fun ttsGemini(text: String, key: String): ByteArray? = try {
        val p = prov("Gemini")
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text",
                "Say in a soft, calm, elegant, slightly husky young anime-girl voice, quietly dominant and subtly teasing: $text")))))
            .put("generationConfig", JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", JSONObject()
                    .put("prebuiltVoiceConfig", JSONObject().put("voiceName", Prefs.geminiVoice)))))
        val res = http("POST", "${p.base}/models/${ttsModel(key)}:generateContent", auth(p, key), body.toString(), 60000)
        val part = JSONObject(res).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
        Base64.decode(part.getJSONObject("inlineData").getString("data"), Base64.DEFAULT)
    } catch (e: HttpErr) {
        if (e.code == 400 || e.code == 404) Prefs.ttsModel = ""
        null
    } catch (_: Exception) { null }

    private const val STYLE = "Voice: a calm, composed, elegant young woman with a soft, low, silky and slightly husky tone, subtly teasing and quietly dominant, like an anime character. Delivery: slow and gentle, intimate, with natural pauses. Speak Hindi and Hinglish naturally."

    private fun ttsOpenAI(text: String, key: String): ByteArray? {
        val p = prov("OpenAI")
        fun req(model: String, instr: Boolean): ByteArray {
            val b = JSONObject().put("model", model).put("input", text).put("voice", Prefs.openaiVoice).put("response_format", "pcm")
            if (instr) b.put("instructions", STYLE)
            return httpBytes("${p.base}/audio/speech", auth(p, key), b.toString())
        }
        return try { req("gpt-4o-mini-tts", true) } catch (_: Exception) { try { req("tts-1", false) } catch (_: Exception) { null } }
    }

    /** Raw 16-bit mono 24 kHz PCM, or null if no voice-capable key / the call failed. */
    fun tts(text: String): ByteArray? {
        val pn = ttsProvider() ?: return null
        val key = Prefs.key(pn)
        return if (pn == "Gemini") ttsGemini(text, key) else ttsOpenAI(text, key)
    }
}
