@file:OptIn(ExperimentalMaterial3Api::class)

package com.jackie.speedkey

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.clickable
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

sealed class It(val k: String, val t: String)
class Sw(k: String, t: String, val d: Boolean) : It(k, t)
class Sl(k: String, t: String, val d: Int, val lo: Int, val hi: Int) : It(k, t)
class Ch(k: String, t: String, val d: Int, val o: List<String>) : It(k, t)

val SCREENS: List<Pair<String, List<It>>> = listOf(
    "🎨 Themes" to listOf(Ch("theme", "Choose a theme", 0, THEMES.map { it.first })),
    "📐 Layout" to listOf(Sw("numRow", "Number row", true), Sl("height", "Keyboard height %", 100, 70, 140), Ch("oneH", "One-handed mode", 0, listOf("Off", "Left", "Right")), Sl("bPad", "Bottom space (dp)", 0, 0, 40)),
    "⌨️ Typing" to listOf(Sw("autoCap", "Auto-capitalize", true), Sw("dblSpace", "Double space = full stop", true), Sw("autoSpace", "Space after suggestion", true)),
    "🧠 Prediction" to listOf(Sw("predict", "Smart suggestions", true), Sw("nextWord", "Next-word prediction", true), Sw("typo", "Typo help", true), Sw("learn", "Learn my words", true)),
    "📳 Feedback" to listOf(Sw("haptic", "Vibration", true), Sl("hms", "Vibration length (ms)", 12, 5, 40), Sw("sound", "Key sound", false), Sw("preview", "Key popup", true)),
    "✨ Appearance" to listOf(Sl("radius", "Key roundness", 8, 0, 20), Sl("gap", "Key gap", 4, 1, 10), Sl("font", "Text size %", 100, 70, 130), Sw("hints", "Symbol hints on keys", true), Sw("boldKeys", "Bold key text", false), Sw("spaceLabel", "Show SpeedKey on space bar", false), Sl("popScale", "Key popup size %", 100, 80, 160)),
    "🔤 Fonts" to listOf(Ch("fstyle", "Typing font (the letters you type change style). Also switch from the Aa key on the keyboard.", 0, FONT_NAMES)),
    "😀 Emoji" to listOf(Sl("emojiCols", "Emoji per row", 8, 5, 10), Sl("emojiSize", "Emoji size %", 100, 70, 140), Sw("recentOn", "Remember recent emoji", true)),
    "👆 Gestures" to listOf(Sw("swipe", "Swipe on space moves cursor", true), Sl("step", "Swipe distance (dp)", 14, 6, 30)),
    "📋 Clipboard" to listOf(Sw("clip", "Save everything I copy (never auto-deleted)", true)),
    "⚡ Speed" to listOf(Sl("lp", "Long-press delay (ms)", 300, 150, 600), Sl("rep", "Backspace repeat (ms)", 45, 20, 100))
)

class MainActivity : ComponentActivity() {
    var tick by mutableIntStateOf(0)
    override fun onCreate(b: Bundle?) { super.onCreate(b); setContent { Root(this) } }
    override fun onResume() { super.onResume(); tick++ }
}

@Composable
fun Root(act: MainActivity) {
    val pf = remember { prefs(act) }
    var screen by remember { mutableIntStateOf(0) }
    val cs = darkColorScheme(
        primary = Color(0xFF4FC3F7), onPrimary = Color(0xFF00212E), background = Color(0xFF0E1116), surface = Color(0xFF171C24),
        onBackground = Color(0xFFE8ECF1), onSurface = Color(0xFFE8ECF1), surfaceVariant = Color(0xFF232A35),
        onSurfaceVariant = Color(0xFFB8C0CC), secondaryContainer = Color(0xFF1F3A4A), onSecondaryContainer = Color(0xFFE8ECF1)
    )
    MaterialTheme(colorScheme = cs) {
        BackHandler(enabled = screen != 0) { screen = 0 }
        Scaffold(
            containerColor = cs.background,
            topBar = {
                TopAppBar(
                    title = { Text(if (screen == 0) "SpeedKey" else if (screen <= SCREENS.size) SCREENS[screen - 1].first else "ℹ️ About & Reset") },
                    navigationIcon = { if (screen != 0) TextButton(onClick = { screen = 0 }) { Text("←", fontSize = 22.sp) } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = cs.surface, titleContentColor = cs.onSurface)
                )
            }
        ) { pad ->
            Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
                when {
                    screen == 0 -> Home(act) { screen = it }
                    screen <= SCREENS.size -> SCREENS[screen - 1].second.forEach { Item(pf, it) }
                    else -> About(act, pf)
                }
            }
        }
    }
}

@Composable
fun Home(act: MainActivity, open: (Int) -> Unit) {
    val t = act.tick
    val imm = act.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    val enabled = remember(t) { imm.enabledInputMethodList.any { it.packageName == act.packageName } }
    val selected = remember(t) { (Settings.Secure.getString(act.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: "").startsWith(act.packageName + "/") }
    var test by remember { mutableStateOf("") }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) { Image(painterResource(R.drawable.logo), null, Modifier.size(160.dp).clip(CircleShape)) }
    Text("Your own keyboard. Ultra fast.", fontSize = 20.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(12.dp))
    Text(if (enabled) "✅ 1. Enabled" else "⬜ 1. Enable SpeedKey")
    Button(onClick = { act.startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }) { Text("Open keyboard settings") }
    Spacer(Modifier.height(8.dp))
    Text(if (selected) "✅ 2. Selected" else "⬜ 2. Select SpeedKey")
    Button(onClick = { imm.showInputMethodPicker() }) { Text("Choose keyboard") }
    Spacer(Modifier.height(12.dp))
    OutlinedTextField(value = test, onValueChange = { test = it }, label = { Text("Type here to test") }, modifier = Modifier.fillMaxWidth())
    Spacer(Modifier.height(12.dp))
    val tiles = SCREENS.map { it.first } + "ℹ️ About & Reset"
    tiles.chunked(2).forEachIndexed { r, pair ->
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            pair.forEachIndexed { c, name ->
                Card(Modifier.weight(1f).clickable { open(r * 2 + c + 1) }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Text(name, Modifier.padding(18.dp), fontWeight = FontWeight.Medium)
                }
            }
            if (pair.size == 1) Spacer(Modifier.weight(1f))
        }
    }
}

@Composable
fun Item(pf: SharedPreferences, it: It) {
    when (it) {
        is Sw -> {
            var v by remember { mutableStateOf(pf.getBoolean(it.k, it.d)) }
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(it.t, Modifier.weight(1f))
                Switch(checked = v, onCheckedChange = { x -> v = x; pf.edit().putBoolean(it.k, x).apply() })
            }
        }
        is Sl -> {
            var v by remember { mutableFloatStateOf(pf.getInt(it.k, it.d).toFloat()) }
            Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                Text("${it.t}: ${v.toInt()}")
                Slider(value = v, onValueChange = { x -> v = x }, onValueChangeFinished = { pf.edit().putInt(it.k, v.toInt()).apply() }, valueRange = it.lo.toFloat()..it.hi.toFloat())
            }
        }
        is Ch -> {
            var v by remember { mutableIntStateOf(pf.getInt(it.k, it.d)) }
            Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                Text(it.t)
                Row2(Modifier.horizontalScroll(rememberScrollState())) {
                    it.o.forEachIndexed { i, name ->
                        FilterChip(selected = v == i, onClick = { v = i; pf.edit().putInt(it.k, i).apply() }, label = { Text(name) }, modifier = Modifier.padding(end = 6.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun Row2(m: Modifier, c: @Composable RowScope.() -> Unit) = androidx.compose.foundation.layout.Row(m, content = c)

@Composable
fun About(act: MainActivity, pf: SharedPreferences) {
    Text("SpeedKey 1.0", fontWeight = FontWeight.Bold, fontSize = 18.sp)
    Text("Tips: long-press a letter for its symbol. Long-press space to switch keyboards. Swipe on space to move the cursor. Tap Aa on the keyboard to change font.")
    Spacer(Modifier.height(8.dp))
    Text("Emoji pictures: Twemoji by Twitter/jdecked, CC-BY 4.0 (twemoji.twitter.com)")
    Spacer(Modifier.height(12.dp))
    Button(onClick = {
        act.getSharedPreferences("learn", Context.MODE_PRIVATE).edit().clear().apply()
        pf.edit().putInt("learnReset", pf.getInt("learnReset", 0) + 1).apply()
    }) { Text("Clear learned words") }
    Spacer(Modifier.height(8.dp))
    Button(onClick = {
        val r = pf.getInt("learnReset", 0)
        pf.edit().clear().putInt("learnReset", r + 1).apply()
        act.recreate()
    }) { Text("Reset all settings") }
}
