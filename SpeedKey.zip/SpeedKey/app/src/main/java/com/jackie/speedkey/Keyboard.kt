package com.jackie.speedkey

import android.content.ClipboardManager
import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Typeface
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.RectF
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.text.InputType
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager

// bg, key, special, text, accent
val THEMES = listOf(
    "Midnight" to longArrayOf(0xFF0E1116, 0xFF1C222B, 0xFF2A323E, 0xFFE8ECF1, 0xFF4FC3F7),
    "Neon" to longArrayOf(0xFF05060F, 0xFF10132A, 0xFF1B1F44, 0xFFE6F7FF, 0xFF00F0FF),
    "Light" to longArrayOf(0xFFE9ECEF, 0xFFFFFFFF, 0xFFCDD3DA, 0xFF1B1F23, 0xFF1E88E5),
    "AMOLED" to longArrayOf(0xFF000000, 0xFF141414, 0xFF222222, 0xFFFFFFFF, 0xFFBB86FC),
    "Sunset" to longArrayOf(0xFF2B1B2E, 0xFF3D2742, 0xFF54325A, 0xFFFFEFE3, 0xFFFF8A5B),
    "Forest" to longArrayOf(0xFF0F1D16, 0xFF183024, 0xFF22402F, 0xFFE6F5EA, 0xFF4CD97B),
    "Ocean" to longArrayOf(0xFF0A1A2F, 0xFF12304F, 0xFF1A4068, 0xFFE3F2FD, 0xFF29B6F6),
    "Rose" to longArrayOf(0xFFFCE4EC, 0xFFFFFFFF, 0xFFF8BBD0, 0xFF4A1530, 0xFFE91E63),
    "Gold" to longArrayOf(0xFF14110A, 0xFF241E10, 0xFF33290F, 0xFFFFF3D6, 0xFFFFC107),
    "Hacker" to longArrayOf(0xFF020A04, 0xFF07160B, 0xFF0C2413, 0xFF9DFFB0, 0xFF00FF66),
    "Aurora" to longArrayOf(0xFF0B1220, 0xFF15233A, 0xFF1E3350, 0xFFE6F6FF, 0xFF7CFFCB),
    "Cyberpunk" to longArrayOf(0xFF0D0221, 0xFF1A0B3B, 0xFF2B1259, 0xFFF3E8FF, 0xFFFF2BD6),
    "Sakura" to longArrayOf(0xFFFFF1F5, 0xFFFFFFFF, 0xFFFFD6E4, 0xFF5A2A3C, 0xFFFF6FA5),
    "Mocha" to longArrayOf(0xFF1E1612, 0xFF2D2219, 0xFF3D2F23, 0xFFF3E5D8, 0xFFD9A066),
    "Nord" to longArrayOf(0xFF2E3440, 0xFF3B4252, 0xFF4C566A, 0xFFECEFF4, 0xFF88C0D0),
    "Dracula" to longArrayOf(0xFF282A36, 0xFF343746, 0xFF44475A, 0xFFF8F8F2, 0xFFBD93F9),
    "Mint" to longArrayOf(0xFFE8F8F1, 0xFFFFFFFF, 0xFFBFE9D6, 0xFF123B2C, 0xFF16A085),
    "Lavender" to longArrayOf(0xFFF1EDFB, 0xFFFFFFFF, 0xFFD9CEF5, 0xFF2B2150, 0xFF7C4DFF),
    "Crimson" to longArrayOf(0xFF140608, 0xFF251016, 0xFF371A22, 0xFFFFE9EC, 0xFFFF3B5C),
    "Ice" to longArrayOf(0xFFEAF4FB, 0xFFFFFFFF, 0xFFC5DDF0, 0xFF0E2A3F, 0xFF0288D1),
    "Graphite" to longArrayOf(0xFF1A1B1E, 0xFF26282C, 0xFF35383D, 0xFFEDEDED, 0xFF9CA3AF),
    "Insta" to longArrayOf(0xFF1B0F24, 0xFF2A1838, 0xFF3C2250, 0xFFFFEEF8, 0xFFFF5E8A)
)

const val WORDS = "the be to of and a in that have i it for not on with he as you do at this but his by from they we say her she or an will my one all would there their what so up out if about who get which go me when make can like time no just him know take people into year your good some could them see other than then now look only come its over think also back after use two how our work first well way even new want because any these give day most us is are was were been has had did does said going great thank thanks please sorry hello hi hey ok okay yes yeah sure maybe today tomorrow yesterday tonight morning night home phone call message send love happy birthday welcome bad best better very really much many more little big long late soon always never again here where why start stop help need try find feel tell ask friend family money food game video music movie photo app keyboard don't i'm it's can't i'll that's you're what's let's kya hai nahi bhai yaar kaise kahan kab kyun kaun kuch bahut accha theek mera tera tum aap hum main mujhe aur lekin bhi karo kar abhi kal aaj raat ghar kaam paisa dost pyaar shukriya"

class Gl(val u: String, val kind: Int, val a: Int, val b: Int)
private fun hc(v: Long) = v.toInt()
val GL = listOf(
    Gl("😀", 0, 0, 1), Gl("😃", 0, 6, 1), Gl("😄", 0, 1, 1), Gl("😂", 0, 7, 1), Gl("😊", 0, 1, 0), Gl("😍", 0, 2, 1),
    Gl("😎", 0, 3, 0), Gl("😘", 0, 5, 6), Gl("😜", 0, 5, 5), Gl("😢", 0, 7, 3), Gl("😭", 0, 7, 4), Gl("😡", 3, 0, 3),
    Gl("😱", 0, 6, 4), Gl("😴", 0, 4, 2), Gl("🤔", 0, 0, 2), Gl("🙂", 0, 0, 0), Gl("😐", 0, 0, 2), Gl("😇", 0, 1, 0),
    Gl("❤️", 1, hc(0xFFE53935), 0), Gl("🧡", 1, hc(0xFFFB8C00), 0), Gl("💛", 1, hc(0xFFFDD835), 0), Gl("💚", 1, hc(0xFF43A047), 0),
    Gl("💙", 1, hc(0xFF1E88E5), 0), Gl("💜", 1, hc(0xFF8E24AA), 0), Gl("🖤", 1, hc(0xFF37474F), 0), Gl("🤍", 1, hc(0xFFCFD8DC), 0),
    Gl("⭐", 2, hc(0xFFFFB300), 0)
)
val EMO_TABS = listOf("🕘", "😀", "👍", "🐶", "🍕", "🎉", "🚗", "💡", "🔣", "🏳️", "🦸", "🖼️")
val EMO_R = listOf(
    listOf(0x1F600..0x1F64F, 0x1F910..0x1F92F, 0x1F970..0x1F97F, 0x1F9D0..0x1F9D0),
    listOf(0x261D..0x261D, 0x270A..0x270D, 0x1F440..0x1F4A0, 0x1F90C..0x1F90F, 0x1F930..0x1F93F, 0x1F9B0..0x1F9DF, 0x1FAC0..0x1FAFF),
    listOf(0x1F400..0x1F43F, 0x1F980..0x1F9AF, 0x1F330..0x1F344, 0x1FAB0..0x1FABF),
    listOf(0x1F345..0x1F37F, 0x1F9C0..0x1F9CB, 0x1FAD0..0x1FADF, 0x2615..0x2615),
    listOf(0x1F380..0x1F3F0, 0x1F3F8..0x1F3FA, 0x26BD..0x26BE, 0x1F94A..0x1F94F, 0x1F9E7..0x1F9FF),
    listOf(0x1F680..0x1F6D7, 0x1F6E0..0x1F6FC, 0x1F300..0x1F32F, 0x1F3D4..0x1F3DF, 0x1F5FA..0x1F5FF),
    listOf(0x1F4A1..0x1F4FF, 0x1F50A..0x1F52F, 0x1F5A5..0x1F5A5, 0x1F9F0..0x1F9F6),
    listOf(0x2190..0x21FF, 0x2600..0x26FF, 0x2700..0x27BF, 0x2B05..0x2B55, 0x1F170..0x1F19A, 0x1F500..0x1F53D, 0x1F7E0..0x1F7EB, 0x1F493..0x1F49F)
)
val FLAGS: List<String> by lazy {
    val p = Paint()
    val l = ArrayList<String>()
    for (cp in intArrayOf(0x1F3C1, 0x1F6A9, 0x1F3F3, 0x1F3F4)) { val f = String(Character.toChars(cp)) + "\uFE0F"; if (p.hasGlyph(f)) l.add(f) }
    for (a in 'A'..'Z') for (b in 'A'..'Z') {
        val f = String(Character.toChars(0x1F1E6 + (a - 'A'))) + String(Character.toChars(0x1F1E6 + (b - 'A')))
        if (p.hasGlyph(f)) l.add(f)
    }
    val i = l.indexOf("\uD83C\uDDEE\uD83C\uDDF3")
    if (i > 0) { l.removeAt(i); l.add(4, "\uD83C\uDDEE\uD83C\uDDF3") }
    l
}
val HERO_LIST = listOf(
    "🦸", "🦸‍♂️", "🦸‍♀️", "🦹", "🦹‍♂️", "🦹‍♀️", "🕷️", "🕸️", "🛡️", "⚡", "🔨", "⚔️", "🗡️", "🏹", "🐜", "💥", "🔥", "💪", "🦾", "🦿",
    "🧪", "☢️", "🟢", "🔴", "🔵", "⭐", "🌟", "💫", "🚀", "🛸", "👽", "🤖", "🦅", "🐆", "🐺", "🐲", "🔮", "🧙", "🧙‍♂️", "🧙‍♀️",
    "🦇", "🐍", "🦂", "🪐", "🌌", "☄️", "💎", "👑", "🎭", "🥷", "🧠", "👁️", "💀", "🕶️", "🏆", "🎯"
)
val FONT_NAMES = listOf("Normal", "Bold", "Italic", "Bold Italic", "Script", "Bold Script", "Fraktur", "Bold Fraktur", "Double-struck", "Monospace", "Sans", "Sans Bold", "Sans Italic", "Sans Bold Italic", "Circled", "Black Circled", "Squared", "Black Squared", "Parenthesized", "Small caps", "Fullwidth", "Upside down", "Strikethrough", "Underline", "Slashed", "Double underline", "Custom")
private val FUP = intArrayOf(0, 0x1D400, 0x1D434, 0x1D468, 0x1D49C, 0x1D4D0, 0x1D504, 0x1D56C, 0x1D538, 0x1D670, 0x1D5A0, 0x1D5D4, 0x1D608, 0x1D63C, 0x24B6, 0x1F150, 0x1F130, 0x1F170, 0x1F110, 0, 0xFF21)
private val FLO = intArrayOf(0, 0x1D41A, 0x1D44E, 0x1D482, 0x1D4B6, 0x1D4EA, 0x1D51E, 0x1D586, 0x1D552, 0x1D68A, 0x1D5BA, 0x1D5EE, 0x1D622, 0x1D656, 0x24D0, 0x1F150, 0x1F130, 0x1F170, 0x249C, 0, 0xFF41)
private val FEX: Map<Int, Map<Char, Int>> = mapOf(
    2 to mapOf('h' to 0x210E),
    4 to mapOf('B' to 0x212C, 'E' to 0x2130, 'F' to 0x2131, 'H' to 0x210B, 'I' to 0x2110, 'L' to 0x2112, 'M' to 0x2133, 'R' to 0x211B, 'e' to 0x212F, 'g' to 0x210A, 'o' to 0x2134),
    6 to mapOf('C' to 0x212D, 'H' to 0x210C, 'I' to 0x2111, 'R' to 0x211C, 'Z' to 0x2128),
    8 to mapOf('C' to 0x2102, 'H' to 0x210D, 'N' to 0x2115, 'P' to 0x2119, 'Q' to 0x211A, 'R' to 0x211D, 'Z' to 0x2124)
)
private const val SMALLCAPS = "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀsᴛᴜᴠᴡxʏᴢ"
private const val UPSIDE_UP = "∀ᗺƆᗡƎℲ⅁HIſ⋊˥WNOԀΌᴚS⊥∩ΛMX⅄Z"
private const val UPSIDE_LO = "ɐqɔpǝɟƃɥᴉɾʞlɯuodbɹsʇnʌʍxʎz"
var CUSTOM_FONT: Map<Int, String> = emptyMap()

fun fx(style: Int, s: String): String {
    if (style <= 0) return s
    val sb = StringBuilder()
    for (ch in s) {
        if (style == 26) { sb.append(CUSTOM_FONT[ch.code] ?: ch.toString()); continue }
        val up = ch in 'A'..'Z'
        val lo = ch in 'a'..'z'
        if (!up && !lo) { sb.append(ch); continue }
        when (style) {
            19 -> sb.append(SMALLCAPS[ch.lowercaseChar() - 'a'])
            21 -> sb.append(if (up) UPSIDE_UP[ch - 'A'] else UPSIDE_LO[ch - 'a'])
            22 -> { sb.append(ch); sb.append('\u0336') }
            23 -> { sb.append(ch); sb.append('\u0332') }
            24 -> { sb.append(ch); sb.append('\u0338') }
            25 -> { sb.append(ch); sb.append('\u0333') }
            else -> {
                val ex = FEX[style]?.get(ch)
                val cp = ex ?: (if (up) FUP[style] + (ch - 'A') else FLO[style] + (ch - 'a'))
                sb.appendCodePoint(cp)
            }
        }
    }
    return sb.toString()
}

fun loadCustomFont(c: Context) {
    try {
        val lines = c.assets.open("custom_font.txt").bufferedReader().readLines().filter { it.isNotBlank() && !it.startsWith("#") }
        if (lines.size >= 2) {
            val a = lines[0].trim().codePoints().toArray()
            val b = lines[1].trim().codePoints().toArray()
            val m = HashMap<Int, String>()
            for (i in 0 until minOf(a.size, b.size)) m[a[i]] = String(Character.toChars(b[i]))
            CUSTOM_FONT = m
        }
    } catch (e: Exception) { }
}

object EmojiStore {
    @Volatile private var data: List<List<String>>? = null
    @Volatile var map: Map<String, String> = emptyMap()
    val skinBases: Set<Int> = setOf(0x261d, 0x26f9, 0x270a, 0x270b, 0x270c, 0x270d, 0x1f385, 0x1f3c2, 0x1f3c3, 0x1f3c4, 0x1f3c7, 0x1f3ca, 0x1f3cb, 0x1f3cc, 0x1f442, 0x1f443, 0x1f446, 0x1f447, 0x1f448, 0x1f449, 0x1f44a, 0x1f44b, 0x1f44c, 0x1f44d, 0x1f44e, 0x1f44f, 0x1f450, 0x1f466, 0x1f467, 0x1f468, 0x1f469, 0x1f46a, 0x1f46b, 0x1f46c, 0x1f46d, 0x1f46e, 0x1f46f, 0x1f470, 0x1f471, 0x1f472, 0x1f473, 0x1f474, 0x1f475, 0x1f476, 0x1f477, 0x1f478, 0x1f47c, 0x1f481, 0x1f482, 0x1f483, 0x1f485, 0x1f486, 0x1f487, 0x1f48f, 0x1f491, 0x1f4aa, 0x1f574, 0x1f575, 0x1f57a, 0x1f590, 0x1f595, 0x1f596, 0x1f645, 0x1f646, 0x1f647, 0x1f64b, 0x1f64c, 0x1f64d, 0x1f64e, 0x1f64f, 0x1f6a3, 0x1f6b4, 0x1f6b5, 0x1f6b6, 0x1f6c0, 0x1f6cc, 0x1f90c, 0x1f90f, 0x1f918, 0x1f919, 0x1f91a, 0x1f91b, 0x1f91c, 0x1f91d, 0x1f91e, 0x1f91f, 0x1f926, 0x1f930, 0x1f931, 0x1f932, 0x1f933, 0x1f934, 0x1f935, 0x1f936, 0x1f937, 0x1f938, 0x1f939, 0x1f93c, 0x1f93d, 0x1f93e, 0x1f977, 0x1f9b5, 0x1f9b6, 0x1f9b8, 0x1f9b9, 0x1f9bb, 0x1f9cd, 0x1f9ce, 0x1f9cf, 0x1f9d1, 0x1f9d2, 0x1f9d3, 0x1f9d4, 0x1f9d5, 0x1f9d6, 0x1f9d7, 0x1f9d8, 0x1f9d9, 0x1f9da, 0x1f9db, 0x1f9dc, 0x1f9dd, 0x1fac3, 0x1fac4, 0x1fac5, 0x1faf0, 0x1faf1, 0x1faf2, 0x1faf3, 0x1faf4, 0x1faf5, 0x1faf6, 0x1faf7, 0x1faf8)
    fun get(c: Context): List<List<String>> {
        data?.let { return it }
        val p = Paint()
        val cats = ArrayList<List<String>>()
        cats.add(emptyList())
        try {
            for (l in c.assets.open("emoji_data.txt").bufferedReader().readLines()) cats.add(l.split(' ').filter { it.isNotEmpty() && p.hasGlyph(it) })
        } catch (e: Exception) { }
        while (cats.size < 10) cats.add(emptyList())
        cats.add(HERO_LIST.filter { p.hasGlyph(it) })
        data = cats
        return cats
    }
    fun loadMap(c: Context) {
        if (map.isNotEmpty()) return
        val p = Paint()
        val m = HashMap<String, String>()
        try {
            for (l in c.assets.open("emoji_map.txt").bufferedReader().readLines()) {
                val i = l.indexOf(' ')
                if (i > 0) { val e = l.substring(i + 1).trim(); if (e.isNotEmpty() && p.hasGlyph(e)) m[l.substring(0, i)] = e }
            }
        } catch (e: Exception) { }
        map = m
    }
    fun forWord(w: String): String? = if (w.length < 2) null else (map[w] ?: (if (w.endsWith("s")) map[w.dropLast(1)] else null))
}

fun skinify(e: String, tone: Int): String {
    if (tone <= 0 || tone > 5 || e.isEmpty()) return e
    val first = e.codePointAt(0)
    if (first !in EmojiStore.skinBases) return e
    val cps = e.codePoints().toArray()
    for (i in 1 until cps.size) {
        val c = cps[i]
        if (c == 0x1F468 || c == 0x1F469 || c == 0x1F9D1 || c == 0x1F466 || c == 0x1F467 || c == 0x2764 || c == 0x1F48B || c in EmojiStore.skinBases) return e
    }
    val sb = StringBuilder()
    sb.appendCodePoint(first); sb.appendCodePoint(0x1F3FA + tone)
    var i = 1
    if (i < cps.size && cps[i] == 0xFE0F) i++
    while (i < cps.size) { sb.appendCodePoint(cps[i]); i++ }
    return sb.toString()
}

class Photo(val name: String, val file: String, val light: Boolean, val acc: Long, val dim: Int)
val PHOTOS = listOf(
    Photo("Neon City", "neon.jpg", false, 0xFFFF2BD6, 0x22000000),
    Photo("Aurora", "aurora.jpg", false, 0xFF7CFFCB, 0x22000000),
    Photo("Sunset", "sunset.jpg", false, 0xFFFF8A5B, 0x33000000),
    Photo("Ocean", "ocean.jpg", false, 0xFF4FC3F7, 0x22000000),
    Photo("Galaxy", "galaxy.jpg", false, 0xFFB388FF, 0x11000000),
    Photo("Forest", "forest.jpg", false, 0xFF7CE0A0, 0x55000000),
    Photo("Sakura", "sakura.jpg", true, 0xFFFF4D8D, 0x00000000),
    Photo("Gold", "gold.jpg", false, 0xFFFFD700, 0x22000000),
    Photo("Ice", "ice.jpg", true, 0xFF0288D1, 0x00000000),
    Photo("Lava", "lava.jpg", false, 0xFFFF6A00, 0x33000000),
    Photo("Mint", "mint.jpg", true, 0xFF00A383, 0x00000000),
    Photo("Geometry", "geometry.jpg", false, 0xFF80CBC4, 0x11000000),
    Photo("Candy", "candy.jpg", true, 0xFFB14DFF, 0x00000000),
    Photo("Retro Wave", "retro.jpg", false, 0xFFFF4FD8, 0x22000000)
)

fun prefs(c: Context): SharedPreferences = c.getSharedPreferences("speedkey", Context.MODE_PRIVATE)

class Kk(val l: String, val w: Float = 1f, val a: String? = null)

class KView(ctx: Context, private val svc: KeyboardService) : View(ctx) {
    private val sp = prefs(ctx)
    private val d = resources.displayMetrics.density
    var sym = false
    var shift = 0
    var enter = "⏎"
    private var showPred = true
    var panel = 0
    private var items = listOf<String>()
    private var cat = 0
    private var scrollY = 0f
    private var bPad = 0
    private var rowH = 0f
    private var gridTop = 0f
    private var gridBot = 0f
    private val ip = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gpath = Path()
    private var cBg = 0; private var cKey = 0; private var cSp = 0; private var cTx = 0; private var cAc = 0
    private var numRow = true; private var hPct = 100; private var rad = 8; private var gap = 4
    private var hap = true; private var hms = 12; private var snd = false; private var prv = true
    private var swp = true; private var step = 14; private var lpMs = 300; private var rep = 45
    private var fs = 100; private var oneH = 0; private var hints = true
    private var bold = false; private var pop = 100; private var cols = 8; private var emSize = 100; private var recOn = true; private var spLbl = false; private var shadowOn = true
    private val rp = ctx.getSharedPreferences("recent", Context.MODE_PRIVATE)
    private val bmpCache = HashMap<String, Bitmap?>()
    private val emCache = HashMap<String, Bitmap?>()
    private val emojiPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private var userTf: Typeface? = null
    private val notoTf: Typeface? by lazy { try { Typeface.createFromAsset(context.assets, "NotoColorEmoji.ttf") } catch (e: Throwable) { null } }
    private var notoOn = true
    private var skin = 0
    private var bgSrc: Bitmap? = null
    private var bgScaled: Bitmap? = null
    private var bgDim = 0
    private var customNames: List<String>? = null
    private var slots = arrayOf("", "", "")
    private val cells = ArrayList<RectF>()
    private val keys = ArrayList<Kk>()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val hintP = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.RIGHT }
    private val sg = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val vib = ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    private val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val h = Handler(Looper.getMainLooper())
    private val n = 6
    private val pk = arrayOfNulls<Kk>(n)
    private val pc = IntArray(n)
    private val px = FloatArray(n)
    private val plast = FloatArray(n)
    private val pl = BooleanArray(n)
    private val psw = BooleanArray(n)
    private val ps = IntArray(n) { -1 }
    private val plY = FloatArray(n)
    private val pdY = FloatArray(n)
    private val lr = Array(n) { i -> Runnable { longPress(i) } }
    private val rr = Array(n) { i -> Runnable { rpt(i) } }
    private var stripH = 0f
    private var kl = 0f
    private var kw = 0f
    private var lastShift = 0L
    private val tmp = RectF()

    fun load() {
        userTf = try { val ff = java.io.File(context.filesDir, "emoji_font.ttf"); if (ff.exists()) Typeface.createFromFile(ff) else null } catch (e: Throwable) { null }
        val t = THEMES[sp.getInt("theme", 0).coerceIn(0, THEMES.size - 1)].second
        cBg = t[0].toInt(); cKey = t[1].toInt(); cSp = t[2].toInt(); cTx = t[3].toInt(); cAc = t[4].toInt()
        numRow = sp.getBoolean("numRow", true); hPct = sp.getInt("height", 100); rad = sp.getInt("radius", 8); gap = sp.getInt("gap", 4)
        hap = sp.getBoolean("haptic", true); hms = sp.getInt("hms", 12); snd = sp.getBoolean("sound", false); prv = sp.getBoolean("preview", true)
        swp = sp.getBoolean("swipe", true); step = sp.getInt("step", 14); lpMs = sp.getInt("lp", 300); rep = sp.getInt("rep", 45)
        fs = sp.getInt("font", 100); oneH = sp.getInt("oneH", 0); hints = sp.getBoolean("hints", true); showPred = sp.getBoolean("predict", true); bPad = sp.getInt("bPad", 0)
        bold = sp.getBoolean("boldKeys", false); pop = sp.getInt("popScale", 100); cols = sp.getInt("emojiCols", 8).coerceIn(5, 10); emSize = sp.getInt("emojiSize", 100)
        recOn = sp.getBoolean("recentOn", true); spLbl = sp.getBoolean("spaceLabel", false); shadowOn = sp.getBoolean("keyShadow", true)
        notoOn = sp.getBoolean("notoEmoji", true); skin = sp.getInt("skin", 0)
        bgSrc = null; bgScaled = null; bgDim = 0
        val ph = sp.getInt("photo", 0)
        if (ph != 0) {
            try {
                var light = false
                var acc = 0xFF4FC3F7.toInt()
                var dim = 0x44000000
                if (ph in 1..PHOTOS.size) {
                    val pt = PHOTOS[ph - 1]
                    bgSrc = context.assets.open("themes/" + pt.file).use { BitmapFactory.decodeStream(it) }
                    light = pt.light; acc = pt.acc.toInt(); dim = pt.dim
                } else if (ph == -1) {
                    val f = java.io.File(context.filesDir, "bg_custom.jpg")
                    if (f.exists()) {
                        val o = BitmapFactory.Options(); o.inJustDecodeBounds = true; BitmapFactory.decodeFile(f.path, o)
                        var ss = 1
                        while (o.outWidth / (ss * 2) >= 1000) ss *= 2
                        val o2 = BitmapFactory.Options(); o2.inSampleSize = ss
                        val bb = BitmapFactory.decodeFile(f.path, o2)
                        bgSrc = bb
                        if (bb != null) {
                            val sm = Bitmap.createScaledBitmap(bb, 16, 16, true)
                            var sum = 0.0
                            for (yy in 0 until 16) for (xx in 0 until 16) {
                                val c = sm.getPixel(xx, yy)
                                sum += (0.299 * android.graphics.Color.red(c) + 0.587 * android.graphics.Color.green(c) + 0.114 * android.graphics.Color.blue(c)) / 255.0
                            }
                            light = sum / 256.0 > 0.62
                        }
                        dim = if (light) 0x11FFFFFF else 0x55000000
                    }
                }
                if (bgSrc != null) {
                    bgDim = dim
                    if (light) { cKey = 0xA6FFFFFF.toInt(); cSp = 0x80FFFFFF.toInt(); cTx = 0xFF1B1B1F.toInt(); cBg = 0xFFFFFFFF.toInt() }
                    else { cKey = 0x66000000; cSp = 0x99000000.toInt(); cTx = 0xFFFFFFFF.toInt(); cBg = 0xFF101010.toInt() }
                    cAc = acc
                }
            } catch (e: Throwable) { bgSrc = null }
        }
        requestLayout(); build(); invalidate()
    }

    fun setSlots(l: List<String>) {
        val s = arrayOf(l.getOrElse(1) { "" }, l.getOrElse(0) { "" }, l.getOrElse(2) { "" })
        if (!s.contentEquals(slots)) { slots = s; invalidate() }
    }

    fun applyShift(v: Int) { if (shift != v) { shift = v; invalidate() } }
    fun setPage(s: Boolean) { sym = s; panel = 0; build(); invalidate() }
    fun openPanel(p: Int) { panel = p; scrollY = 0f; refresh(); build(); invalidate() }
    fun refresh() {
        items = when (panel) {
            1 -> (if (cat == 0) recents() else if (cat == 11) customList() else EmojiStore.get(context)[cat]).let { l -> if (skin > 0 && cat != 11) l.map { e -> skinify(e, skin) } else l }
            2 -> svc.clipList()
            3 -> FONT_NAMES
            else -> emptyList()
        }
        invalidate()
    }
    private fun contentH() = if (panel == 1) Math.ceil(items.size / cols.toDouble()).toFloat() * rowH else items.size * rowH

    private fun recents(): List<String> = if (!recOn) emptyList() else (rp.getString("r", "") ?: "").split('\u0001').filter { it.isNotEmpty() }
    private fun addRecent(e: String) {
        if (!recOn) return
        val l = ArrayList(recents()); l.remove(e); l.add(0, e)
        rp.edit().putString("r", l.take(40).joinToString("\u0001")).apply()
    }
    private fun customList(): List<String> {
        customNames?.let { return it }
        val l = try {
            (context.assets.list("custom_emoji") ?: emptyArray()).filter { n -> val x = n.lowercase(); x.endsWith(".png") || x.endsWith(".webp") || x.endsWith(".gif") || x.endsWith(".jpg") || x.endsWith(".jpeg") }.sorted()
        } catch (e: Exception) { emptyList<String>() }
        customNames = l
        return l
    }
    private fun emBmp(e: String, size: Int): Bitmap? {
        val key = e + "#" + size
        if (emCache.containsKey(key)) return emCache[key]
        if (emCache.size > 700) emCache.clear()
        val cps = ArrayList<String>()
        var i = 0
        while (i < e.length) { val cp = e.codePointAt(i); cps.add(Integer.toHexString(cp)); i += Character.charCount(cp) }
        val full = cps.joinToString("-")
        val stripped = cps.filter { it != "fe0f" }.joinToString("-")
        val names = if (cps.contains("200d")) listOf(full, stripped) else listOf(stripped, full)
        var out: Bitmap? = null
        for (n in names) {
            try {
                val src = context.assets.open("emoji/" + n + ".png").use { BitmapFactory.decodeStream(it) }
                if (src != null) { out = Bitmap.createScaledBitmap(src, size, size, true); break }
            } catch (ex: Exception) { }
        }
        emCache[key] = out
        return out
    }
    private fun bmp(name: String, size: Int): Bitmap? {
        if (bmpCache.containsKey(name)) return bmpCache[name]
        var out: Bitmap? = null
        try {
            val o = BitmapFactory.Options(); o.inJustDecodeBounds = true
            context.assets.open("custom_emoji/" + name).use { BitmapFactory.decodeStream(it, null, o) }
            val big = maxOf(o.outWidth, o.outHeight)
            var ss = 1
            while (big / (ss * 2) >= size * 2) ss *= 2
            val o2 = BitmapFactory.Options(); o2.inSampleSize = ss
            val src = context.assets.open("custom_emoji/" + name).use { BitmapFactory.decodeStream(it, null, o2) }
            if (src != null) {
                val sc = size.toFloat() / maxOf(src.width, src.height)
                out = Bitmap.createScaledBitmap(src, maxOf(1, (src.width * sc).toInt()), maxOf(1, (src.height * sc).toInt()), true)
            }
        } catch (e: Exception) { out = null }
        bmpCache[name] = out
        return out
    }

    private fun r(s: String, alts: String? = null) = s.mapIndexed { i, ch -> Kk(ch.toString(), 1f, alts?.get(i)?.toString()) }

    private fun rows(): List<List<Kk>> {
        if (panel != 0) return listOf(listOf(Kk("A", 1.5f), Kk("_", 5f), Kk("<", 1.5f), Kk("!", 1.5f)))
        val bottom = listOf(Kk("#", 1.3f), Kk("E"), Kk("F"), Kk(","), Kk("_", 4.4f), Kk("."), Kk("C"), Kk("!", 1.4f))
        if (sym) return listOf(r("1234567890"), r("@#\$_&-+()/"), r("*\"':;!?%=") + Kk("<", 1.5f), bottom)
        val l = ArrayList<List<Kk>>()
        if (numRow) l.add(r("1234567890"))
        l.add(r("qwertyuiop", if (numRow) null else "1234567890"))
        l.add(listOf(Kk("", .5f)) + r("asdfghjkl", "@#\$%&-+()") + Kk("", .5f))
        l.add(listOf(Kk("^", 1.5f)) + r("zxcvbnm", "*\"':;!?") + Kk("<", 1.5f))
        l.add(bottom)
        return l
    }

    private fun build() {
        cells.clear(); keys.clear()
        if (width == 0) return
        val rs = rows()
        stripH = if (showPred) 40 * d else 0f
        val avail = height - stripH - bPad * d
        val rh = avail / (if (panel != 0) 5 else rs.size)
        val t0 = if (panel != 0) stripH + avail - rh else stripH
        rowH = rh; gridBot = t0; gridTop = stripH + (if (panel == 1) rh * .8f else 0f)
        kw = if (oneH != 0) width * .82f else width.toFloat()
        kl = if (oneH == 2) width - kw else 0f
        rs.forEachIndexed { ri, row ->
            var tot = 0f
            for (k in row) tot += k.w
            var x = kl
            for (k in row) {
                val w = kw * k.w / tot
                cells.add(RectF(x, t0 + ri * rh, x + w, t0 + (ri + 1) * rh)); keys.add(k); x += w
            }
        }
        tp.textSize = minOf(rh * .42f, kw / 10f * .62f) * fs / 100f
        hintP.textSize = tp.textSize * .4f
        sg.textSize = 16 * d
    }

    override fun onMeasure(w: Int, hh: Int) {
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val row = 50 * d * hPct / 100f * (if (land) .72f else 1f)
        setMeasuredDimension(MeasureSpec.getSize(w), ((if (showPred) 40 * d else 0f) + row * 5 + bPad * d).toInt())
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) = build()

    private fun bl(p: Paint, cy: Float) = cy - (p.ascent() + p.descent()) / 2f

    override fun onDraw(cv: Canvas) {
        val bs = bgSrc
        if (bs != null) {
            var sc = bgScaled
            if (sc == null || sc.width != width || sc.height != height) {
                val sf = maxOf(width / bs.width.toFloat(), height / bs.height.toFloat())
                val bw = maxOf((bs.width * sf).toInt(), width)
                val bh = maxOf((bs.height * sf).toInt(), height)
                val big = Bitmap.createScaledBitmap(bs, bw, bh, true)
                sc = Bitmap.createBitmap(big, (bw - width) / 2, (bh - height) / 2, width, height)
                bgScaled = sc
            }
            cv.drawBitmap(sc!!, 0f, 0f, null)
            if (bgDim != 0) cv.drawColor(bgDim)
        } else cv.drawColor(cBg)
        if (showPred) {
            val w3 = width / 3f
            for (i in 0..2) {
                val sl = slots[i]
                val mk = sl.isNotEmpty() && sl[0] in '\u0002'..'\u0005'
                val chip = sl.startsWith("\u0002") || sl.startsWith("\u0003")
                sg.color = if (chip) cAc else cTx; sg.isFakeBoldText = i == 1
                cv.drawText(if (mk) sl.substring(1) else sl, w3 * i + w3 / 2, bl(sg, stripH / 2), sg)
                if (i > 0) { fill.color = cSp; cv.drawRect(w3 * i, stripH * .25f, w3 * i + 1, stripH * .75f, fill) }
            }
        }
        if (panel != 0) drawPanel(cv)
        val g = gap * d / 2
        val rd = rad * d
        val ts = tp.textSize
        for (i in cells.indices) {
            val k = keys[i]
            if (k.l.isEmpty()) continue
            val ce = cells[i]
            tmp.set(ce.left + g, ce.top + g, ce.right - g, ce.bottom - g)
            var down = false
            for (p in 0 until n) if (pk[p] === k) down = true
            val special = k.l == "^" || k.l == "<" || k.l == "#" || k.l == "A"
            fill.color = when {
                k.l == "!" || (k.l == "^" && shift > 0) -> cAc
                down -> if (special) cAc else cSp
                special -> cSp
                else -> cKey
            }
            if (shadowOn) {
                val keep = fill.color
                fill.color = 0x40000000
                tmp.offset(0f, 1.5f * d); cv.drawRoundRect(tmp, rd, rd, fill); tmp.offset(0f, -1.5f * d)
                fill.color = keep
            }
            cv.drawRoundRect(tmp, rd, rd, fill)
            val lab = when (k.l) {
                "^" -> if (shift == 2) "⇪" else "⇧"
                "<" -> "⌫"
                "!" -> enter
                "#" -> if (sym) "ABC" else "?123"
                "_" -> if (spLbl) "SpeedKey" else ""
                "A" -> "ABC"
                "E" -> "☺"
                "F" -> "Aa"
                "C" -> "📋"
                else -> if (shift > 0 && !sym) k.l.uppercase() else k.l
            }
            tp.color = if (k.l == "!" || (k.l == "^" && shift > 0)) cBg else cTx
            tp.textSize = if (special || k.l == "!") ts * .8f else if (k.l == "_") ts * .6f else ts
            tp.isFakeBoldText = bold
            cv.drawText(lab, tmp.centerX(), bl(tp, tmp.centerY()), tp)
            val a = k.a
            if (hints && a != null) { hintP.color = cTx and 0x99FFFFFF.toInt(); cv.drawText(a, tmp.right - 4 * d, tmp.top + hintP.textSize + 2 * d, hintP) }
        }
        tp.textSize = ts; tp.isFakeBoldText = false
        if (prv) for (p in 0 until n) {
            val k = pk[p] ?: continue
            if (pl[p] || k.l.length != 1 || "AEFC^<#!_".contains(k.l) || pc[p] >= cells.size || keys[pc[p]] !== k) continue
            val ce = cells[pc[p]]
            val bw = ce.width() * 1.3f * pop / 100f
            val bh = (ce.height()) * 1.15f * pop / 100f
            val l = (ce.centerX() - bw / 2).coerceIn(0f, width - bw)
            val t = maxOf(0f, ce.top - bh - 4 * d)
            tmp.set(l, t, l + bw, t + bh)
            fill.color = cSp; cv.drawRoundRect(tmp, rd * 1.5f, rd * 1.5f, fill)
            tp.textSize = ts * 1.4f; tp.color = cTx
            cv.drawText(if (shift > 0 && !sym) k.l.uppercase() else k.l, tmp.centerX(), bl(tp, tmp.centerY()), tp)
            tp.textSize = ts
        }
    }

    private fun drawPanel(cv: Canvas) {
        val rh = rowH; val orig = tp.textSize
        if (panel == 1) {
            val tw = width / EMO_TABS.size.toFloat()
            for (i in EMO_TABS.indices) {
                if (i == cat) { tmp.set(tw * i + 2 * d, stripH + 4 * d, tw * (i + 1) - 2 * d, stripH + rh * .8f - 2 * d); fill.color = cSp; cv.drawRoundRect(tmp, 12 * d, 12 * d, fill) }
                tp.color = cTx; tp.textSize = minOf(rh * .42f, tw * .7f)
                cv.drawText(EMO_TABS[i], tw * i + tw / 2, bl(tp, stripH + rh * .4f), tp)
            }
        }
        cv.save(); cv.clipRect(0f, gridTop, width.toFloat(), gridBot)
        if (panel == 1) {
            val cw = width / cols.toFloat(); tp.textSize = minOf(rh * .56f, cw * .72f) * emSize / 100f; tp.color = cTx
            if (items.isEmpty()) {
                sg.color = cTx
                val msg = if (cat == 0) "Recent emoji show here" else "Put images in assets/custom_emoji and rebuild"
                cv.drawText(msg, width / 2f, bl(sg, gridTop + rh), sg)
            }
            for (i in items.indices) {
                val y = gridTop + (i / cols) * rh - scrollY
                if (y + rh < gridTop || y > gridBot) continue
                val cx = (i % cols) * cw + cw / 2
                if (cat == 11) {
                    val b = bmp(items[i], (minOf(rh, cw) * .8f * emSize / 100f).toInt().coerceAtLeast(8))
                    if (b != null) cv.drawBitmap(b, cx - b.width / 2f, y + rh / 2 - b.height / 2f, null)
                } else {
                    val utf = userTf ?: (if (notoOn) notoTf else null)
                    if (utf != null) {
                        emojiPaint.typeface = utf
                        emojiPaint.textSize = minOf(rh, cw) * .72f * emSize / 100f
                        cv.drawText(items[i], cx, bl(emojiPaint, y + rh / 2), emojiPaint)
                    } else {
                        val eb = emBmp(items[i], (minOf(rh, cw) * .78f * emSize / 100f).toInt().coerceAtLeast(8))
                        if (eb != null) cv.drawBitmap(eb, cx - eb.width / 2f, y + rh / 2 - eb.height / 2f, null)
                        else cv.drawText(items[i], cx, bl(tp, y + rh / 2), tp)
                    }
                }
            }
        } else if (panel == 3) {
            val cur = sp.getInt("fstyle", 0)
            for (i in items.indices) {
                val y = gridTop + i * rh - scrollY
                if (y + rh < gridTop || y > gridBot) continue
                tmp.set(6 * d, y + 2 * d, width - 6 * d, y + rh - 2 * d)
                fill.color = if (i == cur) cSp else cKey; cv.drawRoundRect(tmp, 8 * d, 8 * d, fill)
                ip.textSize = rh * .3f; ip.color = cTx; ip.isFakeBoldText = false
                cv.drawText(items[i], 14 * d, bl(ip, y + rh / 2), ip)
                tp.textSize = rh * .38f; tp.color = cTx
                tp.textAlign = Paint.Align.RIGHT
                cv.drawText(fx(i, "Speed Key 123"), width - 14 * d, bl(tp, y + rh / 2), tp)
                tp.textAlign = Paint.Align.CENTER
            }
        } else {
            ip.textSize = rh * .32f; ip.color = cTx
            if (items.isEmpty()) { sg.color = cTx; cv.drawText("Copy something, it shows here forever", width / 2f, bl(sg, gridTop + rh), sg) }
            for (i in items.indices) {
                val y = gridTop + i * rh - scrollY
                if (y + rh < gridTop || y > gridBot) continue
                tmp.set(6 * d, y + 2 * d, width - 6 * d, y + rh - 2 * d)
                fill.color = cKey; cv.drawRoundRect(tmp, 8 * d, 8 * d, fill)
                var t = items[i].replace('\n', ' ')
                if (t.length > 40) t = t.take(40) + "…"
                cv.drawText(t, 14 * d, bl(ip, y + rh / 2), ip)
                tp.textSize = rh * .4f; tp.color = cTx
                cv.drawText(if (svc.pinned(items[i])) "📌" else "📍", width * .76f, bl(tp, y + rh / 2), tp)
                cv.drawText("✕", width * .93f, bl(tp, y + rh / 2), tp)
            }
        }
        cv.restore(); tp.textSize = orig
    }

    private fun lite(c: Int): Int = android.graphics.Color.rgb(minOf(255, android.graphics.Color.red(c) + 90), minOf(255, android.graphics.Color.green(c) + 90), minOf(255, android.graphics.Color.blue(c) + 90))

    private fun heart(cv: Canvas, cx: Float, cy: Float, s: Float) {
        gpath.reset(); gpath.moveTo(cx, cy + s * .9f)
        gpath.cubicTo(cx - s * 1.4f, cy, cx - s * .9f, cy - s * 1.1f, cx, cy - s * .35f)
        gpath.cubicTo(cx + s * .9f, cy - s * 1.1f, cx + s * 1.4f, cy, cx, cy + s * .9f)
        gpath.close(); cv.drawPath(gpath, gp)
    }

    private fun drawGl(cv: Canvas, g: Gl, cx: Float, cy: Float, r: Float) {
        val dk = 0xFF4E342E.toInt()
        gp.style = Paint.Style.FILL
        if (g.kind == 1 || g.kind == 2) {
            gp.shader = RadialGradient(cx - r * .3f, cy - r * .4f, r * 1.5f, lite(g.a), g.a, Shader.TileMode.CLAMP)
            if (g.kind == 1) heart(cv, cx, cy, r * .8f) else {
                gpath.reset()
                for (i in 0 until 10) {
                    val rad = if (i % 2 == 0) r else r * .45f; val a = -Math.PI / 2 + i * Math.PI / 5
                    val x = (cx + rad * Math.cos(a)).toFloat(); val y = (cy + rad * Math.sin(a)).toFloat()
                    if (i == 0) gpath.moveTo(x, y) else gpath.lineTo(x, y)
                }
                gpath.close(); cv.drawPath(gpath, gp)
            }
            gp.shader = null; gp.color = 0x77FFFFFF; cv.drawOval(cx - r * .55f, cy - r * .7f, cx - r * .1f, cy - r * .35f, gp)
            return
        }
        val red = g.kind == 3
        gp.shader = RadialGradient(cx - r * .3f, cy - r * .4f, r * 1.4f, if (red) 0xFFFF8A80.toInt() else 0xFFFFE57F.toInt(), if (red) 0xFFD32F2F.toInt() else 0xFFFFA000.toInt(), Shader.TileMode.CLAMP)
        cv.drawCircle(cx, cy, r, gp); gp.shader = null
        gp.color = 0x66FFFFFF; cv.drawOval(cx - r * .6f, cy - r * .9f, cx + r * .25f, cy - r * .4f, gp)
        val ey = cy - r * .12f; val ex = r * .36f
        fun fillP(c: Int) { gp.style = Paint.Style.FILL; gp.color = c }
        fun strokeP() { gp.style = Paint.Style.STROKE; gp.strokeWidth = r * .09f; gp.strokeCap = Paint.Cap.ROUND; gp.color = dk }
        for (sg2 in intArrayOf(-1, 1)) {
            val x = cx + sg2 * ex
            when (g.a) {
                0, 7 -> { fillP(dk); cv.drawCircle(x, ey, r * .1f, gp); if (g.a == 7 && sg2 == -1) { fillP(0xFF4FC3F7.toInt()); cv.drawCircle(x - r * .05f, ey + r * .3f, r * .08f, gp) } }
                1 -> { strokeP(); cv.drawArc(x - r * .16f, ey - r * .12f, x + r * .16f, ey + r * .2f, 200f, 140f, false, gp) }
                2 -> { fillP(0xFFE53935.toInt()); heart(cv, x, ey, r * .17f) }
                4 -> { strokeP(); cv.drawLine(x - r * .14f, ey, x + r * .14f, ey, gp) }
                5 -> if (sg2 == -1) { fillP(dk); cv.drawCircle(x, ey, r * .1f, gp) } else { strokeP(); cv.drawLine(x - r * .14f, ey, x + r * .14f, ey, gp) }
                6 -> { fillP(0xFFFFFFFF.toInt()); cv.drawCircle(x, ey, r * .17f, gp); fillP(dk); cv.drawCircle(x, ey, r * .08f, gp) }
            }
            if (red) { strokeP(); cv.drawLine(x - sg2 * r * .2f, ey - r * .32f, x + sg2 * r * .2f, ey - r * .16f, gp) }
        }
        if (g.a == 3) { fillP(0xFF212121.toInt()); cv.drawRoundRect(cx - r * .68f, cy - r * .32f, cx - r * .06f, cy + r * .06f, r * .1f, r * .1f, gp); cv.drawRoundRect(cx + r * .06f, cy - r * .32f, cx + r * .68f, cy + r * .06f, r * .1f, r * .1f, gp) }
        val my = cy + r * .3f
        when (g.b) {
            0 -> { strokeP(); cv.drawArc(cx - r * .4f, my - r * .3f, cx + r * .4f, my + r * .3f, 20f, 140f, false, gp) }
            1 -> { fillP(dk); cv.drawArc(cx - r * .45f, my - r * .3f, cx + r * .45f, my + r * .4f, 0f, 180f, true, gp) }
            2 -> { strokeP(); cv.drawLine(cx - r * .3f, my + r * .1f, cx + r * .3f, my + r * .1f, gp) }
            3 -> { strokeP(); cv.drawArc(cx - r * .35f, my, cx + r * .35f, my + r * .6f, 200f, 140f, false, gp) }
            4 -> { fillP(dk); cv.drawCircle(cx, my + r * .15f, r * .16f, gp) }
            5 -> { fillP(dk); cv.drawArc(cx - r * .4f, my - r * .3f, cx + r * .4f, my + r * .3f, 0f, 180f, true, gp); fillP(0xFFFF6F91.toInt()); cv.drawOval(cx - r * .15f, my + r * .05f, cx + r * .15f, my + r * .42f, gp) }
            6 -> { fillP(0xFFE53935.toInt()); heart(cv, cx, my + r * .1f, r * .16f) }
        }
        gp.style = Paint.Style.FILL
    }

    private fun gridTap(x: Float, y: Float) {
        if (panel == 1 && y < gridTop) { cat = (x / (width / EMO_TABS.size.toFloat())).toInt().coerceIn(0, EMO_TABS.size - 1); scrollY = 0f; refresh(); return }
        val row = ((y - gridTop + scrollY) / rowH).toInt()
        if (panel == 1) {
            val i = row * cols + (x / (width / cols.toFloat())).toInt().coerceIn(0, cols - 1)
            if (i in items.indices) {
                if (cat == 11) svc.sendImage(items[i]) else { svc.type(items[i]); addRecent(items[i]) }
            }
        } else if (panel == 3) {
            if (row in items.indices) { sp.edit().putInt("fstyle", row).apply(); panel = 0; build(); invalidate() }
        } else if (row in items.indices) {
            val t = items[row]
            if (x > width * .86f) svc.clipDel(t) else if (x > width * .68f) svc.clipPin(t) else svc.paste(t)
            refresh()
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val i = e.actionIndex
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> down(e.getPointerId(i), e.getX(i), e.getY(i))
            MotionEvent.ACTION_MOVE -> for (j in 0 until e.pointerCount) move(e.getPointerId(j), e.getX(j), e.getY(j))
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> up(e.getPointerId(i), e.getY(i))
            MotionEvent.ACTION_CANCEL -> for (j in 0 until n) { h.removeCallbacks(lr[j]); h.removeCallbacks(rr[j]); pk[j] = null; ps[j] = -1 }
        }
        invalidate()
        return true
    }

    private fun down(id: Int, x: Float, y: Float) {
        if (id >= n) return
        px[id] = x; plast[id] = x; pl[id] = false; psw[id] = false; ps[id] = -1; pk[id] = null
        if (y < stripH) { ps[id] = (x / width * 3).toInt().coerceIn(0, 2); return }
        if (panel != 0 && y >= stripH && y < gridBot) { ps[id] = 8; plY[id] = y; pdY[id] = y; return }
        if (oneH != 0 && (x < kl || x > kl + kw)) { ps[id] = 9; return }
        var hit = -1
        for (i in cells.indices) if (cells[i].contains(x, y)) { hit = i; break }
        if (hit < 0) return
        val k = keys[hit]
        if (k.l.isEmpty()) return
        pk[id] = k; pc[id] = hit; fb(k)
        when (k.l) {
            "^" -> if (!sym) {
                val now = SystemClock.uptimeMillis()
                shift = if (shift == 2) 0 else if (shift == 1 && now - lastShift < 350) 2 else if (shift == 1) 0 else 1
                lastShift = now
            }
            "#" -> { sym = !sym; build() }
            "A" -> { panel = 0; build() }
            "E" -> openPanel(1)
            "C" -> openPanel(2)
            "F" -> openPanel(3)
            "<" -> { svc.del(); h.postDelayed(rr[id], 350) }
            "!" -> svc.enter()
            "_" -> h.postDelayed(lr[id], 500)
            else -> {
                val t = if (shift > 0 && !sym) k.l.uppercase() else k.l
                if (shift == 1) shift = 0
                svc.type(t)
                if (k.a != null) h.postDelayed(lr[id], lpMs.toLong())
            }
        }
    }

    private fun move(id: Int, x: Float, y: Float) {
        if (id >= n) return
        if (ps[id] == 8) {
            if (Math.abs(y - pdY[id]) > 10 * d) psw[id] = true
            if (psw[id]) scrollY = (scrollY - (y - plY[id])).coerceIn(0f, maxOf(0f, contentH() - (gridBot - gridTop)))
            plY[id] = y; return
        }
        val k = pk[id] ?: return
        if (k.l == "_" && swp) {
            val st = step * d
            while (Math.abs(x - plast[id]) >= st) {
                val dir = if (x > plast[id]) 1 else -1
                plast[id] += dir * st; psw[id] = true; h.removeCallbacks(lr[id]); svc.move(dir)
            }
        } else if (Math.abs(x - px[id]) > 14 * d) h.removeCallbacks(lr[id])
    }

    private fun up(id: Int, y: Float) {
        if (id >= n) return
        h.removeCallbacks(lr[id]); h.removeCallbacks(rr[id])
        if (ps[id] == 8) { if (!psw[id]) gridTap(px[id], pdY[id]); ps[id] = -1; return }
        if (ps[id] in 0..2 && y < stripH && slots[ps[id]].isNotEmpty()) svc.pick(slots[ps[id]])
        if (ps[id] == 9) sp.edit().putInt("oneH", 0).apply()
        if (pk[id]?.l == "_" && !psw[id] && !pl[id]) svc.space()
        pk[id] = null; ps[id] = -1
    }

    private fun longPress(i: Int) {
        val k = pk[i] ?: return
        if (psw[i]) return
        pl[i] = true
        if (k.l == "_") {
            when (sp.getInt("spaceLP", 0)) { 1 -> svc.pasteLatest(); 2 -> openPanel(3); else -> svc.picker() }
        } else k.a?.let { svc.alt(it) }
        invalidate()
    }

    private fun rpt(i: Int) {
        if (pk[i]?.l == "<") { svc.del(); fb(null); h.postDelayed(rr[i], rep.toLong()) }
    }

    private fun fb(k: Kk?) {
        if (hap) vib?.vibrate(VibrationEffect.createOneShot(hms.toLong(), VibrationEffect.DEFAULT_AMPLITUDE))
        if (snd) am.playSoundEffect(if (k?.l == "_") AudioManager.FX_KEYPRESS_SPACEBAR else AudioManager.FX_KEYPRESS_STANDARD, .6f)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        for (j in 0 until n) { h.removeCallbacks(lr[j]); h.removeCallbacks(rr[j]) }
    }
}

class KeyboardService : InputMethodService() {
    private var v: KView? = null
    private val word = StringBuilder()
    private var prev = ""
    private val learned = HashMap<String, Int>()
    private val next = HashMap<String, String>()
    private var base: List<String> = emptyList()
    private var sugOn = true
    private var act = 0
    private var lastSp = 0L
    private var autoSp = false
    private var dirty = true
    private var seenReset = 0
    private var lastLen = 1
    private var freshClip: String? = null
    private var clipAt = 0L
    private var clipUsed = true
    private var shotUri: android.net.Uri? = null
    private var shotId = -1L
    private var shotAt = 0L
    private var usedShotId = -1L
    private var imgOk = false
    private val sp by lazy { prefs(this) }
    private val lp by lazy { getSharedPreferences("learn", Context.MODE_PRIVATE) }
    val clips = ArrayList<String>()
    private val pins = HashSet<String>()
    private val cp by lazy { getSharedPreferences("clips", Context.MODE_PRIVATE) }
    private val lis = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> dirty = true }

    override fun onCreate() {
        super.onCreate()
        val extra = ArrayList<String>()
        for (f in arrayOf("words_en.txt", "words_hi.txt", "words_more.txt")) {
            try { assets.open(f).bufferedReader().readLines().forEach { w -> if (w.isNotBlank()) extra.add(w.trim()) } } catch (e: Exception) { }
        }
        base = (WORDS.split(' ') + extra).distinct()
        loadCustomFont(this)
        Thread { EmojiStore.get(this); EmojiStore.loadMap(this) }.start()
        lp.getString("w", "")!!.split('\n').forEach { val p = it.split('='); if (p.size == 2) learned[p[0]] = p[1].toIntOrNull() ?: 1 }
        lp.getString("n", "")!!.split('\n').forEach { val p = it.split('>'); if (p.size == 2) next[p[0]] = p[1] }
        cp.getString("c", "")!!.split('\u0001').filter { it.isNotEmpty() }.forEach { clips.add(it) }
        cp.getString("p", "")!!.split('\u0001').filter { it.isNotEmpty() }.forEach { pins.add(it) }
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.addPrimaryClipChangedListener {
            val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()
            if (!t.isNullOrBlank() && sp.getBoolean("clip", true)) { clips.remove(t); clips.add(0, t); saveClips() }
            if (!t.isNullOrBlank()) { freshClip = t; clipAt = System.currentTimeMillis(); clipUsed = false; sugs() }
        }
        seenReset = sp.getInt("learnReset", 0)
        sp.registerOnSharedPreferenceChangeListener(lis)
    }

    override fun onDestroy() { sp.unregisterOnSharedPreferenceChangeListener(lis); super.onDestroy() }
    override fun onEvaluateFullscreenMode() = false

    override fun onCreateInputView(): View {
        val k = KView(this, this)
        k.load(); v = k; dirty = false
        return k
    }

    override fun onStartInputView(info: EditorInfo, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        val k = v ?: return
        if (dirty) { k.load(); dirty = false }
        if (sp.getInt("learnReset", 0) != seenReset) { seenReset = sp.getInt("learnReset", 0); learned.clear(); next.clear() }
        val cls = info.inputType and InputType.TYPE_MASK_CLASS
        val va = info.inputType and InputType.TYPE_MASK_VARIATION
        val txt = cls == InputType.TYPE_CLASS_TEXT
        sugOn = txt && va != InputType.TYPE_TEXT_VARIATION_PASSWORD && va != InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD &&
            va != InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD && va != InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS && va != InputType.TYPE_TEXT_VARIATION_URI
        val a = info.imeOptions and EditorInfo.IME_MASK_ACTION
        act = if ((info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0 || a == EditorInfo.IME_ACTION_NONE || a == EditorInfo.IME_ACTION_UNSPECIFIED) 0 else a
        k.enter = when (act) { EditorInfo.IME_ACTION_SEARCH -> "🔍"; EditorInfo.IME_ACTION_SEND -> "➤"; EditorInfo.IME_ACTION_GO -> "➜"; EditorInfo.IME_ACTION_NEXT -> "→"; EditorInfo.IME_ACTION_DONE -> "✓"; else -> "⏎" }
        word.setLength(0); prev = ""
        k.setPage(!txt)
        imgOk = try { androidx.core.view.inputmethod.EditorInfoCompat.getContentMimeTypes(info).any { it.startsWith("image/") || it == "*/*" } } catch (e: Exception) { false }
        findShot()
        autoCap(); sugs()
    }

    override fun onFinishInput() {
        super.onFinishInput()
        if (learned.size > 3000) learned.entries.removeAll { it.value < 2 }
        lp.edit().putString("w", learned.entries.joinToString("\n") { it.key + "=" + it.value })
            .putString("n", next.entries.joinToString("\n") { it.key + ">" + it.value }).apply()
    }

    private fun cap(s: String, like: String) = if (like.isNotEmpty() && like[0].isUpperCase()) s.replaceFirstChar { it.uppercase() } else s

    private fun lev1(a: String, b: String): Boolean {
        if (a == b) return true
        if (Math.abs(a.length - b.length) > 1) return false
        var i = 0
        while (i < a.length && i < b.length && a[i] == b[i]) i++
        return a.substring(i + (if (a.length >= b.length) 1 else 0)) == b.substring(i + (if (b.length >= a.length) 1 else 0))
    }

    private fun sugs() {
        val k = v ?: return
        if (!sugOn || !sp.getBoolean("predict", true)) { k.setSlots(emptyList()); return }
        val raw = word.toString(); val w = raw.lowercase()
        val sc = HashMap<String, Int>()
        if (w.isEmpty()) {
            if (sp.getBoolean("nextWord", true)) next[prev]?.let { sc[it] = 99900 }
            if (prev.isEmpty()) { sc["I"] = 3; sc["The"] = 2; sc["Hi"] = 1 }
        } else {
            var found = 0
            for (i in base.indices) { val b = base[i]; if (b.startsWith(w)) { sc[b] = 100000 - i; found++; if (found >= 3) break } }
            if (sp.getBoolean("learn", true)) for ((b, c) in learned) if (b.startsWith(w)) sc[b] = maxOf(sc[b] ?: 0, 99500 + c * 50)
            if (sc.size < 3 && w.length >= 3 && sp.getBoolean("typo", true)) for (i in 0 until minOf(base.size, 8000)) { val b = base[i]; if (b[0] == w[0] && lev1(w, b)) sc.putIfAbsent(b, 99400 - i) }
        }
        val out = ArrayList(sc.entries.sortedByDescending { it.value }.take(3).map { if (w.isEmpty() && k.shift > 0) it.key.replaceFirstChar { c -> c.uppercase() } else cap(it.key, raw) })
        if (w.isNotEmpty() && (out.isEmpty() || out[0].lowercase() != w)) {
            val q = "\u0005\"" + raw + "\""
            if (out.isEmpty()) out.add(q) else out.add(1, q)
        }
        if (sp.getBoolean("emojiSug", true)) {
            val em = EmojiStore.forWord(if (w.isNotEmpty()) w else prev)
            if (em != null) { val e = "\u0004" + em; if (out.size >= 2) out.add(2, e) else out.add(e) }
        }
        if (w.isEmpty()) chipText()?.let { out.add(0, it) }
        k.setSlots(out.take(3))
    }

    private fun endWord() {
        if (word.isEmpty()) return
        val w = word.toString().lowercase()
        if (w.length > 1 && sugOn && sp.getBoolean("learn", true)) { learned[w] = (learned[w] ?: 0) + 1; if (prev.isNotEmpty()) next[prev] = w }
        prev = w; word.setLength(0)
    }

    private fun resync() {
        val b = currentInputConnection?.getTextBeforeCursor(24, 0)?.toString() ?: ""
        var i = b.length
        while (i > 0 && b[i - 1].isLetterOrDigit()) i--
        word.setLength(0); word.append(b, i, b.length)
    }

    private fun autoCap() {
        val k = v ?: return
        if (!sugOn || !sp.getBoolean("autoCap", true) || k.sym || k.shift == 2) return
        val ic = currentInputConnection ?: return
        val t = (currentInputEditorInfo?.inputType ?: 0) or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        k.applyShift(if (ic.getCursorCapsMode(t) != 0) 1 else 0)
    }

    fun type(t: String) {
        val ic = currentInputConnection ?: return
        if (autoSp && t.length == 1 && ".,!?;:".contains(t)) ic.deleteSurroundingText(1, 0)
        autoSp = false
        val out = fx(sp.getInt("fstyle", 0), t)
        ic.commitText(out, 1); lastLen = out.length
        if (t[0].isLetterOrDigit()) { clipUsed = true; usedShotId = shotId }
        if (t[0].isLetterOrDigit() || t == "'") word.append(t) else { endWord(); if (".!?".contains(t)) prev = "" }
        sugs()
    }

    fun alt(a: String) {
        currentInputConnection?.deleteSurroundingText(lastLen.coerceAtLeast(1), 0)
        if (word.isNotEmpty()) word.setLength(word.length - 1)
        type(a)
    }

    fun del() {
        autoSp = false
        sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        if (word.isNotEmpty()) word.setLength(word.length - 1) else resync()
        sugs()
    }

    fun space() {
        val ic = currentInputConnection ?: return
        val now = SystemClock.uptimeMillis()
        if (sp.getBoolean("dblSpace", true) && word.isEmpty() && now - lastSp < 450) {
            val b = ic.getTextBeforeCursor(2, 0)
            if (b != null && b.length == 2 && b[1] == ' ' && b[0].isLetterOrDigit()) {
                ic.deleteSurroundingText(1, 0); ic.commitText(". ", 1)
                lastSp = 0; prev = ""; autoCap(); sugs(); return
            }
        }
        endWord(); ic.commitText(" ", 1); autoSp = false; lastSp = now; autoCap(); sugs()
    }

    fun enter() {
        endWord(); prev = ""; autoSp = false
        if (act != 0) currentInputConnection?.performEditorAction(act) else sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        autoCap(); sugs()
    }

    fun pick(t: String) {
        if (t.startsWith("\u0002")) { freshClip?.let { paste(it) }; clipUsed = true; sugs(); return }
        if (t.startsWith("\u0003")) { sendShot(); return }
        if (t.startsWith("\u0004")) {
            val ic0 = currentInputConnection ?: return
            val em = t.substring(1)
            if (word.isNotEmpty()) { endWord(); ic0.commitText(" ", 1) }
            ic0.commitText(em, 1); lastLen = em.length; prev = ""; autoSp = false
            sugs(); return
        }
        if (t.startsWith("\u0005")) {
            val ic0 = currentInputConnection ?: return
            endWord(); ic0.commitText(" ", 1); sugs(); return
        }
        val ic = currentInputConnection ?: return
        val fs = sp.getInt("fstyle", 0)
        if (word.isNotEmpty()) ic.deleteSurroundingText(fx(fs, word.toString()).length, 0)
        val s = sp.getBoolean("autoSpace", true)
        val out = fx(fs, t)
        ic.commitText(if (s) "$out " else out, 1)
        word.setLength(0); word.append(t); endWord(); autoSp = s
        autoCap(); sugs()
    }

    fun move(dir: Int) {
        sendDownUpKeyEvents(if (dir < 0) KeyEvent.KEYCODE_DPAD_LEFT else KeyEvent.KEYCODE_DPAD_RIGHT)
        resync(); sugs()
    }

    private fun saveClips() { cp.edit().putString("c", clips.joinToString("\u0001")).putString("p", pins.joinToString("\u0001")).apply() }
    fun clipList(): List<String> = clips.filter { it in pins } + clips.filter { it !in pins }
    fun pinned(t: String) = t in pins
    fun clipDel(t: String) { clips.remove(t); pins.remove(t); saveClips() }
    fun clipPin(t: String) { if (!pins.add(t)) pins.remove(t); saveClips() }
    fun paste(t: String) { currentInputConnection?.commitText(t, 1); word.setLength(0); prev = ""; sugs() }


    private fun chipText(): String? {
        if (!sp.getBoolean("showChip", true)) return null
        val now = System.currentTimeMillis()
        val clipOk = !clipUsed && freshClip != null && now - clipAt < 600000
        val shotOk = imgOk && shotUri != null && shotId != usedShotId
        if (shotOk && (!clipOk || shotAt >= clipAt)) return "\u0003🖼️ Screenshot"
        if (clipOk) {
            val t = freshClip!!.replace('\n', ' ').trim()
            return "\u0002📋 " + (if (t.length > 12) t.take(12) + "…" else t)
        }
        return null
    }

    private fun findShot() {
        shotUri = null
        if (!sp.getBoolean("shot", true)) return
        val perm = if (android.os.Build.VERSION.SDK_INT >= 33) android.Manifest.permission.READ_MEDIA_IMAGES else android.Manifest.permission.READ_EXTERNAL_STORAGE
        if (checkSelfPermission(perm) != android.content.pm.PackageManager.PERMISSION_GRANTED) return
        try {
            val since = System.currentTimeMillis() / 1000 - 180
            val cr = contentResolver
            val base = android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            cr.query(
                base,
                arrayOf(android.provider.MediaStore.Images.Media._ID, android.provider.MediaStore.Images.Media.DATE_ADDED),
                android.provider.MediaStore.Images.Media.DATE_ADDED + " >= ? AND " + android.provider.MediaStore.Images.Media.DISPLAY_NAME + " LIKE ?",
                arrayOf(since.toString(), "%creenshot%"),
                android.provider.MediaStore.Images.Media.DATE_ADDED + " DESC"
            )?.use { c ->
                if (c.moveToFirst()) {
                    shotId = c.getLong(0); shotAt = c.getLong(1) * 1000
                    shotUri = android.content.ContentUris.withAppendedId(base, shotId)
                }
            }
        } catch (e: Exception) { }
    }

    private fun sendShot() {
        val ic = currentInputConnection ?: return
        val ei = currentInputEditorInfo ?: return
        val u = shotUri ?: return
        try {
            val mime = contentResolver.getType(u) ?: "image/png"
            val info = androidx.core.view.inputmethod.InputContentInfoCompat(u, android.content.ClipDescription("screenshot", arrayOf(mime)), null)
            val ok = androidx.core.view.inputmethod.InputConnectionCompat.commitContent(ic, ei, info, androidx.core.view.inputmethod.InputConnectionCompat.INPUT_CONTENT_GRANT_READ_URI_PERMISSION, null)
            if (ok) { usedShotId = shotId; sugs() } else android.widget.Toast.makeText(this, "This app did not accept the image", android.widget.Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { }
    }

    fun pasteLatest() { clips.firstOrNull()?.let { paste(it) } }

    fun sendImage(name: String) {
        val ic = currentInputConnection ?: return
        val ei = currentInputEditorInfo ?: return
        try {
            val dir = java.io.File(cacheDir, "emoji"); dir.mkdirs()
            val f = java.io.File(dir, name)
            assets.open("custom_emoji/" + name).use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            val ln = name.lowercase()
            val mime = if (ln.endsWith(".gif")) "image/gif" else if (ln.endsWith(".webp")) "image/webp" else if (ln.endsWith(".jpg") || ln.endsWith(".jpeg")) "image/jpeg" else "image/png"
            val ok = androidx.core.view.inputmethod.EditorInfoCompat.getContentMimeTypes(ei).any { android.content.ClipDescription.compareMimeTypes(mime, it) }
            if (!ok) { android.widget.Toast.makeText(this, "This app does not accept images", android.widget.Toast.LENGTH_SHORT).show(); return }
            val uri = androidx.core.content.FileProvider.getUriForFile(this, packageName + ".files", f)
            val info = androidx.core.view.inputmethod.InputContentInfoCompat(uri, android.content.ClipDescription(name, arrayOf(mime)), null)
            androidx.core.view.inputmethod.InputConnectionCompat.commitContent(ic, ei, info, androidx.core.view.inputmethod.InputConnectionCompat.INPUT_CONTENT_GRANT_READ_URI_PERMISSION, null)
        } catch (e: Exception) { }
    }

    fun picker() { (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() }
}
