package com.jackie.speedkey

import android.content.ClipboardManager
import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.RectF
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.text.InputType
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager

// bg, key, special, text, accent
val THEMES = listOf(
    "Midnight" to longArrayOf(0xFF0E1116, 0xFF1C222B, 0xFF2A323E, 0xFFE8ECF1, 0xFF4FC3F7),
    "Neon" to longArrayOf(0xFF05060F, 0xFF10132A, 0xFF1B1F44, 0xFFE6F7FF, 0xFF00F0FF),
    "Light" to longArrayOf(0xFFE9ECEF, 0xFFFFFFFF, 0xFFCDD3DA, 0xFF1B1F23, 0xFF1E88E5),
    "AMOLED" to longArrayOf(0xFF000000, 0xFF141414, 0xFF222222, 0xFFFFFFFF, 0xFFBB86FC),
    "Sunset" to longArrayOf(0xFF2B1B2E, 0xFF3D2742, 0xFF54325A, 0xFFFFEFE3, 0xFFFF8A5B),
    "Forest" to longArrayOf(0xFF0F1D16, 0xFF183024, 0xFF22402F, 0xFFE6F5EA, 0xFF4CD97B),
    "Ocean" to longArrayOf(0xFF0A1A2F, 0xFF12304F, 0xFF1A4068, 0xFFE3F2FD, 0xFF29B6F6),
    "Rose" to longArrayOf(0xFFFCE4EC, 0xFFFFFFFF, 0xFFF8BBD0, 0xFF4A1530, 0xFFE91E63),
    "Gold" to longArrayOf(0xFF14110A, 0xFF241E10, 0xFF33290F, 0xFFFFF3D6, 0xFFFFC107),
    "Hacker" to longArrayOf(0xFF020A04, 0xFF07160B, 0xFF0C2413, 0xFF9DFFB0, 0xFF00FF66)
)

const val WORDS = "the be to of and a in that have i it for not on with he as you do at this but his by from they we say her she or an will my one all would there their what so up out if about who get which go me when make can like time no just him know take people into year your good some could them see other than then now look only come its over think also back after use two how our work first well way even new want because any these give day most us is are was were been has had did does said going great thank thanks please sorry hello hi hey ok okay yes yeah sure maybe today tomorrow yesterday tonight morning night home phone call message send love happy birthday welcome bad best better very really much many more little big long late soon always never again here where why start stop help need try find feel tell ask friend family money food game video music movie photo app keyboard don't i'm it's can't i'll that's you're what's let's kya hai nahi bhai yaar kaise kahan kab kyun kaun kuch bahut accha theek mera tera tum aap hum main mujhe aur lekin bhi karo kar abhi kal aaj raat ghar kaam paisa dost pyaar shukriya"

class Gl(val u: String, val kind: Int, val a: Int, val b: Int)
private fun hc(v: Long) = v.toInt()
val GL = listOf(
    Gl("😀", 0, 0, 1), Gl("😃", 0, 6, 1), Gl("😄", 0, 1, 1), Gl("😂", 0, 7, 1), Gl("😊", 0, 1, 0), Gl("😍", 0, 2, 1),
    Gl("😎", 0, 3, 0), Gl("😘", 0, 5, 6), Gl("😜", 0, 5, 5), Gl("😢", 0, 7, 3), Gl("😭", 0, 7, 4), Gl("😡", 3, 0, 3),
    Gl("😱", 0, 6, 4), Gl("😴", 0, 4, 2), Gl("🤔", 0, 0, 2), Gl("🙂", 0, 0, 0), Gl("😐", 0, 0, 2), Gl("😇", 0, 1, 0),
    Gl("❤️", 1, hc(0xFFE53935), 0), Gl("🧡", 1, hc(0xFFFB8C00), 0), Gl("💛", 1, hc(0xFFFDD835), 0), Gl("💚", 1, hc(0xFF43A047), 0),
    Gl("💙", 1, hc(0xFF1E88E5), 0), Gl("💜", 1, hc(0xFF8E24AA), 0), Gl("🖤", 1, hc(0xFF37474F), 0), Gl("🤍", 1, hc(0xFFCFD8DC), 0),
    Gl("⭐", 2, hc(0xFFFFB300), 0)
)
val EMO_TABS = listOf("✨", "😀", "👍", "🐶", "🍕", "🎉", "🚗", "💡", "🔣", "🏳️")
val EMO_R = listOf(
    listOf(0x1F600..0x1F64F, 0x1F910..0x1F92F, 0x1F970..0x1F97F, 0x1F9D0..0x1F9D0),
    listOf(0x261D..0x261D, 0x270A..0x270D, 0x1F440..0x1F4A0, 0x1F90C..0x1F90F, 0x1F930..0x1F93F, 0x1F9B0..0x1F9DF, 0x1FAC0..0x1FAFF),
    listOf(0x1F400..0x1F43F, 0x1F980..0x1F9AF, 0x1F330..0x1F344, 0x1FAB0..0x1FABF),
    listOf(0x1F345..0x1F37F, 0x1F9C0..0x1F9CB, 0x1FAD0..0x1FADF, 0x2615..0x2615),
    listOf(0x1F380..0x1F3F0, 0x1F3F8..0x1F3FA, 0x26BD..0x26BE, 0x1F94A..0x1F94F, 0x1F9E7..0x1F9FF),
    listOf(0x1F680..0x1F6D7, 0x1F6E0..0x1F6FC, 0x1F300..0x1F32F, 0x1F3D4..0x1F3DF, 0x1F5FA..0x1F5FF),
    listOf(0x1F4A1..0x1F4FF, 0x1F50A..0x1F52F, 0x1F5A5..0x1F5A5, 0x1F9F0..0x1F9F6),
    listOf(0x2190..0x21FF, 0x2600..0x26FF, 0x2700..0x27BF, 0x2B05..0x2B55, 0x1F170..0x1F19A, 0x1F500..0x1F53D, 0x1F7E0..0x1F7EB, 0x1F493..0x1F49F)
)
val FLAGS: List<String> by lazy {
    val p = Paint()
    val l = ArrayList<String>()
    for (cp in intArrayOf(0x1F3C1, 0x1F6A9, 0x1F3F3, 0x1F3F4)) { val f = String(Character.toChars(cp)) + "\uFE0F"; if (p.hasGlyph(f)) l.add(f) }
    for (a in 'A'..'Z') for (b in 'A'..'Z') {
        val f = String(Character.toChars(0x1F1E6 + (a - 'A'))) + String(Character.toChars(0x1F1E6 + (b - 'A')))
        if (p.hasGlyph(f)) l.add(f)
    }
    val i = l.indexOf("\uD83C\uDDEE\uD83C\uDDF3")
    if (i > 0) { l.removeAt(i); l.add(4, "\uD83C\uDDEE\uD83C\uDDF3") }
    l
}
val EMOJI: List<List<String>> by lazy {
    val p = Paint()
    listOf(GL.map { it.u }) + EMO_R.map { rs ->
        rs.flatMap { r -> r.mapNotNull { cp ->
            val b = String(Character.toChars(cp))
            val v = b + "\uFE0F"
            if (p.hasGlyph(v)) v else if (p.hasGlyph(b)) b else null
        } }
    } + listOf(FLAGS)
}

fun prefs(c: Context): SharedPreferences = c.getSharedPreferences("speedkey", Context.MODE_PRIVATE)

class Kk(val l: String, val w: Float = 1f, val a: String? = null)

class KView(ctx: Context, private val svc: KeyboardService) : View(ctx) {
    private val sp = prefs(ctx)
    private val d = resources.displayMetrics.density
    var sym = false
    var shift = 0
    var enter = "⏎"
    private var showPred = true
    var panel = 0
    private var items = listOf<String>()
    private var cat = 0
    private var scrollY = 0f
    private var bPad = 0
    private var rowH = 0f
    private var gridTop = 0f
    private var gridBot = 0f
    private val ip = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gpath = Path()
    private var cBg = 0; private var cKey = 0; private var cSp = 0; private var cTx = 0; private var cAc = 0
    private var numRow = true; private var hPct = 100; private var rad = 8; private var gap = 4
    private var hap = true; private var hms = 12; private var snd = false; private var prv = true
    private var swp = true; private var step = 14; private var lpMs = 300; private var rep = 45
    private var fs = 100; private var oneH = 0; private var hints = true
    private var slots = arrayOf("", "", "")
    private val cells = ArrayList<RectF>()
    private val keys = ArrayList<Kk>()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val hintP = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.RIGHT }
    private val sg = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val vib = ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    private val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val h = Handler(Looper.getMainLooper())
    private val n = 6
    private val pk = arrayOfNulls<Kk>(n)
    private val pc = IntArray(n)
    private val px = FloatArray(n)
    private val plast = FloatArray(n)
    private val pl = BooleanArray(n)
    private val psw = BooleanArray(n)
    private val ps = IntArray(n) { -1 }
    private val plY = FloatArray(n)
    private val pdY = FloatArray(n)
    private val lr = Array(n) { i -> Runnable { longPress(i) } }
    private val rr = Array(n) { i -> Runnable { rpt(i) } }
    private var stripH = 0f
    private var kl = 0f
    private var kw = 0f
    private var lastShift = 0L
    private val tmp = RectF()

    fun load() {
        val t = THEMES[sp.getInt("theme", 0).coerceIn(0, THEMES.size - 1)].second
        cBg = t[0].toInt(); cKey = t[1].toInt(); cSp = t[2].toInt(); cTx = t[3].toInt(); cAc = t[4].toInt()
        numRow = sp.getBoolean("numRow", true); hPct = sp.getInt("height", 100); rad = sp.getInt("radius", 8); gap = sp.getInt("gap", 4)
        hap = sp.getBoolean("haptic", true); hms = sp.getInt("hms", 12); snd = sp.getBoolean("sound", false); prv = sp.getBoolean("preview", true)
        swp = sp.getBoolean("swipe", true); step = sp.getInt("step", 14); lpMs = sp.getInt("lp", 300); rep = sp.getInt("rep", 45)
        fs = sp.getInt("font", 100); oneH = sp.getInt("oneH", 0); hints = sp.getBoolean("hints", true); showPred = sp.getBoolean("predict", true); bPad = sp.getInt("bPad", 0)
        requestLayout(); build(); invalidate()
    }

    fun setSlots(l: List<String>) {
        val s = arrayOf(l.getOrElse(1) { "" }, l.getOrElse(0) { "" }, l.getOrElse(2) { "" })
        if (!s.contentEquals(slots)) { slots = s; invalidate() }
    }

    fun applyShift(v: Int) { if (shift != v) { shift = v; invalidate() } }
    fun setPage(s: Boolean) { sym = s; panel = 0; build(); invalidate() }
    fun openPanel(p: Int) { panel = p; scrollY = 0f; refresh(); build(); invalidate() }
    fun refresh() { items = if (panel == 1) EMOJI[cat] else if (panel == 2) svc.clipList() else emptyList(); invalidate() }
    private fun contentH() = if (panel == 1) Math.ceil(items.size / 8.0).toFloat() * rowH else items.size * rowH

    private fun r(s: String, alts: String? = null) = s.mapIndexed { i, ch -> Kk(ch.toString(), 1f, alts?.get(i)?.toString()) }

    private fun rows(): List<List<Kk>> {
        if (panel != 0) return listOf(listOf(Kk("A", 1.5f), Kk("_", 5f), Kk("<", 1.5f), Kk("!", 1.5f)))
        val bottom = listOf(Kk("#", 1.3f), Kk("E"), Kk(","), Kk("_", 3.4f), Kk("."), Kk("C"), Kk("!", 1.4f))
        if (sym) return listOf(r("1234567890"), r("@#\$_&-+()/"), r("*\"':;!?%=") + Kk("<", 1.5f), bottom)
        val l = ArrayList<List<Kk>>()
        if (numRow) l.add(r("1234567890"))
        l.add(r("qwertyuiop", if (numRow) null else "1234567890"))
        l.add(listOf(Kk("", .5f)) + r("asdfghjkl", "@#\$%&-+()") + Kk("", .5f))
        l.add(listOf(Kk("^", 1.5f)) + r("zxcvbnm", "*\"':;!?") + Kk("<", 1.5f))
        l.add(bottom)
        return l
    }

    private fun build() {
        cells.clear(); keys.clear()
        if (width == 0) return
        val rs = rows()
        stripH = if (showPred) 40 * d else 0f
        val avail = height - stripH - bPad * d
        val rh = avail / (if (panel != 0) 5 else rs.size)
        val t0 = if (panel != 0) stripH + avail - rh else stripH
        rowH = rh; gridBot = t0; gridTop = stripH + (if (panel == 1) rh * .8f else 0f)
        kw = if (oneH != 0) width * .82f else width.toFloat()
        kl = if (oneH == 2) width - kw else 0f
        rs.forEachIndexed { ri, row ->
            var tot = 0f
            for (k in row) tot += k.w
            var x = kl
            for (k in row) {
                val w = kw * k.w / tot
                cells.add(RectF(x, t0 + ri * rh, x + w, t0 + (ri + 1) * rh)); keys.add(k); x += w
            }
        }
        tp.textSize = minOf(rh * .42f, kw / 10f * .62f) * fs / 100f
        hintP.textSize = tp.textSize * .4f
        sg.textSize = 16 * d
    }

    override fun onMeasure(w: Int, hh: Int) {
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val row = 50 * d * hPct / 100f * (if (land) .72f else 1f)
        setMeasuredDimension(MeasureSpec.getSize(w), ((if (showPred) 40 * d else 0f) + row * 5 + bPad * d).toInt())
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) = build()

    private fun bl(p: Paint, cy: Float) = cy - (p.ascent() + p.descent()) / 2f

    override fun onDraw(cv: Canvas) {
        cv.drawColor(cBg)
        if (showPred) {
            val w3 = width / 3f
            for (i in 0..2) {
                sg.color = cTx; sg.isFakeBoldText = i == 1
                cv.drawText(slots[i], w3 * i + w3 / 2, bl(sg, stripH / 2), sg)
                if (i > 0) { fill.color = cSp; cv.drawRect(w3 * i, stripH * .25f, w3 * i + 1, stripH * .75f, fill) }
            }
        }
        if (panel != 0) drawPanel(cv)
        val g = gap * d / 2
        val rd = rad * d
        val ts = tp.textSize
        for (i in cells.indices) {
            val k = keys[i]
            if (k.l.isEmpty()) continue
            val ce = cells[i]
            tmp.set(ce.left + g, ce.top + g, ce.right - g, ce.bottom - g)
            var down = false
            for (p in 0 until n) if (pk[p] === k) down = true
            val special = k.l == "^" || k.l == "<" || k.l == "#" || k.l == "A"
            fill.color = when {
                k.l == "!" || (k.l == "^" && shift > 0) -> cAc
                down -> if (special) cAc else cSp
                special -> cSp
                else -> cKey
            }
            cv.drawRoundRect(tmp, rd, rd, fill)
            val lab = when (k.l) {
                "^" -> if (shift == 2) "⇪" else "⇧"
                "<" -> "⌫"
                "!" -> enter
                "#" -> if (sym) "ABC" else "?123"
                "_" -> ""
                "A" -> "ABC"
                "E" -> "☺"
                "C" -> "📋"
                else -> if (shift > 0 && !sym) k.l.uppercase() else k.l
            }
            tp.color = if (k.l == "!" || (k.l == "^" && shift > 0)) cBg else cTx
            tp.textSize = if (special || k.l == "!") ts * .8f else ts
            cv.drawText(lab, tmp.centerX(), bl(tp, tmp.centerY()), tp)
            val a = k.a
            if (hints && a != null) { hintP.color = cTx and 0x99FFFFFF.toInt(); cv.drawText(a, tmp.right - 4 * d, tmp.top + hintP.textSize + 2 * d, hintP) }
        }
        tp.textSize = ts
        if (prv) for (p in 0 until n) {
            val k = pk[p] ?: continue
            if (pl[p] || k.l.length != 1 || "AEC^<#!_".contains(k.l) || pc[p] >= cells.size || keys[pc[p]] !== k) continue
            val ce = cells[pc[p]]
            val bw = ce.width() * 1.3f
            val bh = (ce.height()) * 1.15f
            val l = (ce.centerX() - bw / 2).coerceIn(0f, width - bw)
            val t = maxOf(0f, ce.top - bh - 4 * d)
            tmp.set(l, t, l + bw, t + bh)
            fill.color = cSp; cv.drawRoundRect(tmp, rd * 1.5f, rd * 1.5f, fill)
            tp.textSize = ts * 1.4f; tp.color = cTx
            cv.drawText(if (shift > 0 && !sym) k.l.uppercase() else k.l, tmp.centerX(), bl(tp, tmp.centerY()), tp)
            tp.textSize = ts
        }
    }

    private fun drawPanel(cv: Canvas) {
        val rh = rowH; val orig = tp.textSize
        if (panel == 1) {
            val tw = width / EMO_TABS.size.toFloat()
            for (i in EMO_TABS.indices) {
                if (i == cat) { fill.color = cSp; cv.drawRect(tw * i, stripH, tw * (i + 1), stripH + rh * .8f, fill) }
                tp.color = cTx; tp.textSize = rh * .45f
                cv.drawText(EMO_TABS[i], tw * i + tw / 2, bl(tp, stripH + rh * .4f), tp)
            }
        }
        cv.save(); cv.clipRect(0f, gridTop, width.toFloat(), gridBot)
        if (panel == 1) {
            val cw = width / 8f; tp.textSize = rh * .5f; tp.color = cTx
            for (i in items.indices) {
                val y = gridTop + (i / 8) * rh - scrollY
                if (y + rh < gridTop || y > gridBot) continue
                if (cat == 0 && i < GL.size) drawGl(cv, GL[i], (i % 8) * cw + cw / 2, y + rh / 2, rh * .36f)
                else cv.drawText(items[i], (i % 8) * cw + cw / 2, bl(tp, y + rh / 2), tp)
            }
        } else {
            ip.textSize = rh * .32f; ip.color = cTx
            if (items.isEmpty()) { sg.color = cTx; cv.drawText("Copy something, it shows here forever", width / 2f, bl(sg, gridTop + rh), sg) }
            for (i in items.indices) {
                val y = gridTop + i * rh - scrollY
                if (y + rh < gridTop || y > gridBot) continue
                tmp.set(6 * d, y + 2 * d, width - 6 * d, y + rh - 2 * d)
                fill.color = cKey; cv.drawRoundRect(tmp, 8 * d, 8 * d, fill)
                var t = items[i].replace('\n', ' ')
                if (t.length > 40) t = t.take(40) + "…"
                cv.drawText(t, 14 * d, bl(ip, y + rh / 2), ip)
                tp.textSize = rh * .4f; tp.color = cTx
                cv.drawText(if (svc.pinned(items[i])) "📌" else "📍", width * .76f, bl(tp, y + rh / 2), tp)
                cv.drawText("✕", width * .93f, bl(tp, y + rh / 2), tp)
            }
        }
        cv.restore(); tp.textSize = orig
    }

    private fun lite(c: Int): Int = android.graphics.Color.rgb(minOf(255, android.graphics.Color.red(c) + 90), minOf(255, android.graphics.Color.green(c) + 90), minOf(255, android.graphics.Color.blue(c) + 90))

    private fun heart(cv: Canvas, cx: Float, cy: Float, s: Float) {
        gpath.reset(); gpath.moveTo(cx, cy + s * .9f)
        gpath.cubicTo(cx - s * 1.4f, cy, cx - s * .9f, cy - s * 1.1f, cx, cy - s * .35f)
        gpath.cubicTo(cx + s * .9f, cy - s * 1.1f, cx + s * 1.4f, cy, cx, cy + s * .9f)
        gpath.close(); cv.drawPath(gpath, gp)
    }

    private fun drawGl(cv: Canvas, g: Gl, cx: Float, cy: Float, r: Float) {
        val dk = 0xFF4E342E.toInt()
        gp.style = Paint.Style.FILL
        if (g.kind == 1 || g.kind == 2) {
            gp.shader = RadialGradient(cx - r * .3f, cy - r * .4f, r * 1.5f, lite(g.a), g.a, Shader.TileMode.CLAMP)
            if (g.kind == 1) heart(cv, cx, cy, r * .8f) else {
                gpath.reset()
                for (i in 0 until 10) {
                    val rad = if (i % 2 == 0) r else r * .45f; val a = -Math.PI / 2 + i * Math.PI / 5
                    val x = (cx + rad * Math.cos(a)).toFloat(); val y = (cy + rad * Math.sin(a)).toFloat()
                    if (i == 0) gpath.moveTo(x, y) else gpath.lineTo(x, y)
                }
                gpath.close(); cv.drawPath(gpath, gp)
            }
            gp.shader = null; gp.color = 0x77FFFFFF; cv.drawOval(cx - r * .55f, cy - r * .7f, cx - r * .1f, cy - r * .35f, gp)
            return
        }
        val red = g.kind == 3
        gp.shader = RadialGradient(cx - r * .3f, cy - r * .4f, r * 1.4f, if (red) 0xFFFF8A80.toInt() else 0xFFFFE57F.toInt(), if (red) 0xFFD32F2F.toInt() else 0xFFFFA000.toInt(), Shader.TileMode.CLAMP)
        cv.drawCircle(cx, cy, r, gp); gp.shader = null
        gp.color = 0x66FFFFFF; cv.drawOval(cx - r * .6f, cy - r * .9f, cx + r * .25f, cy - r * .4f, gp)
        val ey = cy - r * .12f; val ex = r * .36f
        fun fillP(c: Int) { gp.style = Paint.Style.FILL; gp.color = c }
        fun strokeP() { gp.style = Paint.Style.STROKE; gp.strokeWidth = r * .09f; gp.strokeCap = Paint.Cap.ROUND; gp.color = dk }
        for (sg2 in intArrayOf(-1, 1)) {
            val x = cx + sg2 * ex
            when (g.a) {
                0, 7 -> { fillP(dk); cv.drawCircle(x, ey, r * .1f, gp); if (g.a == 7 && sg2 == -1) { fillP(0xFF4FC3F7.toInt()); cv.drawCircle(x - r * .05f, ey + r * .3f, r * .08f, gp) } }
                1 -> { strokeP(); cv.drawArc(x - r * .16f, ey - r * .12f, x + r * .16f, ey + r * .2f, 200f, 140f, false, gp) }
                2 -> { fillP(0xFFE53935.toInt()); heart(cv, x, ey, r * .17f) }
                4 -> { strokeP(); cv.drawLine(x - r * .14f, ey, x + r * .14f, ey, gp) }
                5 -> if (sg2 == -1) { fillP(dk); cv.drawCircle(x, ey, r * .1f, gp) } else { strokeP(); cv.drawLine(x - r * .14f, ey, x + r * .14f, ey, gp) }
                6 -> { fillP(0xFFFFFFFF.toInt()); cv.drawCircle(x, ey, r * .17f, gp); fillP(dk); cv.drawCircle(x, ey, r * .08f, gp) }
            }
            if (red) { strokeP(); cv.drawLine(x - sg2 * r * .2f, ey - r * .32f, x + sg2 * r * .2f, ey - r * .16f, gp) }
        }
        if (g.a == 3) { fillP(0xFF212121.toInt()); cv.drawRoundRect(cx - r * .68f, cy - r * .32f, cx - r * .06f, cy + r * .06f, r * .1f, r * .1f, gp); cv.drawRoundRect(cx + r * .06f, cy - r * .32f, cx + r * .68f, cy + r * .06f, r * .1f, r * .1f, gp) }
        val my = cy + r * .3f
        when (g.b) {
            0 -> { strokeP(); cv.drawArc(cx - r * .4f, my - r * .3f, cx + r * .4f, my + r * .3f, 20f, 140f, false, gp) }
            1 -> { fillP(dk); cv.drawArc(cx - r * .45f, my - r * .3f, cx + r * .45f, my + r * .4f, 0f, 180f, true, gp) }
            2 -> { strokeP(); cv.drawLine(cx - r * .3f, my + r * .1f, cx + r * .3f, my + r * .1f, gp) }
            3 -> { strokeP(); cv.drawArc(cx - r * .35f, my, cx + r * .35f, my + r * .6f, 200f, 140f, false, gp) }
            4 -> { fillP(dk); cv.drawCircle(cx, my + r * .15f, r * .16f, gp) }
            5 -> { fillP(dk); cv.drawArc(cx - r * .4f, my - r * .3f, cx + r * .4f, my + r * .3f, 0f, 180f, true, gp); fillP(0xFFFF6F91.toInt()); cv.drawOval(cx - r * .15f, my + r * .05f, cx + r * .15f, my + r * .42f, gp) }
            6 -> { fillP(0xFFE53935.toInt()); heart(cv, cx, my + r * .1f, r * .16f) }
        }
        gp.style = Paint.Style.FILL
    }

    private fun gridTap(x: Float, y: Float) {
        if (panel == 1 && y < gridTop) { cat = (x / (width / EMO_TABS.size.toFloat())).toInt().coerceIn(0, EMO_TABS.size - 1); scrollY = 0f; refresh(); return }
        val row = ((y - gridTop + scrollY) / rowH).toInt()
        if (panel == 1) {
            val i = row * 8 + (x / (width / 8f)).toInt().coerceIn(0, 7)
            if (i in items.indices) svc.type(items[i])
        } else if (row in items.indices) {
            val t = items[row]
            if (x > width * .86f) svc.clipDel(t) else if (x > width * .68f) svc.clipPin(t) else svc.paste(t)
            refresh()
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val i = e.actionIndex
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> down(e.getPointerId(i), e.getX(i), e.getY(i))
            MotionEvent.ACTION_MOVE -> for (j in 0 until e.pointerCount) move(e.getPointerId(j), e.getX(j), e.getY(j))
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> up(e.getPointerId(i), e.getY(i))
            MotionEvent.ACTION_CANCEL -> for (j in 0 until n) { h.removeCallbacks(lr[j]); h.removeCallbacks(rr[j]); pk[j] = null; ps[j] = -1 }
        }
        invalidate()
        return true
    }

    private fun down(id: Int, x: Float, y: Float) {
        if (id >= n) return
        px[id] = x; plast[id] = x; pl[id] = false; psw[id] = false; ps[id] = -1; pk[id] = null
        if (y < stripH) { ps[id] = (x / width * 3).toInt().coerceIn(0, 2); return }
        if (panel != 0 && y >= stripH && y < gridBot) { ps[id] = 8; plY[id] = y; pdY[id] = y; return }
        if (oneH != 0 && (x < kl || x > kl + kw)) { ps[id] = 9; return }
        var hit = -1
        for (i in cells.indices) if (cells[i].contains(x, y)) { hit = i; break }
        if (hit < 0) return
        val k = keys[hit]
        if (k.l.isEmpty()) return
        pk[id] = k; pc[id] = hit; fb(k)
        when (k.l) {
            "^" -> if (!sym) {
                val now = SystemClock.uptimeMillis()
                shift = if (shift == 2) 0 else if (shift == 1 && now - lastShift < 350) 2 else if (shift == 1) 0 else 1
                lastShift = now
            }
            "#" -> { sym = !sym; build() }
            "A" -> { panel = 0; build() }
            "E" -> openPanel(1)
            "C" -> openPanel(2)
            "<" -> { svc.del(); h.postDelayed(rr[id], 350) }
            "!" -> svc.enter()
            "_" -> h.postDelayed(lr[id], 500)
            else -> {
                val t = if (shift > 0 && !sym) k.l.uppercase() else k.l
                if (shift == 1) shift = 0
                svc.type(t)
                if (k.a != null) h.postDelayed(lr[id], lpMs.toLong())
            }
        }
    }

    private fun move(id: Int, x: Float, y: Float) {
        if (id >= n) return
        if (ps[id] == 8) {
            if (Math.abs(y - pdY[id]) > 10 * d) psw[id] = true
            if (psw[id]) scrollY = (scrollY - (y - plY[id])).coerceIn(0f, maxOf(0f, contentH() - (gridBot - gridTop)))
            plY[id] = y; return
        }
        val k = pk[id] ?: return
        if (k.l == "_" && swp) {
            val st = step * d
            while (Math.abs(x - plast[id]) >= st) {
                val dir = if (x > plast[id]) 1 else -1
                plast[id] += dir * st; psw[id] = true; h.removeCallbacks(lr[id]); svc.move(dir)
            }
        } else if (Math.abs(x - px[id]) > 14 * d) h.removeCallbacks(lr[id])
    }

    private fun up(id: Int, y: Float) {
        if (id >= n) return
        h.removeCallbacks(lr[id]); h.removeCallbacks(rr[id])
        if (ps[id] == 8) { if (!psw[id]) gridTap(px[id], pdY[id]); ps[id] = -1; return }
        if (ps[id] in 0..2 && y < stripH && slots[ps[id]].isNotEmpty()) svc.pick(slots[ps[id]])
        if (ps[id] == 9) sp.edit().putInt("oneH", 0).apply()
        if (pk[id]?.l == "_" && !psw[id] && !pl[id]) svc.space()
        pk[id] = null; ps[id] = -1
    }

    private fun longPress(i: Int) {
        val k = pk[i] ?: return
        if (psw[i]) return
        pl[i] = true
        if (k.l == "_") svc.picker() else k.a?.let { svc.alt(it) }
        invalidate()
    }

    private fun rpt(i: Int) {
        if (pk[i]?.l == "<") { svc.del(); fb(null); h.postDelayed(rr[i], rep.toLong()) }
    }

    private fun fb(k: Kk?) {
        if (hap) vib?.vibrate(VibrationEffect.createOneShot(hms.toLong(), VibrationEffect.DEFAULT_AMPLITUDE))
        if (snd) am.playSoundEffect(if (k?.l == "_") AudioManager.FX_KEYPRESS_SPACEBAR else AudioManager.FX_KEYPRESS_STANDARD, .6f)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        for (j in 0 until n) { h.removeCallbacks(lr[j]); h.removeCallbacks(rr[j]) }
    }
}

class KeyboardService : InputMethodService() {
    private var v: KView? = null
    private val word = StringBuilder()
    private var prev = ""
    private val learned = HashMap<String, Int>()
    private val next = HashMap<String, String>()
    private var base: List<String> = emptyList()
    private var sugOn = true
    private var act = 0
    private var lastSp = 0L
    private var autoSp = false
    private var dirty = true
    private var seenReset = 0
    private val sp by lazy { prefs(this) }
    private val lp by lazy { getSharedPreferences("learn", Context.MODE_PRIVATE) }
    val clips = ArrayList<String>()
    private val pins = HashSet<String>()
    private val cp by lazy { getSharedPreferences("clips", Context.MODE_PRIVATE) }
    private val lis = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> dirty = true }

    override fun onCreate() {
        super.onCreate()
        base = WORDS.split(' ')
        Thread { EMOJI.size }.start()
        lp.getString("w", "")!!.split('\n').forEach { val p = it.split('='); if (p.size == 2) learned[p[0]] = p[1].toIntOrNull() ?: 1 }
        lp.getString("n", "")!!.split('\n').forEach { val p = it.split('>'); if (p.size == 2) next[p[0]] = p[1] }
        cp.getString("c", "")!!.split('\u0001').filter { it.isNotEmpty() }.forEach { clips.add(it) }
        cp.getString("p", "")!!.split('\u0001').filter { it.isNotEmpty() }.forEach { pins.add(it) }
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.addPrimaryClipChangedListener {
            val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()
            if (!t.isNullOrBlank() && sp.getBoolean("clip", true)) { clips.remove(t); clips.add(0, t); saveClips() }
        }
        seenReset = sp.getInt("learnReset", 0)
        sp.registerOnSharedPreferenceChangeListener(lis)
    }

    override fun onDestroy() { sp.unregisterOnSharedPreferenceChangeListener(lis); super.onDestroy() }
    override fun onEvaluateFullscreenMode() = false

    override fun onCreateInputView(): View {
        val k = KView(this, this)
        k.load(); v = k; dirty = false
        return k
    }

    override fun onStartInputView(info: EditorInfo, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        val k = v ?: return
        if (dirty) { k.load(); dirty = false }
        if (sp.getInt("learnReset", 0) != seenReset) { seenReset = sp.getInt("learnReset", 0); learned.clear(); next.clear() }
        val cls = info.inputType and InputType.TYPE_MASK_CLASS
        val va = info.inputType and InputType.TYPE_MASK_VARIATION
        val txt = cls == InputType.TYPE_CLASS_TEXT
        sugOn = txt && va != InputType.TYPE_TEXT_VARIATION_PASSWORD && va != InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD &&
            va != InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD && va != InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS && va != InputType.TYPE_TEXT_VARIATION_URI
        val a = info.imeOptions and EditorInfo.IME_MASK_ACTION
        act = if ((info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0 || a == EditorInfo.IME_ACTION_NONE || a == EditorInfo.IME_ACTION_UNSPECIFIED) 0 else a
        k.enter = when (act) { EditorInfo.IME_ACTION_SEARCH -> "🔍"; EditorInfo.IME_ACTION_SEND -> "➤"; EditorInfo.IME_ACTION_GO -> "➜"; EditorInfo.IME_ACTION_NEXT -> "→"; EditorInfo.IME_ACTION_DONE -> "✓"; else -> "⏎" }
        word.setLength(0); prev = ""
        k.setPage(!txt)
        autoCap(); sugs()
    }

    override fun onFinishInput() {
        super.onFinishInput()
        if (learned.size > 3000) learned.entries.removeAll { it.value < 2 }
        lp.edit().putString("w", learned.entries.joinToString("\n") { it.key + "=" + it.value })
            .putString("n", next.entries.joinToString("\n") { it.key + ">" + it.value }).apply()
    }

    private fun cap(s: String, like: String) = if (like.isNotEmpty() && like[0].isUpperCase()) s.replaceFirstChar { it.uppercase() } else s

    private fun lev1(a: String, b: String): Boolean {
        if (a == b) return true
        if (Math.abs(a.length - b.length) > 1) return false
        var i = 0
        while (i < a.length && i < b.length && a[i] == b[i]) i++
        return a.substring(i + (if (a.length >= b.length) 1 else 0)) == b.substring(i + (if (b.length >= a.length) 1 else 0))
    }

    private fun sugs() {
        val k = v ?: return
        if (!sugOn || !sp.getBoolean("predict", true)) { k.setSlots(emptyList()); return }
        val raw = word.toString(); val w = raw.lowercase()
        val sc = HashMap<String, Int>()
        if (w.isEmpty()) {
            if (sp.getBoolean("nextWord", true)) next[prev]?.let { sc[it] = 900 }
            if (prev.isEmpty()) { sc["I"] = 3; sc["The"] = 2; sc["Hi"] = 1 }
        } else {
            base.forEachIndexed { i, b -> if (b.startsWith(w)) sc[b] = 1000 - i }
            if (sp.getBoolean("learn", true)) for ((b, c) in learned) if (b.startsWith(w)) sc[b] = maxOf(sc[b] ?: 0, 500 + c * 50)
            if (sc.size < 3 && w.length >= 3 && sp.getBoolean("typo", true)) base.forEachIndexed { i, b -> if (b[0] == w[0] && lev1(w, b)) sc.putIfAbsent(b, 400 - i) }
        }
        val out = sc.entries.sortedByDescending { it.value }.take(3).map { if (w.isEmpty() && k.shift > 0) it.key.replaceFirstChar { c -> c.uppercase() } else cap(it.key, raw) }
        k.setSlots(out)
    }

    private fun endWord() {
        if (word.isEmpty()) return
        val w = word.toString().lowercase()
        if (w.length > 1 && sugOn && sp.getBoolean("learn", true)) { learned[w] = (learned[w] ?: 0) + 1; if (prev.isNotEmpty()) next[prev] = w }
        prev = w; word.setLength(0)
    }

    private fun resync() {
        val b = currentInputConnection?.getTextBeforeCursor(24, 0)?.toString() ?: ""
        var i = b.length
        while (i > 0 && b[i - 1].isLetterOrDigit()) i--
        word.setLength(0); word.append(b, i, b.length)
    }

    private fun autoCap() {
        val k = v ?: return
        if (!sugOn || !sp.getBoolean("autoCap", true) || k.sym || k.shift == 2) return
        val ic = currentInputConnection ?: return
        val t = (currentInputEditorInfo?.inputType ?: 0) or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        k.applyShift(if (ic.getCursorCapsMode(t) != 0) 1 else 0)
    }

    fun type(t: String) {
        val ic = currentInputConnection ?: return
        if (autoSp && t.length == 1 && ".,!?;:".contains(t)) ic.deleteSurroundingText(1, 0)
        autoSp = false
        ic.commitText(t, 1)
        if (t[0].isLetterOrDigit() || t == "'") word.append(t) else { endWord(); if (".!?".contains(t)) prev = "" }
        sugs()
    }

    fun alt(a: String) {
        currentInputConnection?.deleteSurroundingText(1, 0)
        if (word.isNotEmpty()) word.setLength(word.length - 1)
        type(a)
    }

    fun del() {
        autoSp = false
        sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        if (word.isNotEmpty()) word.setLength(word.length - 1) else resync()
        sugs()
    }

    fun space() {
        val ic = currentInputConnection ?: return
        val now = SystemClock.uptimeMillis()
        if (sp.getBoolean("dblSpace", true) && word.isEmpty() && now - lastSp < 450) {
            val b = ic.getTextBeforeCursor(2, 0)
            if (b != null && b.length == 2 && b[1] == ' ' && b[0].isLetterOrDigit()) {
                ic.deleteSurroundingText(1, 0); ic.commitText(". ", 1)
                lastSp = 0; prev = ""; autoCap(); sugs(); return
            }
        }
        endWord(); ic.commitText(" ", 1); autoSp = false; lastSp = now; autoCap(); sugs()
    }

    fun enter() {
        endWord(); prev = ""; autoSp = false
        if (act != 0) currentInputConnection?.performEditorAction(act) else sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        autoCap(); sugs()
    }

    fun pick(t: String) {
        val ic = currentInputConnection ?: return
        if (word.isNotEmpty()) ic.deleteSurroundingText(word.length, 0)
        val s = sp.getBoolean("autoSpace", true)
        ic.commitText(if (s) "$t " else t, 1)
        word.setLength(0); word.append(t); endWord(); autoSp = s
        autoCap(); sugs()
    }

    fun move(dir: Int) {
        sendDownUpKeyEvents(if (dir < 0) KeyEvent.KEYCODE_DPAD_LEFT else KeyEvent.KEYCODE_DPAD_RIGHT)
        resync(); sugs()
    }

    private fun saveClips() { cp.edit().putString("c", clips.joinToString("\u0001")).putString("p", pins.joinToString("\u0001")).apply() }
    fun clipList(): List<String> = clips.filter { it in pins } + clips.filter { it !in pins }
    fun pinned(t: String) = t in pins
    fun clipDel(t: String) { clips.remove(t); pins.remove(t); saveClips() }
    fun clipPin(t: String) { if (!pins.add(t)) pins.remove(t); saveClips() }
    fun paste(t: String) { currentInputConnection?.commitText(t, 1); word.setLength(0); prev = ""; sugs() }

    fun picker() { (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() }
}
