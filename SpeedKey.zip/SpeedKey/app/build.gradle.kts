import java.net.URL
import java.util.zip.ZipInputStream

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.jackie.speedkey"
    compileSdk = 34
    defaultConfig { applicationId = "com.jackie.speedkey"; minSdk = 26; targetSdk = 34; versionCode = 1; versionName = "1.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.core:core-ktx:1.13.1")
}

// Downloads Twemoji (iPhone-like emoji pictures) at build time. If the download fails, the keyboard falls back to normal system emoji.
val emojiOut = layout.buildDirectory.dir("generated/emoji/assets")
val fetchEmoji by tasks.registering {
    outputs.dir(emojiOut)
    doLast {
        val dir = emojiOut.get().asFile
        val marker = File(dir, "emoji/.done")
        if (marker.exists()) return@doLast
        try {
            File(dir, "emoji").mkdirs()
            val conn = URL("https://github.com/jdecked/twemoji/archive/refs/heads/main.zip").openConnection()
            conn.connectTimeout = 20000
            conn.readTimeout = 120000
            ZipInputStream(conn.getInputStream().buffered()).use { z ->
                var e = z.nextEntry
                while (e != null) {
                    val n = e.name
                    if (!e.isDirectory && n.contains("/assets/72x72/") && n.endsWith(".png")) {
                        File(dir, "emoji/" + n.substringAfterLast('/')).outputStream().use { o -> z.copyTo(o) }
                    }
                    e = z.nextEntry
                }
            }
            marker.writeText("ok")
        } catch (ex: Exception) {
            println("Emoji download skipped: " + ex.message)
        }
    }
}
android.sourceSets.getByName("main").assets.srcDir(emojiOut)
tasks.configureEach {
    if (name.startsWith("merge") && name.endsWith("Assets")) dependsOn(fetchEmoji)
}
